package com.paycore.audit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.WebApplicationContextRunner;

import static org.assertj.core.api.Assertions.*;

/**
 * Section 2: Tests the starter's conditional behavior.
 * Verifies beans exist/don't exist based on properties.
 */
class AuditAutoConfigurationTest {

    private final WebApplicationContextRunner runner = new WebApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(AuditAutoConfiguration.class));

    @Test
    @DisplayName("Default: AuditLogger registered when no property set (matchIfMissing=true)")
    void shouldRegisterAuditLoggerByDefault() {
        runner.run(ctx -> assertThat(ctx).hasSingleBean(AuditLogger.class));
    }

    @Test
    @DisplayName("Opt-out: No beans when paycore.audit.enabled=false")
    void shouldNotRegisterWhenDisabled() {
        runner
            .withPropertyValues("paycore.audit.enabled=false")
            .run(ctx -> {
                assertThat(ctx).doesNotHaveBean(AuditLogger.class);
                assertThat(ctx).doesNotHaveBean(AuditInterceptor.class);
            });
    }

    @Test
    @DisplayName("Custom destination property binds correctly")
    void shouldBindCustomDestination() {
        runner
            .withPropertyValues("paycore.audit.destination=kafka://paycore-audit-events")
            .run(ctx -> {
                AuditLogger logger = ctx.getBean(AuditLogger.class);
                assertThat(logger.getProperties().getDestination())
                    .isEqualTo("kafka://paycore-audit-events");
            });
    }

    @Test
    @DisplayName("@ConditionalOnMissingBean: Custom AuditLogger replaces auto-configured one")
    void shouldAllowCustomAuditLogger() {
        runner
            .withUserConfiguration(CustomAuditConfig.class)
            .run(ctx -> {
                assertThat(ctx).hasSingleBean(AuditLogger.class);
                assertThat(ctx.getBean(AuditLogger.class))
                    .isInstanceOf(CustomAuditConfig.CustomLogger.class);
            });
    }

    static class CustomAuditConfig {
        @org.springframework.context.annotation.Bean
        public AuditLogger auditLogger(AuditProperties props) {
            return new CustomLogger(props);
        }
        static class CustomLogger extends AuditLogger {
            CustomLogger(AuditProperties p) { super(p); }
        }
    }
}
