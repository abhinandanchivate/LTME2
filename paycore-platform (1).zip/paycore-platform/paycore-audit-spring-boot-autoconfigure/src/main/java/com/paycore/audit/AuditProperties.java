package com.paycore.audit;

import org.springframework.boot.context.properties.ConfigurationProperties;
import java.util.List;

/**
 * Section 2: Custom Starters & @ConditionalOnProperty
 * Type-safe binding for all paycore.audit.* properties.
 */
@ConfigurationProperties(prefix = "paycore.audit")
public class AuditProperties {

    /** Enable or disable audit logging entirely */
    private boolean enabled = true;

    /** Kafka topic or log file destination */
    private String destination = "audit-log";

    /** HTTP methods to audit */
    private List<String> methods = List.of("POST", "PUT", "DELETE", "PATCH");

    /** Whether to include request body in audit records */
    private boolean includeBody = false;

    /** Max body size to capture in bytes */
    private int maxBodyBytes = 4096;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public List<String> getMethods() { return methods; }
    public void setMethods(List<String> methods) { this.methods = methods; }
    public boolean isIncludeBody() { return includeBody; }
    public void setIncludeBody(boolean includeBody) { this.includeBody = includeBody; }
    public int getMaxBodyBytes() { return maxBodyBytes; }
    public void setMaxBodyBytes(int maxBodyBytes) { this.maxBodyBytes = maxBodyBytes; }
}
