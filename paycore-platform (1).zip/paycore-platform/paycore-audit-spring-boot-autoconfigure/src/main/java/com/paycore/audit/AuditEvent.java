package com.paycore.audit;

import java.time.Instant;

/**
 * Immutable audit record captured per HTTP request.
 */
public record AuditEvent(
        String method,
        String uri,
        int statusCode,
        String destination,
        Instant timestamp,
        String transactionId
) {
    public AuditEvent(String method, String uri, int statusCode, String destination) {
        this(method, uri, statusCode, destination, Instant.now(),
             "TXN-" + System.nanoTime());
    }
}
