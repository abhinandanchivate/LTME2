package com.paycore.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Section 2 & 3: Core audit logging service.
 * Decorated with @ConditionalOnMissingBean in AuditAutoConfiguration
 * so consumers can replace this with a high-throughput version (Section 3 demo).
 */
public class AuditLogger {

    private static final Logger log = LoggerFactory.getLogger(AuditLogger.class);
    private final AuditProperties properties;

    public AuditLogger(AuditProperties properties) {
        this.properties = properties;
    }

    public void log(AuditEvent event) {
        log.info("[AUDIT] {} {} → {} | dest={} | txn={}",
                event.method(), event.uri(), event.statusCode(),
                event.destination(), event.transactionId());
    }

    public AuditProperties getProperties() {
        return properties;
    }
}
