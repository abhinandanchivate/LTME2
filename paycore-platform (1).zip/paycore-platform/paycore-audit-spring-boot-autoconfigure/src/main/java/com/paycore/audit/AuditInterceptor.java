package com.paycore.audit;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * Section 2: Web interceptor — registered only when inside a web application.
 * @ConditionalOnWebApplication in AuditAutoConfiguration guards this bean.
 */
public class AuditInterceptor implements HandlerInterceptor {

    private final AuditLogger auditLogger;
    private final AuditProperties properties;

    public AuditInterceptor(AuditLogger auditLogger, AuditProperties properties) {
        this.auditLogger = auditLogger;
        this.properties = properties;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response,
                                Object handler, Exception ex) {
        String method = request.getMethod();
        if (properties.getMethods().contains(method)) {
            auditLogger.log(new AuditEvent(method, request.getRequestURI(),
                    response.getStatus(), properties.getDestination()));
        }
    }
}
