package com.example.greeting;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;

import static org.assertj.core.api.Assertions.*;

/**
 * Section 1: Verifies the lifecycle conditions behave as designed.
 * Uses ApplicationContextRunner (no server started) for fast unit-style testing.
 */
class GreetingAutoConfigurationTest {

    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(GreetingAutoConfiguration.class));

    @Test
    @DisplayName("Phase ④: Bean instantiated when property is absent (matchIfMissing=true)")
    void shouldLoadServiceWhenEnabled() {
        runner.run(ctx -> {
            assertThat(ctx).hasSingleBean(GreetingService.class);
            assertThat(ctx.getBean(GreetingService.class).sayHello()).isEqualTo("Hello");
        });
    }

    @Test
    @DisplayName("Phase ②: Condition fails → bean excluded when disabled")
    void shouldNotLoadServiceWhenDisabled() {
        runner
            .withPropertyValues("custom.greeting.enabled=false")
            .run(ctx -> assertThat(ctx).doesNotHaveBean(GreetingService.class));
    }

    @Test
    @DisplayName("Phase ②: Spanish language property wires correctly")
    void shouldUseSpanishWhenConfigured() {
        runner
            .withPropertyValues("custom.greeting.language=es")
            .run(ctx -> {
                assertThat(ctx).hasSingleBean(GreetingService.class);
                assertThat(ctx.getBean(GreetingService.class).sayHello()).isEqualTo("Hola");
            });
    }

    @Test
    @DisplayName("Phase ③: @ConditionalOnMissingBean — user-defined bean overrides auto-config")
    void shouldAllowUserOverride() {
        runner
            .withUserConfiguration(CustomGreetingConfig.class)
            .run(ctx -> {
                assertThat(ctx).hasSingleBean(GreetingService.class);
                // Should be the custom one, not the auto-configured one
                assertThat(ctx.getBean(GreetingService.class).sayHello())
                    .isEqualTo("Bonjour");
            });
    }

    // Inner config simulating a user overriding the bean
    static class CustomGreetingConfig {
        @Bean
        public GreetingService greetingService() {
            return new GreetingService("fr") {
                @Override public String sayHello() { return "Bonjour"; }
            };
        }
    }
}
