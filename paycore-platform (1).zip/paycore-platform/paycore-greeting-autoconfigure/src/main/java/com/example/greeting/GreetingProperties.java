package com.example.greeting;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Section 1: Auto-Configuration Internals
 * Binds external config to a type-safe object via prefix "custom.greeting"
 */
@ConfigurationProperties(prefix = "custom.greeting")
public class GreetingProperties {

    /** Enable or disable the greeting service entirely */
    private boolean enabled = true;

    /** The language code (e.g., 'en', 'es') */
    private String language = "en";

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public String getLanguage() { return language; }
    public void setLanguage(String language) { this.language = language; }
}
