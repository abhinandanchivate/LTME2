package com.example.greeting;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Section 1: Auto-Configuration Lifecycle Demo
 *
 * PHASE ①  DISCOVERY   → Listed in AutoConfiguration.imports
 * PHASE ②  CONDITION   → @ConditionalOnProperty: only if custom.greeting.enabled=true
 * PHASE ③  REGISTRATION → @Bean methods registered as BeanDefinitions
 * PHASE ④  REFRESH     → Beans instantiated at ApplicationContext.refresh()
 */
@AutoConfiguration
@ConditionalOnProperty(prefix = "custom.greeting", name = "enabled", matchIfMissing = true)
@EnableConfigurationProperties(GreetingProperties.class)
public class GreetingAutoConfiguration {

    /**
     * @ConditionalOnMissingBean = override hook.
     * Consumers can declare their own GreetingService @Bean to replace this default.
     */
    @Bean
    @ConditionalOnMissingBean
    GreetingService greetingService(GreetingProperties properties) {
        System.out.println("[GreetingAutoConfig] Registering GreetingService with language="
                + properties.getLanguage());
        return new GreetingService(properties.getLanguage());
    }
}
