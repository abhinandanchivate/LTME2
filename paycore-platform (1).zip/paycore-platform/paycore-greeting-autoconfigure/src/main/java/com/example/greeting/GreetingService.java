package com.example.greeting;

/**
 * Section 1: The actual service — registered as a bean only when conditions pass.
 * Condition flow: @ConditionalOnProperty → @ConditionalOnMissingBean → this bean
 */
public class GreetingService {

    private final String language;

    public GreetingService(String language) {
        this.language = language;
    }

    public String sayHello() {
        return "es".equals(language) ? "Hola" : "Hello";
    }

    public String getLanguage() {
        return language;
    }
}
