package com.paycore;

import com.paycore.fraud.FraudAnalyzer;
import com.paycore.payment.PaymentProcessingService;
import com.paycore.payment.PaymentRequest;
import com.paycore.payment.PaymentResult;
import com.paycore.security.SecurityFilterChain;
import com.paycore.tenant.TenantService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.*;

@SpringBootTest
class PayCoreIntegrationTest {

    @Autowired ApplicationContext ctx;
    @Autowired PaymentProcessingService paymentService;
    @Autowired ObjectProvider<FraudAnalyzer> fraudAnalyzerProvider;

    // ── Section 3 ─────────────────────────────────────────────────────────────
    @Test
    @DisplayName("§3 — SecurityFilterChain registered (ordering works)")
    void section3_securityBeanPresent() {
        assertThat(ctx.containsBean("securityFilterChain")).isTrue();
        assertThat(ctx.getBean(SecurityFilterChain.class).getName())
                .isEqualTo("DEFAULT_SECURITY_CHAIN");
    }

    // ── Section 4 ─────────────────────────────────────────────────────────────
    @Test
    @DisplayName("§4 — Read path returns result (REPLICA routing)")
    void section4_replicaRouting() {
        String history = paymentService.getPaymentHistory("TEST-ACCOUNT");
        assertThat(history).contains("TEST-ACCOUNT").contains("REPLICA");
    }

    // ── Section 5 ─────────────────────────────────────────────────────────────
    @Test
    @DisplayName("§5 — ObjectProvider gives a NEW FraudAnalyzer each call")
    void section5_prototypeNewInstance() {
        FraudAnalyzer a1 = fraudAnalyzerProvider.getObject();
        FraudAnalyzer a2 = fraudAnalyzerProvider.getObject();
        assertThat(a1).isNotSameAs(a2);
    }

    @Test
    @DisplayName("§5 — Normal payment ($500) is approved")
    void section5_normalApproved() {
        PaymentResult result = paymentService.processPayment(
                new PaymentRequest("ACC-001", new BigDecimal("500"), "US", 2));
        // Use .isEqualTo() on boolean primitive — .isTrue()/.isFalse() requires Boolean wrapper
        assertThat(result.approved()).isEqualTo(true);
    }

    @Test
    @DisplayName("§5 — High-value payment ($500k) is rejected")
    void section5_suspiciousRejected() {
        PaymentResult result = paymentService.processPayment(
                new PaymentRequest("ACC-002", new BigDecimal("500000"), "NG", 80));
        assertThat(result.approved()).isEqualTo(false);
        assertThat(result.reason()).contains("High-value");
    }

    @Test
    @DisplayName("§5 — State isolation: large payment doesn't leak into next analysis")
    void section5_stateIsolation() {
        paymentService.processPayment(
                new PaymentRequest("ACC-001", new BigDecimal("999999"), "NG", 100));
        PaymentResult r2 = paymentService.processPayment(
                new PaymentRequest("ACC-002", new BigDecimal("100"), "US", 1));
        assertThat(r2.approved()).isEqualTo(true);
    }

    // ── Section 6 ─────────────────────────────────────────────────────────────
    @Test
    @DisplayName("§6 — ACME_BANK tenant bean registered from clients.yaml")
    void section6_acmeBankRegistered() {
        TenantService ts = ctx.getBean("tenantService_acme_bank", TenantService.class);
        assertThat(ts.getTenantId()).isEqualTo("ACME_BANK");
        assertThat(ts.getSettlementCurrency()).isEqualTo("USD");
        assertThat(ts.getDailyLimit()).isEqualTo(10_000_000L);
    }

    @Test
    @DisplayName("§6 — GLOBAL_BANK tenant bean registered")
    void section6_globalBankRegistered() {
        TenantService ts = ctx.getBean("tenantService_global_bank", TenantService.class);
        assertThat(ts.getTenantId()).isEqualTo("GLOBAL_BANK");
        assertThat(ts.getSettlementCurrency()).isEqualTo("EUR");
    }

    @Test
    @DisplayName("§6 — All 3 tenants from clients.yaml are present")
    void section6_allThreeTenantsPresent() {
        String[] beans = ctx.getBeanNamesForType(TenantService.class);
        assertThat(beans).hasSize(3);
        assertThat(ctx.containsBean("tenantService_apex_fintech")).isTrue();
    }
}
