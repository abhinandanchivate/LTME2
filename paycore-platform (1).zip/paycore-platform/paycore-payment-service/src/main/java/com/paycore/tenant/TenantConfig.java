package com.paycore.tenant;

/**
 * Section 6: Value object representing one bank tenant loaded from clients.yaml
 */
public record TenantConfig(String id, String settlementCurrency, long dailyLimit) {}
