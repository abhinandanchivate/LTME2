package com.paycore.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Section 3: Auto-Configuration Ordering Demo
 *
 * Uses @Configuration (not @AutoConfiguration) because this class lives inside
 * the main application module and is picked up by @SpringBootApplication's
 * component scan — not via META-INF/spring/AutoConfiguration.imports discovery.
 *
 * @AutoConfiguration is only for library jars registered in AutoConfiguration.imports.
 * Using it on a component-scanned class is misleading; @Configuration is correct here.
 *
 * The ordering demo (Section 3) shows that AuditAutoConfiguration (a real starter)
 * declares @AutoConfigureAfter + @ConditionalOnBean to safely depend on this bean.
 */
@Configuration
public class SecurityAutoConfiguration {

    @Bean
    SecurityFilterChain securityFilterChain() {
        System.out.println("[SecurityAutoConfig] Registering SecurityFilterChain");
        return new SecurityFilterChain("DEFAULT_SECURITY_CHAIN");
    }
}
