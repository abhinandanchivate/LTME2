package com.paycore.tenant;

/**
 * Section 6: Per-tenant service registered programmatically via
 * BeanDefinitionRegistryPostProcessor — not via @Bean methods.
 * Bean name pattern: tenantService_{tenantId_lowercase}
 */
public class TenantService {

    private final String tenantId;
    private final String settlementCurrency;
    private final long dailyLimit;

    public TenantService(String tenantId, String settlementCurrency, long dailyLimit) {
        this.tenantId = tenantId;
        this.settlementCurrency = settlementCurrency;
        this.dailyLimit = dailyLimit;
        System.out.println("[TenantService] Instantiated for tenant=" + tenantId
                + " currency=" + settlementCurrency
                + " limit=" + dailyLimit);
    }

    public String getTenantId() { return tenantId; }
    public String getSettlementCurrency() { return settlementCurrency; }
    public long getDailyLimit() { return dailyLimit; }

    @Override
    public String toString() {
        return "TenantService[id=" + tenantId
                + ", currency=" + settlementCurrency
                + ", dailyLimit=" + dailyLimit + "]";
    }
}
