package com.paycore.fraud;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Section 5: Scope Mixing — Prototype in Singleton
 *
 * @Scope(PROTOTYPE): Each call to ObjectProvider.getObject() returns a NEW instance.
 * This guarantees per-payment state isolation.
 *
 * WHY NOT SINGLETON: A singleton FraudAnalyzer would share signal state across
 * concurrent requests → race conditions → incorrect fraud decisions.
 *
 * WHY NOT @Autowired directly into singleton: Spring injects ONCE at construction →
 * prototype behavior is lost → effectively becomes a singleton.
 *
 * SOLUTION: Use ObjectProvider<FraudAnalyzer> in the singleton service (see PaymentProcessingService).
 */
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class FraudAnalyzer {

    private final List<String> signals = new ArrayList<>();
    private final String instanceId = "FraudAnalyzer@" + Integer.toHexString(System.identityHashCode(this));

    public FraudAnalyzer() {
        System.out.println("[FraudAnalyzer] NEW instance created: " + instanceId);
    }

    public void addSignal(String signal) {
        signals.add(signal);
        System.out.println("[" + instanceId + "] Signal added: " + signal
                + " (total=" + signals.size() + ")");
    }

    public FraudResult evaluate() {
        System.out.println("[" + instanceId + "] Evaluating " + signals.size() + " signals");
        boolean suspicious = signals.stream()
                .anyMatch(s -> s.startsWith("amount:") && extractAmount(s) > 100_000);
        return suspicious
                ? new FraudResult(true, "High-value transaction flagged: " + signals)
                : new FraudResult(false, null);
    }

    public String getInstanceId() { return instanceId; }

    private double extractAmount(String signal) {
        try {
            return Double.parseDouble(signal.substring("amount:".length()).trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
