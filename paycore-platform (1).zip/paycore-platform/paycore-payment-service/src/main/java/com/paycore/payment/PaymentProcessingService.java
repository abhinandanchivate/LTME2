package com.paycore.payment;

import com.paycore.datasource.DataSourceContext;
import com.paycore.fraud.FraudAnalyzer;
import com.paycore.fraud.FraudResult;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Section 4 & 5 Demo Service
 *
 * Section 4: Demonstrates datasource routing via DataSourceContext ThreadLocal.
 * Section 5: Uses ObjectProvider<FraudAnalyzer> to get a NEW prototype instance
 *             per payment — guaranteeing state isolation between concurrent requests.
 */
@Service
public class PaymentProcessingService {

    private final ObjectProvider<FraudAnalyzer> fraudAnalyzerProvider;
    private final AtomicInteger processedCount = new AtomicInteger(0);

    public PaymentProcessingService(ObjectProvider<FraudAnalyzer> fraudAnalyzerProvider) {
        this.fraudAnalyzerProvider = fraudAnalyzerProvider;
    }

    /** Section 4: Write path → PRIMARY. Section 5: fresh FraudAnalyzer per call. */
    public PaymentResult processPayment(PaymentRequest request) {
        DataSourceContext.usePrimary();
        try {
            System.out.println("\n[PaymentService] Payment #" + processedCount.incrementAndGet()
                    + " account=" + request.accountId()
                    + " amount=" + request.amount()
                    + " ds=" + DataSourceContext.getCurrent());

            // Section 5: fresh prototype instance — no shared state across requests
            FraudAnalyzer analyzer = fraudAnalyzerProvider.getObject();
            analyzer.addSignal("amount:" + request.amount().toPlainString());
            analyzer.addSignal("country:" + request.destinationCountry());
            analyzer.addSignal("velocity:" + request.recentTransactionCount());

            FraudResult result = analyzer.evaluate();
            if (result.isSuspicious()) {
                System.out.println("[PaymentService] ❌ REJECTED: " + result.reason());
                return PaymentResult.rejected(result.reason());
            }
            System.out.println("[PaymentService] ✅ APPROVED");
            return PaymentResult.success();
        } finally {
            DataSourceContext.clear(); // prevent thread pool pollution
        }
    }

    /** Section 4: Read path → REPLICA datasource. */
    public String getPaymentHistory(String accountId) {
        DataSourceContext.useReplica();
        try {
            System.out.println("[PaymentService] History for " + accountId
                    + " → ds=" + DataSourceContext.getCurrent());
            return "Payment history for " + accountId + " (served from REPLICA)";
        } finally {
            DataSourceContext.clear();
        }
    }
}
