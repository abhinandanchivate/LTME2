package com.paycore.security;

/**
 * Section 3: Simplified stand-in for Spring Security's SecurityFilterChain.
 * Used to demonstrate @AutoConfigureAfter + @ConditionalOnBean ordering.
 */
public class SecurityFilterChain {
    private final String name;
    public SecurityFilterChain(String name) { this.name = name; }
    public String getName() { return name; }
    @Override public String toString() { return "SecurityFilterChain[" + name + "]"; }
}
