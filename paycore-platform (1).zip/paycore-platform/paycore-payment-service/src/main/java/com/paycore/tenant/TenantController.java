package com.paycore.tenant;

import org.springframework.context.ApplicationContext;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Section 6: REST endpoint to inspect dynamically registered tenant beans.
 * Demonstrates that beans created via BeanDefinitionRegistryPostProcessor
 * are fully available in the ApplicationContext at runtime.
 *
 * Try: GET /tenants
 */
@RestController
@RequestMapping("/tenants")
public class TenantController {

    private final ApplicationContext context;

    public TenantController(ApplicationContext context) {
        this.context = context;
    }

    @GetMapping
    public List<Map<String, Object>> listTenants() {
        return Arrays.stream(context.getBeanNamesForType(TenantService.class))
                .map(name -> {
                    TenantService ts = context.getBean(name, TenantService.class);
                    return Map.<String, Object>of(
                            "beanName", name,
                            "tenantId", ts.getTenantId(),
                            "currency", ts.getSettlementCurrency(),
                            "dailyLimit", ts.getDailyLimit()
                    );
                })
                .collect(Collectors.toList());
    }
}
