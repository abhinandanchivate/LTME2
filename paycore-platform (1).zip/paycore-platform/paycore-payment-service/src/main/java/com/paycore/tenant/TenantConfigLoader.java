package com.paycore.tenant;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * Section 6: Early-stage config reader.
 *
 * IMPORTANT: This runs during BeanDefinitionRegistryPostProcessor phase,
 * BEFORE the ApplicationContext is ready. Therefore:
 *   - Cannot use @Value or @Autowired
 *   - Cannot use Spring's Environment (not yet wired)
 *   - Must use raw classpath resource reading
 */
@SuppressWarnings("unchecked")
public class TenantConfigLoader {

    private static final Logger log = LoggerFactory.getLogger(TenantConfigLoader.class);

    public static List<TenantConfig> load() {
        try {
            ObjectMapper yaml = new ObjectMapper(new YAMLFactory());
            InputStream stream = TenantConfigLoader.class.getResourceAsStream("/clients.yaml");

            if (stream == null) {
                log.warn("[TenantConfigLoader] clients.yaml not found — no tenants registered");
                return List.of();
            }

            Map<String, Object> root = yaml.readValue(stream, Map.class);
            List<Map<String, Object>> tenantMaps =
                    (List<Map<String, Object>>) root.get("tenants");

            List<TenantConfig> configs = tenantMaps.stream()
                    .map(m -> new TenantConfig(
                            (String) m.get("id"),
                            (String) m.get("settlementCurrency"),
                            ((Number) m.get("dailyLimit")).longValue()
                    ))
                    .toList();

            log.info("[TenantConfigLoader] Loaded {} tenant(s) from clients.yaml", configs.size());
            return configs;

        } catch (Exception e) {
            throw new IllegalStateException("Failed to load tenant configuration", e);
        }
    }
}
