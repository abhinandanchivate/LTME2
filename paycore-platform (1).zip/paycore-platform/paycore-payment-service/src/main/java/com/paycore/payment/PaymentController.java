package com.paycore.payment;

import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * REST controller exposing payment endpoints.
 * Uses PaymentResult.success() (renamed from .approved() to avoid record accessor clash).
 */
@RestController
@RequestMapping("/payments")
public class PaymentController {

    private final PaymentProcessingService paymentService;

    public PaymentController(PaymentProcessingService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping
    public PaymentResult processPayment(@RequestBody PaymentRequest request) {
        return paymentService.processPayment(request);
    }

    @GetMapping("/{accountId}/history")
    public String getHistory(@PathVariable String accountId) {
        return paymentService.getPaymentHistory(accountId);
    }

    @GetMapping("/demo/suspicious")
    public PaymentResult demoSuspicious() {
        return paymentService.processPayment(
            new PaymentRequest("ACME-001", new BigDecimal("500000"), "NG", 50));
    }

    @GetMapping("/demo/normal")
    public PaymentResult demoNormal() {
        return paymentService.processPayment(
            new PaymentRequest("ACME-002", new BigDecimal("250"), "US", 2));
    }
}
