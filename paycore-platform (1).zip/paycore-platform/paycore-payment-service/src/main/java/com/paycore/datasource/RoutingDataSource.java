package com.paycore.datasource;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * Section 4: Transaction-Aware Routing DataSource
 *
 * Lifecycle of a routing decision:
 *   1. @Transactional opens → Spring calls DataSource.getConnection()
 *   2. RoutingDataSource.getConnection() → delegates here
 *   3. determineCurrentLookupKey() called ← routing decision HERE
 *   4. TransactionSynchronizationManager queried for readOnly flag
 *   5. Selects PRIMARY or REPLICA connection pool
 *
 * This is SAFE because determineCurrentLookupKey() is called AFTER @Transactional
 * has set the readOnly flag — eliminating the aspect-ordering timing flaw.
 */
public class RoutingDataSource extends AbstractRoutingDataSource {

    @Override
    protected Object determineCurrentLookupKey() {
        if (TransactionSynchronizationManager.isActualTransactionActive()) {
            boolean readOnly = TransactionSynchronizationManager.isCurrentTransactionReadOnly();
            String selected = readOnly ? "REPLICA" : "PRIMARY";
            System.out.println("[RoutingDataSource] Active transaction, readOnly="
                    + readOnly + " → routing to " + selected);
            return readOnly
                    ? DataSourceContext.DataSourceType.REPLICA
                    : DataSourceContext.DataSourceType.PRIMARY;
        }
        // Non-transactional: use explicit ThreadLocal, defaulting to PRIMARY
        DataSourceContext.DataSourceType type = DataSourceContext.getCurrent();
        System.out.println("[RoutingDataSource] Non-transactional → routing to " + type);
        return type;
    }
}
