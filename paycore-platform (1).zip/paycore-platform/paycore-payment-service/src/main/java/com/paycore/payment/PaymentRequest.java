package com.paycore.payment;

import java.math.BigDecimal;

public record PaymentRequest(
        String accountId,
        BigDecimal amount,
        String destinationCountry,
        int recentTransactionCount
) {}
