package com.paycore.payment;

/**
 * Immutable result of a payment processing attempt.
 *
 * NOTE: Factory methods renamed to isApproved()/isRejected() to avoid clash
 * with the record's auto-generated accessor approved(). Java records generate
 * an accessor method with the exact same name as each component — a static
 * method named approved() would conflict with the boolean accessor approved().
 */
public record PaymentResult(boolean approved, String reason) {

    public static PaymentResult success() {
        return new PaymentResult(true, "Approved");
    }

    public static PaymentResult rejected(String reason) {
        return new PaymentResult(false, reason);
    }
}
