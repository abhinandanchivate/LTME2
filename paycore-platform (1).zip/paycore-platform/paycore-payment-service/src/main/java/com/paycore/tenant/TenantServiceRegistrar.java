package com.paycore.tenant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Section 6: BeanDefinitionRegistryPostProcessor — Dynamic Bean Registration
 *
 * Reads clients.yaml at startup and registers one TenantService singleton bean
 * per tenant entry — no @Bean method required per tenant.
 *
 * NOTE ON BeanRegistrar vs BeanDefinitionRegistryPostProcessor:
 *   BeanRegistrar is a Spring Framework 7 AOT-compilation API (for GraalVM native images).
 *   It is NOT available in the runtime classpath of spring-boot-starter-classic — it lives
 *   in spring-context-aot which is only activated during the AOT build phase (mvn package -Pnative).
 *   For standard JVM runtime bean registration, BeanDefinitionRegistryPostProcessor
 *   remains the correct approach in both Spring Boot 3.x and 4.x.
 *
 * LIFECYCLE:
 *   1. postProcessBeanDefinitionRegistry() → runs BEFORE any @Bean is instantiated
 *   2. postProcessBeanFactory()            → modify existing definitions (unused here)
 *   3. Bean instantiation / @PostConstruct
 *   4. ApplicationReadyEvent
 *
 * RULES:
 *   - Do NOT @Autowired anything here — other beans don't exist yet
 *   - Use constructor args only for TenantService
 *   - Startup only — changing clients.yaml requires a restart
 */
@Component
public class TenantServiceRegistrar implements BeanDefinitionRegistryPostProcessor, Ordered {

    private static final Logger log = LoggerFactory.getLogger(TenantServiceRegistrar.class);

    @Override
    public int getOrder() {
        return Ordered.HIGHEST_PRECEDENCE;
    }

    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry)
            throws BeansException {

        log.info("[TenantServiceRegistrar] Starting dynamic tenant bean registration...");
        List<TenantConfig> tenants = TenantConfigLoader.load();

        if (tenants.isEmpty()) {
            log.warn("[TenantServiceRegistrar] No tenants found in clients.yaml");
            return;
        }

        for (TenantConfig tenant : tenants) {
            String beanName = "tenantService_" + tenant.id().toLowerCase();

            BeanDefinition beanDef = BeanDefinitionBuilder
                    .genericBeanDefinition(TenantService.class)
                    .addConstructorArgValue(tenant.id())
                    .addConstructorArgValue(tenant.settlementCurrency())
                    .addConstructorArgValue(tenant.dailyLimit())
                    .setScope(BeanDefinition.SCOPE_SINGLETON)  // correct API (not setSingleton)
                    .getBeanDefinition();

            registry.registerBeanDefinition(beanName, beanDef);
            log.info("[TenantServiceRegistrar] ✅ Registered '{}' tenant={} currency={} limit={}",
                    beanName, tenant.id(), tenant.settlementCurrency(), tenant.dailyLimit());
        }

        log.info("[TenantServiceRegistrar] Done — {} tenant beans registered.", tenants.size());
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
            throws BeansException {
        // No modifications needed
    }
}
