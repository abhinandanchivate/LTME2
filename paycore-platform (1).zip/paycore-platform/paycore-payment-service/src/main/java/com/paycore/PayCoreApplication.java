package com.paycore;

import com.paycore.payment.PaymentProcessingService;
import com.paycore.payment.PaymentRequest;
import com.paycore.payment.PaymentResult;
import com.paycore.tenant.TenantService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import java.math.BigDecimal;
import java.util.Arrays;

/**
 * PayCore Platform — Spring Boot 4.0.5
 *
 * SPRING BOOT 4 CHANGES APPLIED IN THIS PROJECT:
 * ┌──────────────────────────────────────────────────────────────────────┐
 * │ Version:   3.3.6 → 4.0.5                                            │
 * │ Java min:  21 (unchanged — we were already on 21)                    │
 * │ Framework: Spring Framework 7 (via spring-boot-starter-parent)       │
 * │ Web:       spring-boot-starter-classic (full classpath bridge)       │
 * │ Tests:     spring-boot-starter-test-classic (JUnit 5 → 6 bridge)    │
 * │ @Bean:     package-private (public @Bean removed — Boot 4 enforces) │
 * │ Records:   factory method renamed success() — accessor clash fixed   │
 * └──────────────────────────────────────────────────────────────────────┘
 *
 * REST endpoints:
 *   GET  /payments/demo/normal      → fraud analysis APPROVED  (§5)
 *   GET  /payments/demo/suspicious  → fraud analysis REJECTED  (§5)
 *   GET  /payments/{id}/history     → REPLICA datasource       (§4)
 *   GET  /tenants                   → dynamic tenant beans     (§6)
 */
@SpringBootApplication
public class PayCoreApplication {

    private static final Logger log = LoggerFactory.getLogger(PayCoreApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(PayCoreApplication.class, args);
    }

    @Bean
    ApplicationRunner startupDemo(ApplicationContext ctx,
                                   PaymentProcessingService paymentService) {
        return args -> {
            log.info("\n{}", "=".repeat(72));
            log.info("  PAYCORE PLATFORM — Spring Boot 4.0.5 Startup Demo");
            log.info("{}", "=".repeat(72));

            // ── Section 3: Ordering ──────────────────────────────────────────
            log.info("\n[§3] Auto-Configuration Ordering:");
            log.info("  SecurityFilterChain present: {}", ctx.containsBean("securityFilterChain"));

            // ── Section 4: Datasource Routing ────────────────────────────────
            log.info("\n[§4] Datasource Routing:");
            String history = paymentService.getPaymentHistory("ACME-001");
            log.info("  Read result: {}", history);

            // ── Section 5: Prototype Scope Isolation ─────────────────────────
            log.info("\n[§5] Prototype-in-Singleton (ObjectProvider):");
            PaymentResult normal = paymentService.processPayment(
                    new PaymentRequest("ACC-001", new BigDecimal("500"), "US", 3));
            log.info("  Normal  ($500):     approved={}", normal.approved());

            PaymentResult suspicious = paymentService.processPayment(
                    new PaymentRequest("ACC-002", new BigDecimal("250000"), "NG", 55));
            log.info("  Suspicious ($250k): approved={} reason={}", suspicious.approved(), suspicious.reason());

            // ── Section 6: Dynamic Tenant Beans ──────────────────────────────
            log.info("\n[§6] BeanDefinitionRegistryPostProcessor — Dynamic Tenant Beans:");
            String[] tenantBeans = ctx.getBeanNamesForType(TenantService.class);
            log.info("  {} tenant bean(s) from clients.yaml:", tenantBeans.length);
            Arrays.stream(tenantBeans).forEach(name -> {
                TenantService ts = ctx.getBean(name, TenantService.class);
                log.info("  → {} : {}", name, ts);
            });

            log.info("\n{}", "=".repeat(72));
            log.info("  Server → http://localhost:8080");
            log.info("  GET /payments/demo/normal | /payments/demo/suspicious | /tenants");
            log.info("{}", "=".repeat(72));
        };
    }
}
