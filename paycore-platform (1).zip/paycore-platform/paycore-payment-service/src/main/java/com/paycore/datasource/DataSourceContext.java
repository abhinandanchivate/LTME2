package com.paycore.datasource;

/**
 * Section 4: Multi-Datasource & Runtime Routing
 * ThreadLocal holder for explicit routing key (used for non-transactional code).
 * CRITICAL: Always call clear() in a finally block to prevent thread pool pollution.
 */
public final class DataSourceContext {

    public enum DataSourceType { PRIMARY, REPLICA }

    private static final ThreadLocal<DataSourceType> CONTEXT =
            ThreadLocal.withInitial(() -> DataSourceType.PRIMARY);

    private DataSourceContext() {}

    public static void usePrimary() { CONTEXT.set(DataSourceType.PRIMARY); }
    public static void useReplica()  { CONTEXT.set(DataSourceType.REPLICA); }
    public static DataSourceType getCurrent() { return CONTEXT.get(); }

    /** CRITICAL: Always call this in a finally block to prevent thread pool pollution */
    public static void clear() { CONTEXT.remove(); }
}
