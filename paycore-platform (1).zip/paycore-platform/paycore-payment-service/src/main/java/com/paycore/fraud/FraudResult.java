package com.paycore.fraud;

/**
 * Section 5: Immutable result of fraud analysis for one payment.
 */
public record FraudResult(boolean isSuspicious, String reason) {}
