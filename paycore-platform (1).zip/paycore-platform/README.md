# PayCore Platform — Spring Boot 4.0.5

Multi-module Spring Boot project demonstrating all 6 concepts from
**Day 1: Auto-Configuration & Runtime Customization**, upgraded to Spring Boot 4.0.5.

---

## Spring Boot 4 Changes in This Project

| Area | Boot 3.x (before) | Boot 4.x (now) |
|---|---|---|
| **Version** | `3.3.6` | `4.0.5` |
| **Java minimum** | 17 | 21 (we were already on 21 ✅) |
| **Spring Framework** | 6.x | 7.x |
| **Section 6 API** | `BeanDefinitionRegistryPostProcessor` | `BeanRegistrar` (AOT-safe) |
| **Web starter** | `spring-boot-starter-web` | `spring-boot-starter-web-classic` (bridge) |
| **Test starter** | `spring-boot-starter-test` | `spring-boot-starter-test-classic` (JUnit 5→6 bridge) |
| **Starters** | Monolithic | Modular (classic starters bridge old classpath) |

### Why `-classic` starters?
Spring Boot 4 modularizes its starters into smaller focused jars. During migration,
`spring-boot-starter-web-classic` and `spring-boot-starter-test-classic` provide
the same classpath as Boot 3.x starters — so **zero Java source changes** are needed
for web and test code. Migrate to the native Boot 4 starters when ready.

### Section 6 — BeanRegistrar (the biggest API change)
```java
// Boot 3.x — imperative, not AOT-safe
@Component
public class TenantServiceRegistrar implements BeanDefinitionRegistryPostProcessor {
    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) { ... }
}

// Boot 4.x — AOT-friendly, GraalVM native image compatible
@Component
public class TenantServiceRegistrar implements BeanRegistrar {
    @Override
    public void register(BeanDefinitionRegistry registry, Environment env) { ... }
}
```
`BeanRegistrar` receives `Environment` directly (no more raw YAML file parsing workaround),
and its `register()` method is called during both AOT compilation and runtime — making it
compatible with GraalVM native images out of the box.

---

## Prerequisites

- **Java 21+** (Boot 4 minimum)
- **Maven 3.9+**

## Build & Run

```bash
# Build all 4 modules
mvn clean install

# Run the main app (starts on http://localhost:8080)
cd paycore-payment-service
mvn spring-boot:run
```

## Live Demo Endpoints

```bash
# Section 5: Prototype FraudAnalyzer — each call gets a fresh instance
curl http://localhost:8080/payments/demo/normal        # → {"approved":true,"reason":"Approved"}
curl http://localhost:8080/payments/demo/suspicious    # → {"approved":false,"reason":"High-value..."}

# Section 4: Read path → REPLICA datasource routing
curl http://localhost:8080/payments/ACC-001/history

# Section 6: BeanRegistrar — lists all dynamically registered tenant beans
curl http://localhost:8080/tenants
```

## Run Tests

```bash
# All modules
mvn test

# Individual module
mvn test -pl paycore-greeting-autoconfigure   # Section 1 — 4 lifecycle tests
mvn test -pl paycore-audit-spring-boot-autoconfigure  # Section 2 — 4 conditional tests
mvn test -pl paycore-payment-service          # Sections 3-6 — 8 integration tests
```

---

## Project Structure

```
paycore-platform/
├── pom.xml                                    ← Root (Spring Boot 4.0.5 parent)
│
├── paycore-greeting-autoconfigure/            ← SECTION 1: Auto-Config Lifecycle
│   └── src/main/java/com/example/greeting/
│       ├── GreetingProperties.java            @ConfigurationProperties
│       ├── GreetingService.java               The conditionally registered bean
│       └── GreetingAutoConfiguration.java     4-phase lifecycle annotated
│
├── paycore-audit-spring-boot-autoconfigure/   ← SECTION 2: Custom Starter (behavior)
│   └── src/main/java/com/paycore/audit/
│       ├── AuditProperties.java
│       ├── AuditAutoConfiguration.java        @ConditionalOnClass + @ConditionalOnProperty
│       ├── AuditLogger.java                   @ConditionalOnMissingBean hook
│       └── AuditInterceptor.java              @ConditionalOnWebApplication
│
├── paycore-audit-spring-boot-starter/         ← SECTION 2: Custom Starter (thin wrapper)
│   └── pom.xml                               No @Configuration — just dependency mgmt
│
└── paycore-payment-service/                   ← SECTIONS 3–6: Main runnable app
    └── src/main/java/com/paycore/
        ├── security/
        │   └── SecurityAutoConfiguration.java  SECTION 3: loads first (ordering demo)
        ├── datasource/
        │   ├── RoutingDataSource.java          SECTION 4: determineCurrentLookupKey()
        │   ├── DataSourceContext.java          ThreadLocal PRIMARY/REPLICA
        │   └── DataSourceConfig.java           Wires H2 primary + replica into router
        ├── fraud/
        │   └── FraudAnalyzer.java             SECTION 5: @Scope(PROTOTYPE)
        ├── payment/
        │   └── PaymentProcessingService.java   SECTION 5: ObjectProvider<FraudAnalyzer>
        └── tenant/
            ├── TenantServiceRegistrar.java     SECTION 6: BeanRegistrar (Boot 4 API ✨)
            ├── TenantConfigLoader.java         Reads clients.yaml at registration time
            └── TenantController.java           GET /tenants
```

## Section Quick Reference

| # | Concept | Key Files | Demo |
|---|---------|-----------|------|
| 1 | Auto-Config Lifecycle | `GreetingAutoConfiguration.java` | `mvn test -pl paycore-greeting-autoconfigure` |
| 2 | Custom Starter | `AuditAutoConfiguration.java` | `mvn test -pl paycore-audit-spring-boot-autoconfigure` |
| 3 | Ordering | `SecurityAutoConfiguration.java` | Check startup log for SecurityFilterChain |
| 4 | Datasource Routing | `RoutingDataSource.java` | `GET /payments/ACC-1/history` |
| 5 | Prototype-in-Singleton | `FraudAnalyzer.java` + `ObjectProvider` | `GET /payments/demo/suspicious` |
| 6 | BeanRegistrar (Boot 4) | `TenantServiceRegistrar.java` | `GET /tenants` |

## Add a Tenant Without Code (Section 6 Demo)

Edit `src/main/resources/clients.yaml`:
```yaml
tenants:
  - id: MY_NEW_BANK     # ← add this block
    settlementCurrency: SGD
    dailyLimit: 5000000
```
Restart → `GET /tenants` returns 4 tenants. No code change. No recompile.
This works identically with the new `BeanRegistrar` API as it did with
`BeanDefinitionRegistryPostProcessor` — the interface changed, the behaviour didn't.
