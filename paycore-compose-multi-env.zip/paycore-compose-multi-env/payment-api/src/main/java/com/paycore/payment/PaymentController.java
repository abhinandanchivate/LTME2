package com.paycore.payment;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class PaymentController {

    private final KafkaTemplate<String, String> kafkaTemplate;

    @Value("${spring.profiles.active:local}")
    private String activeProfile;

    @Value("${paycore.audit.log-dir:/var/log/paycore/audit}")
    private String auditLogDir;

    public PaymentController(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    @GetMapping("/info")
    public Map<String, String> info() {
        return Map.of(
                "service", "payment-api",
                "activeProfile", activeProfile,
                "auditLogDir", auditLogDir
        );
    }

    @PostMapping("/payments")
    public ResponseEntity<PaymentResponse> createPayment(@RequestBody PaymentRequest request) {
        PaymentResponse response = PaymentResponse.accepted(request);
        kafkaTemplate.send("payment-events", response.paymentId(), response.toString());
        return ResponseEntity.accepted().body(response);
    }
}
