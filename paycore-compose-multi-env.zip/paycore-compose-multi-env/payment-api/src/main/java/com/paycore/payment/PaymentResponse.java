package com.paycore.payment;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

public record PaymentResponse(
        String paymentId,
        String status,
        BigDecimal amount,
        String currency,
        String channel,
        Instant createdAt
) {
    public static PaymentResponse accepted(PaymentRequest request) {
        return new PaymentResponse(
                "PAY-" + UUID.randomUUID(),
                "ACCEPTED",
                request.amount(),
                request.currency(),
                request.channel(),
                Instant.now()
        );
    }
}
