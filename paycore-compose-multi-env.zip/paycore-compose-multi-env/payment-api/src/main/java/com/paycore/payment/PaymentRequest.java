package com.paycore.payment;

import java.math.BigDecimal;

public record PaymentRequest(
        String fromAccount,
        String toAccount,
        BigDecimal amount,
        String currency,
        String channel
) {}
