INSERT INTO payment_transaction
(payment_id, from_account, to_account, amount, currency, channel, status)
VALUES
('PAY-SEED-001', 'ACC1001', 'ACC2001', 1000.00, 'INR', 'NEFT', 'ACCEPTED')
ON CONFLICT (payment_id) DO NOTHING;
