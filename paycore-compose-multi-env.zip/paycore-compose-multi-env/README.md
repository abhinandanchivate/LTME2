# PayCore Docker Compose Multi-Service + Multi-Environment Lab

This project is based on the PayCore Docker Compose section from the attached DevOps Containers/Kubernetes theory guide.

## Services

| Service | Technology | Purpose | Host URL |
|---|---|---|---|
| payment-api | Spring Boot 3 + Java 17 | Payment REST API | http://localhost:8080 or env-specific port |
| postgres | PostgreSQL 15 | Payment transaction DB | internal only |
| kafka | Confluent Kafka KRaft | Payment event streaming | internal only |
| kafka-ui | Provectus Kafka UI | Kafka topic visibility | http://localhost:8090 or env-specific port |

## Folder structure

```text
paycore-compose-multi-env/
├── docker-compose.yml
├── env/
│   ├── .env.dev
│   ├── .env.staging
│   └── .env.prod.example
├── config/
│   ├── application-dev.yml
│   ├── application-staging.yml
│   └── application-prod.yml
├── scripts/db/init/
│   ├── 01-schema.sql
│   └── 02-seed.sql
└── payment-api/
    ├── Dockerfile
    ├── pom.xml
    └── src/main/...
```

## Run dev environment

```bash
docker compose --env-file env/.env.dev up -d --build
```

Test:

```bash
curl http://localhost:8080/actuator/health
curl http://localhost:8080/api/info
curl -X POST http://localhost:8080/api/payments \
  -H "Content-Type: application/json" \
  -d '{"fromAccount":"ACC1001","toAccount":"ACC2001","amount":1500,"currency":"INR","channel":"NEFT"}'
```

Kafka UI:

```text
http://localhost:8090
```

## Run staging environment

```bash
docker compose --env-file env/.env.staging up -d --build
```

Staging uses different ports:

```bash
curl http://localhost:8180/actuator/health
curl http://localhost:8180/api/info
```

Kafka UI:

```text
http://localhost:8190
```

## Run production-like example

Copy the example file first:

```bash
cp env/.env.prod.example env/.env.prod
```

Edit secrets in `env/.env.prod`, then run:

```bash
docker compose --env-file env/.env.prod up -d --build
```

For real production, do not keep secrets in `.env` files. Inject them from a vault, CI/CD secret manager, Docker secrets, or Kubernetes Secrets.

## Useful commands

```bash
# Check status
docker compose --env-file env/.env.dev ps

# View all logs
docker compose --env-file env/.env.dev logs -f

# View one service log
docker compose --env-file env/.env.dev logs -f payment-api

# Stop but preserve volumes
docker compose --env-file env/.env.dev stop

# Remove containers but preserve volumes
docker compose --env-file env/.env.dev down

# Remove containers and volumes - destroys DB/Kafka/audit data
docker compose --env-file env/.env.dev down -v
```

## Key learning points

1. Multiple services are declared in one Compose file.
2. Environment-specific values are externalized using `--env-file`.
3. PostgreSQL, Kafka, and audit logs use named volumes.
4. `payment-api` waits for PostgreSQL and Kafka health checks before starting.
5. Internal service discovery uses Compose service names: `postgres:5432` and `kafka:9092`.
6. Only API and Kafka UI ports are exposed to the host.
7. Secrets are not hardcoded in the Compose file.
