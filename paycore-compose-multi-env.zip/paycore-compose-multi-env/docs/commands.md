# Command Cheat Sheet

## Dev

```bash
docker compose --env-file env/.env.dev up -d --build
docker compose --env-file env/.env.dev logs -f payment-api
docker compose --env-file env/.env.dev down
```

## Staging

```bash
docker compose --env-file env/.env.staging up -d --build
docker compose --env-file env/.env.staging logs -f payment-api
docker compose --env-file env/.env.staging down
```

## Inspect networking

```bash
docker compose --env-file env/.env.dev exec payment-api sh
wget -qO- http://postgres:5432
```

## Inspect volumes

```bash
docker volume ls | grep paycore
docker volume inspect paycore-dev-postgres-data
```
