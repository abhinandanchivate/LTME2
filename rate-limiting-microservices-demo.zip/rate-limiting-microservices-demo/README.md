# Rate Limiting in Microservices - Complete Spring Boot Demo

This ZIP contains a runnable banking-style microservices example for teaching rate limiting end to end.

## Modules

```text
rate-limiting-microservices-demo/
├── api-gateway/          # Spring Cloud Gateway + Redis distributed rate limiting
├── payment-service/      # Payment API + local Resilience4j rate limiter
├── customer-service/     # Simple downstream API behind gateway
├── scripts/              # curl-based load tests
├── postman/              # Postman collection
├── docs/architecture.md  # Mermaid diagram and production notes
└── docker-compose.yml
```

## Concepts Covered

| Topic | Example |
|---|---|
| API Gateway rate limiting | Blocks excessive traffic before it reaches services |
| Distributed limit | Redis stores counters shared across gateway pods |
| Local service limit | Payment service protects expensive logic even if gateway is bypassed |
| Per-user limit | `X-User-Id` based rate-limit key |
| Per-tenant limit | `X-Tenant-Id` included in Redis key |
| Per-device/IP fallback | Uses `X-Device-Id`, then remote IP |
| Plan-based limits | `FREE`, `SILVER`, `GOLD`, `INTERNAL` |
| 429 handling | Returns HTTP `429 Too Many Requests` and `Retry-After` |
| Observability | Response headers show limit, remaining quota, window |
| Gateway built-in limiter | Spring Cloud Gateway `RequestRateLimiter` token-bucket config |
| Custom limiter | Explicit Redis fixed-window filter for training clarity |

## Rate Limit Rules in This Demo

Custom gateway limiter:

| Plan | Allowed Requests | Window |
|---|---:|---:|
| FREE | 5 | 1 minute |
| SILVER | 15 | 1 minute |
| GOLD | 30 | 1 minute |
| INTERNAL | 200 | 1 minute |

Payment service local limiter:

| Endpoint | Limit | Scope |
|---|---:|---|
| `POST /payments` | 3 requests / 10 seconds | Per service pod/JVM |

## Run with Docker Compose

```bash
docker compose up --build
```

Services:

| Service | URL |
|---|---|
| API Gateway | `http://localhost:8080` |
| Payment Service | `http://localhost:8081` |
| Customer Service | `http://localhost:8082` |
| Redis | `localhost:6379` |

## Test 1: FREE Plan Gateway Limit

```bash
./scripts/test-free-plan-limit.sh
```

Expected behavior:

- First few requests succeed.
- Once the FREE quota is exhausted, gateway returns `HTTP/1.1 429 Too Many Requests`.
- Response includes headers like:

```text
X-RateLimit-Plan: FREE
X-RateLimit-Limit: 5
X-RateLimit-Remaining: 0
Retry-After: 60
```

## Test 2: GOLD Plan Higher Limit

```bash
./scripts/test-gold-plan-limit.sh
```

Expected behavior:

- GOLD plan gets more requests than FREE.
- This demonstrates plan-aware throttling.

## Test 3: Bypass Gateway and Hit Service Directly

```bash
./scripts/test-service-direct-bypass.sh
```

Expected behavior:

- Payment service allows only 3 payment creations per 10 seconds per pod.
- This proves why service-level self-protection is still needed.

## Test 4: Inspect Redis Keys

```bash
./scripts/redis-checks.sh
```

You should see keys similar to:

```text
rl:gateway:bank-a:FREE:user:user-101
rl:gateway:bank-a:GOLD:user:user-202
```

## Manual cURL Example

```bash
curl -i -X POST http://localhost:8080/payments \
  -H 'Content-Type: application/json' \
  -H 'X-Tenant-Id: bank-a' \
  -H 'X-User-Id: user-101' \
  -H 'X-Plan: FREE' \
  -H 'X-Correlation-Id: demo-001' \
  -d '{
    "fromAccount":"ACC1001",
    "toAccount":"ACC2001",
    "amount":1000,
    "currency":"INR",
    "idempotencyKey":"idem-001"
  }'
```

## Key Design Decisions

### 1. Why Rate Limit at API Gateway?

Because the gateway is the first controlled backend entry point. It prevents abusive or accidental high traffic before downstream services, databases, PSP calls, ledger systems, and Kafka producers are affected.

### 2. Why Redis?

In Kubernetes, there may be many gateway pods. Local counters would give each pod a separate quota. Redis gives a shared counter so the limit is global across gateway replicas.

### 3. Why Service-Level Limiter Also?

Gateway limits protect normal traffic. Service limits protect against:

- internal callers bypassing the gateway
- misconfigured gateway routes
- sudden expensive endpoint spikes
- batch jobs or partner integrations
- downstream pressure from PSP, database, or ledger systems

### 4. Fixed Window vs Token Bucket

| Algorithm | Good For | Risk |
|---|---|---|
| Fixed window | Simple quotas like 100/minute | Boundary burst at minute edge |
| Sliding window | More accurate rolling quota | More storage/compute |
| Token bucket | Allows healthy bursts | Needs careful replenish/burst config |
| Leaky bucket | Smooth outgoing traffic | Can add latency |

This demo includes:

- custom fixed-window limiter for readability
- Spring Cloud Gateway RedisRateLimiter token bucket for production-style gateway throttling

## HTTP Status Code Strategy

| Situation | Status |
|---|---:|
| Rate limit exceeded | `429 Too Many Requests` |
| Service unavailable | `503 Service Unavailable` |
| Invalid request | `400 Bad Request` |
| Unauthorized | `401 Unauthorized` |
| Forbidden by quota plan | `403 Forbidden` or `429`, depending on business rule |

## Production Enhancements

1. Store rate-limit plans in DB/config service.
2. Add admin API to update quota dynamically.
3. Use JWT claims instead of trusting `X-User-Id` from public clients.
4. Let API Gateway inject trusted identity headers after authentication.
5. Add Prometheus metrics for allowed/rejected requests.
6. Add alerting on high 429 rate.
7. Use separate limits for login, OTP, payments, search, statements, and admin APIs.
8. Add idempotency key handling for payment retries.
9. Do not retry automatically on 429 unless `Retry-After` is respected.
10. Use Redis cluster/sentinel for production availability.

## Troubleshooting

### Redis connection issue

Check:

```bash
docker ps
docker logs rl-redis
```

### Gateway cannot reach services

Check:

```bash
docker logs rl-api-gateway
docker logs rl-payment-service
docker logs rl-customer-service
```

### Maven build locally

```bash
mvn clean package
```

## Trainer Talking Flow

1. Start with no rate limiting: explain database/API meltdown.
2. Add gateway limiter: protect downstream services.
3. Show per-user vs per-IP keying.
4. Show plan-based quota.
5. Scale gateway pods conceptually: explain why local counters fail.
6. Show Redis keys.
7. Bypass gateway and show service limiter.
8. Discuss 429 and client retry behavior.
9. Discuss production observability and dynamic quota management.
