package com.bank.payment.dto;

import java.math.BigDecimal;
import java.time.Instant;

public record PaymentResponse(
        String transactionId,
        String status,
        BigDecimal amount,
        String currency,
        String idempotencyKey,
        Instant processedAt
) {}
