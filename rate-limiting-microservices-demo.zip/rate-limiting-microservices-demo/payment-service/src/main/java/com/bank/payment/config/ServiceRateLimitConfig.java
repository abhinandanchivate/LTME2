package com.bank.payment.config;

import io.github.resilience4j.ratelimiter.RateLimiter;
import io.github.resilience4j.ratelimiter.RateLimiterConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class ServiceRateLimitConfig {

    /**
     * Local in-memory limiter. This protects expensive logic even if someone bypasses the gateway.
     * Important: this is per pod. For global limits, use Redis/API Gateway/database-backed quotas.
     */
    @Bean
    public RateLimiter paymentCreateLocalLimiter() {
        RateLimiterConfig config = RateLimiterConfig.custom()
                .limitForPeriod(3)
                .limitRefreshPeriod(Duration.ofSeconds(10))
                .timeoutDuration(Duration.ZERO)
                .build();
        return RateLimiter.of("payment-create-local-limiter", config);
    }
}
