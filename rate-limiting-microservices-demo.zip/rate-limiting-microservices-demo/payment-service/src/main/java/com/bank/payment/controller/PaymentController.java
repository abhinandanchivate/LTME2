package com.bank.payment.controller;

import com.bank.payment.dto.PaymentRequest;
import com.bank.payment.dto.PaymentResponse;
import io.github.resilience4j.ratelimiter.RateLimiter;
import io.github.resilience4j.ratelimiter.RequestNotPermitted;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

@RestController
@RequestMapping("/payments")
public class PaymentController {

    private final RateLimiter paymentCreateLocalLimiter;

    public PaymentController(RateLimiter paymentCreateLocalLimiter) {
        this.paymentCreateLocalLimiter = paymentCreateLocalLimiter;
    }

    @PostMapping
    public ResponseEntity<?> createPayment(@Valid @RequestBody PaymentRequest request,
                                           @RequestHeader(value = "X-Correlation-Id", required = false) String correlationId) {
        Supplier<PaymentResponse> protectedCall = RateLimiter.decorateSupplier(
                paymentCreateLocalLimiter,
                () -> processPayment(request)
        );

        try {
            return ResponseEntity.ok()
                    .header("X-Correlation-Id", correlationId == null ? UUID.randomUUID().toString() : correlationId)
                    .body(protectedCall.get());
        } catch (RequestNotPermitted ex) {
            return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
                    .header("Retry-After", "10")
                    .body(Map.of(
                            "error", "SERVICE_LOCAL_RATE_LIMIT_EXCEEDED",
                            "message", "Payment service is throttling expensive payment creation logic. Retry later.",
                            "scope", "per-pod local limiter"
                    ));
        }
    }

    @GetMapping("/status/{transactionId}")
    public Map<String, Object> status(@PathVariable String transactionId) {
        return Map.of(
                "transactionId", transactionId,
                "status", "SUCCESS",
                "checkedAt", Instant.now().toString()
        );
    }

    private PaymentResponse processPayment(PaymentRequest request) {
        return new PaymentResponse(
                "TXN-" + UUID.randomUUID(),
                "SUCCESS",
                request.amount(),
                request.currency(),
                request.idempotencyKey(),
                Instant.now()
        );
    }
}
