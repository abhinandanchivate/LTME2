package com.bank.payment.controller;

import com.bank.payment.config.ServiceRateLimitConfig;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

class PaymentControllerTest {

    private final MockMvc mockMvc = MockMvcBuilders
            .standaloneSetup(new PaymentController(new ServiceRateLimitConfig().paymentCreateLocalLimiter()))
            .build();

    @Test
    void shouldThrottlePaymentCreationAfterLocalLimitIsExceeded() throws Exception {
        String body = """
                {
                  "fromAccount":"ACC1001",
                  "toAccount":"ACC2001",
                  "amount":1000,
                  "currency":"INR",
                  "idempotencyKey":"idem-test"
                }
                """;

        mockMvc.perform(post("/payments").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk());
        mockMvc.perform(post("/payments").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk());
        mockMvc.perform(post("/payments").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk());
        mockMvc.perform(post("/payments").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isTooManyRequests());
    }
}
