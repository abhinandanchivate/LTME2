# Rate Limiting Architecture

```mermaid
flowchart TD
    C[Client / Mobile / Partner API] --> GW[API Gateway]
    GW -->|Redis-backed global limiter| R[(Redis)]
    GW -->|Allowed| PS[Payment Service]
    GW -->|Allowed| CS[Customer Service]
    GW -->|Rejected| E429[HTTP 429 Too Many Requests]
    PS -->|Local per-pod limiter| BL[Business Logic]
    PS -->|Rejected if bypassed/overloaded| S429[HTTP 429]
```

## What this demo covers

| Aspect | Where implemented |
|---|---|
| Global distributed rate limit | `api-gateway` using Redis |
| Plan-aware quota | `X-Plan: FREE/SILVER/GOLD/INTERNAL` in `PlanAwareRedisRateLimitFilter` |
| Tenant/user/device/IP keying | `X-Tenant-Id`, `X-User-Id`, `X-Device-Id`, remote IP fallback |
| Built-in token bucket | Spring Cloud Gateway `RequestRateLimiter` in `application.yml` |
| Custom fixed-window limiter | `PlanAwareRedisRateLimitFilter` |
| Service self-protection | `payment-service` Resilience4j local limiter |
| Gateway bypass protection | direct call to payment service returns 429 after local quota |
| Observability headers | `X-RateLimit-*`, `Retry-After`, `X-Correlation-Id` |
| Docker execution | `docker-compose.yml` |
| Manual tests | `scripts/*.sh` and Postman collection |

## Production notes

1. Prefer gateway-level distributed limits for customer/API traffic.
2. Keep service-level local limits for expensive paths and bypass protection.
3. Use Redis/token bucket for burst-friendly APIs.
4. Use fixed window only when simple quotas are acceptable.
5. Never retry blindly on HTTP 429. Respect `Retry-After`.
6. Use separate quotas for login, payment creation, OTP, search, statement download, and admin APIs.
7. Key by tenant + user for authenticated traffic. Use IP/device only for anonymous traffic.
8. Internal bypass headers must be added only by trusted infrastructure, not by public clients.
