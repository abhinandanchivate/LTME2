package com.bank.customer.controller;

import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @GetMapping("/{customerId}")
    public Map<String, Object> getCustomer(@PathVariable String customerId,
                                           @RequestHeader(value = "X-Tenant-Id", defaultValue = "public") String tenantId) {
        return Map.of(
                "customerId", customerId,
                "tenantId", tenantId,
                "name", "Demo Customer",
                "riskCategory", "LOW",
                "fetchedAt", Instant.now().toString()
        );
    }
}
