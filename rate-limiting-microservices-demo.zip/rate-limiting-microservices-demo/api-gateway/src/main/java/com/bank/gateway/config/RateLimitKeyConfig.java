package com.bank.gateway.config;

import org.springframework.cloud.gateway.filter.ratelimit.KeyResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import reactor.core.publisher.Mono;

import java.net.InetSocketAddress;

@Configuration
public class RateLimitKeyConfig {

    /**
     * Used by Spring Cloud Gateway's RedisRateLimiter.
     * Priority: tenant + authenticated user -> tenant + device -> source IP.
     */
    @Bean
    public KeyResolver userOrIpKeyResolver() {
        return exchange -> {
            String tenantId = header(exchange, "X-Tenant-Id", "public");
            String userId = exchange.getRequest().getHeaders().getFirst("X-User-Id");
            String deviceId = exchange.getRequest().getHeaders().getFirst("X-Device-Id");

            if (userId != null && !userId.isBlank()) {
                return Mono.just("tenant:" + tenantId + ":user:" + userId);
            }
            if (deviceId != null && !deviceId.isBlank()) {
                return Mono.just("tenant:" + tenantId + ":device:" + deviceId);
            }
            InetSocketAddress address = exchange.getRequest().getRemoteAddress();
            String ip = address == null ? "unknown" : address.getAddress().getHostAddress();
            return Mono.just("tenant:" + tenantId + ":ip:" + ip);
        };
    }

    private static String header(org.springframework.web.server.ServerWebExchange exchange, String name, String defaultValue) {
        String value = exchange.getRequest().getHeaders().getFirst(name);
        return value == null || value.isBlank() ? defaultValue : value;
    }
}
