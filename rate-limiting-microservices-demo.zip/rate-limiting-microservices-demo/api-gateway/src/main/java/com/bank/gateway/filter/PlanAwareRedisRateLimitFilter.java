package com.bank.gateway.filter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.data.redis.core.ReactiveStringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.net.InetSocketAddress;
import java.time.Duration;
import java.util.Map;

/**
 * A custom distributed fixed-window limiter to demonstrate real production concerns:
 * 1. one rate-limit decision before traffic enters microservices
 * 2. different limits by plan/header
 * 3. tenant/user/device/IP keying
 * 4. Redis-backed shared counter across gateway pods
 * 5. standard rate-limit response headers
 *
 * Spring Cloud Gateway also provides RedisRateLimiter route filters in application.yml.
 * This class is intentionally explicit for training and debugging.
 */
@Component
public class PlanAwareRedisRateLimitFilter implements GlobalFilter, Ordered {

    private final ReactiveStringRedisTemplate redisTemplate;
    private final Map<String, PlanLimit> limits;
    private final boolean enabled;

    public PlanAwareRedisRateLimitFilter(
            ReactiveStringRedisTemplate redisTemplate,
            @Value("${bank.rate-limit.custom-enabled:true}") boolean enabled
    ) {
        this.redisTemplate = redisTemplate;
        this.enabled = enabled;
        this.limits = Map.of(
                "FREE", new PlanLimit(5, Duration.ofMinutes(1)),
                "SILVER", new PlanLimit(15, Duration.ofMinutes(1)),
                "GOLD", new PlanLimit(30, Duration.ofMinutes(1)),
                "INTERNAL", new PlanLimit(200, Duration.ofMinutes(1))
        );
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        if (!enabled || isActuator(exchange) || isInternalHealthCall(exchange)) {
            return chain.filter(exchange);
        }

        String plan = normalizePlan(exchange.getRequest().getHeaders().getFirst("X-Plan"));
        PlanLimit planLimit = limits.getOrDefault(plan, limits.get("FREE"));
        String key = buildKey(exchange, plan);

        return redisTemplate.opsForValue()
                .increment(key)
                .flatMap(count -> applyWindowAndDecision(exchange, chain, key, count, planLimit, plan));
    }

    private Mono<Void> applyWindowAndDecision(ServerWebExchange exchange,
                                              GatewayFilterChain chain,
                                              String key,
                                              Long count,
                                              PlanLimit planLimit,
                                              String plan) {
        Mono<Boolean> expire = count == 1
                ? redisTemplate.expire(key, planLimit.window())
                : Mono.just(Boolean.TRUE);

        return expire.then(Mono.defer(() -> {
            long remaining = Math.max(0, planLimit.allowedRequests() - count);
            ServerHttpResponse response = exchange.getResponse();
            response.getHeaders().add("X-RateLimit-Plan", plan);
            response.getHeaders().add("X-RateLimit-Limit", String.valueOf(planLimit.allowedRequests()));
            response.getHeaders().add("X-RateLimit-Remaining", String.valueOf(remaining));
            response.getHeaders().add("X-RateLimit-Window-Seconds", String.valueOf(planLimit.window().toSeconds()));

            if (count > planLimit.allowedRequests()) {
                response.setStatusCode(HttpStatus.TOO_MANY_REQUESTS);
                response.getHeaders().add("Retry-After", String.valueOf(planLimit.window().toSeconds()));
                byte[] body = ("{\"error\":\"RATE_LIMIT_EXCEEDED\",\"message\":\"Too many requests for plan "
                        + plan + ". Retry later.\"}").getBytes();
                return response.writeWith(Mono.just(response.bufferFactory().wrap(body)));
            }
            return chain.filter(exchange);
        }));
    }

    private String buildKey(ServerWebExchange exchange, String plan) {
        String tenantId = header(exchange, "X-Tenant-Id", "public");
        String userId = exchange.getRequest().getHeaders().getFirst("X-User-Id");
        String deviceId = exchange.getRequest().getHeaders().getFirst("X-Device-Id");
        String subject;

        if (userId != null && !userId.isBlank()) {
            subject = "user:" + userId;
        } else if (deviceId != null && !deviceId.isBlank()) {
            subject = "device:" + deviceId;
        } else {
            InetSocketAddress address = exchange.getRequest().getRemoteAddress();
            String ip = address == null ? "unknown" : address.getAddress().getHostAddress();
            subject = "ip:" + ip;
        }
        return "rl:gateway:" + tenantId + ":" + plan + ":" + subject;
    }

    private String normalizePlan(String plan) {
        if (plan == null || plan.isBlank()) return "FREE";
        return plan.trim().toUpperCase();
    }

    private boolean isActuator(ServerWebExchange exchange) {
        return exchange.getRequest().getURI().getPath().startsWith("/actuator");
    }

    private boolean isInternalHealthCall(ServerWebExchange exchange) {
        return "true".equalsIgnoreCase(exchange.getRequest().getHeaders().getFirst("X-Internal-Health-Check"));
    }

    private static String header(ServerWebExchange exchange, String name, String defaultValue) {
        String value = exchange.getRequest().getHeaders().getFirst(name);
        return value == null || value.isBlank() ? defaultValue : value;
    }

    @Override
    public int getOrder() {
        return -100;
    }

    private record PlanLimit(long allowedRequests, Duration window) {}
}
