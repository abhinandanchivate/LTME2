#!/usr/bin/env bash
set -euo pipefail

URL="${URL:-http://localhost:8080/customers/CUST-101}"

echo "Calling FREE plan customer API 8 times. First 5 should pass custom gateway limiter; later calls should return 429."
for i in {1..8}; do
  echo "\n--- Request $i ---"
  curl -i -s "$URL" \
    -H 'X-Tenant-Id: bank-a' \
    -H 'X-User-Id: user-101' \
    -H 'X-Plan: FREE' | sed -n '1,20p'
done
