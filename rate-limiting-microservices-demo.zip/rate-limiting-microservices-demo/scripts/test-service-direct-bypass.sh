#!/usr/bin/env bash
set -euo pipefail

URL="${URL:-http://localhost:8081/payments}"

echo "Bypassing gateway and hitting payment-service directly. Local per-pod limiter allows 3 requests per 10 seconds."
for i in {1..6}; do
  echo "\n--- Direct service request $i ---"
  curl -i -s -X POST "$URL" \
    -H 'Content-Type: application/json' \
    -H "X-Correlation-Id: direct-$i" \
    -d "{\"fromAccount\":\"ACC1001\",\"toAccount\":\"ACC2001\",\"amount\":1000,\"currency\":\"INR\",\"idempotencyKey\":\"direct-$i\"}" | sed -n '1,20p'
done
