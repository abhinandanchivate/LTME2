#!/usr/bin/env bash
set -euo pipefail

URL="${URL:-http://localhost:8080/customers/CUST-101}"

echo "Calling GOLD plan 12 times. Should stay within custom plan quota, unless built-in route limiter is configured lower."
for i in {1..12}; do
  echo "\n--- Request $i ---"
  curl -i -s "$URL" \
    -H 'X-Tenant-Id: bank-a' \
    -H 'X-User-Id: user-202' \
    -H 'X-Plan: GOLD' | sed -n '1,18p'
done
