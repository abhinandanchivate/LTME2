#!/usr/bin/env bash
set -euo pipefail

echo "Redis rate-limit keys:"
docker exec -it rl-redis redis-cli KEYS 'rl:*'

echo "Gateway built-in RedisRateLimiter keys may look like request_rate_limiter.* depending on Spring Cloud Gateway internals."
docker exec -it rl-redis redis-cli KEYS '*request*'
