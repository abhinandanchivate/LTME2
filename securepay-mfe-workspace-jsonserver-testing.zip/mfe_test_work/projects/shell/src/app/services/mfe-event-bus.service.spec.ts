import { take } from 'rxjs';
import { MfeEventBusService } from './mfe-event-bus.service';

describe('MfeEventBusService', () => {
  let service: MfeEventBusService;

  beforeEach(() => {
    service = new MfeEventBusService();
  });

  it('should emit and receive ACCOUNT_SELECTED events', done => {
    service.on('ACCOUNT_SELECTED').pipe(take(1)).subscribe(payload => {
      expect(payload.accountId).toBe('ACC-1001');
      expect(payload.accountName).toBe('Corporate Salary Account');
      done();
    });

    service.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId: 'ACC-1001', accountName: 'Corporate Salary Account' }
    });
  });
});
