import { take } from 'rxjs';
import { MfeEventBusService } from './mfe-event-bus.service';

describe('MfeEventBusService', () => {
  let service: MfeEventBusService;

  beforeEach(() => {
    service = new MfeEventBusService();
  });

  it('should emit and receive TRANSACTION_CREATED events', done => {
    service.on('TRANSACTION_CREATED').pipe(take(1)).subscribe(payload => {
      expect(payload.transactionId).toBe('TXN-9001');
      expect(payload.amount).toBe(5000);
      expect(payload.accountId).toBe('ACC-1001');
      done();
    });

    service.emit({
      type: 'TRANSACTION_CREATED',
      payload: { transactionId: 'TXN-9001', amount: 5000, accountId: 'ACC-1001' }
    });
  });
});
