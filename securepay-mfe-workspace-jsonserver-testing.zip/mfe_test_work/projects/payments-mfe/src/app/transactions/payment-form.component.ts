import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { MfeEventBusService } from '../services/mfe-event-bus.service';
import { TransactionApiService } from '../api/transaction-api.service';

@Component({
  selector: 'payments-payment-form',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div class="card form-card">
      <span class="badge">POST API demo using JSON Server</span>
      <h2>Create Payment</h2>
      <form [formGroup]="form" (ngSubmit)="submit()">
        <label>Account ID <input formControlName="accountId" placeholder="ACC-1001" /></label>
        <label>Account Name <input formControlName="accountName" placeholder="Corporate Salary Account" /></label>
        <label>Beneficiary <input formControlName="beneficiary" placeholder="Vendor ABC" /></label>
        <label>Amount <input type="number" formControlName="amount" /></label>
        <div class="actions">
          <button class="btn" type="submit" [disabled]="form.invalid || saving()">{{ saving() ? 'Saving...' : 'Submit Payment' }}</button>
          <a routerLink="/transactions">Back</a>
        </div>
      </form>

      @if (message()) {
        <p class="success">{{ message() }}</p>
      }
      @if (error()) {
        <p class="error">{{ error() }}</p>
      }
    </div>
  `,
  styles: [`
    .form-card { max-width:560px; }
    form { display:grid; gap:14px; margin-top:18px; }
    label { display:grid; gap:6px; font-weight:700; }
    input { border:1px solid var(--border); border-radius:10px; padding:12px; font-size:15px; }
    .actions { display:flex; align-items:center; gap:14px; }
    button:disabled { opacity:.5; cursor:not-allowed; }
    .success { color:#166534; font-weight:700; }
    .error { color:#991b1b; font-weight:700; }
  `]
})
export class PaymentFormComponent {
  private fb = inject(FormBuilder);
  private eventBus = inject(MfeEventBusService);
  private api = inject(TransactionApiService);

  saving = signal(false);
  message = signal<string | null>(null);
  error = signal<string | null>(null);

  form = this.fb.nonNullable.group({
    accountId: ['ACC-1001', Validators.required],
    accountName: ['Corporate Salary Account', Validators.required],
    beneficiary: ['', Validators.required],
    amount: [1000, [Validators.required, Validators.min(1)]]
  });

  submit(): void {
    if (this.form.invalid) return;
    this.saving.set(true);
    this.message.set(null);
    this.error.set(null);

    const value = this.form.getRawValue();
    this.api.createTransaction({
      ...value,
      status: 'PENDING',
      createdAt: new Date().toISOString()
    }).subscribe({
      next: tx => {
        this.saving.set(false);
        this.message.set(`Payment ${tx.id} saved to JSON Server and event emitted.`);
        this.eventBus.emit({
          type: 'TRANSACTION_CREATED',
          payload: { transactionId: tx.id, amount: tx.amount, accountId: tx.accountId }
        });
      },
      error: () => {
        this.saving.set(false);
        this.error.set('Could not save payment. Start JSON Server using npm run api or npm run start:all.');
      }
    });
  }
}
