import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { TransactionListComponent } from './transaction-list.component';
import { TransactionApiService } from '../api/transaction-api.service';
import { MfeEventBusService } from '../services/mfe-event-bus.service';

describe('TransactionListComponent', () => {
  let fixture: ComponentFixture<TransactionListComponent>;
  let apiSpy: jasmine.SpyObj<TransactionApiService>;
  let eventBusSpy: jasmine.SpyObj<MfeEventBusService>;

  beforeEach(async () => {
    apiSpy = jasmine.createSpyObj<TransactionApiService>('TransactionApiService', ['getTransactions']);
    eventBusSpy = jasmine.createSpyObj<MfeEventBusService>('MfeEventBusService', ['emit']);
    apiSpy.getTransactions.and.returnValue(of([
      { id: 'TXN-1001', accountId: 'ACC-1001', accountName: 'Corporate Salary Account', beneficiary: 'Payroll', amount: 1000, status: 'SUCCESS', createdAt: '2026-05-14T00:00:00.000Z' }
    ]));

    await TestBed.configureTestingModule({
      imports: [TransactionListComponent],
      providers: [
        provideRouter([]),
        { provide: TransactionApiService, useValue: apiSpy },
        { provide: MfeEventBusService, useValue: eventBusSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(TransactionListComponent);
    fixture.detectChanges();
  });

  it('should load transactions from the API service', () => {
    expect(apiSpy.getTransactions).toHaveBeenCalled();
    expect(fixture.nativeElement.textContent).toContain('TXN-1001');
  });

  it('should emit ACCOUNT_SELECTED when a row account is selected', () => {
    const component = fixture.componentInstance;
    component.selectAccount(component.transactions()[0]);

    expect(eventBusSpy.emit).toHaveBeenCalledWith({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId: 'ACC-1001', accountName: 'Corporate Salary Account' }
    });
  });
});
