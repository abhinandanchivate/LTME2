import { Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { MfeEventBusService } from '../services/mfe-event-bus.service';
import { Transaction, TransactionApiService } from '../api/transaction-api.service';

@Component({
  selector: 'payments-transaction-list',
  standalone: true,
  imports: [RouterLink, CurrencyPipe, DatePipe],
  template: `
    <div class="grid">
      <div class="card heading">
        <div>
          <span class="badge">Payments MFE loaded from remoteEntry.js</span>
          <h2>Transactions from JSON Server</h2>
          <p>Select an account here. Reports MFE listens using the shared browser event contract.</p>
        </div>
        <a class="btn" routerLink="new">Create Payment</a>
      </div>

      @if (loading()) {
        <div class="card">Loading transactions from <code>http://localhost:3000/transactions</code>...</div>
      }

      @if (error()) {
        <div class="card error">{{ error() }}</div>
      }

      <div class="card table-card">
        <table>
          <thead>
            <tr><th>ID</th><th>Account</th><th>Beneficiary</th><th>Amount</th><th>Status</th><th>Created</th><th>Action</th></tr>
          </thead>
          <tbody>
            @for (tx of transactions(); track tx.id) {
              <tr>
                <td>{{ tx.id }}</td>
                <td>{{ tx.accountName }}</td>
                <td>{{ tx.beneficiary }}</td>
                <td>{{ tx.amount | currency:'INR' }}</td>
                <td><span class="status" [class.pending]="tx.status === 'PENDING'" [class.failed]="tx.status === 'FAILED'">{{ tx.status }}</span></td>
                <td>{{ tx.createdAt | date:'medium' }}</td>
                <td><button class="btn secondary" (click)="selectAccount(tx)">Select Account</button></td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .heading { display:flex; justify-content:space-between; gap:20px; align-items:center; }
    h2 { margin:10px 0; font-size:28px; }
    p { color:var(--muted); }
    table { width:100%; border-collapse:collapse; }
    th, td { padding:12px; border-bottom:1px solid var(--border); text-align:left; }
    th { color:var(--muted); font-size:13px; }
    .status { padding:4px 10px; border-radius:999px; background:#dcfce7; color:#166534; font-weight:700; font-size:12px; }
    .status.pending { background:#fef9c3; color:#854d0e; }
    .status.failed { background:#fee2e2; color:#991b1b; }
    .table-card { overflow:auto; }
    .error { border-color:#fecaca; background:#fff7f7; color:#991b1b; }
    code { background:#111827; color:white; padding:2px 6px; border-radius:6px; }
  `]
})
export class TransactionListComponent implements OnInit {
  private eventBus = inject(MfeEventBusService);
  private api = inject(TransactionApiService);

  transactions = signal<Transaction[]>([]);
  loading = signal(false);
  error = signal<string | null>(null);

  ngOnInit(): void {
    this.loadTransactions();
  }

  loadTransactions(): void {
    this.loading.set(true);
    this.error.set(null);

    this.api.getTransactions().subscribe({
      next: transactions => {
        this.transactions.set(transactions);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Could not load transactions. Start JSON Server using npm run api or npm run start:all.');
        this.loading.set(false);
      }
    });
  }

  selectAccount(tx: Transaction): void {
    this.eventBus.emit({ type: 'ACCOUNT_SELECTED', payload: { accountId: tx.accountId, accountName: tx.accountName } });
    alert(`Account selected: ${tx.accountName}. Now open Reports MFE.`);
  }
}
