import { ComponentFixture, TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { of } from 'rxjs';
import { PaymentFormComponent } from './payment-form.component';
import { TransactionApiService } from '../api/transaction-api.service';
import { MfeEventBusService } from '../services/mfe-event-bus.service';

describe('PaymentFormComponent', () => {
  let fixture: ComponentFixture<PaymentFormComponent>;
  let component: PaymentFormComponent;
  let apiSpy: jasmine.SpyObj<TransactionApiService>;
  let eventBusSpy: jasmine.SpyObj<MfeEventBusService>;

  beforeEach(async () => {
    apiSpy = jasmine.createSpyObj<TransactionApiService>('TransactionApiService', ['createTransaction']);
    eventBusSpy = jasmine.createSpyObj<MfeEventBusService>('MfeEventBusService', ['emit']);

    await TestBed.configureTestingModule({
      imports: [PaymentFormComponent],
      providers: [
        provideRouter([]),
        { provide: TransactionApiService, useValue: apiSpy },
        { provide: MfeEventBusService, useValue: eventBusSpy }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(PaymentFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should disable submit when form is invalid', () => {
    component.form.controls.beneficiary.setValue('');
    fixture.detectChanges();

    const button = fixture.nativeElement.querySelector('button[type="submit"]') as HTMLButtonElement;
    expect(button.disabled).toBeTrue();
  });

  it('should create transaction and emit event when form is valid', () => {
    apiSpy.createTransaction.and.returnValue(of({
      id: 'TXN-9999',
      accountId: 'ACC-1001',
      accountName: 'Corporate Salary Account',
      beneficiary: 'Vendor ABC',
      amount: 1000,
      status: 'PENDING',
      createdAt: '2026-05-14T00:00:00.000Z'
    }));

    component.form.setValue({
      accountId: 'ACC-1001',
      accountName: 'Corporate Salary Account',
      beneficiary: 'Vendor ABC',
      amount: 1000
    });

    component.submit();

    expect(apiSpy.createTransaction).toHaveBeenCalled();
    expect(eventBusSpy.emit).toHaveBeenCalledWith({
      type: 'TRANSACTION_CREATED',
      payload: { transactionId: 'TXN-9999', amount: 1000, accountId: 'ACC-1001' }
    });
  });
});
