import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

export type TransactionStatus = 'SUCCESS' | 'PENDING' | 'FAILED';

export interface Transaction {
  id: string;
  accountId: string;
  accountName: string;
  beneficiary: string;
  amount: number;
  status: TransactionStatus;
  createdAt: string;
}

export interface CreateTransactionRequest {
  accountId: string;
  accountName: string;
  beneficiary: string;
  amount: number;
  status: TransactionStatus;
  createdAt: string;
}

@Injectable({ providedIn: 'root' })
export class TransactionApiService {
  private http = inject(HttpClient);
  private readonly baseUrl = 'http://localhost:3000/transactions';

  getTransactions(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(this.baseUrl);
  }

  createTransaction(request: CreateTransactionRequest): Observable<Transaction> {
    return this.http.post<Transaction>(this.baseUrl, request);
  }
}
