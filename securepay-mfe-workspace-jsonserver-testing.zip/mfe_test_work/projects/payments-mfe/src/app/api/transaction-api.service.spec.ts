import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { TransactionApiService } from './transaction-api.service';

describe('TransactionApiService', () => {
  let service: TransactionApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting(), TransactionApiService]
    });
    service = TestBed.inject(TransactionApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('should GET transactions from JSON Server', () => {
    service.getTransactions().subscribe(transactions => {
      expect(transactions.length).toBe(1);
      expect(transactions[0].id).toBe('TXN-1001');
    });

    const req = http.expectOne('http://localhost:3000/transactions');
    expect(req.request.method).toBe('GET');
    req.flush([
      { id: 'TXN-1001', accountId: 'ACC-1001', accountName: 'Corporate Salary Account', beneficiary: 'Payroll', amount: 1000, status: 'SUCCESS', createdAt: '2026-05-14T00:00:00.000Z' }
    ]);
  });

  it('should POST a new transaction to JSON Server', () => {
    const request = { accountId: 'ACC-1001', accountName: 'Corporate Salary Account', beneficiary: 'Vendor ABC', amount: 1000, status: 'PENDING' as const, createdAt: '2026-05-14T00:00:00.000Z' };

    service.createTransaction(request).subscribe(response => {
      expect(response.id).toBe('TXN-9999');
      expect(response.status).toBe('PENDING');
    });

    const req = http.expectOne('http://localhost:3000/transactions');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(request);
    req.flush({ id: 'TXN-9999', ...request });
  });
});
