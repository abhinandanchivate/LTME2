import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

export interface PaymentReport {
  id: string;
  totalVolume: number;
  successCount: number;
  pendingCount: number;
  failedCount: number;
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
}

@Injectable({ providedIn: 'root' })
export class ReportApiService {
  private http = inject(HttpClient);
  private readonly baseUrl = 'http://localhost:3000/reports';

  getDailyReport(): Observable<PaymentReport[]> {
    return this.http.get<PaymentReport[]>(this.baseUrl);
  }
}
