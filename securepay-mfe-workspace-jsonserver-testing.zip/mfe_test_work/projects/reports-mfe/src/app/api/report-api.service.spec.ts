import { TestBed } from '@angular/core/testing';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { provideHttpClient } from '@angular/common/http';
import { ReportApiService } from './report-api.service';

describe('ReportApiService', () => {
  let service: ReportApiService;
  let http: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting(), ReportApiService]
    });
    service = TestBed.inject(ReportApiService);
    http = TestBed.inject(HttpTestingController);
  });

  afterEach(() => http.verify());

  it('should GET daily report from JSON Server', () => {
    service.getDailyReport().subscribe(reports => {
      expect(reports.length).toBe(1);
      expect(reports[0].totalVolume).toBe(222499);
    });

    const req = http.expectOne('http://localhost:3000/reports');
    expect(req.request.method).toBe('GET');
    req.flush([{ id: 'RPT-DAILY', totalVolume: 222499, successCount: 1, pendingCount: 1, failedCount: 1, riskScore: 'LOW' }]);
  });
});
