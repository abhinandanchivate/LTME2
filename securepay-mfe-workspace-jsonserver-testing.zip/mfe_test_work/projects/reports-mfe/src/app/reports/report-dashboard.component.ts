import { Component, DestroyRef, OnInit, inject, signal } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MfeEventBusService } from '../services/mfe-event-bus.service';
import { PaymentReport, ReportApiService } from '../api/report-api.service';

@Component({
  selector: 'reports-dashboard',
  standalone: true,
  imports: [CurrencyPipe],
  template: `
    <div class="grid">
      <div class="card heading">
        <div>
          <span class="badge">Reports MFE loaded from remoteEntry.js</span>
          <h2>Payment Insights Dashboard</h2>
          <p>Consumes report summary from JSON Server and receives account context from Payments MFE.</p>
        </div>
      </div>

      @if (error()) {
        <div class="card error">{{ error() }}</div>
      }

      <div class="cards">
        <div class="card metric"><span>Total Volume</span><strong>{{ dailyReport()?.totalVolume ?? 0 | currency:'INR' }}</strong></div>
        <div class="card metric"><span>Success Count</span><strong>{{ dailyReport()?.successCount ?? 0 }}</strong></div>
        <div class="card metric"><span>Risk Score</span><strong>{{ dailyReport()?.riskScore ?? 'NA' }}</strong></div>
      </div>

      <div class="card">
        <h3>Selected Account Context</h3>
        @if (selectedAccount()) {
          <p class="selected">{{ selectedAccount()?.accountName }} — {{ selectedAccount()?.accountId }}</p>
        } @else {
          <p class="empty">No account selected yet. Open Payments MFE, click <strong>Select Account</strong>, then return here.</p>
        }
      </div>

      <div class="card">
        <h3>Latest Transaction Event</h3>
        @if (latestTransaction()) {
          <p class="selected">{{ latestTransaction()?.transactionId }} for {{ latestTransaction()?.amount | currency:'INR' }} on {{ latestTransaction()?.accountId }}</p>
        } @else {
          <p class="empty">Create a payment in Payments MFE to see this update.</p>
        }
      </div>
    </div>
  `,
  styles: [`
    .heading h2 { margin: 10px 0; font-size: 28px; }
    p { color: var(--muted); }
    .cards { display:grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap:16px; }
    .metric { display:grid; gap:10px; }
    .metric span { color:var(--muted); font-weight:700; }
    .metric strong { font-size:26px; color:#0f5132; }
    .selected { padding:14px; border-radius:12px; background:#dcfce7; color:#14532d; font-weight:700; }
    .empty { padding:14px; border-radius:12px; background:#f8fafc; }
    .error { border-color:#fecaca; background:#fff7f7; color:#991b1b; }
    @media (max-width: 800px) { .cards { grid-template-columns: 1fr; } }
  `]
})
export class ReportDashboardComponent implements OnInit {
  private eventBus = inject(MfeEventBusService);
  private destroyRef = inject(DestroyRef);
  private reportApi = inject(ReportApiService);

  dailyReport = signal<PaymentReport | null>(null);
  error = signal<string | null>(null);
  selectedAccount = signal<{ accountId: string; accountName: string } | null>(null);
  latestTransaction = signal<{ transactionId: string; amount: number; accountId: string } | null>(null);

  constructor() {
    this.eventBus.on('ACCOUNT_SELECTED')
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(payload => this.selectedAccount.set(payload));

    this.eventBus.on('TRANSACTION_CREATED')
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(payload => this.latestTransaction.set(payload));
  }

  ngOnInit(): void {
    this.reportApi.getDailyReport().subscribe({
      next: reports => this.dailyReport.set(reports[0] ?? null),
      error: () => this.error.set('Could not load report summary. Start JSON Server using npm run api or npm run start:all.')
    });
  }
}
