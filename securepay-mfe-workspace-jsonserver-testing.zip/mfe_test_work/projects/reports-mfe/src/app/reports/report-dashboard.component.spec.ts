import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { ReportDashboardComponent } from './report-dashboard.component';
import { ReportApiService } from '../api/report-api.service';
import { MfeEventBusService } from '../services/mfe-event-bus.service';

describe('ReportDashboardComponent', () => {
  let fixture: ComponentFixture<ReportDashboardComponent>;
  let apiSpy: jasmine.SpyObj<ReportApiService>;
  let eventBus: MfeEventBusService;

  beforeEach(async () => {
    apiSpy = jasmine.createSpyObj<ReportApiService>('ReportApiService', ['getDailyReport']);
    apiSpy.getDailyReport.and.returnValue(of([
      { id: 'RPT-DAILY', totalVolume: 222499, successCount: 1, pendingCount: 1, failedCount: 1, riskScore: 'LOW' }
    ]));
    eventBus = new MfeEventBusService();

    await TestBed.configureTestingModule({
      imports: [ReportDashboardComponent],
      providers: [
        { provide: ReportApiService, useValue: apiSpy },
        { provide: MfeEventBusService, useValue: eventBus }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ReportDashboardComponent);
    fixture.detectChanges();
  });

  it('should load report metrics from API service', () => {
    expect(apiSpy.getDailyReport).toHaveBeenCalled();
    expect(fixture.nativeElement.textContent).toContain('222,499');
    expect(fixture.nativeElement.textContent).toContain('LOW');
  });

  it('should react to ACCOUNT_SELECTED events', () => {
    eventBus.emit({ type: 'ACCOUNT_SELECTED', payload: { accountId: 'ACC-1001', accountName: 'Corporate Salary Account' } });
    fixture.detectChanges();

    expect(fixture.nativeElement.textContent).toContain('Corporate Salary Account');
    expect(fixture.nativeElement.textContent).toContain('ACC-1001');
  });
});
