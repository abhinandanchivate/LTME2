# SecurePay Angular Micro Frontend Workspace

This workspace contains a working local Micro Frontend setup for the SecurePayment Gateway training scenario.

It includes:

- Shell host app on `http://localhost:4200`
- Payments MFE remote on `http://localhost:4201`
- Reports MFE remote on `http://localhost:4202`
- JSON Server mock backend on `http://localhost:3000`
- Webpack Module Federation configuration
- Remote route exposure through `remoteEntry.js`
- Cross-MFE communication using a browser event bus contract
- Unit tests for services, components, and event bus behavior

## 1. Install

```bash
npm install
```

## 2. Run everything together

```bash
npm run start:all
```

This starts:

| Process | URL |
|---|---|
| JSON Server | http://localhost:3000 |
| Shell | http://localhost:4200 |
| Payments MFE | http://localhost:4201 |
| Reports MFE | http://localhost:4202 |

Open:

```text
http://localhost:4200
```

## 3. API endpoints from JSON Server

```text
GET  http://localhost:3000/transactions
POST http://localhost:3000/transactions
GET  http://localhost:3000/reports
```

Mock data lives here:

```text
mock-api/db.json
```

## 4. How the demo flows

1. Open shell: `http://localhost:4200`.
2. Go to **Payments MFE**.
3. Payments loads transactions from JSON Server.
4. Click **Select Account**.
5. Go to **Reports MFE**.
6. Reports displays selected account context using the cross-MFE event contract.
7. Create a payment in Payments MFE.
8. The payment is POSTed to JSON Server and a `TRANSACTION_CREATED` event is emitted.

## 5. Verify remote entries

```bash
npm run verify:remote-entry
```

Expected remote URLs:

```text
http://localhost:4201/remoteEntry.js
http://localhost:4202/remoteEntry.js
```

## 6. Run tests

Run all tests:

```bash
npm run test:all
```

Run individual app tests:

```bash
npm run test:shell
npm run test:payments
npm run test:reports
```

The tests cover:

- Event bus publish/subscribe behavior
- Payments transaction API service with mocked HTTP
- Payments payment form submit behavior
- Payments transaction list loading and account selection
- Reports API service with mocked HTTP
- Reports dashboard metrics and event handling
- Shell component rendering

## 7. Build all applications

```bash
npm run build:all
```

## 8. One-command verification

```bash
npm run verify:all
```

This runs:

1. Production build for Payments MFE
2. Production build for Reports MFE
3. Production build for Shell
4. All unit tests
5. Remote-entry check script

> Note: `verify:remote-entry` expects the dev servers to be running because it checks the local remote URLs.

## 9. Important files

```text
projects/shell/src/app/app.routes.ts
projects/payments-mfe/webpack.config.js
projects/reports-mfe/webpack.config.js
projects/payments-mfe/src/app/api/transaction-api.service.ts
projects/reports-mfe/src/app/api/report-api.service.ts
projects/*/src/app/services/mfe-event-bus.service.ts
mock-api/db.json
karma.conf.js
```

## 10. Training mapping

This demo maps to these MFE learning points:

- Shell owns layout and navigation.
- Remotes expose route arrays, not NgModules.
- Shell lazy-loads remotes at runtime using `remoteEntry.js`.
- Angular, Router, and RxJS are shared as singletons.
- JSON Server simulates backend APIs for hands-on training.
- Tests validate services, components, and cross-MFE events.
