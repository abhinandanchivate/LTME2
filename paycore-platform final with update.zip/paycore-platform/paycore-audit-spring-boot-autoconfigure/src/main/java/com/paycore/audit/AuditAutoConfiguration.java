package com.paycore.audit;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Section 2: Custom Starter Auto-Configuration
 *
 * Guard conditions (Phase ②):
 *   ① @ConditionalOnClass → safe to include in non-web apps (batch services, etc.)
 *   ② @ConditionalOnProperty → consumers opt out via paycore.audit.enabled=false
 *
 * Override hooks (Phase ③):
 *   ③ @ConditionalOnMissingBean on each @Bean → consumers can replace any bean
 */
@AutoConfiguration
@ConditionalOnClass(name = "org.springframework.web.servlet.HandlerInterceptor")
@ConditionalOnProperty(prefix = "paycore.audit", name = "enabled",
        havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(AuditProperties.class)
public class AuditAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public AuditLogger auditLogger(AuditProperties properties) {
        System.out.println("[AuditAutoConfig] Registering default AuditLogger → dest="
                + properties.getDestination());
        return new AuditLogger(properties);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnWebApplication
    public AuditInterceptor auditInterceptor(AuditLogger logger, AuditProperties properties) {
        System.out.println("[AuditAutoConfig] Registering AuditInterceptor");
        return new AuditInterceptor(logger, properties);
    }
}
