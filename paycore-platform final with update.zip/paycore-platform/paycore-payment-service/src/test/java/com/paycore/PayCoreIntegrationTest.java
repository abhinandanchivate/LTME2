package com.paycore;

import com.paycore.fraud.FraudAnalyzer;
import com.paycore.payment.PaymentProcessingService;
import com.paycore.payment.PaymentRequest;
import com.paycore.payment.PaymentResult;
import com.paycore.security.SecurityFilterChain;
import com.paycore.tenant.TenantService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.*;

/**
 * Full integration test — Spring Boot 4.0.5
 *
 * NOTE ON TESTING STACK:
 *   Spring Boot 4 ships with JUnit 6. We use spring-boot-starter-test-classic
 *   which bridges JUnit 5 annotations (@Test, @DisplayName, etc.) onto the
 *   JUnit 6 runtime — so this file compiles unchanged from the Boot 3 version.
 *
 * Section 6 test specifically validates the new BeanRegistrar API:
 *   TenantServiceRegistrar.register() (BeanRegistrar) is called during context
 *   initialization and registers beans the same way as the old
 *   BeanDefinitionRegistryPostProcessor, so assertions are identical.
 */
@SpringBootTest
class PayCoreIntegrationTest {

    @Autowired ApplicationContext ctx;
    @Autowired PaymentProcessingService paymentService;
    @Autowired ObjectProvider<FraudAnalyzer> fraudAnalyzerProvider;

    // ── Section 3: Ordering ───────────────────────────────────────────────────
    @Test
    @DisplayName("§3 — SecurityFilterChain registered first (ordering works)")
    void section3_securityBeanPresent() {
        assertThat(ctx.containsBean("securityFilterChain")).isTrue();
        assertThat(ctx.getBean(SecurityFilterChain.class).getName())
                .isEqualTo("DEFAULT_SECURITY_CHAIN");
    }

    // ── Section 4: Datasource Routing ─────────────────────────────────────────
    @Test
    @DisplayName("§4 — Read path returns result (REPLICA routing)")
    void section4_replicaRouting() {
        String history = paymentService.getPaymentHistory("TEST-ACCOUNT");
        assertThat(history).contains("TEST-ACCOUNT").contains("REPLICA");
    }

    // ── Section 5: Prototype Scope ────────────────────────────────────────────
    @Test
    @DisplayName("§5 — ObjectProvider gives a NEW FraudAnalyzer each call")
    void section5_prototypeNewInstance() {
        FraudAnalyzer a1 = fraudAnalyzerProvider.getObject();
        FraudAnalyzer a2 = fraudAnalyzerProvider.getObject();
        assertThat(a1).isNotSameAs(a2);
    }

    @Test
    @DisplayName("§5 — Normal payment ($500) is approved")
    void section5_normalApproved() {
        PaymentResult result = paymentService.processPayment(
                new PaymentRequest("ACC-001", new BigDecimal("500"), "US", 2));
        assertThat(result.approved()).isTrue();
    }

    @Test
    @DisplayName("§5 — High-value payment ($500k) is rejected")
    void section5_suspiciousRejected() {
        PaymentResult result = paymentService.processPayment(
                new PaymentRequest("ACC-002", new BigDecimal("500000"), "NG", 80));
        assertThat(result.approved()).isFalse();
        assertThat(result.reason()).contains("High-value");
    }

    @Test
    @DisplayName("§5 — State isolation: large payment doesn't pollute next payment's analysis")
    void section5_stateIsolation() {
        paymentService.processPayment(
                new PaymentRequest("ACC-001", new BigDecimal("999999"), "NG", 100));
        // Would fail if FraudAnalyzer were singleton — signals from first call leak into second
        PaymentResult r2 = paymentService.processPayment(
                new PaymentRequest("ACC-002", new BigDecimal("100"), "US", 1));
        assertThat(r2.approved()).isTrue();
    }

    // ── Section 6: BeanRegistrar (Spring Boot 4 API) ──────────────────────────
    @Test
    @DisplayName("§6 — BeanRegistrar: ACME_BANK tenant bean registered from clients.yaml")
    void section6_acmeBankRegistered() {
        TenantService ts = ctx.getBean("tenantService_acme_bank", TenantService.class);
        assertThat(ts.getTenantId()).isEqualTo("ACME_BANK");
        assertThat(ts.getSettlementCurrency()).isEqualTo("USD");
        assertThat(ts.getDailyLimit()).isEqualTo(10_000_000L);
    }

    @Test
    @DisplayName("§6 — BeanRegistrar: GLOBAL_BANK tenant bean registered")
    void section6_globalBankRegistered() {
        TenantService ts = ctx.getBean("tenantService_global_bank", TenantService.class);
        assertThat(ts.getTenantId()).isEqualTo("GLOBAL_BANK");
        assertThat(ts.getSettlementCurrency()).isEqualTo("EUR");
    }

    @Test
    @DisplayName("§6 — BeanRegistrar: All 3 tenants from clients.yaml are present")
    void section6_allThreeTenantsPresent() {
        String[] beans = ctx.getBeanNamesForType(TenantService.class);
        assertThat(beans).hasSize(3);
        assertThat(ctx.containsBean("tenantService_apex_fintech")).isTrue();
    }
}
