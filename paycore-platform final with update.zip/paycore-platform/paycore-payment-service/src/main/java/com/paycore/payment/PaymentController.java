package com.paycore.payment;

import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * REST controller exposing payment endpoints for live demo.
 * Try:
 *   POST /payments  → triggers PRIMARY routing + fraud analysis
 *   GET  /payments/{accountId}/history → triggers REPLICA routing
 */
@RestController
@RequestMapping("/payments")
public class PaymentController {

    private final PaymentProcessingService paymentService;

    public PaymentController(PaymentProcessingService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping
    public PaymentResult processPayment(@RequestBody PaymentRequest request) {
        return paymentService.processPayment(request);
    }

    @GetMapping("/{accountId}/history")
    public String getHistory(@PathVariable String accountId) {
        return paymentService.getPaymentHistory(accountId);
    }

    // Quick demo endpoint — processes a suspicious payment
    @GetMapping("/demo/suspicious")
    public PaymentResult demoSuspicious() {
        return paymentService.processPayment(
            new PaymentRequest("ACME-001", new BigDecimal("500000"), "NG", 50));
    }

    // Quick demo endpoint — processes a normal payment
    @GetMapping("/demo/normal")
    public PaymentResult demoNormal() {
        return paymentService.processPayment(
            new PaymentRequest("ACME-002", new BigDecimal("250"), "US", 2));
    }
}
