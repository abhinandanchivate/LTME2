package com.paycore.datasource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import javax.sql.DataSource;
import java.util.Map;

/**
 * Section 4: Wires PRIMARY and REPLICA datasources into the RoutingDataSource proxy.
 * Uses H2 in-memory databases to simulate primary/replica topology.
 *
 * In production: replace EmbeddedDatabaseBuilder with HikariDataSource
 * configured via paycore.datasource.primary.* and paycore.datasource.replica.*
 */
@Configuration
public class DataSourceConfig {

    @Bean(name = "primaryDataSource")
    public DataSource primaryDataSource() {
        System.out.println("[DataSourceConfig] Creating PRIMARY datasource (H2 in-memory)");
        return new EmbeddedDatabaseBuilder()
                .setType(EmbeddedDatabaseType.H2)
                .setName("primaryDb")
                .build();
    }

    @Bean(name = "replicaDataSource")
    public DataSource replicaDataSource() {
        System.out.println("[DataSourceConfig] Creating REPLICA datasource (H2 in-memory)");
        return new EmbeddedDatabaseBuilder()
                .setType(EmbeddedDatabaseType.H2)
                .setName("replicaDb")
                .build();
    }

    @Primary
    @Bean(name = "routingDataSource")
    public DataSource routingDataSource(
            @Qualifier("primaryDataSource") DataSource primary,
            @Qualifier("replicaDataSource") DataSource replica) {

        RoutingDataSource router = new RoutingDataSource();
        router.setTargetDataSources(Map.of(
                DataSourceContext.DataSourceType.PRIMARY, primary,
                DataSourceContext.DataSourceType.REPLICA, replica
        ));
        router.setDefaultTargetDataSource(primary);
        router.afterPropertiesSet(); // Required: resolves lazy target datasources
        System.out.println("[DataSourceConfig] RoutingDataSource configured with PRIMARY + REPLICA");
        return router;
    }
}
