package com.paycore.payment;

import com.paycore.datasource.DataSourceContext;
import com.paycore.fraud.FraudAnalyzer;
import com.paycore.fraud.FraudResult;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Section 4 & 5 Demo Service
 *
 * Section 4: Demonstrates routing logic by explicitly setting DataSourceContext.
 * In production, @Transactional(readOnly=true) would automatically trigger
 * REPLICA routing via TransactionSynchronizationManager inside RoutingDataSource.
 *
 * Section 5: Uses ObjectProvider<FraudAnalyzer> to get a NEW prototype instance
 * per payment — guaranteeing state isolation between concurrent requests.
 */
@Service
public class PaymentProcessingService {

    private final ObjectProvider<FraudAnalyzer> fraudAnalyzerProvider;
    private final AtomicInteger processedCount = new AtomicInteger(0);

    public PaymentProcessingService(ObjectProvider<FraudAnalyzer> fraudAnalyzerProvider) {
        this.fraudAnalyzerProvider = fraudAnalyzerProvider;
    }

    /**
     * Section 4: Write path → PRIMARY datasource
     * Section 5: Fresh FraudAnalyzer per call via ObjectProvider
     */
    public PaymentResult processPayment(PaymentRequest request) {
        // Section 4: Explicitly route to PRIMARY for writes
        DataSourceContext.usePrimary();
        try {
            System.out.println("\n[PaymentProcessingService] Processing payment #"
                    + processedCount.incrementAndGet()
                    + " | account=" + request.accountId()
                    + " | amount=" + request.amount()
                    + " | DataSource=" + DataSourceContext.getCurrent());

            // Section 5: NEW FraudAnalyzer instance per payment — no shared state
            FraudAnalyzer analyzer = fraudAnalyzerProvider.getObject();
            analyzer.addSignal("amount:" + request.amount().toPlainString());
            analyzer.addSignal("country:" + request.destinationCountry());
            analyzer.addSignal("velocity:" + request.recentTransactionCount());

            FraudResult result = analyzer.evaluate();
            if (result.isSuspicious()) {
                System.out.println("[PaymentProcessingService] ❌ REJECTED: " + result.reason());
                return PaymentResult.rejected(result.reason());
            }

            System.out.println("[PaymentProcessingService] ✅ APPROVED");
            return PaymentResult.approved();
        } finally {
            DataSourceContext.clear(); // CRITICAL: prevent thread pool pollution
        }
    }

    /**
     * Section 4: Read path → REPLICA datasource
     */
    public String getPaymentHistory(String accountId) {
        DataSourceContext.useReplica();
        try {
            System.out.println("[PaymentProcessingService] Fetching history for " + accountId
                    + " → DataSource=" + DataSourceContext.getCurrent());
            return "Payment history for " + accountId + " (served from REPLICA)";
        } finally {
            DataSourceContext.clear();
        }
    }
}
