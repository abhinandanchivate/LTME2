package com.paycore;

import com.paycore.payment.PaymentProcessingService;
import com.paycore.payment.PaymentRequest;
import com.paycore.payment.PaymentResult;
import com.paycore.tenant.TenantService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import java.math.BigDecimal;
import java.util.Arrays;

/**
 * PayCore Platform — Spring Boot 4.0.5
 *
 * SPRING BOOT 4 KEY CHANGES IN THIS PROJECT:
 * ┌──────────────────────────────────────────────────────────────────────────┐
 * │ Section 6: BeanDefinitionRegistryPostProcessor → BeanRegistrar (new API) │
 * │ POMs:      spring-boot-starter-web → spring-boot-starter-web-classic     │
 * │ Tests:     spring-boot-starter-test → spring-boot-starter-test-classic   │
 * │ Java:      21 minimum enforced (same as our baseline)                    │
 * │ Framework: Spring Framework 7 (pulled in via spring-boot-starter-parent) │
 * └──────────────────────────────────────────────────────────────────────────┘
 *
 * REST endpoints:
 *   GET  /payments/demo/normal      → fraud analysis APPROVED
 *   GET  /payments/demo/suspicious  → fraud analysis REJECTED
 *   GET  /payments/{id}/history     → REPLICA datasource routing
 *   GET  /tenants                   → dynamically registered tenant beans
 */
@SpringBootApplication
public class PayCoreApplication {

    private static final Logger log = LoggerFactory.getLogger(PayCoreApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(PayCoreApplication.class, args);
    }

    @Bean
    ApplicationRunner startupDemo(ApplicationContext ctx,
                                   PaymentProcessingService paymentService) {
        return args -> {
            log.info("\n{}", "=".repeat(72));
            log.info("  PAYCORE PLATFORM — Spring Boot 4.0.5 Startup Demo");
            log.info("{}", "=".repeat(72));

            // ── Section 3: Ordering ──────────────────────────────────────────
            log.info("\n[§3] Auto-Configuration Ordering:");
            log.info("  SecurityFilterChain present: {}", ctx.containsBean("securityFilterChain"));

            // ── Section 4: Datasource Routing ───────────────────────────────
            log.info("\n[§4] Datasource Routing:");
            String history = paymentService.getPaymentHistory("ACME-001");
            log.info("  Read result: {}", history);

            // ── Section 5: Prototype Scope Isolation ─────────────────────────
            log.info("\n[§5] Prototype-in-Singleton (ObjectProvider):");

            PaymentResult normal = paymentService.processPayment(
                    new PaymentRequest("ACC-001", new BigDecimal("500"), "US", 3));
            log.info("  Normal  ($500):    {}", normal);

            PaymentResult suspicious = paymentService.processPayment(
                    new PaymentRequest("ACC-002", new BigDecimal("250000"), "NG", 55));
            log.info("  Suspicious ($250k): {}", suspicious);

            // ── Section 6: BeanRegistrar (Boot 4 NEW API) ───────────────────
            log.info("\n[§6] BeanRegistrar — Dynamic Tenant Beans (Spring Boot 4 API):");
            String[] tenantBeans = ctx.getBeanNamesForType(TenantService.class);
            log.info("  {} tenant bean(s) registered from clients.yaml:", tenantBeans.length);
            Arrays.stream(tenantBeans).forEach(name -> {
                TenantService ts = ctx.getBean(name, TenantService.class);
                log.info("  → {} : {}", name, ts);
            });

            log.info("\n{}", "=".repeat(72));
            log.info("  Server running → http://localhost:8080");
            log.info("  GET /payments/demo/normal | /payments/demo/suspicious | /tenants");
            log.info("{}", "=".repeat(72));
        };
    }
}
