package com.paycore.payment;

public record PaymentResult(boolean approved, String reason) {
    public static PaymentResult approved() {
        return new PaymentResult(true, "Approved");
    }
    public static PaymentResult rejected(String reason) {
        return new PaymentResult(false, reason);
    }
}
