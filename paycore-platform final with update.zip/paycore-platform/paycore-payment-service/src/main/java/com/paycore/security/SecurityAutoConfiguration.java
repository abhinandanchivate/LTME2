package com.paycore.security;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.context.annotation.Bean;

/**
 * Section 3: Auto-Configuration Ordering Demo
 * This runs BEFORE AuditAutoConfiguration (which declares @AutoConfigureAfter this class).
 */
@AutoConfiguration
public class SecurityAutoConfiguration {

    @Bean
    public SecurityFilterChain securityFilterChain() {
        System.out.println("[SecurityAutoConfig] Registering SecurityFilterChain");
        return new SecurityFilterChain("DEFAULT_SECURITY_CHAIN");
    }
}
