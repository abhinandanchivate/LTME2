package com.paycore.tenant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.aot.BeanRegistrar;
import org.springframework.beans.factory.aot.BeanRegistrationCode;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Section 6 — UPGRADED FOR SPRING BOOT 4: BeanRegistrar API
 *
 * Spring Boot 4 / Spring Framework 7 introduces BeanRegistrar as the modern,
 * AOT-friendly replacement for BeanDefinitionRegistryPostProcessor.
 *
 * WHY THE CHANGE?
 *   BeanDefinitionRegistryPostProcessor runs imperatively at startup — it cannot
 *   be analyzed by the AOT compiler ahead-of-time, which breaks GraalVM native images.
 *   BeanRegistrar is processed during the AOT phase, enabling native image support.
 *
 * LIFECYCLE COMPARISON:
 *   Boot 3.x BeanDefinitionRegistryPostProcessor:
 *     Context init → postProcessBeanDefinitionRegistry() → postProcessBeanFactory() → refresh
 *   Boot 4.x BeanRegistrar:
 *     AOT compilation → register()  [compile-time, native-image friendly]
 *     OR
 *     Runtime         → register()  [same interface, same logic, both modes]
 *
 * KEY RULES (same as before):
 *   - Do NOT @Autowired beans in here — resolved at registration time, not bean-lifecycle time
 *   - Use constructor args for TenantService, not property injection
 *   - Startup only — changing clients.yaml requires a restart
 */
@Component
public class TenantServiceRegistrar implements BeanRegistrar {

    private static final Logger log = LoggerFactory.getLogger(TenantServiceRegistrar.class);

    /**
     * Called by Spring Framework 7 during AOT processing or at runtime context initialization.
     * Registers a TenantService bean definition for every tenant in clients.yaml.
     *
     * @param registry  the bean definition registry — same API as before
     * @param env       Spring Environment — now injected directly (no more raw file parsing needed)
     */
    @Override
    public void register(BeanDefinitionRegistry registry, Environment env) {
        log.info("[TenantServiceRegistrar] Starting tenant bean registration (BeanRegistrar API)...");

        List<TenantConfig> tenants = TenantConfigLoader.load();

        if (tenants.isEmpty()) {
            log.warn("[TenantServiceRegistrar] No tenants found in clients.yaml");
            return;
        }

        for (TenantConfig tenant : tenants) {
            String beanName = "tenantService_" + tenant.id().toLowerCase();

            var beanDef = BeanDefinitionBuilder
                    .genericBeanDefinition(TenantService.class)
                    .addConstructorArgValue(tenant.id())
                    .addConstructorArgValue(tenant.settlementCurrency())
                    .addConstructorArgValue(tenant.dailyLimit())
                    .setSingleton(true)
                    .getBeanDefinition();

            registry.registerBeanDefinition(beanName, beanDef);
            log.info("[TenantServiceRegistrar] ✅ Registered '{}' | tenant={} currency={} limit={}",
                    beanName, tenant.id(), tenant.settlementCurrency(), tenant.dailyLimit());
        }

        log.info("[TenantServiceRegistrar] Done — {} tenant beans registered.", tenants.size());
    }
}
