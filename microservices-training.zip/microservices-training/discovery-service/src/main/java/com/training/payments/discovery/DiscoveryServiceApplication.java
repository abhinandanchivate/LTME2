package com.training.payments.discovery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * TRAINING MODULE: Day 2 - Gateway & Discovery
 *
 * Eureka Discovery Server.
 *
 * @EnableEurekaServer: Activates Eureka registry server.
 * Once running, navigate to http://localhost:8761 to see the
 * Eureka dashboard showing all registered service instances.
 *
 * DEMO FLOW:
 * 1. Start this service first
 * 2. Start payment-service -> watch it appear in Eureka dashboard
 * 3. Start order-service -> watch it appear
 * 4. Start gateway-service -> watch it appear
 * 5. Scale payment-service (start another instance on port 8082)
 *    -> Watch TWO instances appear in Eureka for payment-service
 * 6. Gateway automatically load-balances between both instances
 */
@SpringBootApplication
@EnableEurekaServer
public class DiscoveryServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(DiscoveryServiceApplication.class, args);
    }
}