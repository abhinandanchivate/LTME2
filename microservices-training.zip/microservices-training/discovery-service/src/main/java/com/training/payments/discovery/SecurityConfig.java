package com.training.payments.discovery;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

/**
 * TRAINING MODULE: Day 2 - Discovery Security
 *
 * Basic security for Eureka server.
 * In production: Use mutual TLS between services and Eureka.
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // Disable CSRF for Eureka dashboard compatibility
            .csrf(csrf -> csrf
                .ignoringRequestMatchers("/eureka/**"))
            .authorizeHttpRequests(auth -> auth
                // Eureka endpoints require authentication
                .requestMatchers("/eureka/**").authenticated()
                // Actuator endpoints open for monitoring
                .requestMatchers("/actuator/**").permitAll()
                .anyRequest().authenticated())
            .httpBasic(basic -> {}); // Basic auth for Eureka clients

        return http.build();
    }
}