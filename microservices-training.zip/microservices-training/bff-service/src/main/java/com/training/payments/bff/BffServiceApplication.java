package com.training.payments.bff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;

/**
 * TRAINING MODULE: Day 3 - BFF Pattern
 *
 * Backend for Frontend service.
 * Aggregates data from payment-service and order-service.
 *
 * @LoadBalanced RestTemplate: Uses Eureka to resolve service names
 * http://payment-service/api/v2/payments -> resolves to actual instance
 */
@SpringBootApplication
@EnableDiscoveryClient
public class BffServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BffServiceApplication.class, args);
    }

    /**
     * Load-balanced RestTemplate.
     * Automatically resolves lb://service-name via Eureka.
     * Round-robin load balancing between instances.
     */
    @Bean
    @LoadBalanced
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}