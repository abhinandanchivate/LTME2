package com.training.payments.bff.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * TRAINING MODULE: Day 3 - BFF Aggregated Response
 *
 * Aggregated response for mobile payment dashboard.
 * Contains EXACTLY what mobile needs - no more, no less.
 *
 * ANTI-PATTERN: Returning full payment + full order + full customer
 * wastes mobile bandwidth and battery.
 *
 * BFF PATTERN: Return only fields the mobile UI actually displays.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentDashboardResponse {

    // Summary stats (top of dashboard)
    private DashboardSummary summary;

    // Recent payments (feed)
    private List<PaymentSummaryItem> recentPayments;

    // Current order status (if active)
    private ActiveOrderStatus activeOrder;

    // Generated at timestamp
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant generatedAt;

    /**
     * Top-level summary statistics
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DashboardSummary {
        private BigDecimal totalSpent;
        private String currency;
        private int totalPayments;
        private int successfulPayments;
        private int failedPayments;
        private BigDecimal averagePayment;
    }

    /**
     * Lightweight payment item for list view
     * Mobile only shows: amount, status, date, merchant
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PaymentSummaryItem {
        private String paymentId;
        private BigDecimal amount;
        private String currency;
        private String status;
        private String paymentMethod;

        @JsonFormat(shape = JsonFormat.Shape.STRING)
        private Instant date;
    }

    /**
     * Active order tracking (simplified)
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ActiveOrderStatus {
        private String orderId;
        private String status;
        private String statusDescription; // Human-readable: "Payment processing..."
        private BigDecimal amount;
        private String currency;
    }
}