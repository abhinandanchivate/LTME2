package com.training.payments.bff.service;

import com.training.payments.bff.dto.PaymentDashboardResponse;
import com.training.payments.common.dto.PagedResponse;
import com.training.payments.common.dto.PaymentResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

/**
 * TRAINING MODULE: Day 3 - BFF Aggregation Service
 *
 * Aggregates data from multiple downstream services.
 *
 * PARALLEL CALLS PATTERN:
 * Instead of sequential calls (slow):
 *   Call payment-service (200ms)
 *   Call order-service   (150ms)
 *   Total: 350ms
 *
 * Use parallel calls (fast):
 *   Call payment-service \
 *                         } simultaneously -> Total: 200ms (slowest)
 *   Call order-service   /
 *
 * Implemented using CompletableFuture for parallel execution.
 *
 * CQRS MENTION:
 * TRAINING Day 3: BFF is related to CQRS Read Side.
 * Read-optimized aggregated view vs normalized write models.
 * BFF could query a denormalized read model (Redis/Elasticsearch)
 * instead of calling multiple services.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class PaymentAggregationService {

    private final RestTemplate restTemplate;

    // Service URLs resolved by Eureka load balancer
    private static final String PAYMENT_SERVICE_URL = "http://payment-service";
    private static final String ORDER_SERVICE_URL   = "http://order-service";

    /**
     * Build mobile payment dashboard by aggregating from multiple services.
     *
     * PARALLEL AGGREGATION:
     * 1. Fetch recent payments (payment-service) }
     *                                            } in parallel
     * 2. Fetch active orders (order-service)     }
     * 3. Combine and return unified response
     */
    public PaymentDashboardResponse buildDashboard(String customerId) {
        log.info("[BFF] Building payment dashboard for customer: {}", customerId);

        // ============================================================
        // PARALLEL FETCH: Call both services simultaneously
        // ============================================================
        CompletableFuture<List<PaymentResponse>> paymentsFuture =
                CompletableFuture.supplyAsync(() -> fetchRecentPayments(customerId));

        CompletableFuture<Object> activeOrderFuture =
                CompletableFuture.supplyAsync(() -> fetchActiveOrder(customerId));

        // Wait for both to complete
        CompletableFuture.allOf(paymentsFuture, activeOrderFuture).join();

        List<PaymentResponse> payments = paymentsFuture.join();
        Map<String, Object> activeOrderData = (Map<String, Object>) activeOrderFuture.join();

        log.info("[BFF] Aggregated {} payments + order data for customer: {}",
                payments.size(), customerId);

        // ============================================================
        // AGGREGATE: Build unified mobile-optimized response
        // ============================================================
        return PaymentDashboardResponse.builder()
                .summary(buildSummary(payments))
                .recentPayments(buildPaymentItems(payments))
                .activeOrder(buildActiveOrder(activeOrderData))
                .generatedAt(Instant.now())
                .build();
    }

    /**
     * Fetch recent payments from payment-service (last 10)
     * Uses cursor pagination (v2 API)
     */
    private List<PaymentResponse> fetchRecentPayments(String customerId) {
        try {
            String url = PAYMENT_SERVICE_URL +
                    "/api/v2/payments?customerId=" + customerId + "&size=10";

            ResponseEntity<PagedResponse<PaymentResponse>> response = restTemplate.exchange(
                    url, HttpMethod.GET, null,
                    new ParameterizedTypeReference<PagedResponse<PaymentResponse>>() {});

            if (response.getBody() != null && response.getBody().getData() != null) {
                return response.getBody().getData();
            }
        } catch (Exception e) {
            // Graceful degradation: Return empty list if payment-service is down
            // BFF should NOT fail entirely if one downstream service fails
            log.error("[BFF] Failed to fetch payments for {}: {}", customerId, e.getMessage());
        }
        return new ArrayList<>();
    }

    /**
     * Fetch active order from order-service
     * Returns Map for flexibility (avoids tight DTO coupling)
     */
    private Object fetchActiveOrder(String customerId) {
        try {
            String url = ORDER_SERVICE_URL +
                    "/api/v1/orders?customerId=" + customerId;

            ResponseEntity<List<Map<String, Object>>> response = restTemplate.exchange(
                    url, HttpMethod.GET, null,
                    new ParameterizedTypeReference<List<Map<String, Object>>>() {});

            if (response.getBody() != null && !response.getBody().isEmpty()) {
                // Return first (most recent) order
                return response.getBody().get(0);
            }
        } catch (Exception e) {
            log.error("[BFF] Failed to fetch orders for {}: {}", customerId, e.getMessage());
        }
        return null;
    }

    private PaymentDashboardResponse.DashboardSummary buildSummary(
            List<PaymentResponse> payments) {
        long successful = payments.stream()
                .filter(p -> "COMPLETED".equals(p.getStatus().name()))
                .count();
        long failed = payments.stream()
                .filter(p -> "FAILED".equals(p.getStatus().name()))
                .count();
        BigDecimal total = payments.stream()
                .filter(p -> "COMPLETED".equals(p.getStatus().name()))
                .map(PaymentResponse::getAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal average = successful > 0
                ? total.divide(BigDecimal.valueOf(successful), 2, RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

        return PaymentDashboardResponse.DashboardSummary.builder()
                .totalSpent(total)
                .currency(payments.isEmpty() ? "USD" : payments.get(0).getCurrency())
                .totalPayments(payments.size())
                .successfulPayments((int) successful)
                .failedPayments((int) failed)
                .averagePayment(average)
                .build();
    }

    private List<PaymentDashboardResponse.PaymentSummaryItem> buildPaymentItems(
            List<PaymentResponse> payments) {
        return payments.stream()
                .map(p -> PaymentDashboardResponse.PaymentSummaryItem.builder()
                        .paymentId(p.getPaymentId())
                        .amount(p.getAmount())
                        .currency(p.getCurrency())
                        .status(p.getStatus().name())
                        .paymentMethod(p.getPaymentMethod())
                        .date(p.getCreatedAt())
                        .build())
                .collect(Collectors.toList());
    }

    @SuppressWarnings("unchecked")
    private PaymentDashboardResponse.ActiveOrderStatus buildActiveOrder(Object orderData) {
        if (orderData == null) return null;
        Map<String, Object> order = (Map<String, Object>) orderData;

        String status = (String) order.getOrDefault("status", "UNKNOWN");
        String statusDesc = switch (status) {
            case "AWAITING_PAYMENT" -> "Payment processing...";
            case "CONFIRMED"        -> "Order confirmed!";
            case "COMPLETED"        -> "Order fulfilled";
            case "CANCELLED"        -> "Order cancelled";
            default                 -> "Processing";
        };

        return PaymentDashboardResponse.ActiveOrderStatus.builder()
                .orderId((String) order.get("orderId"))
                .status(status)
                .statusDescription(statusDesc)
                .amount(order.get("amount") != null
                        ? new BigDecimal(order.get("amount").toString())
                        : BigDecimal.ZERO)
                .currency((String) order.getOrDefault("currency", "USD"))
                .build();
    }
}