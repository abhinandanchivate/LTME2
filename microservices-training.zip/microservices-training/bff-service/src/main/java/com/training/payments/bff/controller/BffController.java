package com.training.payments.bff.controller;

import com.training.payments.bff.dto.PaymentDashboardResponse;
import com.training.payments.bff.service.PaymentAggregationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * TRAINING MODULE: Day 3 - BFF Controller
 *
 * BFF endpoints - aggregated, client-optimized responses.
 *
 * PATTERNS DEMONSTRATED:
 * 1. BFF Pattern: Aggregated mobile-optimized endpoint
 * 2. API Gateway Pattern: Accessed via gateway at /bff/**
 * 3. CQRS Read side: Read-optimized view aggregation
 */
@RestController
@RequestMapping("/payment-summary")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "BFF", description = "Backend for Frontend - Aggregated responses for mobile/web")
public class BffController {

    private final PaymentAggregationService aggregationService;

    /**
     * Mobile payment dashboard.
     *
     * Single endpoint replacing 3 separate calls:
     * Aggregates: recent payments + order status + summary stats
     *
     * Access via gateway: GET http://localhost:8080/bff/payment-summary/dashboard?customerId=C1
     * Direct access:      GET http://localhost:8083/payment-summary/dashboard?customerId=C1
     */
    @Operation(
        summary = "Get payment dashboard (BFF aggregated)",
        description = """
            Returns an aggregated mobile-optimized payment dashboard.
            
            **BFF Pattern**: This single endpoint replaces 3 separate API calls:
            1. GET /api/v2/payments (recent payments)
            2. GET /api/v1/orders (active order)
            
            Data is fetched in parallel and combined server-side,
            reducing mobile round trips from 3 to 1.
            """
    )
    @GetMapping("/dashboard")
    public ResponseEntity<PaymentDashboardResponse> getDashboard(
            @RequestParam String customerId) {
        log.info("[BFF] Dashboard request for customer: {}", customerId);
        PaymentDashboardResponse response =
                aggregationService.buildDashboard(customerId);
        return ResponseEntity.ok(response);
    }
}