<#
.SYNOPSIS
    Microservices Training - Pre-Demo Validation Script
    Validates project structure, builds, infrastructure, and runs smoke tests.

.DESCRIPTION
    This script performs comprehensive pre-demo checks:
    1. PHASE 1: Environment Prerequisites (Java, Maven, Docker)
    2. PHASE 2: Project Structure Validation (all files exist)
    3. PHASE 3: Maven Build (compile, test, package)
    4. PHASE 4: Docker Infrastructure (Redis, Kafka, Zipkin, etc.)
    5. PHASE 5: Service Startup and Health Checks
    6. PHASE 6: Functional Smoke Tests (API calls, Saga, Cache, etc.)
    7. PHASE 7: Summary Report

.PARAMETER SkipBuild
    Skip Maven build phase (use if already built)

.PARAMETER SkipInfra
    Skip Docker infrastructure startup (use if already running)

.PARAMETER SkipTests
    Skip Maven unit tests during build

.PARAMETER StartServices
    Also start all application services after infrastructure

.PARAMETER FixIssues
    Attempt to auto-fix common issues (create missing dirs, etc.)

.PARAMETER VerboseOutput
    Show detailed output for each check

.EXAMPLE
    .\validate-demo.ps1
    .\validate-demo.ps1 -SkipBuild -StartServices
    .\validate-demo.ps1 -FixIssues -VerboseOutput
    .\validate-demo.ps1 -SkipInfra -SkipBuild

.NOTES
    Requires: Windows 11, Java 17+, Maven 3.9+, Docker Desktop
    Author: Microservices Training Team
    Version: 1.1.0 (ASCII-safe, Windows compatible)
#>

[CmdletBinding()]
param(
    [switch]$SkipBuild,
    [switch]$SkipInfra,
    [switch]$SkipTests,
    [switch]$StartServices,
    [switch]$FixIssues,
    [switch]$VerboseOutput
)

# ============================================================
# CONFIGURATION
# ============================================================
$ErrorActionPreference = "Continue"
$ProgressPreference = "SilentlyContinue"

# Project root (script should be in project root)
$PROJECT_ROOT = $PSScriptRoot
if (-not $PROJECT_ROOT) {
    $PROJECT_ROOT = (Get-Location).Path
}

# Service ports
$PORTS = @{
    "discovery-service" = 8761
    "gateway-service"   = 8080
    "payment-service"   = 8081
    "order-service"     = 8082
    "bff-service"       = 8083
    "redis"             = 6379
    "kafka"             = 9092
    "zipkin"            = 9411
    "prometheus"        = 9090
    "grafana"           = 3000
    "kafka-ui"          = 8090
    "redis-commander"   = 8091
    "nginx-cdn"         = 8084
}

# Health check URLs
$HEALTH_URLS = @{
    "discovery-service" = "http://localhost:8761/actuator/health"
    "gateway-service"   = "http://localhost:8080/actuator/health"
    "payment-service"   = "http://localhost:8081/actuator/health"
    "order-service"     = "http://localhost:8082/actuator/health"
    "bff-service"       = "http://localhost:8083/actuator/health"
    "zipkin"            = "http://localhost:9411/health"
    "prometheus"        = "http://localhost:9090/-/healthy"
    "grafana"           = "http://localhost:3000/api/health"
    "kafka-ui"          = "http://localhost:8090/actuator/health"
    "redis-commander"   = "http://localhost:8091/"
    "nginx-cdn"         = "http://localhost:8084/health"
}

# Timeouts
$HTTP_TIMEOUT_SECONDS      = 5
$SERVICE_STARTUP_TIMEOUT   = 120
$INFRA_STARTUP_TIMEOUT     = 90

# ============================================================
# REPORTING VARIABLES
# ============================================================
$script:TotalChecks   = 0
$script:PassedChecks  = 0
$script:FailedChecks  = 0
$script:WarningChecks = 0
$script:SkippedChecks = 0
$script:Errors        = [System.Collections.ArrayList]::new()
$script:Warnings      = [System.Collections.ArrayList]::new()
$script:FixesApplied  = [System.Collections.ArrayList]::new()
$script:StartTime     = Get-Date

# ============================================================
# UTILITY FUNCTIONS
# ============================================================

function Write-Banner {
    param([string]$Text)
    $line = "=" * 70
    Write-Host ""
    Write-Host $line -ForegroundColor Cyan
    Write-Host "  $Text" -ForegroundColor Cyan
    Write-Host $line -ForegroundColor Cyan
    Write-Host ""
}

function Write-Phase {
    param([string]$Phase, [string]$Description)
    Write-Host ""
    Write-Host ("~" * 55) -ForegroundColor DarkCyan
    Write-Host "  PHASE $Phase : $Description" -ForegroundColor Yellow
    Write-Host ("~" * 55) -ForegroundColor DarkCyan
}

function Write-Check {
    param(
        [string]$Name,
        [string]$Status,
        [string]$Details = ""
    )

    $script:TotalChecks++

    switch ($Status) {
        "PASS" {
            $icon = "[OK]"
            $script:PassedChecks++
        }
        "FAIL" {
            $icon = "[FAIL]"
            $script:FailedChecks++
            $null = $script:Errors.Add("$Name : $Details")
        }
        "WARN" {
            $icon = "[WARN]"
            $script:WarningChecks++
            $null = $script:Warnings.Add("$Name : $Details")
        }
        "SKIP" {
            $icon = "[SKIP]"
            $script:SkippedChecks++
        }
        "INFO" {
            $icon = "[INFO]"
            $script:TotalChecks--
        }
        "FIX" {
            $icon = "[FIX]"
            $null = $script:FixesApplied.Add("$Name : $Details")
        }
        default {
            $icon = "[--]"
        }
    }

    $color = switch ($Status) {
        "PASS" { "Green" }
        "FAIL" { "Red" }
        "WARN" { "Yellow" }
        "SKIP" { "DarkGray" }
        "INFO" { "Cyan" }
        "FIX"  { "Magenta" }
        default { "White" }
    }

    $detailText = if ($Details) { " - $Details" } else { "" }
    Write-Host "  $icon $Name$detailText" -ForegroundColor $color
}

function Test-Port {
    param([int]$Port, [int]$Timeout = 2)
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient
        $result = $tcp.BeginConnect("localhost", $Port, $null, $null)
        $success = $result.AsyncWaitHandle.WaitOne($Timeout * 1000)
        if ($success) {
            $tcp.EndConnect($result)
            $tcp.Close()
            return $true
        }
        $tcp.Close()
        return $false
    }
    catch {
        return $false
    }
}

function Test-HttpEndpoint {
    param(
        [string]$Url,
        [int]$TimeoutSec = $HTTP_TIMEOUT_SECONDS,
        [string]$Method = "GET",
        [hashtable]$Headers = @{},
        [string]$Body = "",
        [int[]]$ExpectedStatusCodes = @(200)
    )
    try {
        $params = @{
            Uri             = $Url
            Method          = $Method
            TimeoutSec      = $TimeoutSec
            UseBasicParsing = $true
            ErrorAction     = "Stop"
        }
        if ($Headers.Count -gt 0) {
            $params["Headers"] = $Headers
        }
        if ($Body) {
            $params["Body"] = $Body
            if (-not $Headers.ContainsKey("Content-Type")) {
                $params["ContentType"] = "application/json"
            }
        }

        $response = Invoke-WebRequest @params
        $statusCode = $response.StatusCode

        return @{
            Success    = ($ExpectedStatusCodes -contains $statusCode)
            StatusCode = $statusCode
            Body       = $response.Content
            Headers    = $response.Headers
        }
    }
    catch {
        $statusCode = 0
        if ($_.Exception.Response) {
            $statusCode = [int]$_.Exception.Response.StatusCode
        }
        return @{
            Success    = ($ExpectedStatusCodes -contains $statusCode)
            StatusCode = $statusCode
            Body       = $_.Exception.Message
            Headers    = @{}
            Error      = $_.Exception.Message
        }
    }
}

function Wait-ForService {
    param(
        [string]$Name,
        [string]$HealthUrl,
        [int]$TimeoutSeconds = $SERVICE_STARTUP_TIMEOUT,
        [int]$IntervalSeconds = 5
    )

    $elapsed = 0
    while ($elapsed -lt $TimeoutSeconds) {
        $result = Test-HttpEndpoint -Url $HealthUrl -TimeoutSec 3
        if ($result.Success) {
            return $true
        }
        Start-Sleep -Seconds $IntervalSeconds
        $elapsed += $IntervalSeconds
        if ($VerboseOutput) {
            Write-Host "    Waiting for $Name... ($elapsed/$TimeoutSeconds sec)" -ForegroundColor DarkGray
        }
    }
    return $false
}

function Get-JavaVersion {
    try {
        $output = & java -version 2>&1 | Out-String
        if ($output -match '"(\d+)') {
            return [int]$Matches[1]
        }
        if ($output -match 'version\s+"(\d+)') {
            return [int]$Matches[1]
        }
        if ($output -match '\s(\d+)\.') {
            return [int]$Matches[1]
        }
        return 0
    }
    catch {
        return 0
    }
}

function Get-MavenVersion {
    try {
        $output = & mvn --version 2>&1 | Out-String
        if ($output -match '(\d+\.\d+\.\d+)') {
            return $Matches[1]
        }
        return "0.0.0"
    }
    catch {
        return "0.0.0"
    }
}

function Get-DockerVersion {
    try {
        $output = & docker --version 2>&1 | Out-String
        if ($output -match '(\d+\.\d+\.\d+)') {
            return $Matches[1]
        }
        return "0.0.0"
    }
    catch {
        return "0.0.0"
    }
}

function Get-DockerComposeVersion {
    try {
        $output = & docker compose version 2>&1 | Out-String
        if ($output -match '(\d+\.\d+\.\d+)') {
            return $Matches[1]
        }
        return "0.0.0"
    }
    catch {
        try {
            $output = & docker-compose --version 2>&1 | Out-String
            if ($output -match '(\d+\.\d+\.\d+)') {
                return $Matches[1]
            }
        }
        catch {}
        return "0.0.0"
    }
}


# ============================================================
# PHASE 1: ENVIRONMENT PREREQUISITES
# ============================================================
function Test-Prerequisites {
    Write-Phase "1" "ENVIRONMENT PREREQUISITES"

    # ---- Java Version ----
    $javaVersion = Get-JavaVersion
    if ($javaVersion -ge 17) {
        Write-Check "Java Version" "PASS" "Java $javaVersion detected"
    }
    elseif ($javaVersion -gt 0) {
        Write-Check "Java Version" "FAIL" "Java $javaVersion detected. Requires Java 17+"
    }
    else {
        Write-Check "Java Version" "FAIL" "Java not found in PATH. Install JDK 17+"
    }

    # ---- JAVA_HOME ----
    $javaHome = $env:JAVA_HOME
    if ($javaHome -and (Test-Path $javaHome)) {
        Write-Check "JAVA_HOME" "PASS" $javaHome
    }
    elseif ($javaHome) {
        Write-Check "JAVA_HOME" "WARN" "JAVA_HOME set but path does not exist: $javaHome"
    }
    else {
        Write-Check "JAVA_HOME" "WARN" "JAVA_HOME not set. Maven may fail."
    }

    # ---- Maven Version ----
    $mvnVersion = Get-MavenVersion
    if ($mvnVersion -ne "0.0.0") {
        $parts = $mvnVersion.Split('.')
        $major = [int]$parts[0]
        $minor = [int]$parts[1]
        if ($major -ge 3 -and $minor -ge 8) {
            Write-Check "Maven Version" "PASS" "Maven $mvnVersion"
        }
        else {
            Write-Check "Maven Version" "WARN" "Maven $mvnVersion. Recommend 3.8+"
        }
    }
    else {
        Write-Check "Maven Version" "FAIL" "Maven not found in PATH. Install Maven 3.9+"
    }

    # ---- Docker ----
    $dockerVersion = Get-DockerVersion
    if ($dockerVersion -ne "0.0.0") {
        Write-Check "Docker Version" "PASS" "Docker $dockerVersion"
    }
    else {
        Write-Check "Docker Version" "FAIL" "Docker not found. Install Docker Desktop."
    }

    # ---- Docker Daemon Running ----
    try {
        $dockerInfo = & docker info 2>&1 | Out-String
        if ($dockerInfo -match "Server Version") {
            Write-Check "Docker Daemon" "PASS" "Docker daemon is running"
        }
        else {
            Write-Check "Docker Daemon" "FAIL" "Docker daemon not running. Start Docker Desktop."
        }
    }
    catch {
        Write-Check "Docker Daemon" "FAIL" "Cannot connect to Docker daemon"
    }

    # ---- Docker Compose ----
    $composeVersion = Get-DockerComposeVersion
    if ($composeVersion -ne "0.0.0") {
        Write-Check "Docker Compose" "PASS" "Docker Compose $composeVersion"
    }
    else {
        Write-Check "Docker Compose" "FAIL" "Docker Compose not found"
    }

    # ---- Available RAM ----
    try {
        $os = Get-CimInstance -ClassName Win32_OperatingSystem
        $freeMemGB = [math]::Round($os.FreePhysicalMemory / 1MB, 2)
        $totalMemGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
        if ($freeMemGB -ge 4) {
            Write-Check "Available RAM" "PASS" "${freeMemGB}GB free / ${totalMemGB}GB total"
        }
        elseif ($freeMemGB -ge 2) {
            Write-Check "Available RAM" "WARN" "${freeMemGB}GB free. Recommend 4GB+ free for all services."
        }
        else {
            Write-Check "Available RAM" "FAIL" "Only ${freeMemGB}GB free. Need at least 4GB for demo."
        }
    }
    catch {
        Write-Check "Available RAM" "WARN" "Cannot determine available RAM"
    }

    # ---- Available Disk Space ----
    try {
        $driveLetter = (Get-Location).Path.Substring(0, 1)
        $driveInfo = Get-PSDrive -Name $driveLetter -ErrorAction SilentlyContinue
        if ($driveInfo -and $driveInfo.Free) {
            $freeSpaceGB = [math]::Round($driveInfo.Free / 1GB, 2)
            if ($freeSpaceGB -ge 5) {
                Write-Check "Disk Space" "PASS" "${freeSpaceGB}GB free on ${driveLetter}: drive"
            }
            elseif ($freeSpaceGB -ge 2) {
                Write-Check "Disk Space" "WARN" "${freeSpaceGB}GB free. Docker images need space."
            }
            else {
                Write-Check "Disk Space" "FAIL" "Only ${freeSpaceGB}GB free. Need 5GB+ for Docker images."
            }
        }
        else {
            Write-Check "Disk Space" "WARN" "Cannot determine disk space for drive ${driveLetter}:"
        }
    }
    catch {
        Write-Check "Disk Space" "WARN" "Cannot determine disk space"
    }

    # ---- Port Availability ----
    Write-Host ""
    Write-Host "  Checking port availability..." -ForegroundColor DarkGray
    $portsInUse = 0
    foreach ($svc in $PORTS.GetEnumerator()) {
        $portInUse = Test-Port -Port $svc.Value -Timeout 1
        if ($portInUse) {
            Write-Check "Port $($svc.Value) ($($svc.Key))" "WARN" "Port already in use (may be running already)"
            $portsInUse++
        }
        else {
            if ($VerboseOutput) {
                Write-Check "Port $($svc.Value) ($($svc.Key))" "PASS" "Available"
            }
        }
    }
    if ($portsInUse -eq 0) {
        Write-Check "All Ports" "PASS" "All required ports are available"
    }

    # ---- curl available ----
    try {
        $curlCheck = Get-Command curl.exe -ErrorAction SilentlyContinue
        if ($curlCheck) {
            Write-Check "curl" "PASS" "Found at $($curlCheck.Source)"
        }
        else {
            # PowerShell aliases curl to Invoke-WebRequest, check native curl
            $curlNative = & where.exe curl 2>&1 | Out-String
            if ($curlNative -match "curl") {
                Write-Check "curl" "PASS" "Available"
            }
            else {
                Write-Check "curl" "WARN" "Native curl not found. Demos use curl commands."
            }
        }
    }
    catch {
        Write-Check "curl" "WARN" "curl check failed. Some demos require curl."
    }
}


# ============================================================
# PHASE 2: PROJECT STRUCTURE VALIDATION
# ============================================================
function Test-ProjectStructure {
    Write-Phase "2" "PROJECT STRUCTURE VALIDATION"

    # ---- Required Files ----
    $requiredFiles = @(
        # Parent
        "pom.xml",

        # Payment Common
        "payment-common/pom.xml",
        "payment-common/src/main/java/com/training/payments/common/model/Payment.java",
        "payment-common/src/main/java/com/training/payments/common/model/PaymentStatus.java",
        "payment-common/src/main/java/com/training/payments/common/dto/PaymentRequest.java",
        "payment-common/src/main/java/com/training/payments/common/dto/PaymentResponse.java",
        "payment-common/src/main/java/com/training/payments/common/dto/PagedResponse.java",
        "payment-common/src/main/java/com/training/payments/common/dto/ErrorResponse.java",
        "payment-common/src/main/java/com/training/payments/common/exception/PaymentException.java",
        "payment-common/src/main/java/com/training/payments/common/event/PaymentEvent.java",

        # Payment Service
        "payment-service/pom.xml",
        "payment-service/Dockerfile",
        "payment-service/src/main/resources/application.yml",
        "payment-service/src/main/resources/logback-spring.xml",
        "payment-service/src/main/java/com/training/payments/service/PaymentServiceApplication.java",
        "payment-service/src/main/java/com/training/payments/service/config/OpenApiConfig.java",
        "payment-service/src/main/java/com/training/payments/service/config/CacheConfig.java",
        "payment-service/src/main/java/com/training/payments/service/config/ResilienceConfig.java",
        "payment-service/src/main/java/com/training/payments/service/entity/PaymentEntity.java",
        "payment-service/src/main/java/com/training/payments/service/repository/PaymentRepository.java",
        "payment-service/src/main/java/com/training/payments/service/service/PaymentService.java",
        "payment-service/src/main/java/com/training/payments/service/service/IdempotencyService.java",
        "payment-service/src/main/java/com/training/payments/service/mapper/PaymentMapper.java",
        "payment-service/src/main/java/com/training/payments/service/psp/PspClient.java",
        "payment-service/src/main/java/com/training/payments/service/psp/PspChargeRequest.java",
        "payment-service/src/main/java/com/training/payments/service/psp/PspResponse.java",
        "payment-service/src/main/java/com/training/payments/service/controller/PaymentControllerV1.java",
        "payment-service/src/main/java/com/training/payments/service/controller/PaymentControllerV2.java",
        "payment-service/src/main/java/com/training/payments/service/controller/GlobalExceptionHandler.java",
        "payment-service/src/main/java/com/training/payments/service/filter/RateLimitFilter.java",
        "payment-service/src/main/java/com/training/payments/service/observability/ObservabilityConfig.java",
        "payment-service/src/main/java/com/training/payments/service/observability/PaymentMetrics.java",
        "payment-service/src/main/java/com/training/payments/service/observability/TraceFilter.java",
        "payment-service/src/main/java/com/training/payments/service/patterns/PatternsController.java",
        "payment-service/src/main/java/com/training/payments/service/edge/EdgeSimulationController.java",

        # Discovery Service
        "discovery-service/pom.xml",
        "discovery-service/Dockerfile",
        "discovery-service/src/main/resources/application.yml",
        "discovery-service/src/main/java/com/training/payments/discovery/DiscoveryServiceApplication.java",
        "discovery-service/src/main/java/com/training/payments/discovery/SecurityConfig.java",

        # Gateway Service
        "gateway-service/pom.xml",
        "gateway-service/Dockerfile",
        "gateway-service/src/main/resources/application.yml",
        "gateway-service/src/main/java/com/training/payments/gateway/GatewayServiceApplication.java",
        "gateway-service/src/main/java/com/training/payments/gateway/config/GatewayConfig.java",
        "gateway-service/src/main/java/com/training/payments/gateway/controller/FallbackController.java",

        # Order Service
        "order-service/pom.xml",
        "order-service/Dockerfile",
        "order-service/src/main/resources/application.yml",
        "order-service/src/main/java/com/training/payments/order/OrderServiceApplication.java",
        "order-service/src/main/java/com/training/payments/order/model/Order.java",
        "order-service/src/main/java/com/training/payments/order/model/OrderStatus.java",
        "order-service/src/main/java/com/training/payments/order/event/OrderEvent.java",
        "order-service/src/main/java/com/training/payments/order/repository/OrderRepository.java",
        "order-service/src/main/java/com/training/payments/order/service/OrderService.java",
        "order-service/src/main/java/com/training/payments/order/saga/PaymentEventConsumer.java",
        "order-service/src/main/java/com/training/payments/order/saga/OrderEventConsumer.java",
        "order-service/src/main/java/com/training/payments/order/controller/OrderController.java",
        "order-service/src/main/java/com/training/payments/order/dto/CreateOrderRequest.java",
        "order-service/src/main/java/com/training/payments/order/dto/OrderResponse.java",

        # BFF Service
        "bff-service/pom.xml",
        "bff-service/Dockerfile",
        "bff-service/src/main/resources/application.yml",
        "bff-service/src/main/java/com/training/payments/bff/BffServiceApplication.java",
        "bff-service/src/main/java/com/training/payments/bff/dto/PaymentDashboardResponse.java",
        "bff-service/src/main/java/com/training/payments/bff/service/PaymentAggregationService.java",
        "bff-service/src/main/java/com/training/payments/bff/controller/BffController.java",

        # Infrastructure configs
        "docker-compose.yml",
        "infra/redis/redis.conf",
        "infra/prometheus/prometheus.yml",
        "infra/nginx/nginx.conf",
        "infra/nginx/static/ui/index.html",

        # Documentation
        "playbook.md"
    )

    $missingFiles = @()
    $presentFiles = 0

    foreach ($file in $requiredFiles) {
        $fullPath = Join-Path $PROJECT_ROOT $file
        if (Test-Path $fullPath) {
            $presentFiles++
            if ($VerboseOutput) {
                Write-Check "File: $file" "PASS"
            }
        }
        else {
            $missingFiles += $file
            Write-Check "File: $file" "FAIL" "MISSING"

            # ---- Auto-fix: Create missing directories ----
            if ($FixIssues) {
                $dir = Split-Path $fullPath -Parent
                if (-not (Test-Path $dir)) {
                    New-Item -ItemType Directory -Path $dir -Force | Out-Null
                    Write-Check "Created directory: $dir" "FIX" "Auto-created"
                }
            }
        }
    }

    Write-Host ""
    Write-Check "File Summary" "INFO" "$presentFiles/$($requiredFiles.Count) files present"

    if ($missingFiles.Count -gt 0) {
        Write-Check "Missing Files" "FAIL" "$($missingFiles.Count) files missing"
        if (-not $VerboseOutput) {
            Write-Host ""
            Write-Host "  Missing files:" -ForegroundColor Red
            foreach ($f in $missingFiles) {
                Write-Host "    - $f" -ForegroundColor Red
            }
        }
    }
    else {
        Write-Check "All Required Files" "PASS" "All $($requiredFiles.Count) files present"
    }

    # ---- Check for required directories ----
    $requiredDirs = @(
        "infra/redis",
        "infra/prometheus",
        "infra/nginx/static/ui",
        "infra/grafana/provisioning",
        "infra/grafana/dashboards"
    )

    foreach ($dir in $requiredDirs) {
        $fullPath = Join-Path $PROJECT_ROOT $dir
        if (Test-Path $fullPath) {
            if ($VerboseOutput) {
                Write-Check "Directory: $dir" "PASS"
            }
        }
        else {
            if ($FixIssues) {
                New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
                Write-Check "Directory: $dir" "FIX" "Auto-created"
            }
            else {
                Write-Check "Directory: $dir" "WARN" "Missing (use -FixIssues to create)"
            }
        }
    }

    # ---- Validate POM Structure ----
    Write-Host ""
    Write-Host "  Validating POM files..." -ForegroundColor DarkGray

    $parentPomPath = Join-Path $PROJECT_ROOT "pom.xml"
    if (Test-Path $parentPomPath) {
        $parentPom = Get-Content $parentPomPath -Raw
        $expectedModules = @("payment-common", "payment-service", "order-service",
                             "discovery-service", "gateway-service", "bff-service")

        foreach ($moduleName in $expectedModules) {
            if ($parentPom -match "<module>$moduleName</module>") {
                if ($VerboseOutput) {
                    Write-Check "Parent POM module: $moduleName" "PASS"
                }
            }
            else {
                Write-Check "Parent POM module: $moduleName" "FAIL" "Not declared in parent pom.xml"
            }
        }
    }

    # Check child POMs reference parent
    $childModules = @("payment-common", "payment-service", "order-service",
                      "discovery-service", "gateway-service", "bff-service")

    foreach ($moduleName in $childModules) {
        $childPomPath = Join-Path $PROJECT_ROOT "$moduleName/pom.xml"
        if (Test-Path $childPomPath) {
            $childPom = Get-Content $childPomPath -Raw
            if ($childPom -match "<artifactId>microservices-training</artifactId>") {
                if ($VerboseOutput) {
                    Write-Check "$moduleName parent reference" "PASS"
                }
            }
            else {
                Write-Check "$moduleName parent reference" "WARN" "May not reference parent POM correctly"
            }
        }
    }

    # ---- Validate Dockerfiles ----
    Write-Host ""
    Write-Host "  Validating Dockerfiles..." -ForegroundColor DarkGray

    $dockerfileModules = @("payment-service", "order-service", "discovery-service",
                           "gateway-service", "bff-service")
    foreach ($moduleName in $dockerfileModules) {
        $dfPath = Join-Path $PROJECT_ROOT "$moduleName/Dockerfile"
        if (Test-Path $dfPath) {
            $df = Get-Content $dfPath -Raw
            if ($df -match "eclipse-temurin" -and $df -match "17" -and $df -match "EXPOSE") {
                if ($VerboseOutput) {
                    Write-Check "Dockerfile: $moduleName" "PASS" "Java 17 base + EXPOSE"
                }
            }
            else {
                Write-Check "Dockerfile: $moduleName" "WARN" "Check Java version and EXPOSE directive"
            }
        }
    }

    # ---- Validate application.yml configs ----
    Write-Host ""
    Write-Host "  Validating application.yml configs..." -ForegroundColor DarkGray

    $configChecks = @{
        "payment-service/src/main/resources/application.yml" = @("server:", "spring:", "resilience4j:", "eureka:")
        "order-service/src/main/resources/application.yml"   = @("server:", "spring:", "kafka:", "eureka:")
        "gateway-service/src/main/resources/application.yml" = @("server:", "spring:", "eureka:", "resilience4j:")
        "discovery-service/src/main/resources/application.yml" = @("server:", "eureka:")
        "bff-service/src/main/resources/application.yml"       = @("server:", "eureka:")
    }

    foreach ($config in $configChecks.GetEnumerator()) {
        $configPath = Join-Path $PROJECT_ROOT $config.Key
        if (Test-Path $configPath) {
            $content = Get-Content $configPath -Raw
            $missingKeys = @()
            foreach ($key in $config.Value) {
                if ($content -notmatch [regex]::Escape($key)) {
                    $missingKeys += $key
                }
            }
            if ($missingKeys.Count -eq 0) {
                if ($VerboseOutput) {
                    Write-Check "Config: $($config.Key)" "PASS" "All required sections present"
                }
            }
            else {
                Write-Check "Config: $($config.Key)" "WARN" "Missing sections: $($missingKeys -join ', ')"
            }
        }
    }
}


# ============================================================
# PHASE 3: MAVEN BUILD
# ============================================================
function Test-MavenBuild {
    Write-Phase "3" "MAVEN BUILD"

    if ($SkipBuild) {
        Write-Check "Maven Build" "SKIP" "Skipped by -SkipBuild flag"

        # Check if JARs exist from previous build
        $jars = @(
            "payment-common/target/payment-common-1.0.0-SNAPSHOT.jar",
            "payment-service/target/payment-service-1.0.0-SNAPSHOT.jar",
            "order-service/target/order-service-1.0.0-SNAPSHOT.jar",
            "discovery-service/target/discovery-service-1.0.0-SNAPSHOT.jar",
            "gateway-service/target/gateway-service-1.0.0-SNAPSHOT.jar",
            "bff-service/target/bff-service-1.0.0-SNAPSHOT.jar"
        )

        foreach ($jar in $jars) {
            $jarPath = Join-Path $PROJECT_ROOT $jar
            if (Test-Path $jarPath) {
                $size = [math]::Round((Get-Item $jarPath).Length / 1MB, 2)
                Write-Check "JAR: $(Split-Path $jar -Leaf)" "PASS" "${size}MB"
            }
            else {
                Write-Check "JAR: $(Split-Path $jar -Leaf)" "FAIL" "Not found. Run without -SkipBuild"
            }
        }
        return
    }

    # ---- Maven Clean Install ----
    Write-Host "  Building all modules (this may take 2-5 minutes)..." -ForegroundColor Yellow

    $buildArgs = @("clean", "install")
    if ($SkipTests) {
        $buildArgs += "-DskipTests"
    }

    $buildStart = Get-Date
    Push-Location $PROJECT_ROOT

    try {
        $buildOutput = & mvn @buildArgs 2>&1 | Out-String

        $buildEnd = Get-Date
        $buildDuration = ($buildEnd - $buildStart).TotalSeconds

        if ($buildOutput -match "BUILD SUCCESS") {
            Write-Check "Maven Build" "PASS" "BUILD SUCCESS in $([math]::Round($buildDuration))s"

            # Parse individual module results
            $lines = $buildOutput -split "`n"
            foreach ($line in $lines) {
                if ($line -match "\[INFO\]\s+(payment-common|payment-service|order-service|discovery-service|gateway-service|bff-service)\s+\.+\s+(SUCCESS|FAILURE)\s+\[(.+?)\]") {
                    $mName = $Matches[1]
                    $mResult = $Matches[2]
                    $mTime = $Matches[3]
                    if ($mResult -eq "SUCCESS") {
                        Write-Check "Module: $mName" "PASS" "Built in $mTime"
                    }
                    else {
                        Write-Check "Module: $mName" "FAIL" "Build failed"
                    }
                }
            }
        }
        elseif ($buildOutput -match "BUILD FAILURE") {
            Write-Check "Maven Build" "FAIL" "BUILD FAILURE after $([math]::Round($buildDuration))s"

            # Extract error lines
            $lines = $buildOutput -split "`n"
            $errorLines = $lines | Where-Object { $_ -match "\[ERROR\]" } | Select-Object -First 10
            foreach ($errorLine in $errorLines) {
                Write-Host "    $errorLine" -ForegroundColor Red
            }
        }
        else {
            Write-Check "Maven Build" "WARN" "Build completed but could not determine result"
        }

        # ---- Test Results ----
        if (-not $SkipTests) {
            if ($buildOutput -match "Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+),\s*Skipped:\s*(\d+)") {
                $run = $Matches[1]; $fail = $Matches[2]
                $err = $Matches[3]; $skip = $Matches[4]

                if ([int]$fail -eq 0 -and [int]$err -eq 0) {
                    Write-Check "Unit Tests" "PASS" "Run: $run, Failures: $fail, Errors: $err, Skipped: $skip"
                }
                else {
                    Write-Check "Unit Tests" "FAIL" "Run: $run, Failures: $fail, Errors: $err"
                }
            }
            else {
                Write-Check "Unit Tests" "WARN" "Could not parse test results"
            }
        }
        else {
            Write-Check "Unit Tests" "SKIP" "Skipped by -SkipTests flag"
        }
    }
    finally {
        Pop-Location
    }

    # ---- Verify JAR sizes ----
    Write-Host ""
    Write-Host "  Verifying built artifacts..." -ForegroundColor DarkGray

    $expectedJars = @{
        "payment-service"   = @{MinMB = 30; MaxMB = 150}
        "order-service"     = @{MinMB = 25; MaxMB = 120}
        "discovery-service" = @{MinMB = 20; MaxMB = 100}
        "gateway-service"   = @{MinMB = 20; MaxMB = 100}
        "bff-service"       = @{MinMB = 20; MaxMB = 100}
    }

    foreach ($svc in $expectedJars.GetEnumerator()) {
        $jarPattern = Join-Path $PROJECT_ROOT "$($svc.Key)/target" "$($svc.Key)-*.jar"
        $jarFiles = Get-ChildItem -Path (Join-Path $PROJECT_ROOT "$($svc.Key)/target") -Filter "$($svc.Key)-*.jar" -ErrorAction SilentlyContinue |
                    Where-Object { $_.Name -notmatch "original|sources" } |
                    Sort-Object LastWriteTime -Descending |
                    Select-Object -First 1

        if ($jarFiles) {
            $sizeMB = [math]::Round($jarFiles.Length / 1MB, 2)
            if ($sizeMB -ge $svc.Value.MinMB -and $sizeMB -le $svc.Value.MaxMB) {
                Write-Check "JAR: $($svc.Key)" "PASS" "${sizeMB}MB"
            }
            else {
                Write-Check "JAR: $($svc.Key)" "WARN" "${sizeMB}MB (unexpected size, expected $($svc.Value.MinMB)-$($svc.Value.MaxMB)MB)"
            }
        }
        else {
            Write-Check "JAR: $($svc.Key)" "FAIL" "JAR not found in target/"
        }
    }
}


# ============================================================
# PHASE 4: DOCKER INFRASTRUCTURE
# ============================================================
function Test-DockerInfrastructure {
    Write-Phase "4" "DOCKER INFRASTRUCTURE"

    if ($SkipInfra) {
        Write-Check "Docker Infrastructure" "SKIP" "Skipped by -SkipInfra flag"
        Write-Host "  Checking if infrastructure is already running..." -ForegroundColor DarkGray

        $infraServices = @("redis", "kafka", "zipkin", "prometheus", "grafana",
                           "kafka-ui", "redis-commander", "nginx-cdn")

        foreach ($svc in $infraServices) {
            $port = $PORTS[$svc]
            if (Test-Port -Port $port) {
                Write-Check "$svc (port $port)" "PASS" "Already running"
            }
            else {
                Write-Check "$svc (port $port)" "FAIL" "Not running on port $port"
            }
        }
        return
    }

    # ---- Check docker-compose.yml exists ----
    $composePath = Join-Path $PROJECT_ROOT "docker-compose.yml"
    if (-not (Test-Path $composePath)) {
        Write-Check "docker-compose.yml" "FAIL" "File not found at $composePath"
        return
    }
    Write-Check "docker-compose.yml" "PASS" "Found"

    # ---- Validate docker-compose.yml ----
    Write-Host "  Validating docker-compose.yml syntax..." -ForegroundColor DarkGray
    try {
        Push-Location $PROJECT_ROOT
        $validateOutput = & docker compose config 2>&1 | Out-String
        Pop-Location
        if ($LASTEXITCODE -eq 0) {
            Write-Check "Compose Syntax" "PASS" "docker-compose.yml is valid"
        }
        else {
            Write-Check "Compose Syntax" "FAIL" "Syntax error in docker-compose.yml"
            Write-Host "    $($validateOutput.Substring(0, [Math]::Min(500, $validateOutput.Length)))" -ForegroundColor Red
            return
        }
    }
    catch {
        Pop-Location -ErrorAction SilentlyContinue
        Write-Check "Compose Syntax" "WARN" "Cannot validate compose file"
    }

    # ---- Start infrastructure containers ----
    Write-Host "  Starting infrastructure containers..." -ForegroundColor Yellow
    Write-Host "  (This may take 1-3 minutes on first run - downloading images)" -ForegroundColor DarkGray

    $infraContainerNames = @("redis", "zookeeper", "kafka", "zipkin", "prometheus",
                             "grafana", "kafka-ui", "redis-commander", "nginx-cdn")

    Push-Location $PROJECT_ROOT
    try {
        $startOutput = & docker compose up -d @infraContainerNames 2>&1 | Out-String
        if ($LASTEXITCODE -eq 0) {
            Write-Check "Docker Compose Up" "PASS" "Infrastructure containers started"
        }
        else {
            Write-Check "Docker Compose Up" "FAIL" "Failed to start containers"
            Write-Host "    $($startOutput.Substring(0, [Math]::Min(500, $startOutput.Length)))" -ForegroundColor Red
            return
        }
    }
    finally {
        Pop-Location
    }

    # ---- Wait for containers to be healthy ----
    Write-Host "  Waiting for containers to be healthy..." -ForegroundColor Yellow

    # Redis check
    Write-Host "    Waiting for Redis..." -ForegroundColor DarkGray
    $redisReady = $false
    for ($i = 0; $i -lt 30; $i++) {
        try {
            $ping = & docker exec payments-redis redis-cli ping 2>&1 | Out-String
            if ($ping -match "PONG") {
                $redisReady = $true
                break
            }
        }
        catch {}
        Start-Sleep -Seconds 2
    }
    if ($redisReady) {
        Write-Check "Redis" "PASS" "PONG response received"
    }
    else {
        Write-Check "Redis" "FAIL" "Redis not responding after 60s"
    }

    # Kafka check
    Write-Host "    Waiting for Kafka (may take 30-60s)..." -ForegroundColor DarkGray
    $kafkaReady = $false
    for ($i = 0; $i -lt 30; $i++) {
        if (Test-Port -Port 9092) {
            $kafkaReady = $true
            break
        }
        Start-Sleep -Seconds 3
    }
    if ($kafkaReady) {
        Write-Check "Kafka" "PASS" "Broker accessible on port 9092"

        # Create topics
        Write-Host "    Creating Kafka topics..." -ForegroundColor DarkGray
        & docker exec payments-kafka kafka-topics --create --if-not-exists --bootstrap-server localhost:9092 --topic payment-events --partitions 3 --replication-factor 1 2>&1 | Out-Null
        & docker exec payments-kafka kafka-topics --create --if-not-exists --bootstrap-server localhost:9092 --topic order-events --partitions 3 --replication-factor 1 2>&1 | Out-Null

        $topics = & docker exec payments-kafka kafka-topics --list --bootstrap-server localhost:9092 2>&1 | Out-String
        if ($topics -match "payment-events" -and $topics -match "order-events") {
            Write-Check "Kafka Topics" "PASS" "payment-events + order-events created"
        }
        else {
            Write-Check "Kafka Topics" "WARN" "Topics may not exist yet"
        }
    }
    else {
        Write-Check "Kafka" "FAIL" "Kafka not accessible after 90s"
    }

    # Zipkin check
    Write-Host "    Waiting for Zipkin..." -ForegroundColor DarkGray
    $zipkinReady = Wait-ForService -Name "Zipkin" -HealthUrl "http://localhost:9411/health" -TimeoutSeconds 60
    if ($zipkinReady) {
        Write-Check "Zipkin" "PASS" "Tracing UI ready"
    }
    else {
        Write-Check "Zipkin" "FAIL" "Zipkin not ready after 60s"
    }

    # Prometheus check
    $promReady = Wait-ForService -Name "Prometheus" -HealthUrl "http://localhost:9090/-/healthy" -TimeoutSeconds 30
    if ($promReady) {
        Write-Check "Prometheus" "PASS" "Metrics collection ready"
    }
    else {
        Write-Check "Prometheus" "WARN" "Prometheus may not be ready"
    }

    # Grafana check
    $grafanaReady = Wait-ForService -Name "Grafana" -HealthUrl "http://localhost:3000/api/health" -TimeoutSeconds 30
    if ($grafanaReady) {
        Write-Check "Grafana" "PASS" "Dashboard UI ready"
    }
    else {
        Write-Check "Grafana" "WARN" "Grafana may not be ready"
    }

    # Kafka UI
    if (Test-Port -Port 8090) {
        Write-Check "Kafka UI" "PASS" "Accessible on port 8090"
    }
    else {
        Write-Check "Kafka UI" "WARN" "Kafka UI not accessible yet"
    }

    # Redis Commander
    if (Test-Port -Port 8091) {
        Write-Check "Redis Commander" "PASS" "Accessible on port 8091"
    }
    else {
        Write-Check "Redis Commander" "WARN" "Redis Commander not accessible yet"
    }

    # NGINX CDN
    $nginxReady = Wait-ForService -Name "NGINX CDN" -HealthUrl "http://localhost:8084/health" -TimeoutSeconds 15
    if ($nginxReady) {
        Write-Check "NGINX CDN" "PASS" "Static content server ready"
    }
    else {
        Write-Check "NGINX CDN" "WARN" "NGINX CDN may not be ready"
    }

    # ---- Docker container status ----
    Write-Host ""
    Write-Host "  Container status:" -ForegroundColor DarkGray
    try {
        Push-Location $PROJECT_ROOT
        $containers = & docker compose ps 2>&1 | Out-String
        Pop-Location
        $containerLines = $containers -split "`n"
        foreach ($line in $containerLines) {
            if ($line.Trim()) {
                $color = if ($line -match "Up|running|healthy") { "Green" }
                         elseif ($line -match "Exit|unhealthy|Restarting") { "Red" }
                         else { "White" }
                Write-Host "    $line" -ForegroundColor $color
            }
        }
    }
    catch {
        Pop-Location -ErrorAction SilentlyContinue
        Write-Host "    Cannot list containers" -ForegroundColor Yellow
    }
}


# ============================================================
# PHASE 5: SERVICE STARTUP & HEALTH CHECKS
# ============================================================
function Test-ServiceHealth {
    Write-Phase "5" "SERVICE HEALTH CHECKS"

    if (-not $StartServices) {
        Write-Host "  Checking if services are already running..." -ForegroundColor DarkGray
        Write-Host "  (Use -StartServices flag to start them automatically)" -ForegroundColor DarkGray

        $appServices = @("discovery-service", "payment-service", "order-service",
                         "bff-service", "gateway-service")

        foreach ($svc in $appServices) {
            $port = $PORTS[$svc]
            if (Test-Port -Port $port) {
                $healthUrl = $HEALTH_URLS[$svc]
                $result = Test-HttpEndpoint -Url $healthUrl
                if ($result.Success) {
                    Write-Check "$svc (port $port)" "PASS" "Healthy"
                }
                else {
                    Write-Check "$svc (port $port)" "WARN" "Port open but health check failed (status $($result.StatusCode))"
                }
            }
            else {
                Write-Check "$svc (port $port)" "WARN" "Not running (start manually or use -StartServices)"
            }
        }
        return
    }

    # ---- Start services in correct order ----
    Write-Host "  Starting application services in order..." -ForegroundColor Yellow

    $serviceOrder = @(
        @{Name = "discovery-service"; Port = 8761; Timeout = 60},
        @{Name = "payment-service";   Port = 8081; Timeout = 90},
        @{Name = "order-service";     Port = 8082; Timeout = 90},
        @{Name = "bff-service";       Port = 8083; Timeout = 60},
        @{Name = "gateway-service";   Port = 8080; Timeout = 60}
    )

    $step = 0
    foreach ($svc in $serviceOrder) {
        $step++
        Write-Host "  $step/$($serviceOrder.Count) Starting $($svc.Name)..." -ForegroundColor Yellow

        if (-not (Test-Port -Port $svc.Port)) {
            $mavenArgs = @("spring-boot:run", "-pl", $svc.Name)
            Start-Process -FilePath "mvn" -ArgumentList $mavenArgs `
                          -WorkingDirectory $PROJECT_ROOT -WindowStyle Minimized

            $healthUrl = $HEALTH_URLS[$svc.Name]
            $ready = Wait-ForService -Name $svc.Name -HealthUrl $healthUrl -TimeoutSeconds $svc.Timeout
            if ($ready) {
                Write-Check $svc.Name "PASS" "Started and healthy"
            }
            else {
                Write-Check $svc.Name "FAIL" "Failed to start within $($svc.Timeout)s"
                if ($svc.Name -eq "discovery-service") {
                    Write-Host "    Cannot continue without discovery service." -ForegroundColor Red
                    return
                }
            }
        }
        else {
            Write-Check $svc.Name "PASS" "Already running on port $($svc.Port)"
        }
    }

    # ---- Eureka Registration Check ----
    Write-Host ""
    Write-Host "  Checking Eureka registrations..." -ForegroundColor DarkGray
    Start-Sleep -Seconds 5

    try {
        $eurekaResult = Test-HttpEndpoint -Url "http://localhost:8761/eureka/apps" `
                        -Headers @{"Accept" = "application/json"; "Authorization" = "Basic ZXVyZWthOmV1cmVrYS1zZWNyZXQ="}
        if ($eurekaResult.Success) {
            $expectedRegistrations = @("PAYMENT-SERVICE", "ORDER-SERVICE",
                                       "BFF-SERVICE", "GATEWAY-SERVICE")

            foreach ($expected in $expectedRegistrations) {
                if ($eurekaResult.Body -match $expected) {
                    Write-Check "Eureka: $expected" "PASS" "Registered"
                }
                else {
                    Write-Check "Eureka: $expected" "WARN" "Not registered yet"
                }
            }
        }
        else {
            Write-Check "Eureka Registration Check" "WARN" "Cannot query Eureka API (status $($eurekaResult.StatusCode))"
        }
    }
    catch {
        Write-Check "Eureka Registration Check" "WARN" "Eureka API error"
    }
}


# ============================================================
# PHASE 6: FUNCTIONAL SMOKE TESTS
# ============================================================
function Test-FunctionalSmoke {
    Write-Phase "6" "FUNCTIONAL SMOKE TESTS"

    # Check if payment-service is running
    if (-not (Test-Port -Port 8081)) {
        Write-Check "Smoke Tests" "SKIP" "payment-service not running on port 8081. Start it first."
        return
    }

    $allTestsPassed = $true

    # ---- TEST 1: OpenAPI Spec ----
    Write-Host "  Test 1: OpenAPI specification" -ForegroundColor DarkGray
    $openApiResult = Test-HttpEndpoint -Url "http://localhost:8081/v3/api-docs"
    if ($openApiResult.Success) {
        try {
            $spec = $openApiResult.Body | ConvertFrom-Json
            $pathCount = 0
            if ($spec.paths) {
                $pathCount = ($spec.paths | Get-Member -MemberType NoteProperty).Count
            }
            Write-Check "OpenAPI Spec" "PASS" "$pathCount API paths documented"
        }
        catch {
            Write-Check "OpenAPI Spec" "WARN" "Returned 200 but could not parse JSON"
        }
    }
    else {
        Write-Check "OpenAPI Spec" "FAIL" "Status: $($openApiResult.StatusCode)"
        $allTestsPassed = $false
    }

    # ---- TEST 2: Swagger UI ----
    $swaggerResult = Test-HttpEndpoint -Url "http://localhost:8081/swagger-ui/index.html"
    if ($swaggerResult.Success) {
        Write-Check "Swagger UI" "PASS" "Accessible"
    }
    else {
        Write-Check "Swagger UI" "WARN" "Swagger UI not loading (status $($swaggerResult.StatusCode))"
    }

    # ---- TEST 3: Create Payment (Happy Path) ----
    Write-Host ""
    Write-Host "  Test 3: Payment creation (happy path)" -ForegroundColor DarkGray
    $idempotencyKey = "smoke-test-" + [guid]::NewGuid().ToString().Substring(0, 8)
    $createBody = @{
        orderId        = "SMOKE-ORDER-001"
        customerId     = "SMOKE-CUST-001"
        amount         = 5.99
        currency       = "USD"
        paymentMethod  = "CARD"
        cardNumber     = "4111111111111111"
        idempotencyKey = $idempotencyKey
    } | ConvertTo-Json

    $createResult = Test-HttpEndpoint -Url "http://localhost:8081/api/v1/payments" `
                    -Method "POST" `
                    -Headers @{
                        "Content-Type"      = "application/json"
                        "X-Idempotency-Key" = $idempotencyKey
                    } `
                    -Body $createBody `
                    -ExpectedStatusCodes @(200, 201)

    $paymentId = $null
    if ($createResult.Success) {
        try {
            $payment = $createResult.Body | ConvertFrom-Json
            $paymentId = $payment.paymentId
            Write-Check "Create Payment" "PASS" "PaymentId: $paymentId Status: $($payment.status)"
        }
        catch {
            Write-Check "Create Payment" "WARN" "Created but response parse failed"
        }
    }
    else {
        Write-Check "Create Payment" "FAIL" "Status: $($createResult.StatusCode) Error: $($createResult.Error)"
        $allTestsPassed = $false
    }

    # ---- TEST 4: Idempotency (Retry) ----
    Write-Host ""
    Write-Host "  Test 4: Idempotency (duplicate request)" -ForegroundColor DarkGray
    if ($paymentId) {
        $retryResult = Test-HttpEndpoint -Url "http://localhost:8081/api/v1/payments" `
                       -Method "POST" `
                       -Headers @{
                           "Content-Type"      = "application/json"
                           "X-Idempotency-Key" = $idempotencyKey
                       } `
                       -Body $createBody `
                       -ExpectedStatusCodes @(200, 201)

        if ($retryResult.Success) {
            try {
                $retryPayment = $retryResult.Body | ConvertFrom-Json
                if ($retryPayment.paymentId -eq $paymentId) {
                    Write-Check "Idempotency" "PASS" "Same paymentId returned (no duplicate charge)"
                }
                else {
                    Write-Check "Idempotency" "FAIL" "Different paymentId returned - DUPLICATE CHARGE"
                    $allTestsPassed = $false
                }
            }
            catch {
                Write-Check "Idempotency" "WARN" "Response parse failed"
            }
        }
        else {
            Write-Check "Idempotency" "FAIL" "Retry request failed (status $($retryResult.StatusCode))"
            $allTestsPassed = $false
        }
    }
    else {
        Write-Check "Idempotency" "SKIP" "No paymentId from previous test"
    }

    # ---- TEST 5: Get Payment (Cache Test) ----
    Write-Host ""
    Write-Host "  Test 5: Get payment + cache behavior" -ForegroundColor DarkGray
    if ($paymentId) {
        $getResult1 = Test-HttpEndpoint -Url "http://localhost:8081/api/v2/payments/$paymentId"
        if ($getResult1.Success) {
            Write-Check "GET Payment (1st call - cache miss)" "PASS" "Retrieved from DB"
        }
        else {
            Write-Check "GET Payment (1st call)" "FAIL" "Status: $($getResult1.StatusCode)"
            $allTestsPassed = $false
        }

        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        $getResult2 = Test-HttpEndpoint -Url "http://localhost:8081/api/v2/payments/$paymentId"
        $sw.Stop()
        if ($getResult2.Success) {
            Write-Check "GET Payment (2nd call - cache hit)" "PASS" "Retrieved in $($sw.ElapsedMilliseconds)ms"
        }
        else {
            Write-Check "GET Payment (2nd call)" "FAIL" "Status: $($getResult2.StatusCode)"
        }
    }
    else {
        Write-Check "GET Payment" "SKIP" "No paymentId available"
    }

    # ---- TEST 6: Pagination (V1 offset) ----
    Write-Host ""
    Write-Host "  Test 6: Offset pagination (v1)" -ForegroundColor DarkGray
    $pageResult = Test-HttpEndpoint -Url "http://localhost:8081/api/v1/payments?customerId=SMOKE-CUST-001&page=0&size=5"
    if ($pageResult.Success) {
        try {
            $pageData = $pageResult.Body | ConvertFrom-Json
            Write-Check "Offset Pagination" "PASS" "Page: $($pageData.page), Size: $($pageData.size), Total: $($pageData.totalElements)"
        }
        catch {
            Write-Check "Offset Pagination" "WARN" "Response parse failed"
        }
    }
    else {
        Write-Check "Offset Pagination" "FAIL" "Status: $($pageResult.StatusCode)"
    }

    # ---- TEST 7: Cursor pagination (V2) ----
    Write-Host ""
    Write-Host "  Test 7: Cursor pagination (v2)" -ForegroundColor DarkGray
    $cursorResult = Test-HttpEndpoint -Url "http://localhost:8081/api/v2/payments?customerId=SMOKE-CUST-001&size=5"
    if ($cursorResult.Success) {
        try {
            $cursorData = $cursorResult.Body | ConvertFrom-Json
            $hasNext = if ($cursorData.nextCursor) { "yes" } else { "no" }
            Write-Check "Cursor Pagination" "PASS" "Items: $($cursorData.data.Count), HasMore: $($cursorData.hasMore), NextCursor: $hasNext"
        }
        catch {
            Write-Check "Cursor Pagination" "WARN" "Response parse failed"
        }
    }
    else {
        Write-Check "Cursor Pagination" "FAIL" "Status: $($cursorResult.StatusCode)"
    }

    # ---- TEST 8: Validation Error ----
    Write-Host ""
    Write-Host "  Test 8: Request validation" -ForegroundColor DarkGray
    $invalidBody = '{"orderId":"","amount":-1,"currency":"INVALID","paymentMethod":"CASH","idempotencyKey":"val-test"}'
    $valResult = Test-HttpEndpoint -Url "http://localhost:8081/api/v1/payments" `
                 -Method "POST" `
                 -Headers @{
                     "Content-Type"      = "application/json"
                     "X-Idempotency-Key" = "val-test-001"
                 } `
                 -Body $invalidBody `
                 -ExpectedStatusCodes @(400)
    if ($valResult.Success) {
        Write-Check "Validation Error" "PASS" "400 returned for invalid input"
    }
    else {
        Write-Check "Validation Error" "FAIL" "Expected 400, got $($valResult.StatusCode)"
    }

    # ---- TEST 9: Rate Limiting ----
    Write-Host ""
    Write-Host "  Test 9: Rate limiting (sending 70 rapid requests)" -ForegroundColor DarkGray
    $rateLimitHit = $false
    for ($i = 0; $i -lt 70; $i++) {
        $rlResult = Test-HttpEndpoint -Url "http://localhost:8081/api/v1/payments?customerId=SMOKE-CUST-001" `
                    -Headers @{"X-API-Key" = "rate-limit-smoke-test"} `
                    -ExpectedStatusCodes @(200, 429)
        if ($rlResult.StatusCode -eq 429) {
            $rateLimitHit = $true
            Write-Check "Rate Limiting" "PASS" "429 returned after $($i + 1) rapid requests"
            break
        }
    }
    if (-not $rateLimitHit) {
        Write-Check "Rate Limiting" "WARN" "Rate limit not triggered after 70 rapid requests (may need tuning)"
    }

    # ---- TEST 10: Circuit Breaker Endpoint ----
    Write-Host ""
    Write-Host "  Test 10: Circuit breaker status" -ForegroundColor DarkGray
    $cbResult = Test-HttpEndpoint -Url "http://localhost:8081/actuator/circuitbreakers"
    if ($cbResult.Success) {
        Write-Check "Circuit Breaker Status" "PASS" "Actuator endpoint accessible"
    }
    else {
        Write-Check "Circuit Breaker Status" "WARN" "Cannot access CB actuator (status $($cbResult.StatusCode))"
    }

    # ---- TEST 11: Prometheus Metrics ----
    Write-Host ""
    Write-Host "  Test 11: Prometheus metrics endpoint" -ForegroundColor DarkGray
    $metricsResult = Test-HttpEndpoint -Url "http://localhost:8081/actuator/prometheus"
    if ($metricsResult.Success) {
        $body = $metricsResult.Body
        $hasPaymentMetrics = $body -match "payment"
        $hasJvmMetrics = $body -match "jvm_memory"
        Write-Check "Prometheus Metrics" "PASS" "Payment metrics: $hasPaymentMetrics, JVM metrics: $hasJvmMetrics"
    }
    else {
        Write-Check "Prometheus Metrics" "FAIL" "Status: $($metricsResult.StatusCode)"
    }

    # ---- TEST 12: Gateway Routing ----
    if (Test-Port -Port 8080) {
        Write-Host ""
        Write-Host "  Test 12: Gateway routing" -ForegroundColor DarkGray

        $gwResult = Test-HttpEndpoint -Url "http://localhost:8080/api/v1/payments?customerId=SMOKE-CUST-001" `
                    -Headers @{"X-API-Key" = "demo-key"}
        if ($gwResult.Success) {
            Write-Check "Gateway -> Payment Service" "PASS" "Routed successfully"
        }
        else {
            Write-Check "Gateway -> Payment Service" "FAIL" "Routing failed (status $($gwResult.StatusCode))"
        }

        # Auth test - no API key should fail
        $noAuthResult = Test-HttpEndpoint -Url "http://localhost:8080/api/v1/payments?customerId=SMOKE-CUST-001" `
                        -ExpectedStatusCodes @(401)
        if ($noAuthResult.Success) {
            Write-Check "Gateway Auth (no API key)" "PASS" "401 returned without API key"
        }
        else {
            Write-Check "Gateway Auth (no API key)" "WARN" "Expected 401, got $($noAuthResult.StatusCode)"
        }
    }
    else {
        Write-Check "Gateway Routing" "SKIP" "Gateway not running on port 8080"
    }

    # ---- TEST 13: Order Service ----
    if (Test-Port -Port 8082) {
        Write-Host ""
        Write-Host "  Test 13: Order service" -ForegroundColor DarkGray

        $orderBody = @{
            customerId  = "SMOKE-CUST-001"
            amount      = 9.99
            currency    = "USD"
            description = "Smoke test order"
        } | ConvertTo-Json

        $orderResult = Test-HttpEndpoint -Url "http://localhost:8082/api/v1/orders" `
                       -Method "POST" `
                       -Body $orderBody `
                       -ExpectedStatusCodes @(200, 201)

        if ($orderResult.Success) {
            try {
                $order = $orderResult.Body | ConvertFrom-Json
                Write-Check "Create Order" "PASS" "OrderId: $($order.orderId) Status: $($order.status)"
            }
            catch {
                Write-Check "Create Order" "WARN" "Created but response parse failed"
            }
        }
        else {
            Write-Check "Create Order" "FAIL" "Status: $($orderResult.StatusCode)"
        }
    }
    else {
        Write-Check "Order Service" "SKIP" "Not running on port 8082"
    }

    # ---- TEST 14: Design Patterns Endpoint ----
    Write-Host ""
    Write-Host "  Test 14: Design patterns endpoint" -ForegroundColor DarkGray
    $patternsResult = Test-HttpEndpoint -Url "http://localhost:8081/api/patterns/overview"
    if ($patternsResult.Success) {
        Write-Check "Patterns Overview" "PASS" "Returns all pattern descriptions"
    }
    else {
        Write-Check "Patterns Overview" "FAIL" "Status: $($patternsResult.StatusCode)"
    }

    # ---- TEST 15: WAF Simulation ----
    Write-Host ""
    Write-Host "  Test 15: WAF simulation" -ForegroundColor DarkGray

    $wafClean = Test-HttpEndpoint -Url "http://localhost:8081/api/edge/waf-check" `
                -Method "POST" `
                -Body '{"customerId":"CUST-001"}' `
                -ExpectedStatusCodes @(200)
    if ($wafClean.Success) {
        Write-Check "WAF - Clean Request" "PASS" "ALLOWED (200)"
    }
    else {
        Write-Check "WAF - Clean Request" "FAIL" "Status: $($wafClean.StatusCode)"
    }

    $wafSqlBody = '{"customerId":"1 OR 1=1; DROP TABLE payments;"}'
    $wafSql = Test-HttpEndpoint -Url "http://localhost:8081/api/edge/waf-check" `
              -Method "POST" `
              -Body $wafSqlBody `
              -ExpectedStatusCodes @(403)
    if ($wafSql.Success) {
        Write-Check "WAF - SQL Injection" "PASS" "BLOCKED (403)"
    }
    else {
        Write-Check "WAF - SQL Injection" "WARN" "Expected 403, got $($wafSql.StatusCode)"
    }

    # ---- TEST 16: Edge Simulation Endpoints ----
    Write-Host ""
    Write-Host "  Test 16: Edge simulation endpoints" -ForegroundColor DarkGray

    $edgeEndpoints = @(
        @{Name = "Traffic Flow";  Url = "http://localhost:8081/api/edge/traffic-flow"},
        @{Name = "DNS Flow";      Url = "http://localhost:8081/api/edge/dns-flow"},
        @{Name = "CDN Strategy";  Url = "http://localhost:8081/api/edge/cdn-strategy"}
    )

    foreach ($ep in $edgeEndpoints) {
        $result = Test-HttpEndpoint -Url $ep.Url
        if ($result.Success) {
            Write-Check "Edge: $($ep.Name)" "PASS" "Returns explanatory JSON"
        }
        else {
            Write-Check "Edge: $($ep.Name)" "FAIL" "Status: $($result.StatusCode)"
        }
    }

    # ---- TEST 17: CDN Static Content ----
    if (Test-Port -Port 8084) {
        Write-Host ""
        Write-Host "  Test 17: CDN static content" -ForegroundColor DarkGray

        $cdnResult = Test-HttpEndpoint -Url "http://localhost:8084/ui/index.html"
        if ($cdnResult.Success) {
            $cacheHeader = ""
            if ($cdnResult.Headers -and $cdnResult.Headers.ContainsKey("Cache-Control")) {
                $cacheHeader = $cdnResult.Headers["Cache-Control"]
            }
            Write-Check "CDN - Static HTML" "PASS" "Served with Cache-Control: $cacheHeader"
        }
        else {
            Write-Check "CDN - Static HTML" "FAIL" "Status: $($cdnResult.StatusCode)"
        }
    }
    else {
        Write-Check "CDN Static Content" "SKIP" "NGINX CDN not running on port 8084"
    }

    Write-Host ""
    if ($allTestsPassed) {
        Write-Check "Smoke Tests Summary" "PASS" "All critical tests passed"
    }
    else {
        Write-Check "Smoke Tests Summary" "WARN" "Some tests failed - review results above"
    }
}


# ============================================================
# PHASE 7: SUMMARY REPORT
# ============================================================
function Write-SummaryReport {
    Write-Phase "7" "SUMMARY REPORT"

    $duration = ((Get-Date) - $script:StartTime).TotalSeconds
    $durationFormatted = "{0:N1}" -f $duration

    # Status determination
    $overallStatus = if ($script:FailedChecks -eq 0 -and $script:WarningChecks -eq 0) {
        "READY FOR DEMO"
    }
    elseif ($script:FailedChecks -eq 0) {
        "READY WITH WARNINGS"
    }
    elseif ($script:FailedChecks -le 3) {
        "PARTIALLY READY"
    }
    else {
        "NOT READY"
    }

    $statusColor = switch ($overallStatus) {
        "READY FOR DEMO"       { "Green" }
        "READY WITH WARNINGS"  { "Yellow" }
        "PARTIALLY READY"      { "Yellow" }
        "NOT READY"            { "Red" }
        default                { "White" }
    }

    $statusMarker = switch ($overallStatus) {
        "READY FOR DEMO"       { "[+++]" }
        "READY WITH WARNINGS"  { "[++ ]" }
        "PARTIALLY READY"      { "[+  ]" }
        "NOT READY"            { "[---]" }
        default                { "[???]" }
    }

    # ---- Summary Box ----
    $boxWidth = 52
    $sep = "+" + ("-" * $boxWidth) + "+"

    Write-Host ""
    Write-Host "  $sep" -ForegroundColor $statusColor
    Write-Host "  |$(' ' * $boxWidth)|" -ForegroundColor $statusColor
    $statusLine = "  $statusMarker OVERALL STATUS: $overallStatus"
    $padLen = $boxWidth - $statusLine.Length + 4
    if ($padLen -lt 0) { $padLen = 0 }
    Write-Host "  | $statusMarker OVERALL STATUS: $overallStatus$(' ' * $padLen)|" -ForegroundColor $statusColor
    Write-Host "  |$(' ' * $boxWidth)|" -ForegroundColor $statusColor

    $lines = @(
        @{Label = "Total Checks:";    Value = $script:TotalChecks;   Color = "White"},
        @{Label = "Passed:";          Value = $script:PassedChecks;  Color = "Green"},
        @{Label = "Failed:";          Value = $script:FailedChecks;  Color = $(if ($script:FailedChecks -gt 0) {"Red"} else {"Green"})},
        @{Label = "Warnings:";        Value = $script:WarningChecks; Color = $(if ($script:WarningChecks -gt 0) {"Yellow"} else {"Green"})},
        @{Label = "Skipped:";         Value = $script:SkippedChecks; Color = "DarkGray"},
        @{Label = "Fixes Applied:";   Value = $script:FixesApplied.Count; Color = "Magenta"},
        @{Label = "Duration:";        Value = "${durationFormatted}s"; Color = "Cyan"}
    )

    foreach ($line in $lines) {
        $text = "   $($line.Label.PadRight(18)) $($line.Value)"
        $pad = $boxWidth - $text.Length
        if ($pad -lt 0) { $pad = 0 }
        Write-Host "  |$text$(' ' * $pad)|" -ForegroundColor $line.Color
    }

    Write-Host "  |$(' ' * $boxWidth)|" -ForegroundColor $statusColor
    Write-Host "  $sep" -ForegroundColor $statusColor

    # ---- Errors Detail ----
    if ($script:Errors.Count -gt 0) {
        Write-Host ""
        Write-Host "  [ERRORS] Must fix before demo:" -ForegroundColor Red
        Write-Host "  $("-" * 40)" -ForegroundColor Red
        for ($i = 0; $i -lt $script:Errors.Count; $i++) {
            Write-Host "  $($i + 1). $($script:Errors[$i])" -ForegroundColor Red
        }
    }

    # ---- Warnings Detail ----
    if ($script:Warnings.Count -gt 0) {
        Write-Host ""
        Write-Host "  [WARNINGS] May affect demo:" -ForegroundColor Yellow
        Write-Host "  $("-" * 40)" -ForegroundColor Yellow
        $maxWarnings = [math]::Min($script:Warnings.Count, 15)
        for ($i = 0; $i -lt $maxWarnings; $i++) {
            Write-Host "  $($i + 1). $($script:Warnings[$i])" -ForegroundColor Yellow
        }
        if ($script:Warnings.Count -gt 15) {
            Write-Host "  ... and $($script:Warnings.Count - 15) more warnings" -ForegroundColor DarkYellow
        }
    }

    # ---- Fixes Applied ----
    if ($script:FixesApplied.Count -gt 0) {
        Write-Host ""
        Write-Host "  [FIXES APPLIED]:" -ForegroundColor Magenta
        Write-Host "  $("-" * 40)" -ForegroundColor Magenta
        foreach ($fix in $script:FixesApplied) {
            Write-Host "  * $fix" -ForegroundColor Magenta
        }
    }

    # ---- Quick Fix Suggestions ----
    if ($script:FailedChecks -gt 0 -or $script:WarningChecks -gt 0) {
        Write-Host ""
        Write-Host "  [SUGGESTED FIXES]:" -ForegroundColor Cyan
        Write-Host "  $("-" * 40)" -ForegroundColor Cyan

        $errorText = ($script:Errors + $script:Warnings) -join " "

        if ($errorText -match "Java") {
            Write-Host "  * Install JDK 17: https://adoptium.net/" -ForegroundColor White
            Write-Host "    Set JAVA_HOME: setx JAVA_HOME `"C:\path\to\jdk-17`"" -ForegroundColor DarkGray
        }
        if ($errorText -match "Maven") {
            Write-Host "  * Install Maven: https://maven.apache.org/download.cgi" -ForegroundColor White
        }
        if ($errorText -match "Docker") {
            Write-Host "  * Install Docker Desktop: https://www.docker.com/products/docker-desktop/" -ForegroundColor White
            Write-Host "  * Start Docker Desktop and wait for engine to be ready" -ForegroundColor DarkGray
        }
        if ($errorText -match "MISSING") {
            Write-Host "  * Re-run with -FixIssues to auto-create missing directories" -ForegroundColor White
            Write-Host "  * Copy missing source files from the training project" -ForegroundColor DarkGray
        }
        if ($errorText -match "BUILD FAILURE") {
            Write-Host "  * Check Maven build: mvn clean install -DskipTests" -ForegroundColor White
            Write-Host "  * Build common first: mvn install -pl payment-common" -ForegroundColor DarkGray
        }
        if ($errorText -match "Not running") {
            Write-Host "  * Start infra: docker compose up -d redis kafka zookeeper zipkin" -ForegroundColor White
            Write-Host "  * Re-run with -StartServices to start app services" -ForegroundColor DarkGray
        }
    }

    # ---- Service URLs ----
    Write-Host ""
    Write-Host "  [SERVICE URLS]:" -ForegroundColor Cyan
    Write-Host "  $("-" * 40)" -ForegroundColor Cyan

    $urlList = @(
        @{Name = "Payment API Swagger";  Url = "http://localhost:8081/swagger-ui.html";  Port = 8081},
        @{Name = "Order API Swagger";    Url = "http://localhost:8082/swagger-ui.html";  Port = 8082},
        @{Name = "BFF API Swagger";      Url = "http://localhost:8083/swagger-ui.html";  Port = 8083},
        @{Name = "API Gateway";          Url = "http://localhost:8080/actuator/health";  Port = 8080},
        @{Name = "Eureka Dashboard";     Url = "http://localhost:8761";                  Port = 8761},
        @{Name = "Zipkin Traces";        Url = "http://localhost:9411";                  Port = 9411},
        @{Name = "Prometheus";           Url = "http://localhost:9090";                  Port = 9090},
        @{Name = "Grafana";              Url = "http://localhost:3000 (admin/admin)";    Port = 3000},
        @{Name = "Kafka UI";             Url = "http://localhost:8090";                  Port = 8090},
        @{Name = "Redis Commander";      Url = "http://localhost:8091";                  Port = 8091},
        @{Name = "CDN Static Demo";      Url = "http://localhost:8084/ui/index.html";    Port = 8084}
    )

    foreach ($svc in $urlList) {
        $running = Test-Port -Port $svc.Port -Timeout 1
        $statusChar = if ($running) { "[UP]  " } else { "[DOWN]" }
        $color = if ($running) { "Green" } else { "DarkGray" }
        Write-Host "  $statusChar $($svc.Name.PadRight(25)) $($svc.Url)" -ForegroundColor $color
    }

    # ---- Next Steps ----
    Write-Host ""
    Write-Host "  [NEXT STEPS]:" -ForegroundColor Cyan
    Write-Host "  $("-" * 40)" -ForegroundColor Cyan

    if ($overallStatus -eq "READY FOR DEMO" -or $overallStatus -eq "READY WITH WARNINGS") {
        Write-Host "  1. Open http://localhost:8084/ui/index.html for quick links" -ForegroundColor White
        Write-Host "  2. Open http://localhost:8081/swagger-ui.html for API testing" -ForegroundColor White
        Write-Host "  3. Follow the playbook.md for demo walkthrough" -ForegroundColor White
        Write-Host "  4. Have Kafka UI, Zipkin, and Redis Commander open" -ForegroundColor White
    }
    else {
        Write-Host "  1. Fix the ERRORS listed above" -ForegroundColor White
        Write-Host "  2. Re-run this script: .\validate-demo.ps1" -ForegroundColor White
        Write-Host "  3. Once all checks pass, proceed with demo" -ForegroundColor White
    }

    Write-Host ""
}


# ============================================================
# MAIN EXECUTION
# ============================================================

Write-Banner "Microservices Training - Pre-Demo Validation"
Write-Host "  Project Root: $PROJECT_ROOT" -ForegroundColor DarkGray
Write-Host "  Timestamp:    $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor DarkGray
Write-Host "  Flags:        SkipBuild=$SkipBuild SkipInfra=$SkipInfra SkipTests=$SkipTests StartServices=$StartServices FixIssues=$FixIssues" -ForegroundColor DarkGray

# Execute all phases
Test-Prerequisites
Test-ProjectStructure
Test-MavenBuild
Test-DockerInfrastructure
Test-ServiceHealth
Test-FunctionalSmoke
Write-SummaryReport

# Exit code for CI/CD integration
if ($script:FailedChecks -gt 0) {
    exit 1
}
else {
    exit 0
}