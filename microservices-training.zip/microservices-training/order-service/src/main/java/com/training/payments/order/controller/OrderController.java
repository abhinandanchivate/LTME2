package com.training.payments.order.controller;

import com.training.payments.order.dto.CreateOrderRequest;
import com.training.payments.order.dto.OrderResponse;
import com.training.payments.order.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * TRAINING MODULE: Day 3 - Order API (Saga entry point)
 *
 * REST API for orders. Creating an order starts the Saga.
 *
 * DEMO FLOW:
 * 1. POST /api/v1/orders -> creates order (Saga starts)
 * 2. Copy orderId from response
 * 3. POST /api/v1/payments with orderId -> processes payment
 * 4. Watch Kafka events flow: payment-events -> order-service
 * 5. GET /api/v1/orders/{orderId} -> see order status updated
 */
@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Orders", description = "Order management - Saga entry point")
public class OrderController {

    private final OrderService orderService;

    @Operation(
        summary = "Create an order",
        description = """
            Creates a new order. This is the START of the Payment-Order Saga.
            
            **Saga Flow**:
            1. Create order (this endpoint) -> orderId returned
            2. POST /api/v1/payments with orderId and X-Idempotency-Key
            3. Monitor order status via GET /api/v1/orders/{orderId}
            """
    )
    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(
            @Valid @RequestBody CreateOrderRequest request) {
        log.info("[ORDER] POST /api/v1/orders - customer: {}", request.getCustomerId());
        OrderResponse response = orderService.createOrder(request);
        return ResponseEntity.status(201).body(response);
    }

    @Operation(summary = "Get order by ID")
    @GetMapping("/{orderId}")
    public ResponseEntity<OrderResponse> getOrder(@PathVariable String orderId) {
        log.info("[ORDER] GET /api/v1/orders/{}", orderId);
        return ResponseEntity.ok(orderService.getOrder(orderId));
    }

    @Operation(summary = "Get all orders for a customer")
    @GetMapping
    public ResponseEntity<List<OrderResponse>> getCustomerOrders(
            @RequestParam String customerId) {
        log.info("[ORDER] GET /api/v1/orders - customer: {}", customerId);
        return ResponseEntity.ok(orderService.getCustomerOrders(customerId));
    }
}