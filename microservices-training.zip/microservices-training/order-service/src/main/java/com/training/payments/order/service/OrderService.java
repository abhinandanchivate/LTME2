package com.training.payments.order.service;

import com.training.payments.order.dto.CreateOrderRequest;
import com.training.payments.order.dto.OrderResponse;
import com.training.payments.order.event.OrderEvent;
import com.training.payments.order.model.Order;
import com.training.payments.order.model.OrderStatus;
import com.training.payments.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

/**
 * TRAINING MODULE: Day 3 - Order Service Logic + Timeout Handling
 *
 * Order service business logic including:
 * 1. Order creation (starts Saga)
 * 2. Timeout detection (AWAITING_PAYMENT orders stuck > 5 min)
 * 3. Order queries
 */
@Service
@Slf4j
@RequiredArgsConstructor
@Transactional
public class OrderService {

    private final OrderRepository orderRepository;
    private final KafkaTemplate<String, OrderEvent> kafkaTemplate;
    private static final String ORDER_EVENTS_TOPIC = "order-events";

    /**
     * Create a new order and start the Saga.
     *
     * SAGA START: Creating the order is the first step.
     * The client then calls POST /payments with this orderId.
     * Payment service publishes PAYMENT_INITIATED event.
     * Order service listens and moves to AWAITING_PAYMENT.
     */
    public OrderResponse createOrder(CreateOrderRequest request) {
        Order order = Order.createNew(
                request.getCustomerId(),
                request.getAmount(),
                request.getCurrency(),
                request.getDescription()
        );

        order = orderRepository.save(order);
        log.info("[ORDER] Created order: {} for customer: {}",
                order.getId(), order.getCustomerId());

        // Publish ORDER_CREATED event
        OrderEvent event = OrderEvent.of(
                OrderEvent.OrderEventType.ORDER_CREATED,
                order.getId(),
                order.getCustomerId(),
                null, // No payment yet
                order.getAmount(),
                order.getCurrency(),
                order.getSagaCorrelationId()
        );
        kafkaTemplate.send(ORDER_EVENTS_TOPIC, order.getId(), event);

        return OrderResponse.from(order);
    }

    /**
     * Get order by ID
     */
    @Transactional(readOnly = true)
    public OrderResponse getOrder(String orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderId));
        return OrderResponse.from(order);
    }

    /**
     * Get all orders for a customer
     */
    @Transactional(readOnly = true)
    public List<OrderResponse> getCustomerOrders(String customerId) {
        return orderRepository
                .findByCustomerIdOrderByCreatedAtDesc(customerId)
                .stream()
                .map(OrderResponse::from)
                .collect(Collectors.toList());
    }

    /**
     * TIMEOUT HANDLING for Saga
     *
     * TRAINING Day 3: Timeout handling in Saga
     *
     * Problem: What if payment-service never responds?
     * - Order stays in AWAITING_PAYMENT forever
     * - Customer never knows what happened
     *
     * Solution: Scheduled job cancels stale AWAITING_PAYMENT orders.
     *
     * Runs every 60 seconds.
     * Cancels orders stuck in AWAITING_PAYMENT for > 5 minutes.
     *
     * In production:
     * - Use a distributed scheduler (Quartz, AWS EventBridge)
     * - Ensure only ONE instance runs the job (leader election)
     * - Send notification to customer on timeout
     */
    @Scheduled(fixedDelay = 60000) // Every 60 seconds
    public void handleTimedOutOrders() {
        Instant timeout = Instant.now().minus(5, ChronoUnit.MINUTES);

        List<Order> timedOutOrders = orderRepository
                .findByStatus(OrderStatus.AWAITING_PAYMENT)
                .stream()
                .filter(o -> o.getUpdatedAt().isBefore(timeout))
                .collect(Collectors.toList());

        if (!timedOutOrders.isEmpty()) {
            log.warn("[SAGA TIMEOUT] Found {} orders stuck in AWAITING_PAYMENT > 5 min",
                    timedOutOrders.size());
        }

        for (Order order : timedOutOrders) {
            log.warn("[SAGA TIMEOUT] Cancelling timed-out order: {} (stuck since {})",
                    order.getId(), order.getUpdatedAt());

            order.setStatus(OrderStatus.CANCELLED);
            order.setFailureReason("Payment timeout - no response from payment service");
            order.setUpdatedAt(Instant.now());
            orderRepository.save(order);

            // Publish cancellation event
            OrderEvent timeoutEvent = OrderEvent.of(
                    OrderEvent.OrderEventType.ORDER_CANCELLED,
                    order.getId(),
                    order.getCustomerId(),
                    order.getPaymentId(),
                    order.getAmount(),
                    order.getCurrency(),
                    order.getSagaCorrelationId()
            );
            timeoutEvent.setFailureReason("Saga timeout");
            kafkaTemplate.send(ORDER_EVENTS_TOPIC, order.getId(), timeoutEvent);
        }
    }
}