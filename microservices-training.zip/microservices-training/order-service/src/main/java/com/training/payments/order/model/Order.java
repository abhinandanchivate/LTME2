package com.training.payments.order.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * TRAINING MODULE: Day 3 - Distributed Transactions
 *
 * Order entity representing the ORDER side of the Payment-Order Saga.
 *
 * ORDER STATES in Saga context:
 *
 *   [CREATED]
 *      │
 *      │ (payment initiated)
 *      ▼
 *   [AWAITING_PAYMENT]
 *      │                    │
 *      │ PAYMENT_COMPLETED  │ PAYMENT_FAILED
 *      ▼                    ▼
 *   [CONFIRMED]         [CANCELLED]
 *      │
 *      │ (fulfillment failure)
 *      ▼
 *   [FULFILLMENT_FAILED]
 *      │
 *      │ (triggers compensation)
 *      ▼
 *   [REFUND_REQUESTED] -> payment-service issues refund
 *
 * KEY INSIGHT: 
 * Order and Payment are in DIFFERENT databases (different services).
 * We cannot use a single ACID transaction across both.
 * Saga provides eventual consistency through compensating transactions.
 *
 * 2PC vs SAGA:
 * 2PC (Two-Phase Commit):
 *   - Coordinator locks resources across ALL services
 *   - All commit or all rollback (atomic)
 *   - Problem: Coordinator failure = system hangs
 *   - Problem: Long-held locks reduce throughput
 *
 * SAGA:
 *   - Each service commits locally
 *   - Compensation (undo) on failure
 *   - No distributed lock
 *   - Eventually consistent (not immediately consistent)
 */
@Entity
@Table(name = "orders")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Order {

    @Id
    @Column(name = "id", nullable = false, length = 36)
    private String id;

    @Column(name = "customer_id", nullable = false, length = 36)
    private String customerId;

    @Column(name = "amount", nullable = false, precision = 19, scale = 4)
    private BigDecimal amount;

    @Column(name = "currency", nullable = false, length = 3)
    private String currency;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private OrderStatus status;

    /**
     * Payment ID linked to this order (set when payment initiated in Saga)
     */
    @Column(name = "payment_id", length = 36)
    private String paymentId;

    /**
     * Description of items ordered
     */
    @Column(name = "description")
    private String description;

    /**
     * Saga correlation ID - links all events in one Saga flow
     * TRAINING: Same correlationId appears in payment-events and order-events
     * Allows tracing the FULL saga flow across services
     */
    @Column(name = "saga_correlation_id", length = 36)
    private String sagaCorrelationId;

    /**
     * Reason for cancellation or failure
     */
    @Column(name = "failure_reason", length = 500)
    private String failureReason;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    /**
     * Factory method - new order starts in CREATED state
     */
    public static Order createNew(String customerId, BigDecimal amount,
                                   String currency, String description) {
        return Order.builder()
                .id(UUID.randomUUID().toString())
                .customerId(customerId)
                .amount(amount)
                .currency(currency)
                .description(description)
                .status(OrderStatus.CREATED)
                .sagaCorrelationId(UUID.randomUUID().toString())
                .build();
    }
}