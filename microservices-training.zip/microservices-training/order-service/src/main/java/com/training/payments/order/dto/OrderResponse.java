package com.training.payments.order.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.training.payments.order.model.Order;
import com.training.payments.order.model.OrderStatus;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * TRAINING MODULE: Day 3 - Order Response DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderResponse {

    private String orderId;
    private String customerId;
    private BigDecimal amount;
    private String currency;
    private OrderStatus status;
    private String paymentId;
    private String description;
    private String sagaCorrelationId;
    private String failureReason;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant createdAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant updatedAt;

    public static OrderResponse from(Order order) {
        return OrderResponse.builder()
                .orderId(order.getId())
                .customerId(order.getCustomerId())
                .amount(order.getAmount())
                .currency(order.getCurrency())
                .status(order.getStatus())
                .paymentId(order.getPaymentId())
                .description(order.getDescription())
                .sagaCorrelationId(order.getSagaCorrelationId())
                .failureReason(order.getFailureReason())
                .createdAt(order.getCreatedAt())
                .updatedAt(order.getUpdatedAt())
                .build();
    }
}