package com.training.payments.order.saga;

import com.training.payments.common.event.PaymentEvent;
import com.training.payments.order.event.OrderEvent;
import com.training.payments.order.model.Order;
import com.training.payments.order.model.OrderStatus;
import com.training.payments.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Optional;

/**
 * TRAINING MODULE: Day 3 - Saga Choreography (Consumer Side)
 *
 * Listens to payment-events topic and reacts to payment status changes.
 *
 * CHOREOGRAPHY SAGA FLOW:
 * ┌─────────────────────────────────────────────────────────────────┐
 * │                    HAPPY PATH                                    │
 * │                                                                  │
 * │  Client                payment-service           order-service   │
 * │    │                        │                         │          │
 * │    │── POST /orders ────────│────────────────────────►│          │
 * │    │                        │                         │          │
 * │    │◄─ orderId returned ────│─────────────────────────│          │
 * │    │                        │                         │          │
 * │    │── POST /payments ──────►│                         │          │
 * │    │                        │── [PAYMENT_COMPLETED] ──►│          │
 * │    │                        │                         │          │
 * │    │                        │                         │ confirms  │
 * │    │◄── payment response ───│                         │ order     │
 * └─────────────────────────────────────────────────────────────────┘
 *
 * COMPENSATION FLOW (Payment Failed):
 * ┌─────────────────────────────────────────────────────────────────┐
 * │                    COMPENSATION PATH                             │
 * │                                                                  │
 * │  payment-service                          order-service          │
 * │       │── [PAYMENT_FAILED] ──────────────►│                      │
 * │       │                                   │ cancels order        │
 * │       │── [PAYMENT_REFUNDED] ─────────────►│                      │
 * │       │                (if refund needed)  │ marks refunded       │
 * └─────────────────────────────────────────────────────────────────┘
 *
 * TIMEOUT HANDLING:
 * - If order-service never receives PAYMENT_COMPLETED after X minutes
 * - A scheduled job cancels AWAITING_PAYMENT orders (timeout compensation)
 *
 * IDEMPOTENCY IN CONSUMERS:
 * - Kafka may deliver same event TWICE (at-least-once delivery)
 * - Consumer MUST be idempotent
 * - We check current order status before applying transition
 * - If already CONFIRMED, skip processing PAYMENT_COMPLETED again
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class PaymentEventConsumer {

    private final OrderRepository orderRepository;
    private final KafkaTemplate<String, OrderEvent> kafkaTemplate;

    private static final String ORDER_EVENTS_TOPIC = "order-events";

    /**
     * Listen to payment-events topic.
     *
     * containerFactory = "kafkaListenerContainerFactory" (default)
     * groupId = "order-service" (set in application.yml)
     *
     * Manual acknowledgment (ackMode = MANUAL):
     * - Don't commit offset until we've successfully processed the event
     * - If processing fails, reprocess on next consumer start
     * - Prevents lost events but requires idempotent processing
     */
    @KafkaListener(
        topics = "payment-events",
        groupId = "order-service",
        containerFactory = "kafkaListenerContainerFactory"
    )
    @Transactional
    public void handlePaymentEvent(
            @Payload PaymentEvent event,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int partition,
            @Header(KafkaHeaders.OFFSET) long offset) {

        log.info("[SAGA] Received payment event: {} for order: {} " +
                 "| topic:{} partition:{} offset:{}",
                event.getEventType(), event.getOrderId(),
                topic, partition, offset);

        // Route to appropriate handler based on event type
        switch (event.getEventType()) {
            case PAYMENT_COMPLETED -> handlePaymentCompleted(event);
            case PAYMENT_FAILED    -> handlePaymentFailed(event);
            case PAYMENT_REFUNDED  -> handlePaymentRefunded(event);
            case PAYMENT_INITIATED -> handlePaymentInitiated(event);
            default -> log.debug("[SAGA] Ignoring event type: {}",
                               event.getEventType());
        }
    }

    /**
     * SAGA STEP: Payment Initiated
     * Update order to AWAITING_PAYMENT state
     */
    private void handlePaymentInitiated(PaymentEvent event) {
        log.info("[SAGA] Payment initiated for order: {}", event.getOrderId());

        orderRepository.findById(event.getOrderId()).ifPresent(order -> {
            // IDEMPOTENCY: Skip if already in AWAITING_PAYMENT
            if (order.getStatus() == OrderStatus.AWAITING_PAYMENT) {
                log.info("[SAGA IDEMPOTENT] Order {} already AWAITING_PAYMENT",
                        order.getId());
                return;
            }

            if (order.getStatus() == OrderStatus.CREATED) {
                order.setStatus(OrderStatus.AWAITING_PAYMENT);
                order.setPaymentId(event.getPaymentId());
                order.setUpdatedAt(Instant.now());
                orderRepository.save(order);
                log.info("[SAGA] Order {} -> AWAITING_PAYMENT", order.getId());
            }
        });
    }

    /**
     * SAGA STEP: Payment Completed (Happy Path)
     * Confirm the order and trigger fulfillment.
     *
     * EVENTUAL CONSISTENCY DEMO:
     * At this moment:
     * - Payment DB: status=COMPLETED (committed in payment-service TX)
     * - Order DB: status=AWAITING_PAYMENT (not yet updated)
     * There is a brief window of inconsistency.
     * After this method completes, both are consistent.
     */
    private void handlePaymentCompleted(PaymentEvent event) {
        log.info("[SAGA] Payment completed for order: {}. Confirming order.",
                event.getOrderId());

        Optional<Order> orderOpt = orderRepository.findById(event.getOrderId());
        if (orderOpt.isEmpty()) {
            log.warn("[SAGA] Order not found for payment: {}. " +
                     "Order may not exist yet - will be retried.",
                    event.getOrderId());
            return;
        }

        Order order = orderOpt.get();

        // IDEMPOTENCY CHECK: Don't re-confirm an already confirmed order
        if (order.getStatus() == OrderStatus.CONFIRMED ||
            order.getStatus() == OrderStatus.COMPLETED) {
            log.info("[SAGA IDEMPOTENT] Order {} already confirmed. Skipping.",
                    order.getId());
            return;
        }

        // Transition order to CONFIRMED
        order.setStatus(OrderStatus.CONFIRMED);
        order.setPaymentId(event.getPaymentId());
        order.setUpdatedAt(Instant.now());
        orderRepository.save(order);

        log.info("[SAGA] Order {} CONFIRMED after payment {} completed",
                order.getId(), event.getPaymentId());

        // Simulate fulfillment (10% random failure for demo)
        boolean fulfillmentSucceeded = simulateFulfillment(order);

        if (!fulfillmentSucceeded) {
            // COMPENSATION NEEDED: Fulfillment failed after payment!
            // Must request refund from payment-service
            log.error("[SAGA COMPENSATION] Fulfillment failed for order {}! " +
                      "Triggering payment refund compensation.", order.getId());

            order.setStatus(OrderStatus.FULFILLMENT_FAILED);
            order.setFailureReason("Fulfillment system unavailable");
            order.setUpdatedAt(Instant.now());
            orderRepository.save(order);

            // Publish ORDER_FAILED event -> payment-service will refund
            OrderEvent failureEvent = OrderEvent.of(
                    OrderEvent.OrderEventType.ORDER_FAILED,
                    order.getId(),
                    order.getCustomerId(),
                    event.getPaymentId(),
                    order.getAmount(),
                    order.getCurrency(),
                    order.getSagaCorrelationId()
            );
            failureEvent.setFailureReason("Fulfillment failed");
            kafkaTemplate.send(ORDER_EVENTS_TOPIC, order.getId(), failureEvent);
        } else {
            order.setStatus(OrderStatus.COMPLETED);
            order.setUpdatedAt(Instant.now());
            orderRepository.save(order);
            log.info("[SAGA] Order {} COMPLETED (fulfilled)", order.getId());

            // Publish ORDER_CONFIRMED event
            OrderEvent confirmedEvent = OrderEvent.of(
                    OrderEvent.OrderEventType.ORDER_CONFIRMED,
                    order.getId(),
                    order.getCustomerId(),
                    event.getPaymentId(),
                    order.getAmount(),
                    order.getCurrency(),
                    order.getSagaCorrelationId()
            );
            kafkaTemplate.send(ORDER_EVENTS_TOPIC, order.getId(), confirmedEvent);
        }
    }

    /**
     * SAGA STEP: Payment Failed (Compensation)
     * Cancel the order since payment was rejected.
     */
    private void handlePaymentFailed(PaymentEvent event) {
        log.warn("[SAGA COMPENSATION] Payment failed for order: {}. Cancelling order.",
                event.getOrderId());

        orderRepository.findById(event.getOrderId()).ifPresent(order -> {
            // IDEMPOTENCY: Already cancelled
            if (order.getStatus() == OrderStatus.CANCELLED) {
                log.info("[SAGA IDEMPOTENT] Order {} already CANCELLED", order.getId());
                return;
            }

            order.setStatus(OrderStatus.CANCELLED);
            order.setFailureReason("Payment failed: " + event.getFailureReason());
            order.setUpdatedAt(Instant.now());
            orderRepository.save(order);

            log.info("[SAGA] Order {} CANCELLED due to payment failure", order.getId());

            // Publish ORDER_CANCELLED event
            OrderEvent cancelledEvent = OrderEvent.of(
                    OrderEvent.OrderEventType.ORDER_CANCELLED,
                    order.getId(),
                    order.getCustomerId(),
                    event.getPaymentId(),
                    order.getAmount(),
                    order.getCurrency(),
                    order.getSagaCorrelationId()
            );
            kafkaTemplate.send(ORDER_EVENTS_TOPIC, order.getId(), cancelledEvent);
        });
    }

    /**
     * SAGA STEP: Payment Refunded (Compensation Complete)
     * Acknowledge refund completion.
     */
    private void handlePaymentRefunded(PaymentEvent event) {
        log.info("[SAGA] Payment refunded for order: {}", event.getOrderId());

        orderRepository.findById(event.getOrderId()).ifPresent(order -> {
            order.setStatus(OrderStatus.REFUND_REQUESTED);
            order.setUpdatedAt(Instant.now());
            orderRepository.save(order);

            log.info("[SAGA] Order {} updated to REFUND_REQUESTED", order.getId());
        });
    }

    /**
     * Simulate fulfillment system (random 10% failure for demo)
     * In production: Call warehouse/shipping system
     */
    private boolean simulateFulfillment(Order order) {
        boolean success = Math.random() > 0.10; // 90% success rate
        if (success) {
            log.info("[FULFILLMENT] Order {} fulfillment SUCCESSFUL", order.getId());
        } else {
            log.error("[FULFILLMENT] Order {} fulfillment FAILED (simulated)",
                    order.getId());
        }
        return success;
    }
}