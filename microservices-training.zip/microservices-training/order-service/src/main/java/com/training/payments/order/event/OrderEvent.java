package com.training.payments.order.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * TRAINING MODULE: Day 3 - Saga Choreography
 *
 * Events published by order-service to trigger Saga compensations.
 *
 * CHOREOGRAPHY EVENT FLOW:
 *
 * payment-service ──[PAYMENT_COMPLETED]──► order-service
 *                                              │
 *                                              │ (confirms order)
 *                                              │
 *                                              │ (fulfillment fails!)
 *                                              │
 *                 ◄──[ORDER_FAILED]────── order-service
 *                         │
 *                         │ (payment-service issues refund)
 *                         │
 * payment-service ──[PAYMENT_REFUNDED]──► order-service
 *                                              │
 *                                         (marks REFUND_REQUESTED)
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderEvent {

    private String eventId;
    private OrderEventType eventType;
    private String orderId;
    private String customerId;
    private String paymentId;
    private BigDecimal amount;
    private String currency;
    private String failureReason;
    private String correlationId;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant occurredAt;

    public enum OrderEventType {
        ORDER_CREATED,
        ORDER_PAYMENT_INITIATED,
        ORDER_CONFIRMED,
        ORDER_CANCELLED,
        ORDER_FAILED,           // Triggers payment refund compensation
        ORDER_REFUND_REQUESTED
    }

    public static OrderEvent of(OrderEventType type, String orderId,
                                 String customerId, String paymentId,
                                 BigDecimal amount, String currency,
                                 String correlationId) {
        return OrderEvent.builder()
                .eventId(UUID.randomUUID().toString())
                .eventType(type)
                .orderId(orderId)
                .customerId(customerId)
                .paymentId(paymentId)
                .amount(amount)
                .currency(currency)
                .correlationId(correlationId)
                .occurredAt(Instant.now())
                .build();
    }
}