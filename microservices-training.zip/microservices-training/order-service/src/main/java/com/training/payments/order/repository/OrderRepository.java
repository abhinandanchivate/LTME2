package com.training.payments.order.repository;

import com.training.payments.order.model.Order;
import com.training.payments.order.model.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * TRAINING MODULE: Day 3 - Order Repository
 */
@Repository
public interface OrderRepository extends JpaRepository<Order, String> {

    Optional<Order> findByPaymentId(String paymentId);

    List<Order> findByCustomerIdOrderByCreatedAtDesc(String customerId);

    List<Order> findByStatus(OrderStatus status);

    Optional<Order> findBySagaCorrelationId(String correlationId);
}