package com.training.payments.order.saga;

import com.training.payments.order.event.OrderEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * TRAINING MODULE: Day 3 - Saga Observability
 *
 * Listens to order-events for monitoring/audit purposes.
 * In production this would be a separate audit/notification service.
 * Shown here to demonstrate the full event flow.
 */
@Component
@Slf4j
public class OrderEventConsumer {

    @KafkaListener(topics = "order-events", groupId = "order-service-audit")
    public void handleOrderEvent(
            @Payload OrderEvent event,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic) {

        log.info("[ORDER EVENT AUDIT] Event: {} | Order: {} | Correlation: {}",
                event.getEventType(), event.getOrderId(), event.getCorrelationId());
    }
}