package com.training.payments.order.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;

/**
 * TRAINING MODULE: Day 3 - Order Request DTO
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateOrderRequest {

    @NotBlank(message = "Customer ID required")
    private String customerId;

    @NotNull(message = "Amount required")
    @DecimalMin(value = "0.01", message = "Amount must be positive")
    private BigDecimal amount;

    @NotBlank(message = "Currency required")
    @Pattern(regexp = "[A-Z]{3}", message = "3-letter ISO currency code required")
    private String currency;

    @NotBlank(message = "Description required")
    private String description;
}