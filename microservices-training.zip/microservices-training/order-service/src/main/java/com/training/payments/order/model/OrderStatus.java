package com.training.payments.order.model;

/**
 * TRAINING MODULE: Day 3 - Saga State Machine
 *
 * Order status transitions in the Saga flow.
 */
public enum OrderStatus {
    CREATED,              // Order created, payment not yet initiated
    AWAITING_PAYMENT,     // Payment saga started
    CONFIRMED,            // Payment completed, order confirmed
    CANCELLED,            // Payment failed - order cancelled
    FULFILLMENT_FAILED,   // Order confirmed but fulfillment failed
    REFUND_REQUESTED,     // Compensation: refund requested from payment-service
    COMPLETED             // Fully fulfilled and completed
}