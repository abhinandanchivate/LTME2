package com.training.payments.common.model;

/**
 * TRAINING MODULE: Day 1 + Day 3
 *
 * Payment Status State Machine:
 *
 *  [PENDING] --> [PROCESSING] --> [COMPLETED]
 *      |               |
 *      |               v
 *      +--------> [FAILED]
 *      |
 *      v
 *  [CANCELLED]
 *      |
 *      v (via Saga compensation)
 *  [REFUNDED]
 *
 * TRAINING Day 3 - Saga:
 * - PENDING: Saga started, payment initiated
 * - PROCESSING: Sent to PSP, awaiting confirmation
 * - COMPLETED: PSP confirmed, order can be fulfilled
 * - FAILED: PSP rejected, Saga triggers compensation in order-service
 * - CANCELLED: Payment cancelled before processing
 * - REFUNDED: Compensation applied after order failure
 */
public enum PaymentStatus {

    /**
     * Initial state - payment created but not yet sent to PSP
     */
    PENDING,

    /**
     * Sent to PSP - awaiting async confirmation
     */
    PROCESSING,

    /**
     * PSP confirmed payment success
     * Cache-safe: This status can be cached with longer TTL
     */
    COMPLETED,

    /**
     * PSP rejected or error occurred
     * Cache-safe: This status can be cached briefly
     */
    FAILED,

    /**
     * Client cancelled before processing
     */
    CANCELLED,

    /**
     * Refund issued - Saga compensation flow
     * TRAINING Day 3: This is the compensating transaction
     */
    REFUNDED;

    /**
     * Check if this is a terminal state (no further transitions possible)
     * Used by idempotency logic to decide if we should re-process
     */
    public boolean isTerminal() {
        return this == COMPLETED || this == FAILED ||
               this == CANCELLED || this == REFUNDED;
    }

    /**
     * Check if status is cacheable (stable enough to cache)
     */
    public boolean isCacheable() {
        return this == COMPLETED || this == REFUNDED;
    }
}