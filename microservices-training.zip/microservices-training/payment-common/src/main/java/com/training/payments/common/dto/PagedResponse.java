package com.training.payments.common.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.List;

/**
 * TRAINING MODULE: Day 1 - Pagination vs Filtering Tradeoffs
 *
 * Generic paged response wrapper supporting BOTH pagination strategies:
 *
 * OFFSET-BASED PAGINATION (traditional):
 * - GET /payments?page=0&size=20
 * - Simple, works with SQL LIMIT/OFFSET
 * - Problem: Page drift when data changes (items inserted between pages)
 * - Good for: Admin dashboards, stable datasets
 *
 * CURSOR-BASED PAGINATION (recommended for payments):
 * - GET /payments?cursor=eyJpZCI6IjEyMyJ9&size=20
 * - No page drift - cursor anchors to a specific record
 * - Good for: Real-time feeds, payment history, infinite scroll
 * - Used by: Twitter, Facebook, Stripe API
 *
 * This class supports BOTH strategies.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PagedResponse<T> {

    /**
     * The actual data items for this page
     */
    private List<T> data;

    // =====================================
    // OFFSET PAGINATION fields
    // =====================================

    /**
     * Current page number (0-based)
     */
    private Integer page;

    /**
     * Items per page
     */
    private Integer size;

    /**
     * Total items across all pages
     * WARNING: Expensive COUNT query - avoid on huge datasets!
     */
    private Long totalElements;

    /**
     * Total pages available
     */
    private Integer totalPages;

    // =====================================
    // CURSOR PAGINATION fields
    // =====================================

    /**
     * Opaque cursor for next page.
     * Clients treat this as a black box and pass it back.
     * Internally encoded as Base64(JSON{lastId, lastTimestamp})
     */
    private String nextCursor;

    /**
     * Cursor for previous page (for bidirectional cursor paging)
     */
    private String prevCursor;

    /**
     * Whether there are more results after this page
     */
    private boolean hasMore;

    // =====================================
    // Common metadata
    // =====================================

    /**
     * Filters that were applied to produce this result
     * Helps clients understand what they're looking at
     */
    private java.util.Map<String, String> appliedFilters;

    /**
     * Factory for offset-based response
     */
    public static <T> PagedResponse<T> ofOffset(List<T> data, int page, int size,
                                                  long total) {
        return PagedResponse.<T>builder()
                .data(data)
                .page(page)
                .size(size)
                .totalElements(total)
                .totalPages((int) Math.ceil((double) total / size))
                .hasMore((long) (page + 1) * size < total)
                .build();
    }

    /**
     * Factory for cursor-based response
     */
    public static <T> PagedResponse<T> ofCursor(List<T> data, String nextCursor,
                                                  String prevCursor, boolean hasMore) {
        return PagedResponse.<T>builder()
                .data(data)
                .nextCursor(nextCursor)
                .prevCursor(prevCursor)
                .hasMore(hasMore)
                .build();
    }
}