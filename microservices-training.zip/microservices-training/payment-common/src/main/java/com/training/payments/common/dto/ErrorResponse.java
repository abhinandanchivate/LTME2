package com.training.payments.common.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * TRAINING MODULE: Day 1 - OpenAPI Error Models
 *
 * Standardized error response structure.
 * ALL services return this same shape on errors.
 *
 * Design principles:
 * 1. errorCode: Stable machine-readable identifier (never change these!)
 * 2. message: Human-readable (can change between versions)
 * 3. traceId: Links to distributed trace for debugging
 * 4. fieldErrors: Validation errors mapped by field name
 *
 * Example:
 * {
 *   "errorCode": "VALIDATION_ERROR",
 *   "message": "Request validation failed",
 *   "traceId": "abc-123-xyz",
 *   "fieldErrors": {
 *     "amount": "must be positive",
 *     "currency": "must be 3-letter ISO code"
 *   }
 * }
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ErrorResponse {

    /**
     * Machine-readable error code - stable across API versions
     * Clients should switch on this, NOT on the message string
     */
    private String errorCode;

    /**
     * Human-readable error description
     */
    private String message;

    /**
     * HTTP status code (redundant but helpful for logging middleware)
     */
    private int status;

    /**
     * Distributed trace ID - paste this into Zipkin/Jaeger to find the full trace
     * TRAINING Day 3: Observability - this connects HTTP error to distributed trace
     */
    private String traceId;

    /**
     * Request path that caused the error
     */
    private String path;

    /**
     * When the error occurred
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant timestamp;

    /**
     * Field-level validation errors
     * key = field name, value = error message
     */
    private Map<String, String> fieldErrors;

    /**
     * Additional error details
     */
    private List<String> details;

    /**
     * Factory method for simple errors
     */
    public static ErrorResponse of(String errorCode, String message,
                                    int status, String traceId) {
        return ErrorResponse.builder()
                .errorCode(errorCode)
                .message(message)
                .status(status)
                .traceId(traceId)
                .timestamp(Instant.now())
                .build();
    }
}