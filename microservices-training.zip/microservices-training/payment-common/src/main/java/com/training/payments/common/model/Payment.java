package com.training.payments.common.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * TRAINING MODULE: Day 1 - Shared Payment Model
 *
 * This is the core Payment domain model shared across ALL services.
 * By placing it in payment-common, we ensure:
 * 1. Single source of truth for Payment structure
 * 2. No duplication across payment-service, order-service, bff-service
 * 3. Consistent serialization/deserialization everywhere
 *
 * DESIGN NOTE: In real microservices, teams debate whether to share models.
 * Sharing creates coupling. The alternative is per-service models with mapping.
 * For this training, we share to keep focus on microservices concepts.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL) // Don't serialize null fields
public class Payment {

    /**
     * Unique payment identifier - UUID format for global uniqueness
     * across distributed systems (no DB sequence needed)
     */
    private String id;

    /**
     * Idempotency key - provided by the CLIENT to prevent duplicate payments.
     * If client retries with the same key, we return existing result.
     * TRAINING: Day 1 - Idempotency concept
     */
    @NotBlank(message = "Idempotency key is required")
    private String idempotencyKey;

    /**
     * Order this payment belongs to - links payment to order-service
     * TRAINING: Day 3 - Saga coordination uses this reference
     */
    @NotBlank(message = "Order ID is required")
    private String orderId;

    /**
     * Amount to charge - BigDecimal for precise monetary calculations
     * NEVER use float/double for money!
     */
    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be positive")
    @DecimalMax(value = "999999.99", message = "Amount exceeds limit")
    private BigDecimal amount;

    /**
     * ISO 4217 currency code (USD, EUR, GBP, etc.)
     */
    @NotBlank(message = "Currency is required")
    @Size(min = 3, max = 3, message = "Currency must be 3-letter ISO code")
    @Pattern(regexp = "[A-Z]{3}", message = "Currency must be uppercase")
    private String currency;

    /**
     * Payment status - drives the state machine
     * TRAINING: Day 2 - Circuit Breaker fallback uses PENDING status
     * TRAINING: Day 2 - Cache stores COMPLETED/FAILED statuses
     */
    private PaymentStatus status;

    /**
     * Payment method details
     */
    private String paymentMethod; // CARD, BANK_TRANSFER, WALLET

    /**
     * Masked card number (last 4 digits only - PCI DSS compliance)
     */
    private String maskedCardNumber;

    /**
     * PSP (Payment Service Provider) transaction reference
     * e.g., Stripe charge ID, PayPal transaction ID
     */
    private String pspReference;

    /**
     * Customer making the payment
     */
    @NotBlank(message = "Customer ID is required")
    private String customerId;

    /**
     * Timestamps for audit trail
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant createdAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant updatedAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant processedAt;

    /**
     * Failure reason if status is FAILED
     */
    private String failureReason;

    /**
     * Metadata - flexible key/value for extensibility
     * TRAINING: Avoid breaking changes by using metadata for new fields
     */
    private java.util.Map<String, String> metadata;

    /**
     * Factory method - creates a new payment in PENDING state
     */
    public static Payment createNew(String orderId, String customerId,
                                    BigDecimal amount, String currency,
                                    String idempotencyKey) {
        return Payment.builder()
                .id(UUID.randomUUID().toString())
                .idempotencyKey(idempotencyKey)
                .orderId(orderId)
                .customerId(customerId)
                .amount(amount)
                .currency(currency)
                .status(PaymentStatus.PENDING)
                .createdAt(Instant.now())
                .updatedAt(Instant.now())
                .build();
    }
}