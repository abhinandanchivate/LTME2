package com.training.payments.common.exception;

import lombok.Getter;

/**
 * TRAINING MODULE: Day 1 - Error Models in API Design
 *
 * Base exception hierarchy for consistent error handling.
 * In microservices, structured exceptions translate to
 * consistent HTTP error responses with machine-readable codes.
 *
 * Error model design:
 * - errorCode: Machine-readable (e.g., PAYMENT_NOT_FOUND)
 * - message: Human-readable description
 * - details: Additional context for debugging
 */
@Getter
public class PaymentException extends RuntimeException {

    private final String errorCode;
    private final int httpStatus;

    public PaymentException(String errorCode, String message, int httpStatus) {
        super(message);
        this.errorCode = errorCode;
        this.httpStatus = httpStatus;
    }

    public PaymentException(String errorCode, String message, int httpStatus,
                            Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.httpStatus = httpStatus;
    }

    // ===== Specific exception types =====

    public static class PaymentNotFoundException extends PaymentException {
        public PaymentNotFoundException(String paymentId) {
            super("PAYMENT_NOT_FOUND",
                  "Payment not found: " + paymentId, 404);
        }
    }

    public static class DuplicatePaymentException extends PaymentException {
        public DuplicatePaymentException(String idempotencyKey) {
            super("DUPLICATE_PAYMENT",
                  "Payment with idempotency key already exists: " + idempotencyKey,
                  409);
        }
    }

    public static class PaymentProcessingException extends PaymentException {
        public PaymentProcessingException(String message) {
            super("PAYMENT_PROCESSING_ERROR", message, 422);
        }
    }

    public static class InsufficientFundsException extends PaymentException {
        public InsufficientFundsException() {
            super("INSUFFICIENT_FUNDS",
                  "Payment declined: Insufficient funds", 422);
        }
    }

    public static class PspUnavailableException extends PaymentException {
        public PspUnavailableException(String pspName) {
            super("PSP_UNAVAILABLE",
                  "Payment processor " + pspName + " is currently unavailable",
                  503);
        }
    }

    public static class RateLimitExceededException extends PaymentException {
        public RateLimitExceededException(String clientId) {
            super("RATE_LIMIT_EXCEEDED",
                  "Too many requests from client: " + clientId, 429);
        }
    }
}