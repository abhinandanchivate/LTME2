package com.training.payments.common.dto;

import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;

/**
 * TRAINING MODULE: Day 1 - API Design & OpenAPI
 *
 * PaymentRequest is what CLIENTS send to create a payment.
 * Separate from the Payment domain model to:
 * 1. Control exactly what clients can set (vs internal fields like id, status)
 * 2. Allow API contract to evolve independently of domain model
 * 3. Apply input validation at the boundary
 *
 * CONTRACT-FIRST DESIGN: This DTO is the contract.
 * The OpenAPI spec is generated FROM this class via annotations.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentRequest {

    @NotBlank(message = "Order ID is required")
    private String orderId;

    @NotBlank(message = "Customer ID is required")
    private String customerId;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Minimum payment is 0.01")
    @DecimalMax(value = "999999.99", message = "Maximum payment is 999,999.99")
    private BigDecimal amount;

    @NotBlank(message = "Currency required")
    @Pattern(regexp = "[A-Z]{3}", message = "Currency must be 3-letter ISO 4217 code")
    private String currency;

    @NotBlank(message = "Payment method required")
    @Pattern(regexp = "CARD|BANK_TRANSFER|WALLET",
             message = "Payment method must be CARD, BANK_TRANSFER, or WALLET")
    private String paymentMethod;

    /**
     * Card number - only required when paymentMethod = CARD
     * Will be masked before storage (PCI DSS)
     */
    private String cardNumber;

    /**
     * Idempotency key - client generates this UUID.
     * On retry, same key = same result returned without re-processing.
     * TRAINING Day 1: Critical for preventing double-charging!
     */
    @NotBlank(message = "Idempotency key required to prevent duplicate payments")
    private String idempotencyKey;
}