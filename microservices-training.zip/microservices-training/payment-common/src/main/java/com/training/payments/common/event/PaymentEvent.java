package com.training.payments.common.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.training.payments.common.model.PaymentStatus;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/**
 * TRAINING MODULE: Day 3 - Saga Choreography Events
 *
 * Events published to message broker (Kafka/RabbitMQ) when
 * payment status changes. Order-service listens to these events
 * to react in the Saga choreography pattern.
 *
 * Event types:
 * - PAYMENT_INITIATED: Saga started
 * - PAYMENT_COMPLETED: Order service should confirm order
 * - PAYMENT_FAILED: Order service should cancel order
 * - PAYMENT_REFUNDED: Compensation complete
 *
 * CHOREOGRAPHY vs ORCHESTRATION:
 * - This event approach = CHOREOGRAPHY (no central coordinator)
 * - Each service reacts independently to events
 * - Contrast with Orchestration where a Saga orchestrator directs each step
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentEvent {

    /**
     * Unique event ID - for deduplication at consumer side
     */
    private String eventId;

    /**
     * Type of event - drives consumer behavior
     */
    private PaymentEventType eventType;

    /**
     * Payment this event relates to
     */
    private String paymentId;

    /**
     * Order this payment belongs to
     */
    private String orderId;

    /**
     * Customer making the payment
     */
    private String customerId;

    /**
     * Payment amount
     */
    private BigDecimal amount;

    /**
     * Currency
     */
    private String currency;

    /**
     * New status after this event
     */
    private PaymentStatus newStatus;

    /**
     * Failure reason if PAYMENT_FAILED event
     */
    private String failureReason;

    /**
     * Correlation ID links all events in one Saga flow
     * TRAINING Day 3: Tracing - same correlationId tracks full saga
     */
    private String correlationId;

    /**
     * When event was emitted
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private Instant occurredAt;

    /**
     * Factory method for payment events
     */
    public static PaymentEvent of(PaymentEventType type, String paymentId,
                                   String orderId, String customerId,
                                   BigDecimal amount, String currency,
                                   PaymentStatus status, String correlationId) {
        return PaymentEvent.builder()
                .eventId(UUID.randomUUID().toString())
                .eventType(type)
                .paymentId(paymentId)
                .orderId(orderId)
                .customerId(customerId)
                .amount(amount)
                .currency(currency)
                .newStatus(status)
                .correlationId(correlationId)
                .occurredAt(Instant.now())
                .build();
    }

    public enum PaymentEventType {
        PAYMENT_INITIATED,      // Saga starts
        PAYMENT_PROCESSING,     // Sent to PSP
        PAYMENT_COMPLETED,      // PSP confirmed - order service: confirm order
        PAYMENT_FAILED,         // PSP failed - order service: cancel order
        PAYMENT_CANCELLED,      // Client cancelled
        PAYMENT_REFUNDED        // Compensation complete
    }
}