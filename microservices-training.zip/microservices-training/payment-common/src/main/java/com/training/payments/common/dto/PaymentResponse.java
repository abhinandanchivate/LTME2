package com.training.payments.common.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.training.payments.common.model.Payment;
import com.training.payments.common.model.PaymentStatus;
import lombok.*;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * TRAINING MODULE: Day 1 - API Design
 *
 * PaymentResponse is what we return to clients.
 * Key design decisions demonstrated:
 * 1. Never expose internal PSP references in v1 (backward compat)
 * 2. Use consistent timestamp format (ISO 8601)
 * 3. Include HATEOAS-style links for discoverability
 * 4. Mask sensitive data before returning
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentResponse {

    private String paymentId;
    private String orderId;
    private String customerId;
    private BigDecimal amount;
    private String currency;
    private PaymentStatus status;
    private String paymentMethod;
    private String maskedCardNumber; // Never return full card number!
    private String pspReference;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'",
                timezone = "UTC")
    private Instant createdAt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss'Z'",
                timezone = "UTC")
    private Instant processedAt;

    private String failureReason;

    /**
     * API version that created this response
     * TRAINING Day 1: Versioning - helps clients know which contract applies
     */
    private String apiVersion;

    /**
     * Factory method: Build response from domain Payment
     * Demonstrates mapping domain -> DTO at the boundary
     */
    public static PaymentResponse from(Payment payment, String apiVersion) {
        return PaymentResponse.builder()
                .paymentId(payment.getId())
                .orderId(payment.getOrderId())
                .customerId(payment.getCustomerId())
                .amount(payment.getAmount())
                .currency(payment.getCurrency())
                .status(payment.getStatus())
                .paymentMethod(payment.getPaymentMethod())
                .maskedCardNumber(payment.getMaskedCardNumber())
                .pspReference(payment.getPspReference())
                .createdAt(payment.getCreatedAt())
                .processedAt(payment.getProcessedAt())
                .failureReason(payment.getFailureReason())
                .apiVersion(apiVersion)
                .build();
    }
}