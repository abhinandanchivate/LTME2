package com.training.payments.gateway.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.Map;

/**
 * TRAINING MODULE: Day 2 - Gateway Fallback
 *
 * Fallback endpoints called when Circuit Breaker OPENS at gateway level.
 *
 * When payment-service is DOWN:
 * 1. Client calls: GET /api/v1/payments/123
 * 2. Gateway circuit breaker opens (too many failures)
 * 3. Gateway routes to: /fallback/payment-service
 * 4. This controller returns graceful degraded response
 *
 * FALLBACK STRATEGIES:
 * - Cached response (best UX)
 * - Static error message (chosen here)
 * - Redirect to status page
 *
 * TRAINING: Uses Mono<> (reactive) since gateway is WebFlux-based
 */
@RequestMapping("/fallback")
public class FallbackController {

    @GetMapping("/payment-service")
    public Mono<ResponseEntity<Map<String, Object>>> paymentServiceFallback() {
        Map<String, Object> response = Map.of(
            "errorCode", "SERVICE_UNAVAILABLE",
            "message", "Payment service is temporarily unavailable. Please try again later.",
            "timestamp", Instant.now().toString(),
            "retryAfter", "30s",
            "status", 503
        );
        return Mono.just(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(response));
    }

    @GetMapping("/order-service")
    public Mono<ResponseEntity<Map<String, Object>>> orderServiceFallback() {
        Map<String, Object> response = Map.of(
            "errorCode", "SERVICE_UNAVAILABLE",
            "message", "Order service is temporarily unavailable. Please try again later.",
            "timestamp", Instant.now().toString(),
            "status", 503
        );
        return Mono.just(ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(response));
    }
}