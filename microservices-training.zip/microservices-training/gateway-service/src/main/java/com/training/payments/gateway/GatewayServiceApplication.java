package com.training.payments.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * TRAINING MODULE: Day 2 - Gateway & Discovery
 *
 * API Gateway entry point.
 *
 * All client traffic enters HERE first:
 *
 * Client -> Gateway (8080) -> [payment-service, order-service, bff-service]
 *
 * GATEWAY vs LOAD BALANCER:
 * L4 Load Balancer: Routes TCP packets by IP/port (Day 4)
 * L7 API Gateway:   Routes HTTP requests by path/header/method
 *                   Can inspect and modify request content
 *
 * DEMO:
 * With ALL services running, ALL these URLs work via gateway:
 * - http://localhost:8080/api/v1/payments  -> payment-service
 * - http://localhost:8080/api/v2/payments  -> payment-service
 * - http://localhost:8080/api/v1/orders    -> order-service
 * - http://localhost:8080/bff/dashboard    -> bff-service
 */
@SpringBootApplication
@EnableDiscoveryClient
public class GatewayServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(GatewayServiceApplication.class, args);
    }
}