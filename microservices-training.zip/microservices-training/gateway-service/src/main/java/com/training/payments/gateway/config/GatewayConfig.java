package com.training.payments.gateway.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import org.springframework.cloud.gateway.filter.ratelimit.KeyResolver;
import reactor.core.publisher.Mono;

import java.util.UUID;

/**
 * TRAINING MODULE: Day 2 - Gateway Configuration
 *
 * Programmatic route configuration (alternative to application.yml routes).
 * Demonstrates:
 * 1. Programmatic routing with fluent API
 * 2. Custom global filters (applied to ALL routes)
 * 3. Authentication filter (API key validation)
 * 4. Request/Response logging filter
 *
 * TRAINING NOTE: Routes defined here MERGE with application.yml routes.
 * Production teams typically use EITHER code OR YAML, not both.
 * We show both for educational completeness.
 */
@Configuration
@Slf4j
public class GatewayConfig {

    /**
     * Programmatic route definition showing advanced routing.
     *
     * BLUE-GREEN ROUTING DEMO:
     * To simulate blue-green deployment:
     * 1. payment-service (BLUE) runs on port 8081
     * 2. payment-service-green (GREEN) runs on port 8082
     * 3. Header X-Version: green routes to GREEN deployment
     * 4. Default routes to BLUE deployment
     *
     * CANARY ROUTING DEMO:
     * Route 10% of traffic to green (new version) for testing
     */
    @Bean
    public RouteLocator customRoutes(RouteLocatorBuilder builder) {
        return builder.routes()

            // ============================================================
            // CANARY ROUTE: 10% traffic to v2 (green deployment)
            // TRAINING: Header-based routing for A/B testing
            // ============================================================
            .route("payment-canary", r -> r
                .path("/api/v1/payments/**")
                .and()
                .header("X-Canary", "true")  // Only canary requests
                .filters(f -> f
                    .addRequestHeader("X-Deployment", "green")
                    .addResponseHeader("X-Canary-Routed", "true"))
                .uri("lb://payment-service"))

            // ============================================================
            // AGGREGATION ROUTE: Combines payment + order data
            // TRAINING: Gateway aggregation pattern
            // ============================================================
            .route("payment-summary", r -> r
                .path("/api/v1/payment-summary/**")
                .filters(f -> f
                    .rewritePath("/api/v1/payment-summary/(?<segment>.*)",
                                 "/bff/payment-summary/${segment}")
                    .addRequestHeader("X-Gateway-Aggregated", "true"))
                .uri("lb://bff-service"))

            .build();
    }

    /**
     * GLOBAL FILTER 1: Correlation ID injection
     *
     * Ensures EVERY request has a correlation ID for distributed tracing.
     * If client provides X-Correlation-ID, use it (allows end-to-end tracing
     * from client through all services).
     * If not provided, gateway generates one.
     *
     * TRAINING Day 3: Observability - correlation IDs link all log entries
     * across payment-service, order-service for a single transaction.
     */
    @Bean
    @Order(1)
    public GlobalFilter correlationIdFilter() {
        return (exchange, chain) -> {
            String correlationId = exchange.getRequest()
                    .getHeaders()
                    .getFirst("X-Correlation-ID");

            if (correlationId == null || correlationId.isEmpty()) {
                correlationId = UUID.randomUUID().toString();
                log.debug("[GATEWAY] Generated Correlation ID: {}", correlationId);
            } else {
                log.debug("[GATEWAY] Using client Correlation ID: {}", correlationId);
            }

            // Add to request going to downstream service
            final String finalCorrelationId = correlationId;
            ServerWebExchange mutatedExchange = exchange.mutate()
                    .request(r -> r.header("X-Correlation-ID", finalCorrelationId))
                    .build();

            // Add to response coming back to client
            return chain.filter(mutatedExchange).then(Mono.fromRunnable(() ->
                exchange.getResponse()
                    .getHeaders()
                    .add("X-Correlation-ID", finalCorrelationId)
            ));
        };
    }

    /**
     * GLOBAL FILTER 2: Request/Response Logging
     *
     * Logs all requests at gateway level.
     * TRAINING Day 3: Centralized access logging (similar to NGINX access log)
     *
     * In production: Send to ELK stack or CloudWatch
     */
    @Bean
    @Order(2)
    public GlobalFilter requestLoggingFilter() {
        return (exchange, chain) -> {
            long startTime = System.currentTimeMillis();
            String path = exchange.getRequest().getURI().getPath();
            String method = exchange.getRequest().getMethod().toString();
            String clientIp = exchange.getRequest().getRemoteAddress() != null
                    ? exchange.getRequest().getRemoteAddress().getAddress().getHostAddress()
                    : "unknown";

            log.info("[GATEWAY ACCESS] {} {} from {} | Headers: {}",
                    method, path, clientIp,
                    exchange.getRequest().getHeaders().getFirst("X-Correlation-ID"));

            return chain.filter(exchange).then(Mono.fromRunnable(() -> {
                long duration = System.currentTimeMillis() - startTime;
                int statusCode = exchange.getResponse().getStatusCode() != null
                        ? exchange.getResponse().getStatusCode().value() : 0;

                log.info("[GATEWAY ACCESS] {} {} -> {} | {}ms",
                        method, path, statusCode, duration);
            }));
        };
    }

    /**
     * GLOBAL FILTER 3: API Key Authentication
     *
     * Validates X-API-Key header on all /api/** routes.
     * TRAINING Day 4: Security at edge (WAF-like validation)
     *
     * In production: Validate against API key store (DB/Redis)
     * or forward to Identity Provider (OAuth2 token validation)
     */
    @Bean
    @Order(3)
    public GlobalFilter apiKeyAuthFilter() {
        return (exchange, chain) -> {
            String path = exchange.getRequest().getURI().getPath();

            // Only protect /api/** endpoints
            if (!path.startsWith("/api/")) {
                return chain.filter(exchange);
            }

            String apiKey = exchange.getRequest()
                    .getHeaders()
                    .getFirst("X-API-Key");

            // For demo: accept any non-empty API key
            // In production: validate against key store
            if (apiKey != null && !apiKey.isEmpty()) {
                log.debug("[GATEWAY AUTH] Valid API key for path: {}", path);
                return chain.filter(exchange);
            }

            // No API key - reject with 401
            log.warn("[GATEWAY AUTH] Missing API key for path: {}", path);
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            exchange.getResponse().getHeaders().add("Content-Type", "application/json");
            return exchange.getResponse().setComplete();
        };
    }

    /**
     * KeyResolver for Gateway-level rate limiting.
     * Extracts client identity from X-API-Key header.
     * Falls back to "anonymous" if header is missing.
     */
    @Bean
    public KeyResolver apiKeyResolver() {
        return exchange -> Mono.justOrEmpty(
                        exchange.getRequest().getHeaders().getFirst("X-API-Key"))
                .defaultIfEmpty("anonymous");
    }
}