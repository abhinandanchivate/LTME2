package com.training.payments.service.entity;

import com.training.payments.common.model.PaymentStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * TRAINING MODULE: Day 1 - Microservice Structure
 *
 * JPA Entity for persistence. Separate from the shared Payment model.
 *
 * WHY SEPARATE ENTITY FROM DOMAIN MODEL?
 * - Entity is tied to JPA/DB concerns (annotations, column mapping)
 * - Domain model (Payment.java in common) is pure business logic
 * - Avoids leaking persistence concerns into the API layer
 * - Allows DB schema to evolve independently of API contract
 *
 * Pattern: Entity -> Domain Model mapping in the service layer
 */
@Entity
@Table(
    name = "payments",
    indexes = {
        // Index on orderId for saga lookups
        @Index(name = "idx_payments_order_id", columnList = "order_id"),
        // Index on customerId for payment history queries
        @Index(name = "idx_payments_customer_id", columnList = "customer_id"),
        // Unique index on idempotency key - enforced at DB level
        @Index(name = "idx_payments_idempotency_key",
               columnList = "idempotency_key", unique = true),
        // Composite index for status + createdAt (common query pattern)
        @Index(name = "idx_payments_status_created",
               columnList = "status, created_at")
    }
)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PaymentEntity {

    @Id
    @Column(name = "id", nullable = false, length = 36)
    private String id;

    /**
     * Unique constraint on idempotency_key prevents duplicate payments
     * at the DATABASE level (last line of defense after application checks)
     */
    @Column(name = "idempotency_key", nullable = false, unique = true, length = 64)
    private String idempotencyKey;

    @Column(name = "order_id", nullable = false, length = 36)
    private String orderId;

    @Column(name = "customer_id", nullable = false, length = 36)
    private String customerId;

    @Column(name = "amount", nullable = false,
            precision = 19, scale = 4)
    private BigDecimal amount;

    @Column(name = "currency", nullable = false, length = 3)
    private String currency;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private PaymentStatus status;

    @Column(name = "payment_method", length = 20)
    private String paymentMethod;

    @Column(name = "masked_card_number", length = 20)
    private String maskedCardNumber;

    @Column(name = "psp_reference", length = 64)
    private String pspReference;

    @Column(name = "failure_reason", length = 500)
    private String failureReason;

    @Column(name = "processed_at")
    private Instant processedAt;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    /**
     * Flexible metadata stored as JSON string
     * In production: use @JdbcTypeCode(SqlTypes.JSON) with PostgreSQL JSONB
     */
    @ElementCollection
    @CollectionTable(name = "payment_metadata",
                     joinColumns = @JoinColumn(name = "payment_id"))
    @MapKeyColumn(name = "meta_key")
    @Column(name = "meta_value")
    @Builder.Default
    private Map<String, String> metadata = new HashMap<>();
}