package com.training.payments.service.observability;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import io.micrometer.observation.ObservationRegistry;
import io.micrometer.observation.aop.ObservedAspect;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * TRAINING MODULE: Day 3 - Observability
 *
 * Configures the THREE PILLARS of observability:
 *
 * 1. LOGS:    Structured log entries (via Slf4j + Logback)
 *             Correlated by traceId/spanId injected automatically
 *             by Micrometer Tracing
 *
 * 2. METRICS: Counters, Timers, Gauges exported to Prometheus
 *             Visualized in Grafana dashboards
 *             GOLDEN SIGNALS for payments:
 *             - Latency:     payment_processing_duration_seconds
 *             - Traffic:     payment_requests_total
 *             - Errors:      payment_failures_total
 *             - Saturation:  jvm_threads_live (thread pool usage)
 *
 * 3. TRACES:  Distributed traces sent to Zipkin
 *             One trace = full journey of ONE payment request
 *             across gateway -> payment-service -> PSP call
 *             Each service = one SPAN in the trace
 *             Spans linked by traceId propagated in HTTP headers
 *
 * CORRELATION IDs vs TRACE IDs:
 * - Correlation ID: Business-level, set by client/gateway, in logs
 * - Trace ID:       Infrastructure-level, set by tracing library, in Zipkin
 * Both appear in logs when Micrometer Tracing is configured.
 *
 * TRACE PROPAGATION HEADERS (B3 format):
 * X-B3-TraceId:  abc123 (same across all services for one request)
 * X-B3-SpanId:   def456 (unique per service hop)
 * X-B3-Sampled:  1      (whether to sample this trace)
 */
@Configuration
public class ObservabilityConfig {

    /**
     * Enable @Observed annotation support.
     * Any method annotated with @Observed gets automatic span creation.
     *
     * Example usage in service:
     *   @Observed(name = "payment.process", contextualName = "process-payment")
     *   public PaymentResponse createPayment(...) { ... }
     */
    @Bean
    public ObservedAspect observedAspect(ObservationRegistry registry) {
        return new ObservedAspect(registry);
    }

    /**
     * GOLDEN SIGNAL: Payment request counter
     * Labels: status (success/failure), method (CARD/BANK_TRANSFER)
     *
     * Query in Prometheus:
     * rate(payment_requests_total[5m])           -> requests/sec
     * rate(payment_requests_total{status="error"}[5m]) -> error rate
     */
    @Bean
    public Counter paymentRequestCounter(MeterRegistry registry) {
        return Counter.builder("payment.requests.total")
                .description("Total number of payment requests")
                .tag("service", "payment-service")
                .register(registry);
    }

    /**
     * GOLDEN SIGNAL: Payment processing duration
     * Tracks end-to-end payment latency including PSP call
     *
     * Query in Prometheus:
     * histogram_quantile(0.99, payment_processing_duration_seconds_bucket)
     *   -> 99th percentile latency (P99)
     */
    @Bean
    public Timer paymentProcessingTimer(MeterRegistry registry) {
        return Timer.builder("payment.processing.duration")
                .description("Time to process a payment end-to-end")
                .tag("service", "payment-service")
                .publishPercentiles(0.5, 0.95, 0.99) // P50, P95, P99
                .register(registry);
    }

    /**
     * GOLDEN SIGNAL: Payment failure counter
     * Labels: reason (psp_error, validation_error, rate_limited)
     *
     * Alert when: rate(payment_failures_total[5m]) > threshold
     */
    @Bean
    public Counter paymentFailureCounter(MeterRegistry registry) {
        return Counter.builder("payment.failures.total")
                .description("Total number of payment failures")
                .tag("service", "payment-service")
                .register(registry);
    }

    /**
     * Circuit breaker state metric
     * Prometheus gauge: 0=CLOSED, 1=OPEN, 2=HALF_OPEN
     * Alert when: payment_circuit_breaker_state == 1 (OPEN)
     */
    @Bean
    public io.micrometer.core.instrument.Gauge circuitBreakerGauge(
            MeterRegistry registry,
            io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry cbRegistry) {
        return io.micrometer.core.instrument.Gauge
                .builder("payment.circuit_breaker.state",
                        cbRegistry.circuitBreaker("psp-circuit-breaker"),
                        cb -> switch (cb.getState()) {
                            case CLOSED    -> 0.0;
                            case OPEN      -> 1.0;
                            case HALF_OPEN -> 2.0;
                            default        -> -1.0;
                        })
                .description("Circuit breaker state: 0=CLOSED, 1=OPEN, 2=HALF_OPEN")
                .register(registry);
    }
}