package com.training.payments.service.psp;

import com.training.payments.common.exception.PaymentException;
import com.training.payments.common.model.Payment;
import io.github.resilience4j.bulkhead.annotation.Bulkhead;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

/**
 * TRAINING MODULE: Day 2 - Circuit Breaker + Retry + Bulkhead
 *
 * PSP Client demonstrates the FULL resilience pattern stack.
 *
 * In production: This calls Stripe, PayPal, Adyen, etc.
 * In training:   This is a MOCK that simulates failures.
 *
 * ANNOTATION ORDER (innermost to outermost):
 * @TimeLimiter -> @Bulkhead -> @CircuitBreaker -> @Retry
 *
 * Execution flow:
 * Retry {
 *   CircuitBreaker {
 *     Bulkhead {
 *       TimeLimiter {
 *         actual PSP call
 *       }
 *     }
 *   }
 * }
 *
 * When PSP is DOWN:
 * 1. @TimeLimiter fires after 5s timeout
 * 2. @Retry retries up to 3 times (with exponential backoff)
 * 3. @CircuitBreaker opens after 50% failures
 * 4. Subsequent calls get IMMEDIATE fallback (no PSP calls!)
 * 5. After 10s, @CircuitBreaker tries HALF-OPEN
 * 6. If PSP recovered, circuit CLOSES and normal flow resumes
 */
@Component
@Slf4j
public class PspClient {

    @Value("${payment.psp.base-url}")
    private String pspBaseUrl;

    // Simulate random failures for demo
    private final Random random = new Random();

    // Track call count for demo visualization
    private int callCount = 0;
    private int failureCount = 0;

    /**
     * Charge a payment via PSP.
     *
     * Resilience annotations applied:
     * - @Retry: retry up to 3 times on IOException/TimeoutException
     * - @CircuitBreaker: open circuit after 50% failure rate
     * - @Bulkhead: max 10 concurrent calls
     *
     * IMPORTANT: The method MUST return CompletableFuture for @TimeLimiter
     *
     * Fallback method = chargePaymentFallback
     * Called when: CB is OPEN, or all retries exhausted
     */
    @Retry(name = "psp-retry", fallbackMethod = "chargePaymentFallback")
    @CircuitBreaker(name = "psp-circuit-breaker", fallbackMethod = "chargePaymentFallback")
    @Bulkhead(name = "psp-bulkhead", fallbackMethod = "chargePaymentFallback")
    public PspResponse chargePayment(PspChargeRequest request) {
        callCount++;
        log.info("[PSP] Attempting charge #{} for payment {} amount {}{}",
                callCount, request.getPaymentId(),
                request.getAmount(), request.getCurrency());

        // ============================================================
        // DEMO SIMULATION: Simulate PSP failure scenarios
        // In real life: RestTemplate/WebClient HTTP call to PSP
        // ============================================================
        simulatePspBehavior(request);

        // Simulate PSP processing delay (100-500ms)
        try {
            Thread.sleep(100 + random.nextInt(400));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Generate mock PSP reference
        String pspRef = "PSP-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        log.info("[PSP] Charge successful. PSP Ref: {}", pspRef);
        return PspResponse.success(pspRef);
    }

    /**
     * FALLBACK METHOD - called when CircuitBreaker is OPEN or all retries fail
     *
     * FALLBACK STRATEGIES:
     * 1. Return CACHED previous result (if available)
     * 2. Return degraded response (payment PENDING - process async later)
     * 3. Queue for retry (put in message queue)
     * 4. Fail fast with clear error (chosen here for transparency)
     *
     * TRAINING: The fallback MUST have same signature as main method
     * PLUS a Throwable parameter as the last argument.
     */
    public PspResponse chargePaymentFallback(PspChargeRequest request, Throwable t) {
        failureCount++;
        log.warn("[PSP FALLBACK] Circuit breaker OPEN or retries exhausted. " +
                 "Payment: {}, Failure: {}", request.getPaymentId(), t.getMessage());

        // Return a PENDING response - we'll process async when PSP recovers
        // TRAINING: This is the "fail gracefully" strategy
        return PspResponse.fallback(
            "PSP temporarily unavailable. Payment queued for processing.");
    }

    /**
     * Refund a payment via PSP
     * Also protected by circuit breaker
     */
    @Retry(name = "psp-retry")
    @CircuitBreaker(name = "psp-circuit-breaker", fallbackMethod = "refundPaymentFallback")
    public PspResponse refundPayment(String pspReference, BigDecimal amount) {
        log.info("[PSP] Refunding PSP ref: {} amount: {}", pspReference, amount);

        // Simulate refund processing
        try {
            Thread.sleep(200 + random.nextInt(300));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        String refundRef = "REF-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        log.info("[PSP] Refund successful. Refund Ref: {}", refundRef);
        return PspResponse.success(refundRef);
    }

    public PspResponse refundPaymentFallback(String pspReference,
                                              BigDecimal amount, Throwable t) {
        log.warn("[PSP FALLBACK] Refund failed for {}: {}", pspReference, t.getMessage());
        return PspResponse.fallback("Refund queued - PSP unavailable");
    }

    /**
     * ============================================================
     * DEMO SIMULATION LOGIC
     * ============================================================
     * Simulates different PSP failure scenarios for training demos.
     * Controlled by payment amount ranges:
     * - amount < 10: Always succeed (happy path)
     * - amount 10-50: 30% random failure
     * - amount 50-100: Always fail (simulate PSP rejection)
     * - amount > 100: Simulate timeout (slow call)
     */
    private void simulatePspBehavior(PspChargeRequest request) {
        BigDecimal amount = request.getAmount();

        if (amount.compareTo(BigDecimal.valueOf(10)) < 0) {
            // Happy path - always succeed
            return;
        }

        if (amount.compareTo(BigDecimal.valueOf(50)) < 0) {
            // 30% failure rate - triggers retry
            if (random.nextInt(100) < 30) {
                log.warn("[PSP MOCK] Simulating transient failure");
                throw new RuntimeException("PSP transient error - connection reset");
            }
        }

        if (amount.compareTo(BigDecimal.valueOf(100)) < 0 &&
            amount.compareTo(BigDecimal.valueOf(50)) >= 0) {
            // Simulate card declined (business error - not retriable)
            log.warn("[PSP MOCK] Simulating insufficient funds");
            throw new PaymentException.InsufficientFundsException();
        }

        if (amount.compareTo(BigDecimal.valueOf(100)) >= 0) {
            // Simulate slow PSP (triggers slow call threshold in CB)
            try {
                log.warn("[PSP MOCK] Simulating slow PSP response (3.5s)");
                Thread.sleep(3500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("PSP call interrupted");
            }
        }
    }

    // Health info for demo visualization
    public String getCircuitBreakerStatus() {
        return String.format("Calls: %d, Failures: %d", callCount, failureCount);
    }
}