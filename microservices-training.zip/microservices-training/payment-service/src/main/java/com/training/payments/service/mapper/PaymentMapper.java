package com.training.payments.service.mapper;

import com.training.payments.common.dto.PaymentResponse;
import com.training.payments.common.model.Payment;
import com.training.payments.service.entity.PaymentEntity;
import org.springframework.stereotype.Component;

/**
 * TRAINING MODULE: Day 1 - Microservice Structure
 *
 * Mapper converts between:
 * - Domain model (Payment) <-> JPA Entity (PaymentEntity)
 * - JPA Entity (PaymentEntity) -> API Response DTO (PaymentResponse)
 *
 * WHY SEPARATE MAPPERS?
 * Each representation serves a different purpose:
 * - Entity: DB persistence (JPA annotations)
 * - Domain: Business logic (pure Java)
 * - DTO: API contract (Jackson annotations, validation)
 *
 * ALTERNATIVES: MapStruct (annotation processor), ModelMapper
 * For training: Manual mapping for clarity
 */
@Component
public class PaymentMapper {

    /**
     * Convert domain Payment to JPA Entity for persistence
     */
    public PaymentEntity toEntity(Payment payment) {
        return PaymentEntity.builder()
                .id(payment.getId())
                .idempotencyKey(payment.getIdempotencyKey())
                .orderId(payment.getOrderId())
                .customerId(payment.getCustomerId())
                .amount(payment.getAmount())
                .currency(payment.getCurrency())
                .status(payment.getStatus())
                .paymentMethod(payment.getPaymentMethod())
                .maskedCardNumber(payment.getMaskedCardNumber())
                .pspReference(payment.getPspReference())
                .failureReason(payment.getFailureReason())
                .processedAt(payment.getProcessedAt())
                .build();
    }

    /**
     * Convert JPA Entity to API Response DTO
     * API version determines which fields are included
     *
     * TRAINING Day 1 - Versioning:
     * v1: No pspReference (internal detail not exposed in v1 contract)
     * v2: Full details including pspReference
     */
    public PaymentResponse toResponse(PaymentEntity entity, String apiVersion) {
        PaymentResponse.PaymentResponseBuilder builder = PaymentResponse.builder()
                .paymentId(entity.getId())
                .orderId(entity.getOrderId())
                .customerId(entity.getCustomerId())
                .amount(entity.getAmount())
                .currency(entity.getCurrency())
                .status(entity.getStatus())
                .paymentMethod(entity.getPaymentMethod())
                .maskedCardNumber(entity.getMaskedCardNumber())
                .createdAt(entity.getCreatedAt())
                .processedAt(entity.getProcessedAt())
                .failureReason(entity.getFailureReason())
                .apiVersion(apiVersion);

        // V2 API includes PSP reference
        if ("v2".equals(apiVersion)) {
            builder.pspReference(entity.getPspReference());
        }
        // V1 hides PSP reference (backward-compatible hiding of new field)

        return builder.build();
    }

    /**
     * Convert JPA Entity to Domain model
     */
    public Payment toDomain(PaymentEntity entity) {
        return Payment.builder()
                .id(entity.getId())
                .idempotencyKey(entity.getIdempotencyKey())
                .orderId(entity.getOrderId())
                .customerId(entity.getCustomerId())
                .amount(entity.getAmount())
                .currency(entity.getCurrency())
                .status(entity.getStatus())
                .paymentMethod(entity.getPaymentMethod())
                .maskedCardNumber(entity.getMaskedCardNumber())
                .pspReference(entity.getPspReference())
                .failureReason(entity.getFailureReason())
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .processedAt(entity.getProcessedAt())
                .build();
    }
}