package com.training.payments.service.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.training.payments.common.dto.ErrorResponse;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Refill;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * TRAINING MODULE: Day 2 - Rate Limiting
 *
 * Implements TOKEN BUCKET rate limiting using Bucket4j.
 *
 * ============================================================
 * TOKEN BUCKET ALGORITHM:
 * ============================================================
 *
 *  [Bucket: max 60 tokens]
 *   tokens: ██████████████████░░░░░░░░░░░░░░  (40/60)
 *
 *  - Bucket refills at rate: 1 token per second (60/min)
 *  - Each request CONSUMES 1 token
 *  - Request allowed if tokens > 0
 *  - Request REJECTED (429) if tokens = 0
 *
 * BURST HANDLING:
 *  Bucket has BURST capacity (10 extra tokens).
 *  A client can burst 10 requests instantly, then throttled to 1/sec.
 *  Good for: mobile apps reconnecting after offline, batch operations
 *
 * TOKEN BUCKET vs LEAKY BUCKET:
 *  Token Bucket: Allows bursts up to bucket capacity
 *  Leaky Bucket: Smooths traffic to constant rate (no bursts)
 *
 * TOKEN BUCKET vs QUOTA:
 *  Token Bucket: Rate per time window (requests/second)
 *  Quota: Total requests per billing period (daily/monthly limit)
 *
 * PER-CLIENT vs GLOBAL:
 *  This implementation: Per-client (keyed by API key or IP)
 *  Each client has their own bucket
 *
 * DDoS AWARENESS:
 *  Rate limiting slows DDoS but doesn't stop it.
 *  Full DDoS protection requires WAF + CDN (Day 4 - WAF module)
 *
 * RESPONSE HEADERS (standard):
 *  X-RateLimit-Limit: 60
 *  X-RateLimit-Remaining: 45
 *  X-RateLimit-Reset: 1704067200 (epoch when bucket refills)
 *  Retry-After: 15 (seconds to wait)
 */
@Component
@Order(1) // Run before other filters
@Slf4j
public class RateLimitFilter implements Filter {

    @Value("${payment.rate-limit.requests-per-minute:60}")
    private int requestsPerMinute;

    @Value("${payment.rate-limit.burst-capacity:10}")
    private int burstCapacity;

    private final ObjectMapper objectMapper;

    /**
     * Per-client bucket store.
     * Key: client identifier (API key or IP)
     * Value: Token bucket for that client
     *
     * TRAINING: In production use Redis-backed Bucket4j for distributed rate limiting
     * (multiple service instances share same bucket state)
     * Library: bucket4j-redis
     */
    private final Map<String, Bucket> clientBuckets = new ConcurrentHashMap<>();

    public RateLimitFilter(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // Only rate limit API endpoints
        String path = httpRequest.getRequestURI();
        if (!path.startsWith("/api/")) {
            chain.doFilter(request, response);
            return;
        }

        // Identify client: API key preferred, fall back to IP
        String clientId = getClientIdentifier(httpRequest);

        // Get or create bucket for this client
        Bucket bucket = clientBuckets.computeIfAbsent(clientId,
                this::createBucket);

        // Available tokens for header
        long availableTokens = bucket.getAvailableTokens();

        // Try to consume 1 token
        if (bucket.tryConsume(1)) {
            // Request ALLOWED - add rate limit headers
            addRateLimitHeaders(httpResponse, availableTokens - 1);
            log.debug("[RATE LIMIT] Client {} allowed. Tokens remaining: {}",
                    clientId, availableTokens - 1);
            chain.doFilter(request, response);
        } else {
            // Request REJECTED - 429 Too Many Requests
            log.warn("[RATE LIMIT] Client {} RATE LIMITED. Path: {}", clientId, path);
            sendRateLimitResponse(httpResponse, clientId);
        }
    }

    /**
     * Create a new token bucket for a client.
     *
     * Bandwidth 1 (GREEDY refill): Refills tokens as fast as possible
     * up to requestsPerMinute per minute.
     *
     * Bandwidth 2 (BURST): Extra burst capacity consumed first.
     */
    private Bucket createBucket(String clientId) {
        // Main rate: 60 requests per minute (greedy - refills evenly)
        Bandwidth mainLimit = Bandwidth.classic(
                requestsPerMinute,
                Refill.greedy(requestsPerMinute, Duration.ofMinutes(1))
        );

        // Burst: allow 10 extra requests immediately
        Bandwidth burstLimit = Bandwidth.classic(
                burstCapacity,
                Refill.intervally(burstCapacity, Duration.ofMinutes(1))
        );

        return Bucket.builder()
                .addLimit(mainLimit)
                .addLimit(burstLimit)
                .build();
    }

    /**
     * Extract client identifier from request.
     * Priority: X-API-Key > X-Client-ID > IP Address
     */
    private String getClientIdentifier(HttpServletRequest request) {
        String apiKey = request.getHeader("X-API-Key");
        if (apiKey != null && !apiKey.isEmpty()) {
            return "apikey:" + apiKey;
        }

        String clientId = request.getHeader("X-Client-ID");
        if (clientId != null && !clientId.isEmpty()) {
            return "client:" + clientId;
        }

        // Fall back to IP (less reliable - multiple users behind NAT)
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null) {
            // Take first IP from chain (client IP before proxies)
            return "ip:" + xForwardedFor.split(",")[0].trim();
        }

        return "ip:" + request.getRemoteAddr();
    }

    /**
     * Add standard rate limit response headers
     */
    private void addRateLimitHeaders(HttpServletResponse response,
                                      long remainingTokens) {
        response.setHeader("X-RateLimit-Limit",
                String.valueOf(requestsPerMinute));
        response.setHeader("X-RateLimit-Remaining",
                String.valueOf(Math.max(0, remainingTokens)));
        response.setHeader("X-RateLimit-Window", "60s");
    }

    /**
     * Send 429 Too Many Requests response
     */
    private void sendRateLimitResponse(HttpServletResponse response,
                                        String clientId) throws IOException {
        response.setStatus(429);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setHeader("Retry-After", "60");  // Retry after 60 seconds
        response.setHeader("X-RateLimit-Limit", String.valueOf(requestsPerMinute));
        response.setHeader("X-RateLimit-Remaining", "0");

        ErrorResponse error = ErrorResponse.builder()
                .errorCode("RATE_LIMIT_EXCEEDED")
                .message("Too many requests. Please retry after 60 seconds.")
                .status(429)
                .timestamp(Instant.now())
                .build();

        response.getWriter().write(objectMapper.writeValueAsString(error));
    }
}