package com.training.payments.service.service;

import com.training.payments.common.dto.*;
import com.training.payments.common.event.PaymentEvent;
import com.training.payments.common.exception.PaymentException;
import com.training.payments.common.model.Payment;
import com.training.payments.common.model.PaymentStatus;
import com.training.payments.service.config.CacheConfig;
import com.training.payments.service.entity.PaymentEntity;
import com.training.payments.service.mapper.PaymentMapper;
import com.training.payments.service.psp.PspChargeRequest;
import com.training.payments.service.psp.PspClient;
import com.training.payments.service.psp.PspResponse;
import com.training.payments.service.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * TRAINING MODULE: Day 1 + Day 2 + Day 3
 *
 * Core payment processing service orchestrating:
 * - Idempotency checks (Day 1)
 * - PSP calls with retry/circuit breaker (Day 2)
 * - Cache management (Day 2)
 * - Event publishing for Saga (Day 3)
 * - Both offset and cursor pagination (Day 1)
 */
@Service
@Slf4j
@RequiredArgsConstructor
@Transactional
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final PspClient pspClient;
    private final IdempotencyService idempotencyService;
    private final PaymentMapper paymentMapper;
    private final KafkaTemplate<String, PaymentEvent> kafkaTemplate;

    private static final String PAYMENT_EVENTS_TOPIC = "payment-events";
    private static final String API_V1 = "v1";
    private static final String API_V2 = "v2";

    // ================================================================
    // CREATE PAYMENT
    // TRAINING: Day 1 - Idempotency + Day 2 - Circuit Breaker
    // ================================================================

    /**
     * Create and process a new payment.
     *
     * Flow:
     * 1. Check idempotency key (cache check first, then DB)
     * 2. Create payment record in PENDING state
     * 3. Call PSP via circuit-breaker-protected client
     * 4. Update payment status based on PSP response
     * 5. Store idempotency response in cache
     * 6. Publish payment event for Saga
     */
    public PaymentResponse createPayment(PaymentRequest request, String apiVersion) {
        log.info("[PAYMENT] Creating payment for order: {} customer: {} amount: {}{}",
                request.getOrderId(), request.getCustomerId(),
                request.getAmount(), request.getCurrency());

        // ============================================================
        // STEP 1: IDEMPOTENCY CHECK
        // Check cache first (fast path), then DB (slow path)
        // ============================================================
        Optional<PaymentResponse> existingResponse =
                idempotencyService.findExistingResponse(request.getIdempotencyKey());

        if (existingResponse.isPresent()) {
            log.info("[IDEMPOTENCY] Duplicate request detected for key: {}. " +
                     "Returning cached response.", request.getIdempotencyKey());
            return existingResponse.get();
        }

        // Check DB for idempotency (handles case where cache was evicted)
        Optional<PaymentEntity> existingPayment =
                paymentRepository.findByIdempotencyKey(request.getIdempotencyKey());

        if (existingPayment.isPresent()) {
            log.info("[IDEMPOTENCY] Found existing payment in DB for key: {}",
                    request.getIdempotencyKey());
            PaymentResponse response = paymentMapper.toResponse(
                    existingPayment.get(), apiVersion);
            // Re-populate cache
            idempotencyService.storeResponse(request.getIdempotencyKey(), response);
            return response;
        }

        // ============================================================
        // STEP 2: MASK CARD NUMBER (PCI DSS)
        // ============================================================
        String maskedCard = maskCardNumber(request.getCardNumber());

        // ============================================================
        // STEP 3: CREATE PAYMENT IN PENDING STATE
        // ============================================================
        Payment newPayment = Payment.createNew(
                request.getOrderId(),
                request.getCustomerId(),
                request.getAmount(),
                request.getCurrency(),
                request.getIdempotencyKey()
        );
        newPayment.setPaymentMethod(request.getPaymentMethod());
        newPayment.setMaskedCardNumber(maskedCard);

        PaymentEntity entity = paymentMapper.toEntity(newPayment);
        entity = paymentRepository.save(entity);

        log.info("[PAYMENT] Payment created with ID: {} in PENDING state",
                entity.getId());

        // Publish PAYMENT_INITIATED event for Saga
        publishEvent(PaymentEvent.PaymentEventType.PAYMENT_INITIATED, entity, null);

        // ============================================================
        // STEP 4: CALL PSP (protected by Circuit Breaker + Retry)
        // ============================================================
        PspChargeRequest pspRequest = PspChargeRequest.builder()
                .paymentId(entity.getId())
                .idempotencyKey(request.getIdempotencyKey())
                .amount(request.getAmount())
                .currency(request.getCurrency())
                .paymentMethod(request.getPaymentMethod())
                .cardNumber(request.getCardNumber())
                .customerId(request.getCustomerId())
                .orderId(request.getOrderId())
                .build();

        PspResponse pspResponse = pspClient.chargePayment(pspRequest);

        // ============================================================
        // STEP 5: UPDATE PAYMENT STATUS BASED ON PSP RESPONSE
        // ============================================================
        if (pspResponse.isSuccessful()) {
            entity.setStatus(PaymentStatus.COMPLETED);
            entity.setPspReference(pspResponse.getPspReference());
            entity.setProcessedAt(Instant.now());
            log.info("[PAYMENT] Payment COMPLETED. PSP Ref: {}",
                    pspResponse.getPspReference());
            publishEvent(PaymentEvent.PaymentEventType.PAYMENT_COMPLETED, entity, null);

        } else if (pspResponse.isFallback()) {
            // Circuit breaker fallback - leave PENDING for async processing
            entity.setStatus(PaymentStatus.PENDING);
            log.warn("[PAYMENT] PSP unavailable. Payment {} left PENDING for retry.",
                    entity.getId());
            publishEvent(PaymentEvent.PaymentEventType.PAYMENT_PROCESSING, entity, null);

        } else {
            entity.setStatus(PaymentStatus.FAILED);
            entity.setFailureReason(pspResponse.getMessage());
            log.warn("[PAYMENT] Payment FAILED: {}", pspResponse.getMessage());
            publishEvent(PaymentEvent.PaymentEventType.PAYMENT_FAILED,
                    entity, pspResponse.getMessage());
        }

        entity.setUpdatedAt(Instant.now());
        entity = paymentRepository.save(entity);

        // ============================================================
        // STEP 6: CACHE THE RESPONSE FOR IDEMPOTENCY
        // ============================================================
        PaymentResponse response = paymentMapper.toResponse(entity, apiVersion);
        idempotencyService.storeResponse(request.getIdempotencyKey(), response);

        return response;
    }

    // ================================================================
    // GET PAYMENT BY ID
    // TRAINING: Day 2 - Caching with @Cacheable
    // ================================================================

    /**
     * Get payment by ID.
     *
     * @Cacheable: On cache HIT -> return cached value (no DB call!)
     *             On cache MISS -> call method, cache result, return
     *
     * Cache key: "payments::paymentId" (namespace::key)
     *
     * Cache invalidation:
     * - Automatic TTL expiry (5 min for this cache)
     * - Explicit eviction on payment update (@CacheEvict)
     *
     * TRAINING: HTTP Caching alternative:
     * Could set Cache-Control: max-age=300 header on GET /payments/{id}
     * Allows CDN/browser to cache responses.
     * But: Cannot easily invalidate per-item (would need ETag/Last-Modified)
     */
    @Transactional(readOnly = true)
    @Cacheable(value = CacheConfig.CACHE_PAYMENTS, key = "#paymentId",
               unless = "#result.status.name() == 'PENDING'")
    public PaymentResponse getPayment(String paymentId, String apiVersion) {
        log.info("[CACHE MISS] Loading payment {} from database", paymentId);

        PaymentEntity entity = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new PaymentException.PaymentNotFoundException(paymentId));

        return paymentMapper.toResponse(entity, apiVersion);
    }

    /**
     * Get just the payment status (lightweight cache entry)
     */
    @Transactional(readOnly = true)
    @Cacheable(value = CacheConfig.CACHE_PAYMENT_STATUS, key = "#paymentId")
    public PaymentStatus getPaymentStatus(String paymentId) {
        log.info("[CACHE MISS] Loading status for payment {} from DB", paymentId);
        return paymentRepository.findById(paymentId)
                .map(PaymentEntity::getStatus)
                .orElseThrow(() -> new PaymentException.PaymentNotFoundException(paymentId));
    }

    // ================================================================
    // GET PAYMENT HISTORY - OFFSET PAGINATION (v1 API)
    // TRAINING: Day 1 - Offset pagination
    // ================================================================

    /**
     * V1: Offset-based pagination for payment history.
     *
     * TRAINING: Offset pagination tradeoffs:
     * PRO: Simple, SQL-native, supports random page access
     * CON: Page drift, expensive COUNT, slow on large OFFSET
     *
     * @Cacheable with complex key (customer + page + size + status)
     */
    @Transactional(readOnly = true) // 100 / 5 = pages status = success/fail
    @Cacheable(value = CacheConfig.CACHE_PAYMENT_HISTORY,
               key = "#customerId + ':page:' + #page + ':size:' + #size + ':' + #status")
    public PagedResponse<PaymentResponse> getPaymentHistoryOffset(
            String customerId, int page, int size,
            PaymentStatus status, String apiVersion) {

        log.info("[CACHE MISS] Loading payment history (offset) for customer {} page {}",
                customerId, page);

        Pageable pageable = PageRequest.of(page, size,
                Sort.by(Sort.Direction.DESC, "createdAt"));

        Page<PaymentEntity> entityPage;
        if (status != null) {
            entityPage = paymentRepository
                    .findByCustomerIdAndStatusOrderByCreatedAtDesc(
                            customerId, status, pageable);
        } else {
            entityPage = paymentRepository
                    .findByCustomerIdOrderByCreatedAtDesc(customerId, pageable);
        }

        List<PaymentResponse> responses = entityPage.getContent().stream()
                .map(e -> paymentMapper.toResponse(e, apiVersion))
                .collect(Collectors.toList());

        return PagedResponse.ofOffset(responses, page, size,
                entityPage.getTotalElements());
    }

    // ================================================================
    // GET PAYMENT HISTORY - CURSOR PAGINATION (v2 API)
    // TRAINING: Day 1 - Cursor pagination
    // ================================================================

    /**
     * V2: Cursor-based pagination for payment history.
     *
     * TRAINING: Cursor pagination explained:
     * - Cursor encodes the position: Base64(lastCreatedAt + ":" + lastId)
     * - No COUNT query needed
     * - Stable under concurrent inserts
     * - O(log n) with index vs O(n) for large OFFSETs
     *
     * Client flow:
     * 1. GET /api/v2/payments/history?customerId=C1&size=10
     *    Response: { data: [...], nextCursor: "abc123", hasMore: true }
     * 2. GET /api/v2/payments/history?customerId=C1&size=10&cursor=abc123
     *    Response: { data: [...], nextCursor: "def456", hasMore: false }
     */
    @Transactional(readOnly = true)
    public PagedResponse<PaymentResponse> getPaymentHistoryCursor(
            String customerId, String cursor, int size, String apiVersion) {

        log.info("[CURSOR] Loading payment history for customer {} cursor: {}",
                customerId, cursor);

        // Fetch size+1 to detect if there are more pages
        Pageable pageable = PageRequest.of(0, size + 1);

        List<PaymentEntity> entities;
        if (cursor == null || cursor.isEmpty()) {
            // First page - no cursor
            entities = paymentRepository
                    .findByCustomerIdFirstPage(customerId, pageable);
        } else {
            // Decode cursor
            CursorData cursorData = decodeCursor(cursor);
            entities = paymentRepository.findByCustomerIdWithCursor(
                    customerId, cursorData.createdAt(), cursorData.id(), pageable);
        }

        // Determine if there are more pages
        boolean hasMore = entities.size() > size;
        if (hasMore) {
            entities = entities.subList(0, size); // Trim to requested size
        }

        List<PaymentResponse> responses = entities.stream()
                .map(e -> paymentMapper.toResponse(e, apiVersion))
                .collect(Collectors.toList());

        // Build next cursor from last item
        String nextCursor = null;
        String prevCursor = cursor; // Previous cursor is current cursor
        if (hasMore && !entities.isEmpty()) {
            PaymentEntity last = entities.get(entities.size() - 1);
            nextCursor = encodeCursor(last.getCreatedAt(), last.getId());
        }

        return PagedResponse.ofCursor(responses, nextCursor, prevCursor, hasMore);
    }

    // ================================================================
    // CANCEL PAYMENT
    // TRAINING: Cache eviction on state change
    // ================================================================

    /**
     * Cancel a payment.
     * @CacheEvict removes the stale cached entry when payment is updated.
     *
     * Without @CacheEvict: Cache would serve old PENDING status
     * even after payment is CANCELLED in DB. Cache inconsistency!
     */
    @CacheEvict(value = {CacheConfig.CACHE_PAYMENTS, CacheConfig.CACHE_PAYMENT_STATUS},
                key = "#paymentId")
    public PaymentResponse cancelPayment(String paymentId, String apiVersion) {
        PaymentEntity entity = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new PaymentException.PaymentNotFoundException(paymentId));

        if (entity.getStatus() != PaymentStatus.PENDING) {
            throw new PaymentException.PaymentProcessingException(
                    "Cannot cancel payment in " + entity.getStatus() + " state");
        }

        entity.setStatus(PaymentStatus.CANCELLED);
        entity.setUpdatedAt(Instant.now());
        entity = paymentRepository.save(entity);

        log.info("[PAYMENT] Payment {} cancelled", paymentId);
        publishEvent(PaymentEvent.PaymentEventType.PAYMENT_CANCELLED, entity, null);

        return paymentMapper.toResponse(entity, apiVersion);
    }

    // ================================================================
    // REFUND PAYMENT - Saga Compensation
    // TRAINING: Day 3 - Saga compensation flow
    // ================================================================

    /**
     * Refund a payment (Saga compensation transaction).
     * Called when order-service sends COMPENSATION command
     * in the Saga choreography flow.
     */
    @CacheEvict(value = {CacheConfig.CACHE_PAYMENTS, CacheConfig.CACHE_PAYMENT_STATUS},
                key = "#paymentId")
    public PaymentResponse refundPayment(String paymentId, String apiVersion) {
        PaymentEntity entity = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new PaymentException.PaymentNotFoundException(paymentId));

        if (entity.getStatus() != PaymentStatus.COMPLETED) {
            throw new PaymentException.PaymentProcessingException(
                    "Cannot refund payment in " + entity.getStatus() + " state");
        }

        log.info("[SAGA COMPENSATION] Refunding payment {} pspRef: {}",
                paymentId, entity.getPspReference());

        // Call PSP refund API
        PspResponse refundResponse = pspClient.refundPayment(
                entity.getPspReference(), entity.getAmount());

        entity.setStatus(PaymentStatus.REFUNDED);
        entity.setUpdatedAt(Instant.now());
        entity = paymentRepository.save(entity);

        log.info("[SAGA COMPENSATION] Payment {} refunded successfully", paymentId);
        publishEvent(PaymentEvent.PaymentEventType.PAYMENT_REFUNDED, entity, null);

        return paymentMapper.toResponse(entity, apiVersion);
    }

    // ================================================================
    // HELPER METHODS
    // ================================================================

    /**
     * Publish payment event to Kafka for Saga choreography
     * TRAINING: Day 3 - Event-driven Saga
     */
    private void publishEvent(PaymentEvent.PaymentEventType eventType,
                               PaymentEntity entity, String failureReason) {
        try {
            PaymentEvent event = PaymentEvent.of(
                    eventType,
                    entity.getId(),
                    entity.getOrderId(),
                    entity.getCustomerId(),
                    entity.getAmount(),
                    entity.getCurrency(),
                    entity.getStatus(),
                    entity.getId() // correlationId = paymentId for simplicity
            );
            event.setFailureReason(failureReason);

            kafkaTemplate.send(PAYMENT_EVENTS_TOPIC, entity.getOrderId(), event);
            log.info("[EVENT] Published {} for payment {} to topic {}",
                    eventType, entity.getId(), PAYMENT_EVENTS_TOPIC);
        } catch (Exception e) {
            // Don't fail payment if event publish fails
            // TRAINING: Use outbox pattern in production for guaranteed delivery
            log.error("[EVENT] Failed to publish event {} for payment {}: {}",
                    eventType, entity.getId(), e.getMessage());
        }
    }

    /**
     * Encode cursor as Base64 for opaque client representation
     * Cursor format: createdAt_ISO|paymentId
     */
    private String encodeCursor(Instant createdAt, String id) {
        String raw = createdAt.toString() + "|" + id;
        return Base64.getUrlEncoder().encodeToString(raw.getBytes());
    }

    /**
     * Decode cursor to extract pagination anchor values
     */
    private CursorData decodeCursor(String cursor) {
        try {
            String raw = new String(Base64.getUrlDecoder().decode(cursor));
            String[] parts = raw.split("\\|");
            return new CursorData(Instant.parse(parts[0]), parts[1]);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid cursor format: " + cursor);
        }
    }

    /**
     * Mask card number - keep only last 4 digits
     * PCI DSS compliance: Never store full card numbers!
     */
    private String maskCardNumber(String cardNumber) {
        if (cardNumber == null || cardNumber.length() < 4) {
            return null;
        }
        return "**** **** **** " + cardNumber.substring(cardNumber.length() - 4);
    }

    // Record for cursor data (Java 17 feature!)
    private record CursorData(Instant createdAt, String id) {}
}