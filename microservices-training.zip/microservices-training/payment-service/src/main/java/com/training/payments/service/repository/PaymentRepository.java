package com.training.payments.service.repository;

import com.training.payments.common.model.PaymentStatus;
import com.training.payments.service.entity.PaymentEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

/**
 * TRAINING MODULE: Day 1 - Pagination vs Filtering
 *
 * Repository demonstrating:
 * 1. Offset pagination via Spring Data Pageable
 * 2. Cursor pagination via custom query
 * 3. Filter combinations (status, date range, customer)
 *
 * OFFSET vs CURSOR TRADEOFFS:
 *
 * Offset (page=2&size=10):
 * SELECT * FROM payments ORDER BY created_at DESC LIMIT 10 OFFSET 20
 * Problems:
 *   - New payment inserted before page 2 is loaded -> items shift -> duplicate seen
 *   - COUNT(*) query is expensive on large tables
 *   - OFFSET 1000000 is slow (DB scans all skipped rows)
 *
 * Cursor (after=2024-01-15T10:30:00Z&after_id=abc-123):
 * SELECT * FROM payments
 *   WHERE (created_at, id) < (:lastCreatedAt, :lastId)
 *   ORDER BY created_at DESC, id DESC
 *   LIMIT 10
 * Advantages:
 *   - Stable even when new items inserted
 *   - O(log n) with proper index (vs O(n) for OFFSET)
 *   - No COUNT query needed
 */
@Repository
public interface PaymentRepository extends JpaRepository<PaymentEntity, String> {

    /**
     * Find by idempotency key - used for duplicate detection
     * TRAINING Day 1: Idempotency check before processing
     */
    Optional<PaymentEntity> findByIdempotencyKey(String idempotencyKey);

    /**
     * OFFSET PAGINATION: Payment history for a customer
     * Used in v1 API
     * Pageable carries: page number, size, sort direction
     */
    Page<PaymentEntity> findByCustomerIdOrderByCreatedAtDesc(
            String customerId, Pageable pageable);

    /**
     * OFFSET PAGINATION + FILTERING: Customer payments filtered by status
     */
    Page<PaymentEntity> findByCustomerIdAndStatusOrderByCreatedAtDesc(
            String customerId, PaymentStatus status, Pageable pageable);

    /**
     * CURSOR PAGINATION: v2 API uses this
     * Cursor = last seen (createdAt, id) pair encoded as Base64
     *
     * Keyset pagination - efficient with composite index on (created_at, id)
     *
     * @param customerId    Customer to query
     * @param cursorDate    Timestamp of last item seen (from cursor)
     * @param cursorId      ID of last item seen (for tie-breaking)
     * @param pageable      Contains LIMIT (size) - sort ignored here
     */
    @Query("""
        SELECT p FROM PaymentEntity p
        WHERE p.customerId = :customerId
          AND (p.createdAt < :cursorDate
               OR (p.createdAt = :cursorDate AND p.id < :cursorId))
        ORDER BY p.createdAt DESC, p.id DESC
        """)
    List<PaymentEntity> findByCustomerIdWithCursor(
            @Param("customerId") String customerId,
            @Param("cursorDate") Instant cursorDate,
            @Param("cursorId") String cursorId,
            Pageable pageable);

    /**
     * CURSOR PAGINATION: First page (no cursor)
     */
    @Query("""
        SELECT p FROM PaymentEntity p
        WHERE p.customerId = :customerId
        ORDER BY p.createdAt DESC, p.id DESC
        """)
    List<PaymentEntity> findByCustomerIdFirstPage(
            @Param("customerId") String customerId,
            Pageable pageable);

    /**
     * FILTERING: Find by order ID (for Saga coordination)
     */
    Optional<PaymentEntity> findByOrderId(String orderId);

    /**
     * FILTERING: Find all payments for an order (refunds create new records)
     */
    List<PaymentEntity> findAllByOrderIdOrderByCreatedAtDesc(String orderId);

    /**
     * Count by customer and status (for rate limiting checks)
     */
    long countByCustomerIdAndStatusAndCreatedAtAfter(
            String customerId, PaymentStatus status, Instant since);
}