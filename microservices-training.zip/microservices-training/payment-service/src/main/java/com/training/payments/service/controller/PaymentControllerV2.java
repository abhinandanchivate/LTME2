package com.training.payments.service.controller;

import com.training.payments.common.dto.*;
import com.training.payments.service.service.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * TRAINING MODULE: Day 1 - API Design (v2 with cursor pagination)
 *
 * V2 API improvements over V1:
 * 1. CURSOR PAGINATION: More efficient for large datasets
 * 2. PSP reference exposed: Internal detail added in v2
 * 3. Same POST endpoint (backward compatible - v1 clients still work)
 *
 * CONSUMER IMPACT ANALYSIS:
 * - Mobile clients using v1: Still work, no changes needed
 * - Partner clients using v1: Migrated to v2 for cursor pagination
 * - Internal services: Use v2 for better performance
 *
 * MIGRATION STRATEGY:
 * 1. Release v2 alongside v1
 * 2. Deprecate v1 (add Deprecation header)
 * 3. Give clients 6 months to migrate
 * 4. Sunset v1 (remove)
 */
@RestController
@RequestMapping("/api/v2/payments")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Payments V2", description = "Payment processing API - Version 2 (Current)")
public class PaymentControllerV2 {

    private final PaymentService paymentService;
    private static final String API_VERSION = "v2";

    /**
     * Create payment - same as V1 (backward compatible)
     * V2 response includes pspReference field (new in v2)
     */
    @Operation(
        summary = "Create a payment (V2)",
        description = "Same as V1 but response includes PSP reference"
    )
    @PostMapping
    public ResponseEntity<PaymentResponse> createPayment(
            @Valid @RequestBody PaymentRequest request,
            @RequestHeader("X-Idempotency-Key") String idempotencyKey) {

        request.setIdempotencyKey(idempotencyKey);
        log.info("[V2] POST /payments - orderId: {}", request.getOrderId());

        PaymentResponse response = paymentService.createPayment(request, API_VERSION);
        return ResponseEntity.status(201)
                .header("X-Payment-ID", response.getPaymentId())
                .header("X-API-Version", API_VERSION)
                .body(response);
    }

    /**
     * Get payment by ID - returns pspReference in v2
     */
    @GetMapping("/{paymentId}")
    public ResponseEntity<PaymentResponse> getPayment(@PathVariable String paymentId) {
        log.info("[V2] GET /payments/{}", paymentId);
        return ResponseEntity.ok(paymentService.getPayment(paymentId, API_VERSION));
    }

    /**
     * Get payment history with CURSOR pagination.
     *
     * V2 uses cursor pagination:
     * First page: GET /api/v2/payments?customerId=C1&size=10
     * Next page:  GET /api/v2/payments?customerId=C1&size=10&cursor=abc123
     *
     * CURSOR PAGINATION BENEFITS:
     * - No page drift even with real-time inserts
     * - No expensive COUNT(*) query
     * - Consistent O(log n) performance with proper index
     */
    @Operation(
        summary = "Get payment history (cursor pagination)",
        description = """
            Returns payment history using efficient cursor-based pagination.
            
            **First page**: Omit `cursor` parameter.
            **Next page**: Pass `nextCursor` from previous response as `cursor`.
            
            The cursor is an opaque string - do not parse it. It encodes the
            position in the result set and handles result set stability.
            """
    )
    @GetMapping
    public ResponseEntity<PagedResponse<PaymentResponse>> getPaymentHistory(
            @Parameter(description = "Customer ID", required = true)
            @RequestParam String customerId,

            @Parameter(description = "Page size", example = "20")
            @RequestParam(defaultValue = "20") int size,

            @Parameter(description = "Cursor from previous page's nextCursor field")
            @RequestParam(required = false) String cursor) {

        if (size > 100) size = 100;

        log.info("[V2] GET /payments - customer: {} cursor: {} size: {}",
                customerId, cursor != null ? "present" : "null", size);

        PagedResponse<PaymentResponse> response =
                paymentService.getPaymentHistoryCursor(
                        customerId, cursor, size, API_VERSION);

        return ResponseEntity.ok()
                .header("X-API-Version", API_VERSION)
                .body(response);
    }

    /**
     * Refund a payment (new in V2 - not available in V1)
     * Used as Saga compensation endpoint
     */
    @Operation(summary = "Refund a payment (Saga compensation)")
    @PostMapping("/{paymentId}/refund")
    public ResponseEntity<PaymentResponse> refundPayment(
            @PathVariable String paymentId) {
        log.info("[V2] POST /payments/{}/refund", paymentId);
        return ResponseEntity.ok(
                paymentService.refundPayment(paymentId, API_VERSION));
    }
}