package com.training.payments.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * TRAINING MODULE: Day 1 - Microservice Entry Point
 *
 * Bootstrap class for payment-service microservice.
 *
 * Annotations explained:
 * - @SpringBootApplication: Auto-configuration + component scan
 * - @EnableCaching: Activates Spring Cache abstraction (Day 2)
 * - @EnableAsync: Allows @Async methods for non-blocking PSP calls
 * - @EnableRetry: Activates @Retryable annotations (complementary to Resilience4j)
 */
@SpringBootApplication
@EnableCaching
@EnableAsync
@EnableRetry
public class PaymentServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaymentServiceApplication.class, args);
    }
}