package com.training.payments.service.psp;

import lombok.*;

/**
 * TRAINING MODULE: Day 1 - PSP Integration
 * Response from Payment Service Provider
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PspResponse {

    public enum PspStatus { SUCCESS, DECLINED, PENDING, ERROR }

    private PspStatus status;
    private String pspReference;
    private String message;
    private boolean fallback;  // true if this is a fallback response

    public static PspResponse success(String pspRef) {
        return PspResponse.builder()
                .status(PspStatus.SUCCESS)
                .pspReference(pspRef)
                .message("Payment processed successfully")
                .fallback(false)
                .build();
    }

    public static PspResponse fallback(String message) {
        return PspResponse.builder()
                .status(PspStatus.PENDING)
                .message(message)
                .fallback(true)
                .build();
    }

    public boolean isSuccessful() {
        return status == PspStatus.SUCCESS;
    }
}