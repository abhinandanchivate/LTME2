package com.training.payments.service.edge;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * TRAINING MODULE: Day 4 - Edge, DNS, Load Balancer, WAF, CDN
 *
 * This controller simulates and explains the FULL traffic path
 * from a client request to the payment microservice.
 *
 * COMPLETE REQUEST FLOW:
 *
 * [Client Browser/App]
 *      │
 *      │ DNS Lookup: api.payments.example.com
 *      ▼
 * [DNS Resolver] ──(CNAME)──► [CDN/Edge PoP]
 *      │
 *      │ If static/cached: Return from CDN cache (no backend call!)
 *      │ If dynamic API:   Forward to origin
 *      ▼
 * [CDN Origin / WAF]
 *      │ WAF inspects request for OWASP threats
 *      │ SQL injection? Block.
 *      │ XSS? Block.
 *      │ Bot pattern? Rate limit/Block.
 *      │ IP blocklist? Block.
 *      ▼
 * [Load Balancer - L7]
 *      │ TLS Termination (HTTPS -> HTTP internally)
 *      │ Health checks each backend
 *      │ Route based on path/header
 *      ▼
 * [API Gateway - port 8080]
 *      │ Auth validation
 *      │ Rate limiting
 *      │ Route to service
 *      ▼
 * [Payment Service - port 8081]
 *      │ Business logic
 *      │ Cache check
 *      │ PSP call (with CB)
 *      ▼
 * [Response flows back up the chain]
 */
@RestController
@RequestMapping("/api/edge")
@Slf4j
@Tag(name = "Edge & Traffic Demo",
     description = "Day 4: DNS, Load Balancer, WAF, CDN simulation and explanation")
public class EdgeSimulationController {

    /**
     * Simulate the full traffic path for a payment request.
     * Returns explanation of each hop with simulated timings.
     */
    @Operation(
        summary = "Simulate full request traffic path",
        description = "Shows the complete journey of a payment request from DNS to service"
    )
    @GetMapping("/traffic-flow")
    public ResponseEntity<Map<String, Object>> simulateTrafficFlow(
            @RequestParam(defaultValue = "api.payments.example.com") String domain,
            @RequestParam(defaultValue = "/api/v1/payments") String path) {

        log.info("[EDGE DEMO] Simulating traffic flow for {}{}", domain, path);

        Map<String, Object> flow = new LinkedHashMap<>();
        flow.put("simulatedAt", Instant.now());
        flow.put("request", Map.of("domain", domain, "path", path));

        // ============================================================
        // HOP 1: DNS Resolution
        // ============================================================
        flow.put("hop1_dns", Map.of(
            "component", "DNS Resolution",
            "description", "Client's OS queries DNS resolver for " + domain,
            "process", List.of(
                "1. Check local /etc/hosts (or Windows hosts file)",
                "2. Check OS DNS cache (TTL-based)",
                "3. Query configured DNS server (e.g., 8.8.8.8)",
                "4. Recursive resolution: root -> .com TLD -> example.com NS",
                "5. example.com NS returns: " + domain + " CNAME cdn.example.com",
                "6. CDN CNAME resolves to nearest CDN edge node IP: 203.0.113.42"
            ),
            "dnsRecords", Map.of(
                "A_record",     domain + " -> 203.0.113.42 (direct IP, no CDN)",
                "CNAME_record", domain + " -> cdn.example.com (CDN, geo-routed)",
                "geo_routing",  "Cloudflare/Route53 returns nearest CDN PoP IP based on client location"
            ),
            "localDemo", Map.of(
                "hosts_file", "C:\\Windows\\System32\\drivers\\etc\\hosts",
                "add_entry",  "127.0.0.1  api.payments.local",
                "test",       "curl http://api.payments.local:8080/api/v1/payments"
            ),
            "simulatedLatency", "1-50ms (cached DNS: ~1ms, cold DNS: ~50ms)"
        ));

        // ============================================================
        // HOP 2: CDN Edge
        // ============================================================
        flow.put("hop2_cdn", Map.of(
            "component", "CDN Edge Node",
            "description", "Request hits nearest CDN Point of Presence (PoP)",
            "cdnDecision", Map.of(
                "static_content", Map.of(
                    "examples", List.of("/ui/index.html", "/ui/app.js", "/ui/logo.png",
                                        "/swagger-ui/swagger-ui.css"),
                    "action", "Return from CDN cache (no backend call!)",
                    "benefit", "100ms -> 5ms response. Backend never hit.",
                    "cache_control", "Cache-Control: max-age=86400, public"
                ),
                "dynamic_api", Map.of(
                    "examples", List.of("/api/v1/payments", "/api/v2/payments/{id}"),
                    "action", "Forward to origin (cannot cache dynamic data)",
                    "cache_control", "Cache-Control: no-store (payment data is sensitive)"
                ),
                "payment_status_caching", Map.of(
                    "description", "COMPLETED payment status CAN be CDN cached briefly",
                    "example", "GET /api/v2/payments/{id}/status -> Cache-Control: max-age=60",
                    "benefit", "Reduces load during high traffic (e.g., post-purchase status check)"
                )
            ),
            "simulatedLatency", "0ms (cache hit) or 20-50ms (cache miss, forward to LB)"
        ));

        // ============================================================
        // HOP 3: WAF
        // ============================================================
        flow.put("hop3_waf", Map.of(
            "component", "Web Application Firewall (WAF)",
            "description", "Inspects every request for OWASP Top 10 threats",
            "owaspThreats", Map.of(
                "A01_Broken_Access_Control", Map.of(
                    "example", "GET /api/v1/payments?customerId=../../../admin",
                    "wafRule", "Block path traversal patterns",
                    "action",  "Block, return 403"
                ),
                "A03_Injection", Map.of(
                    "example",  "X-Customer-ID: 1'; DROP TABLE payments; --",
                    "wafRule",  "Block SQL injection patterns in headers/body",
                    "action",   "Block, return 403, alert security team"
                ),
                "A07_Auth_Failures", Map.of(
                    "example",  "1000 failed auth attempts from same IP",
                    "wafRule",  "IP-based rate limiting + CAPTCHA",
                    "action",   "Block IP for 1 hour"
                ),
                "DDoS_Protection", Map.of(
                    "example",  "100,000 requests/sec from single IP",
                    "wafRule",  "SYN flood detection, rate limiting, IP block",
                    "action",   "Absorb/drop at edge, never reaches backend"
                ),
                "Bot_Detection", Map.of(
                    "example",  "Scraper hitting /api/v1/payments with no browser headers",
                    "wafRule",  "User-Agent analysis, behavioral detection, JS challenge",
                    "action",   "CAPTCHA challenge or block"
                )
            ),
            "wafModes", Map.of(
                "detection",   "Log threats but allow through (low risk of blocking legit traffic)",
                "prevention",  "Block identified threats (production mode)",
                "recommendation", "Start in detection mode, analyze logs, then enable prevention"
            ),
            "demoSimulation", "See /api/edge/waf-check endpoint below",
            "simulatedLatency", "1-5ms (WAF rule matching)"
        ));

        // ============================================================
        // HOP 4: Load Balancer
        // ============================================================
        flow.put("hop4_load_balancer", Map.of(
            "component", "L7 Load Balancer (e.g., AWS ALB, NGINX, HAProxy)",
            "description", "Distributes traffic across gateway instances",
            "l4_vs_l7", Map.of(
                "L4_TCP_LB", Map.of(
                    "operates_at", "TCP/UDP layer - sees IP packets",
                    "can_do", List.of("Route by IP/port", "TCP health checks",
                                      "Very low latency"),
                    "cannot_do", List.of("Route by URL path", "Inspect HTTP headers",
                                         "SSL termination (usually)"),
                    "use_case", "Database traffic, non-HTTP protocols"
                ),
                "L7_HTTP_LB", Map.of(
                    "operates_at", "HTTP layer - sees full request",
                    "can_do", List.of(
                        "Route by URL path (/api/v1 -> gateway-1)",
                        "Route by header (X-Version: 2 -> green deployment)",
                        "SSL/TLS termination",
                        "HTTP health checks (/actuator/health)",
                        "Sticky sessions (same user -> same instance)",
                        "Request/response modification"
                    ),
                    "use_case", "HTTP API traffic (payment-service)"
                )
            ),
            "tlsTermination", Map.of(
                "description", "HTTPS decrypted at LB; internal traffic uses HTTP",
                "benefit", "Services don't need TLS certs; simpler internal config",
                "security_note", "Internal network must be trusted (VPC/private subnet)"
            ),
            "healthChecks", Map.of(
                "endpoint", "GET /actuator/health",
                "interval", "Every 10 seconds",
                "threshold", "2 consecutive failures -> remove from pool",
                "demo", "Stop payment-service -> LB detects within 20s -> routes to other instance"
            ),
            "algorithms", Map.of(
                "round_robin",     "Requests distributed evenly (default)",
                "least_conn",      "Route to instance with fewest active connections",
                "ip_hash",         "Same client IP -> same instance (sticky)",
                "weighted",        "Send 90% to stable, 10% to canary (blue-green)"
            ),
            "localDemo", "Eureka + gateway-service provides client-side L7 LB",
            "simulatedLatency", "1-3ms (LB routing)"
        ));

        // ============================================================
        // HOP 5: API Gateway
        // ============================================================
        flow.put("hop5_api_gateway", Map.of(
            "component", "API Gateway (gateway-service:8080)",
            "description", "Application-level routing, auth, rate limiting",
            "responsibilities", List.of(
                "Validate X-API-Key header",
                "Apply rate limiting (token bucket per client)",
                "Route /api/v1/payments -> lb://payment-service",
                "Inject X-Correlation-ID for tracing",
                "Apply circuit breaker (if payment-service is down)",
                "Log all requests centrally"
            ),
            "demoUrl", "http://localhost:8080/actuator/gateway/routes",
            "simulatedLatency", "5-15ms (auth + routing)"
        ));

        // ============================================================
        // HOP 6: Payment Service
        // ============================================================
        flow.put("hop6_payment_service", Map.of(
            "component", "Payment Service (payment-service:8081)",
            "description", "Business logic, caching, PSP call",
            "processing", List.of(
                "Check idempotency (Redis cache)",
                "Validate request",
                "Check Redis payment status cache",
                "If cache miss: query H2/PostgreSQL",
                "If creating: call PSP (with CB + retry)",
                "Update DB",
                "Publish Kafka event",
                "Return response"
            ),
            "demoUrl", "http://localhost:8081/swagger-ui.html",
            "simulatedLatency", "100-500ms (DB + PSP call)"
        ));

        flow.put("totalLatency", Map.of(
            "breakdown", Map.of(
                "DNS",          "1-50ms",
                "CDN",          "0-50ms",
                "WAF",          "1-5ms",
                "LoadBalancer", "1-3ms",
                "Gateway",      "5-15ms",
                "Service",      "100-500ms"
            ),
            "typical_total", "108-623ms",
            "cached_total",   "5-20ms (CDN cache hit for static content)"
        ));

        return ResponseEntity.ok(flow);
    }

    /**
     * Simulate WAF request inspection.
     * TRAINING Day 4: Show WAF rule matching in real-time.
     */
    @Operation(
        summary = "Simulate WAF request inspection",
        description = "Inspects a request payload for OWASP threats (demo simulation)"
    )
    @PostMapping("/waf-check")
    public ResponseEntity<Map<String, Object>> simulateWafCheck(
            @RequestBody(required = false) Map<String, String> requestPayload,
            @RequestHeader(value = "User-Agent", defaultValue = "unknown") String userAgent,
            @RequestHeader(value = "X-Forwarded-For", defaultValue = "127.0.0.1") String clientIp) {

        log.info("[WAF DEMO] Inspecting request from IP: {} UA: {}", clientIp, userAgent);

        Map<String, Object> wafResult = new LinkedHashMap<>();
        wafResult.put("clientIp", clientIp);
        wafResult.put("userAgent", userAgent);
        wafResult.put("inspectedAt", Instant.now());

        boolean blocked    = false;
        String  blockReason = null;
        List<String> warnings = new java.util.ArrayList<>();
        List<String> rules   = new java.util.ArrayList<>();

        // ============================================================
        // WAF RULE 1: SQL Injection Detection
        // ============================================================
        String payload = requestPayload != null ? requestPayload.toString() : "";
        if (containsSqlInjection(payload)) {
            blocked     = true;
            blockReason = "SQL_INJECTION_DETECTED";
            rules.add("RULE-942100: SQL injection detected in request body");
        }

        // ============================================================
        // WAF RULE 2: XSS Detection
        // ============================================================
        if (containsXss(payload)) {
            blocked     = true;
            blockReason = "XSS_DETECTED";
            rules.add("RULE-941100: XSS attack detected in request body");
        }

        // ============================================================
        // WAF RULE 3: Bot Detection (User-Agent check)
        // ============================================================
        if (isSuspiciousUserAgent(userAgent)) {
            warnings.add("Suspicious User-Agent pattern detected: " + userAgent);
            rules.add("RULE-913100: Bot/scanner User-Agent pattern");
        }

        // ============================================================
        // WAF RULE 4: Path Traversal
        // ============================================================
        if (containsPathTraversal(payload)) {
            blocked     = true;
            blockReason = "PATH_TRAVERSAL_DETECTED";
            rules.add("RULE-930100: Path traversal attempt");
        }

        // ============================================================
        // WAF RULE 5: IP Reputation (demo: block 10.0.0.1)
        // ============================================================
        if ("10.0.0.1".equals(clientIp)) {
            blocked     = true;
            blockReason = "IP_BLOCKLIST";
            rules.add("RULE-IP-001: IP in threat intelligence blocklist");
        }

        wafResult.put("decision", blocked ? "BLOCK" : "ALLOW");
        wafResult.put("blockReason", blockReason);
        wafResult.put("warnings", warnings);
        wafResult.put("rulesTriggered", rules);
        wafResult.put("action", blocked
                ? "Request blocked. 403 Forbidden returned to client. Incident logged."
                : "Request allowed. Forwarded to load balancer.");

        // Demo: what to send to trigger each rule
        wafResult.put("testPayloads", Map.of(
            "sql_injection", Map.of(
                "payload", "{ \"customerId\": \"1'; DROP TABLE payments;--\" }",
                "result",  "BLOCKED - SQL injection"
            ),
            "xss", Map.of(
                "payload", "{ \"description\": \"<script>alert('xss')</script>\" }",
                "result",  "BLOCKED - XSS"
            ),
            "path_traversal", Map.of(
                "payload", "{ \"path\": \"../../etc/passwd\" }",
                "result",  "BLOCKED - Path traversal"
            ),
            "clean_request", Map.of(
                "payload", "{ \"customerId\": \"CUST-001\", \"amount\": \"9.99\" }",
                "result",  "ALLOWED"
            ),
            "blocked_ip", Map.of(
                "header",  "X-Forwarded-For: 10.0.0.1",
                "result",  "BLOCKED - IP blocklist"
            )
        ));

        int statusCode = blocked ? 403 : 200;
        return ResponseEntity.status(statusCode).body(wafResult);
    }

    /**
     * DNS flow explanation with local demo steps.
     * TRAINING Day 4: DNS & Traffic module
     */
    @Operation(
        summary = "DNS resolution flow explanation",
        description = "Explains DNS resolution for payment domain with geo-routing"
    )
    @GetMapping("/dns-flow")
    public ResponseEntity<Map<String, Object>> getDnsFlow() {
        Map<String, Object> dns = new LinkedHashMap<>();

        dns.put("concept", "DNS Resolution for api.payments.example.com");

        dns.put("recordTypes", Map.of(
            "A",     "Maps hostname directly to IPv4 address",
            "AAAA",  "Maps hostname to IPv6 address",
            "CNAME", "Alias - maps hostname to another hostname (CDN uses this)",
            "MX",    "Mail exchange (not relevant for APIs)",
            "TXT",   "Text records (used for domain verification, SPF)",
            "NS",    "Name server records (who is authoritative for this domain)"
        ));

        dns.put("paymentDomainRecords", Map.of(
            "api.payments.example.com",  "CNAME -> d1234.cloudfront.net (CDN)",
            "d1234.cloudfront.net",      "A -> 13.225.100.50 (nearest CDN PoP)",
            "origin.payments.example.com", "A -> 10.0.1.100 (Load Balancer, private)"
        ));

        dns.put("geoRouting", Map.of(
            "description",
                "DNS returns DIFFERENT IPs based on client location",
            "example", Map.of(
                "US_client",  "api.payments.example.com -> 13.225.100.50 (US East CDN)",
                "EU_client",  "api.payments.example.com -> 52.85.200.30  (EU CDN)",
                "APAC_client","api.payments.example.com -> 52.46.150.20  (Singapore CDN)"
            ),
            "benefit", "Lower latency: APAC users hit Singapore CDN, not US origin",
            "providers", List.of("AWS Route53 Geo routing", "Cloudflare", "Akamai")
        ));

        dns.put("localDemoSteps", Map.of(
            "step1", Map.of(
                "action", "Add to Windows hosts file (run as Administrator)",
                "file",   "C:\\Windows\\System32\\drivers\\etc\\hosts",
                "entry",  "127.0.0.1  api.payments.local"
            ),
            "step2", Map.of(
                "action", "Test DNS resolution",
                "command", "nslookup api.payments.local"
            ),
            "step3", Map.of(
                "action", "Call payment API via local domain",
                "command", "curl -H \"X-API-Key: demo-key\" http://api.payments.local:8080/api/v1/payments?customerId=CUST-001"
            ),
            "step4", Map.of(
                "action", "Verify DNS TTL caching",
                "command", "ipconfig /displaydns | findstr payments"
            )
        ));

        dns.put("ttlExplanation", Map.of(
            "what_is_ttl", "Time To Live - how long DNS record is cached",
            "high_ttl", Map.of(
                "value",   "86400s (24 hours)",
                "benefit", "Fewer DNS queries, faster responses",
                "risk",    "Slow propagation when IP changes (24h to update)"
            ),
            "low_ttl", Map.of(
                "value",   "60s (1 minute)",
                "benefit", "Fast failover (if origin moves, clients update within 1 min)",
                "risk",    "More DNS queries, slight latency increase"
            ),
            "recommendation", "Lower TTL before planned IP change, raise after"
        ));

        return ResponseEntity.ok(dns);
    }

    /**
     * CDN explanation with payment-specific caching strategy.
     * TRAINING Day 4: CDN & Static Content
     */
    @Operation(
        summary = "CDN caching strategy for payments",
        description = "What can be CDN cached vs what must bypass CDN"
    )
    @GetMapping("/cdn-strategy")
    public ResponseEntity<Map<String, Object>> getCdnStrategy() {
        Map<String, Object> cdn = new LinkedHashMap<>();

        cdn.put("concept", "CDN Caching for Payment Platform");

        cdn.put("whatToCache", Map.of(
            "static_assets", Map.of(
                "paths", List.of(
                    "/ui/index.html",
                    "/ui/app.js",
                    "/ui/app.css",
                    "/ui/logo.png",
                    "/swagger-ui/**",
                    "/v3/api-docs"
                ),
                "cache_control", "Cache-Control: max-age=86400, public",
                "cdn_ttl",       "24 hours",
                "benefit",       "Served from CDN edge, backend never hit",
                "demo",          "Start static file server on 8084 (see docker-compose)"
            ),
            "payment_status_completed", Map.of(
                "path",          "GET /api/v2/payments/{id}/status (COMPLETED only)",
                "cache_control", "Cache-Control: max-age=60, public",
                "cdn_ttl",       "60 seconds",
                "benefit",       "COMPLETED status never changes. Safe to cache.",
                "caveat",        "Must vary by payment ID in cache key"
            )
        ));

        cdn.put("whatNotToCache", Map.of(
            "payment_creation", Map.of(
                "path",          "POST /api/v1/payments",
                "cache_control", "Cache-Control: no-store",
                "reason",        "Mutating operation, unique per request"
            ),
            "payment_history", Map.of(
                "path",          "GET /api/v2/payments?customerId=C1",
                "cache_control", "Cache-Control: no-store",
                "reason",        "User-specific data, changes frequently"
            ),
            "pending_status", Map.of(
                "path",          "GET /api/v2/payments/{id} when status=PENDING",
                "cache_control", "Cache-Control: no-store",
                "reason",        "PENDING changes to COMPLETED/FAILED - must not cache stale status"
            )
        ));

        cdn.put("cacheHeaders", Map.of(
            "Cache-Control: no-store",          "Never cache (private payment data)",
            "Cache-Control: no-cache",          "Cache but revalidate each time",
            "Cache-Control: max-age=300",        "Cache for 5 minutes",
            "Cache-Control: max-age=86400,public","Cache for 24h, CDN and browser",
            "ETag",                              "Version identifier for conditional requests",
            "Vary: Accept-Encoding",             "Cache separately for gzip vs plain"
        ));

        cdn.put("localDemo", Map.of(
            "description", "Nginx serves static files like CDN in docker-compose",
            "url",         "http://localhost:8084/ui/index.html",
            "check_cache", "curl -I http://localhost:8084/ui/index.html | grep Cache-Control"
        ));

        return ResponseEntity.ok(cdn);
    }

    // ================================================================
    // WAF Detection Helpers
    // ================================================================

    private boolean containsSqlInjection(String input) {
        if (input == null) return false;
        String lower = input.toLowerCase();
        return lower.contains("drop table") ||
               lower.contains("'; ") ||
               lower.contains("union select") ||
               lower.contains("1=1") ||
               lower.contains("or '1'='1") ||
               lower.contains("--") ||
               lower.contains("xp_cmdshell");
    }

    private boolean containsXss(String input) {
        if (input == null) return false;
        String lower = input.toLowerCase();
        return lower.contains("<script") ||
               lower.contains("javascript:") ||
               lower.contains("onerror=") ||
               lower.contains("onload=") ||
               lower.contains("</script>") ||
               lower.contains("alert(");
    }

    private boolean isSuspiciousUserAgent(String ua) {
        if (ua == null) return false;
        String lower = ua.toLowerCase();
        return lower.contains("sqlmap") ||
               lower.contains("nikto") ||
               lower.contains("nmap") ||
               lower.contains("burpsuite") ||
               lower.contains("masscan") ||
               lower.equals("unknown") ||
               lower.isEmpty();
    }

    private boolean containsPathTraversal(String input) {
        if (input == null) return false;
        return input.contains("../") ||
               input.contains("..\\") ||
               input.contains("%2e%2e") ||
               input.contains("/etc/passwd") ||
               input.contains("c:\\windows");
    }
}