package com.training.payments.service.controller;

import com.training.payments.common.dto.*;
import com.training.payments.common.model.PaymentStatus;
import com.training.payments.service.service.PaymentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * TRAINING MODULE: Day 1 - API Design (v1)
 *
 * V1 REST API for Payments using OFFSET pagination.
 *
 * VERSIONING STRATEGY: URL Path versioning (/api/v1/)
 *
 * OTHER STRATEGIES:
 * 1. URL Path:     /api/v1/payments         (chosen - most visible)
 * 2. Header:       Accept: application/vnd.payments.v1+json
 * 3. Query param:  /api/payments?version=1
 * 4. Subdomain:    v1.api.payments.com
 *
 * BACKWARD COMPATIBILITY RULES (never break v1!):
 * - OK: Add new optional fields to response
 * - OK: Add new optional query parameters
 * - OK: Add new endpoints
 * - BREAKING: Remove/rename existing fields
 * - BREAKING: Change field types
 * - BREAKING: Remove endpoints
 * - BREAKING: Change required → optional or vice versa
 */
@RestController
@RequestMapping("/api/v1/payments")
@RequiredArgsConstructor
@Slf4j
@Tag(name = "Payments V1", description = "Payment processing API - Version 1 (Legacy)")
public class PaymentControllerV1 {

    private final PaymentService paymentService;
    private static final String API_VERSION = "v1";

    /**
     * Create a new payment.
     *
     * IDEMPOTENCY: Client MUST provide X-Idempotency-Key header.
     * Safe to retry with same key without double-charging.
     */
    @Operation(
        summary = "Create a payment",
        description = """
            Create and process a new payment.
            
            **Idempotency**: Provide a unique `X-Idempotency-Key` header.
            Retrying with the same key returns the original response without re-processing.
            
            **Amount ranges for demo**:
            - < $10: Always succeeds
            - $10-$49.99: 30% chance of transient failure (tests retry)
            - $50-$99.99: Always fails (insufficient funds)
            - >= $100: Slow response (tests circuit breaker)
            """
    )
    @ApiResponses({
        @ApiResponse(responseCode = "201", description = "Payment created",
            content = @Content(schema = @Schema(implementation = PaymentResponse.class))),
        @ApiResponse(responseCode = "200", description = "Duplicate - returning existing payment",
            content = @Content(schema = @Schema(implementation = PaymentResponse.class))),
        @ApiResponse(responseCode = "400", description = "Validation error",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(responseCode = "422", description = "Payment declined",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(responseCode = "429", description = "Rate limit exceeded",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class))),
        @ApiResponse(responseCode = "503", description = "PSP unavailable",
            content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
    })
    @PostMapping
    public ResponseEntity<PaymentResponse> createPayment(
            @Valid @RequestBody PaymentRequest request,
            @Parameter(description = "Idempotency key to prevent duplicate payments",
                       required = true, example = "550e8400-e29b-41d4-a716-446655440000")
            @RequestHeader("X-Idempotency-Key") String idempotencyKey) {

        // Merge idempotency key from header into request
        request.setIdempotencyKey(idempotencyKey);

        log.info("[V1] POST /payments - orderId: {} idempotencyKey: {}",
                request.getOrderId(), idempotencyKey);

        PaymentResponse response = paymentService.createPayment(request, API_VERSION);

        // 200 if duplicate (idempotent), 201 if new payment
        HttpStatus status = response.getPaymentId() != null &&
                            idempotencyKey.equals(request.getIdempotencyKey())
                            ? HttpStatus.CREATED : HttpStatus.OK;

        return ResponseEntity.status(HttpStatus.CREATED)
                .header("X-Payment-ID", response.getPaymentId())
                .header("X-API-Version", API_VERSION)
                .body(response);
    }

    /**
     * Get payment by ID.
     * Response cached for 5 minutes (see CacheConfig).
     */
    @Operation(summary = "Get payment by ID")
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Payment found"),
        @ApiResponse(responseCode = "404", description = "Payment not found")
    })
    @GetMapping("/{paymentId}")
    public ResponseEntity<PaymentResponse> getPayment(
            @PathVariable String paymentId) {
        log.info("[V1] GET /payments/{}", paymentId);
        PaymentResponse response = paymentService.getPayment(paymentId, API_VERSION);
        return ResponseEntity.ok()
                .header("Cache-Control", "max-age=300") // HTTP cache hint
                .header("X-API-Version", API_VERSION)
                .body(response);
    }

    /**
     * Get payment history with OFFSET pagination.
     *
     * V1 uses offset pagination (page/size):
     * GET /api/v1/payments?customerId=C1&page=0&size=10&status=COMPLETED
     */
    @Operation(
        summary = "Get payment history (offset pagination)",
        description = """
            Returns paginated payment history using offset-based pagination.
            
            **Pagination**: Use `page` (0-based) and `size` parameters.
            **Filtering**: Use `status` to filter by payment status.
            
            Note: V2 API offers cursor-based pagination which is more efficient
            for large datasets.
            """
    )
    @GetMapping
    public ResponseEntity<PagedResponse<PaymentResponse>> getPaymentHistory(
            @Parameter(description = "Customer ID", required = true)
            @RequestParam String customerId,

            @Parameter(description = "Page number (0-based)", example = "0")
            @RequestParam(defaultValue = "0") int page,

            @Parameter(description = "Page size (max 100)", example = "20")
            @RequestParam(defaultValue = "20") int size,

            @Parameter(description = "Filter by status")
            @RequestParam(required = false) PaymentStatus status) {

        // Validate page size to prevent large queries
        if (size > 100) size = 100;
        if (size < 1) size = 1;

        log.info("[V1] GET /payments - customer: {} page: {} size: {} status: {}",
                customerId, page, size, status);

        PagedResponse<PaymentResponse> response =
                paymentService.getPaymentHistoryOffset(
                        customerId, page, size, status, API_VERSION);

        return ResponseEntity.ok()
                .header("X-API-Version", API_VERSION)
                .header("X-Total-Count",
                        String.valueOf(response.getTotalElements()))
                .body(response);
    }

    /**
     * Cancel a payment (only PENDING payments can be cancelled)
     */
    @Operation(summary = "Cancel a payment")
    @DeleteMapping("/{paymentId}")
    public ResponseEntity<PaymentResponse> cancelPayment(
            @PathVariable String paymentId) {
        log.info("[V1] DELETE /payments/{}", paymentId);
        PaymentResponse response = paymentService.cancelPayment(paymentId, API_VERSION);
        return ResponseEntity.ok(response);
    }
}