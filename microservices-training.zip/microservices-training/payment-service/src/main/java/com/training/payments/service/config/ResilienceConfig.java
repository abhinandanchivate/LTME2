package com.training.payments.service.config;

import io.github.resilience4j.circuitbreaker.CircuitBreakerConfig;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.retry.RetryConfig;
import io.github.resilience4j.retry.RetryRegistry;
import io.github.resilience4j.bulkhead.BulkheadConfig;
import io.github.resilience4j.bulkhead.BulkheadRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeoutException;

/**
 * TRAINING MODULE: Day 2 - Circuit Breaker & Retry
 *
 * Programmatic Resilience4j configuration (alternative to application.yml).
 * Both approaches shown for training purposes.
 *
 * ============================================================
 * CIRCUIT BREAKER STATE MACHINE:
 * ============================================================
 *
 *                    failure rate > threshold
 *     [CLOSED] ─────────────────────────────────► [OPEN]
 *        ▲                                           │
 *        │ success rate OK                           │ wait-duration elapsed
 *        │                                           ▼
 *     [HALF-OPEN] ◄──────────────────────────── [OPEN]
 *        │
 *        │ permitted calls fail
 *        └──────────────────────────────────────► [OPEN]
 *
 * CLOSED:    Normal operation. All calls pass through.
 * OPEN:      Calls IMMEDIATELY fail with fallback. No PSP calls made.
 *            Prevents cascading failures! PSP gets time to recover.
 * HALF-OPEN: Test mode. Limited calls allowed to check if PSP recovered.
 *
 * ============================================================
 * BULKHEAD PATTERN:
 * ============================================================
 * Isolates PSP call thread pool from rest of application.
 * If PSP is slow (but not failing), bulkhead prevents ALL threads
 * from being consumed waiting for PSP responses.
 *
 * Like watertight compartments in a ship - one compartment floods,
 * ship doesn't sink.
 *
 * ============================================================
 * RETRY + CIRCUIT BREAKER COMBINATION:
 * ============================================================
 * Order matters! Apply in this order:
 * Retry(CircuitBreaker(Bulkhead(function)))
 *
 * - Retry retries on transient errors
 * - CircuitBreaker opens after too many failures (even after retries)
 * - Bulkhead limits concurrency
 */
@Configuration
public class ResilienceConfig {

    @Bean
    public CircuitBreakerRegistry circuitBreakerRegistry() {
        CircuitBreakerConfig config = CircuitBreakerConfig.custom()
                // Use count-based sliding window (last N calls)
                .slidingWindowType(CircuitBreakerConfig.SlidingWindowType.COUNT_BASED)
                .slidingWindowSize(10)

                // Open circuit when 50% of calls fail
                .failureRateThreshold(50)

                // Also open when 80% of calls are slow (> 3 seconds)
                .slowCallRateThreshold(80)
                .slowCallDurationThreshold(Duration.ofSeconds(3))

                // Wait 10 seconds in OPEN state before trying HALF-OPEN
                .waitDurationInOpenState(Duration.ofSeconds(10))

                // In HALF-OPEN: allow 3 test calls
                .permittedNumberOfCallsInHalfOpenState(3)

                // Auto transition OPEN -> HALF-OPEN (no manual trigger needed)
                .automaticTransitionFromOpenToHalfOpenEnabled(true)

                // Which exceptions count as failures
                .recordExceptions(IOException.class, TimeoutException.class,
                        RuntimeException.class)

                // Business exceptions - don't count as CB failures
                // (PSP correctly rejected the payment - PSP is working!)
                .ignoreExceptions(
                    com.training.payments.common.exception
                        .PaymentException.InsufficientFundsException.class)

                .build();

        return CircuitBreakerRegistry.of(config);
    }

//    @Bean
//    public RetryRegistry retryRegistry() {
//        RetryConfig config = RetryConfig.custom()
//                .maxAttempts(3)
//
//                // Exponential backoff: 1s, 2s, 4s (with multiplier 2)
//                .intervalFunction(io.github.resilience4j.retry.IntervalFunction
//                        .ofExponentialBackoff(Duration.ofSeconds(1), 2.0))
//                .exponentialBackoffMultiplier(2.0)
//
//                // Cap max wait to prevent infinite wait
//                .retryExceptions(IOException.class, TimeoutException.class)
//
//                // Don't retry on business errors
//                .ignoreExceptions(
//                    com.training.payments.common.exception
//                        .PaymentException.InsufficientFundsException.class,
//                    com.training.payments.common.exception
//                        .PaymentException.DuplicatePaymentException.class)
//
//                .build();
//
//        return RetryRegistry.of(config);
//    }

    @Bean
    public BulkheadRegistry bulkheadRegistry() {
        BulkheadConfig config = BulkheadConfig.custom()
                // Max 10 concurrent calls to PSP
                .maxConcurrentCalls(10)

                // Wait up to 500ms for a slot before rejecting
                .maxWaitDuration(Duration.ofMillis(500))

                .build();

        return BulkheadRegistry.of(config);
    }
}