package com.training.payments.service.observability;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/**
 * TRAINING MODULE: Day 3 - Metrics & Golden Signals
 *
 * Centralized metrics recording for payment operations.
 *
 * GOLDEN SIGNALS (Google SRE Book):
 * 1. LATENCY:    How long requests take (P50, P95, P99)
 * 2. TRAFFIC:    How many requests per second
 * 3. ERRORS:     Error rate (% of failed requests)
 * 4. SATURATION: How "full" the system is (thread pool, queue depth)
 *
 * PAYMENT-SPECIFIC METRICS:
 * - payment_amount_total: Total $ value processed (business metric)
 * - payment_by_method: Breakdown by CARD/BANK_TRANSFER/WALLET
 * - psp_call_duration: How long PSP takes (SLA monitoring)
 * - idempotency_hits: Cache hit rate for idempotency
 * - circuit_breaker_opens: How often CB opens (reliability signal)
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class PaymentMetrics {

    private final MeterRegistry meterRegistry;

    /**
     * Record a successful payment with timing
     * Usage: metrics.recordPaymentSuccess("CARD", timer::record)
     */
    public void recordPaymentSuccess(String paymentMethod, long durationMs) {
        // Counter: total successful payments
        meterRegistry.counter("payment.success.total",
                "method", paymentMethod)
                .increment();

        // Timer: processing duration
        meterRegistry.timer("payment.processing.duration",
                "status", "success",
                "method", paymentMethod)
                .record(durationMs, TimeUnit.MILLISECONDS);

        log.debug("[METRICS] Payment success recorded: method={} duration={}ms",
                paymentMethod, durationMs);
    }

    /**
     * Record a payment failure
     */
    public void recordPaymentFailure(String reason, String paymentMethod) {
        meterRegistry.counter("payment.failure.total",
                "reason", reason,
                "method", paymentMethod != null ? paymentMethod : "unknown")
                .increment();

        log.debug("[METRICS] Payment failure recorded: reason={}", reason);
    }

    /**
     * Record PSP call duration
     * Separate from total payment duration (isolates PSP SLA)
     */
    public void recordPspCallDuration(long durationMs, boolean success) {
        meterRegistry.timer("psp.call.duration",
                "outcome", success ? "success" : "failure")
                .record(durationMs, TimeUnit.MILLISECONDS);
    }

    /**
     * Record idempotency cache hit (duplicate request detected)
     */
    public void recordIdempotencyHit() {
        meterRegistry.counter("payment.idempotency.hits.total").increment();
        log.debug("[METRICS] Idempotency cache hit recorded");
    }

    /**
     * Record rate limit event
     */
    public void recordRateLimitExceeded(String clientId) {
        meterRegistry.counter("payment.rate_limit.exceeded.total",
                "client", clientId.substring(0, Math.min(clientId.length(), 20)))
                .increment();
    }

    /**
     * Time a supplier and record result
     * Usage: metrics.time("payment.db.query", () -> repository.findById(id))
     */
    public <T> T time(String metricName, Supplier<T> supplier) {
        long start = System.currentTimeMillis();
        try {
            T result = supplier.get();
            recordTiming(metricName, System.currentTimeMillis() - start, "success");
            return result;
        } catch (Exception e) {
            recordTiming(metricName, System.currentTimeMillis() - start, "error");
            throw e;
        }
    }

    private void recordTiming(String name, long durationMs, String outcome) {
        meterRegistry.timer(name, "outcome", outcome)
                .record(durationMs, TimeUnit.MILLISECONDS);
    }
}