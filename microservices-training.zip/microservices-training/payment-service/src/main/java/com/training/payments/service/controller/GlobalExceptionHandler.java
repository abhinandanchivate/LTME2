package com.training.payments.service.controller;

import com.training.payments.common.dto.ErrorResponse;
import com.training.payments.common.exception.PaymentException;
import io.micrometer.tracing.Tracer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

/**
 * TRAINING MODULE: Day 1 - Error Models
 *
 * Centralized exception handler.
 * ALL exceptions translate to ErrorResponse (the standard error contract).
 *
 * TRAINING: Note use of Tracer to include traceId in error responses.
 * Client can paste traceId into Zipkin to find the full distributed trace.
 * This is the bridge between error responses and distributed tracing (Day 3).
 */
@RestControllerAdvice
@Slf4j
@RequiredArgsConstructor
public class GlobalExceptionHandler {

    private final Tracer tracer; // Injected by Micrometer Tracing

    /**
     * Handle all PaymentException subtypes
     */
    @ExceptionHandler(PaymentException.class)
    public ResponseEntity<ErrorResponse> handlePaymentException(
            PaymentException ex, WebRequest request) {

        log.error("[ERROR] PaymentException: {} - {}",
                ex.getErrorCode(), ex.getMessage());

        ErrorResponse error = ErrorResponse.builder()
                .errorCode(ex.getErrorCode())
                .message(ex.getMessage())
                .status(ex.getHttpStatus())
                .traceId(getCurrentTraceId())
                .path(extractPath(request))
                .timestamp(Instant.now())
                .build();

        return ResponseEntity.status(ex.getHttpStatus()).body(error);
    }

    /**
     * Handle Bean Validation errors (@Valid)
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidationErrors(
            MethodArgumentNotValidException ex, WebRequest request) {

        Map<String, String> fieldErrors = new HashMap<>();
        for (FieldError fieldError : ex.getBindingResult().getFieldErrors()) {
            fieldErrors.put(fieldError.getField(), fieldError.getDefaultMessage());
        }

        log.warn("[VALIDATION] Validation failed: {}", fieldErrors);

        ErrorResponse error = ErrorResponse.builder()
                .errorCode("VALIDATION_ERROR")
                .message("Request validation failed")
                .status(400)
                .traceId(getCurrentTraceId())
                .path(extractPath(request))
                .timestamp(Instant.now())
                .fieldErrors(fieldErrors)
                .build();

        return ResponseEntity.badRequest().body(error);
    }

    /**
     * Handle unexpected errors (500)
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGenericException(
            Exception ex, WebRequest request) {

        log.error("[ERROR] Unexpected error: {}", ex.getMessage(), ex);

        ErrorResponse error = ErrorResponse.builder()
                .errorCode("INTERNAL_SERVER_ERROR")
                .message("An unexpected error occurred. Please try again.")
                .status(500)
                .traceId(getCurrentTraceId())
                .path(extractPath(request))
                .timestamp(Instant.now())
                .build();

        return ResponseEntity.internalServerError().body(error);
    }

    private String getCurrentTraceId() {
        try {
            return tracer.currentSpan() != null
                    ? tracer.currentSpan().context().traceId()
                    : "no-trace";
        } catch (Exception e) {
            return "no-trace";
        }
    }

    private String extractPath(WebRequest request) {
        return request.getDescription(false).replace("uri=", "");
    }
}