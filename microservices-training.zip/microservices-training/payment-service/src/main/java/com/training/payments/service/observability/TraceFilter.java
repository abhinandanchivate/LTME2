package com.training.payments.service.observability;

import io.micrometer.tracing.Tracer;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * TRAINING MODULE: Day 3 - Distributed Tracing
 *
 * Servlet filter that:
 * 1. Extracts traceId from Micrometer Tracer
 * 2. Puts traceId into MDC (Mapped Diagnostic Context)
 * 3. MDC makes traceId available in ALL log statements automatically
 * 4. Adds traceId to HTTP response header (for client debugging)
 *
 * LOG FORMAT (with MDC traceId):
 * 2024-01-15 10:30:00.123 INFO [payment-service,abc123def,456789abc] 
 *   PaymentService - Payment created: pay-xyz
 *                   ^traceId^  ^spanId^
 *
 * This format is produced by Micrometer Tracing + Logback config.
 * Copy traceId from log -> paste into Zipkin -> see full distributed trace.
 *
 * TRACE PROPAGATION:
 * Request flows: Gateway -> payment-service -> (PSP)
 * Trace headers propagated: X-B3-TraceId, X-B3-SpanId, X-B3-Sampled
 * All spans share same traceId -> linked in Zipkin
 */
@Component
@Order(0) // Run FIRST before rate limit filter
@Slf4j
@RequiredArgsConstructor
public class TraceFilter implements Filter {

    private final Tracer tracer;

    // MDC key names - match your logback pattern
    private static final String TRACE_ID_KEY = "traceId";
    private static final String SPAN_ID_KEY  = "spanId";
    private static final String CORRELATION_ID_KEY = "correlationId";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {

        HttpServletRequest httpRequest   = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        try {
            // Extract trace context from Micrometer Tracer
            String traceId = "no-trace";
            String spanId  = "no-span";

            if (tracer.currentSpan() != null) {
                traceId = tracer.currentSpan().context().traceId();
                spanId  = tracer.currentSpan().context().spanId();
            }

            // Extract business correlation ID from request header
            String correlationId = httpRequest.getHeader("X-Correlation-ID");
            if (correlationId == null) {
                correlationId = traceId; // Fall back to traceId
            }

            // Put into MDC so ALL log statements in this request include these
            MDC.put(TRACE_ID_KEY, traceId);
            MDC.put(SPAN_ID_KEY, spanId);
            MDC.put(CORRELATION_ID_KEY, correlationId);

            // Add to response so clients can use for support tickets
            httpResponse.setHeader("X-Trace-ID", traceId);
            httpResponse.setHeader("X-Correlation-ID", correlationId);

            log.debug("[TRACE] Request: {} {} | traceId: {} | correlationId: {}",
                    httpRequest.getMethod(),
                    httpRequest.getRequestURI(),
                    traceId, correlationId);

            chain.doFilter(request, response);

        } finally {
            // CRITICAL: Always clear MDC to prevent memory leaks
            // and cross-request contamination in thread pools
            MDC.remove(TRACE_ID_KEY);
            MDC.remove(SPAN_ID_KEY);
            MDC.remove(CORRELATION_ID_KEY);
        }
    }
}