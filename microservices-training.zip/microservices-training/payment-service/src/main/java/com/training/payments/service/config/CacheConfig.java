package com.training.payments.service.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

/**
 * TRAINING MODULE: Day 2 - Caching Strategy
 *
 * Cache Configuration demonstrating:
 *
 * 1. CACHE NAMES (mapped to specific TTLs):
 *    - "payments"         : Individual payment status - 5 min TTL
 *    - "payment-history"  : Customer payment list - 2 min TTL
 *    - "payment-status"   : Just status field - 10 min TTL (stable when COMPLETED)
 *
 * 2. TTL STRATEGY:
 *    - Short TTL for PENDING/PROCESSING (status changes frequently)
 *    - Longer TTL for COMPLETED/FAILED (terminal states don't change)
 *    - TRAINING: Cache consistency problem - how do we evict on update?
 *      Answer: @CacheEvict on update/status-change methods
 *
 * 3. EVICTION STRATEGY:
 *    - Redis uses LRU (Least Recently Used) by default
 *    - Configure maxmemory-policy in Redis: allkeys-lru
 *
 * 4. CACHE CONSISTENCY:
 *    - Write-through: Update DB AND cache simultaneously
 *    - Cache-aside: Read from cache, miss -> read DB -> populate cache
 *    - This implementation uses CACHE-ASIDE pattern
 *
 * 5. HTTP CACHING vs SPRING CACHE:
 *    - HTTP Cache: Cache-Control headers, browser/proxy caches response
 *      Use for: Static data, public APIs, GET responses
 *    - Spring Cache: Server-side cache, invisible to clients
 *      Use for: DB query results, expensive computations
 */
@Configuration
@EnableCaching
public class CacheConfig {

    // Cache name constants - use these in @Cacheable annotations
    public static final String CACHE_PAYMENTS = "payments";
    public static final String CACHE_PAYMENT_HISTORY = "payment-history";
    public static final String CACHE_PAYMENT_STATUS = "payment-status";
    public static final String CACHE_IDEMPOTENCY = "idempotency-keys";

    @Bean
    public CacheManager cacheManager(RedisConnectionFactory connectionFactory) {
        // Jackson serializer with Java 8 time support
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        objectMapper.activateDefaultTyping(
                objectMapper.getPolymorphicTypeValidator(),
                ObjectMapper.DefaultTyping.NON_FINAL
        );

        GenericJackson2JsonRedisSerializer jsonSerializer =
                new GenericJackson2JsonRedisSerializer(objectMapper);

        // Default cache configuration
        RedisCacheConfiguration defaultConfig = RedisCacheConfiguration
                .defaultCacheConfig()
                .entryTtl(Duration.ofMinutes(5))           // Default: 5 min TTL
                .serializeKeysWith(
                        RedisSerializationContext.SerializationPair
                                .fromSerializer(new StringRedisSerializer()))
                .serializeValuesWith(
                        RedisSerializationContext.SerializationPair
                                .fromSerializer(jsonSerializer))
                .disableCachingNullValues()                 // Don't cache nulls
                .prefixCacheNameWith("payments:");          // Key prefix

        // Per-cache TTL overrides
        Map<String, RedisCacheConfiguration> cacheConfigs = new HashMap<>();

        // Individual payment - 5 minutes
        cacheConfigs.put(CACHE_PAYMENTS,
                defaultConfig.entryTtl(Duration.ofMinutes(5)));

        // Payment history list - 2 minutes (changes as new payments arrive)
        cacheConfigs.put(CACHE_PAYMENT_HISTORY,
                defaultConfig.entryTtl(Duration.ofMinutes(2)));

        // Payment status only - 10 minutes for terminal states
        // TRAINING: In production, use conditional TTL based on status
        cacheConfigs.put(CACHE_PAYMENT_STATUS,
                defaultConfig.entryTtl(Duration.ofMinutes(10)));

        // Idempotency keys - 24 hours (matches business requirement)
        cacheConfigs.put(CACHE_IDEMPOTENCY,
                defaultConfig.entryTtl(Duration.ofHours(24)));

        return RedisCacheManager.builder(connectionFactory)
                .cacheDefaults(defaultConfig)
                .withInitialCacheConfigurations(cacheConfigs)
                .transactionAware() // Cache operations participate in TX
                .build();
    }
}