package com.training.payments.service.patterns;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * TRAINING MODULE: Day 3 - Microservices Design Patterns
 *
 * Demo endpoint showing all patterns with explanations.
 * GET /api/patterns/overview -> Returns structured pattern map
 *
 * PATTERNS COVERED:
 *
 * ============================================================
 * 1. BFF (Backend for Frontend)
 * ============================================================
 * Problem: Mobile needs different data shape than web
 * Solution: Dedicated backend per client type
 * Example: /bff/mobile/* serves mobile app
 *          /bff/web/* serves web app (richer data)
 *          /bff/partner/* serves partner APIs
 * Demo: bff-service aggregates payment + order for mobile dashboard
 *
 * ============================================================
 * 2. API Gateway
 * ============================================================
 * Problem: Clients need to know all service URLs; auth repeated everywhere
 * Solution: Single entry point; gateway handles cross-cutting concerns
 * Handles: Auth, routing, rate limiting, SSL termination, logging
 * Demo: gateway-service routes ALL traffic
 *
 * ============================================================
 * 3. Strangler Fig
 * ============================================================
 * Problem: Big bang rewrite is risky; monolith can't be replaced at once
 * Solution: Incrementally extract services; route new features to microservices
 *           Old monolith still handles legacy requests
 * Pattern: Plant new service ALONGSIDE monolith; strangle monolith gradually
 * Demo: /api/v2/payments routes to new microservice
 *       /api/v1/payments still works (legacy compatibility)
 *
 * ============================================================
 * 4. Anti-Corruption Layer (ACL)
 * ============================================================
 * Problem: Integrating with legacy PSP that has terrible API/model
 * Solution: ACL translates between your clean domain model and PSP's model
 * Example: PSP returns XML with weird field names
 *          ACL translates to clean PaymentResponse
 * Demo: PspClient acts as ACL between our domain and PSP API
 *
 * ============================================================
 * 5. CQRS (Command Query Responsibility Segregation)
 * ============================================================
 * Problem: Same model serves both writes (complex business logic)
 *          and reads (complex queries, reporting)
 * Solution: Separate write model (Commands) from read model (Queries)
 * Write: POST /payments -> PaymentCommand -> payment_db (normalized)
 * Read:  GET /payments  -> PaymentQuery  -> payment_read_db (denormalized)
 * Demo: PaymentService.createPayment (write) vs getPaymentHistory (read)
 *       Read uses Redis cache as the read model
 *
 * ============================================================
 * 6. Event Sourcing
 * ============================================================
 * Problem: How to audit all payment state changes? How to replay events?
 * Solution: Store EVENTS (not current state); derive state from event log
 * Events: PaymentCreated, PaymentProcessed, PaymentCompleted, PaymentRefunded
 * Benefits: Full audit trail, replay to rebuild state, temporal queries
 * Demo: Kafka topic "payment-events" IS the event log
 *       Payment status derived from replaying events
 *
 * ============================================================
 * 7. Saga
 * ============================================================
 * Problem: Distributed transaction across payment-service + order-service
 * Solution: Sequence of local transactions with compensation
 * Demo: See PaymentEventConsumer + OrderService saga flow
 *
 * ============================================================
 * 8. Sidecar / Ambassador (mentioned, not implemented)
 * ============================================================
 * Problem: Cross-cutting concerns (logging, tracing, mTLS) in every service
 * Solution: Sidecar container handles these alongside the service container
 * Example: Envoy proxy sidecar in Kubernetes (Istio service mesh)
 */
@RestController
@RequestMapping("/api/patterns")
@Slf4j
@Tag(name = "Design Patterns", description = "Microservices pattern reference and demos")
public class PatternsController {

    /**
     * Returns structured overview of all patterns with payment domain examples.
     * Use this as a reference during Day 3 training discussion.
     */
    @Operation(
        summary = "Get microservices patterns overview",
        description = "Returns all microservices patterns with payment domain examples and URLs"
    )
    @GetMapping("/overview")
    public ResponseEntity<Map<String, Object>> getPatternsOverview() {
        log.info("[PATTERNS] Returning patterns overview");

        Map<String, Object> overview = new LinkedHashMap<>();
        overview.put("generatedAt", Instant.now());
        overview.put("context", "Payment Processing Domain - All patterns demonstrated");

        // ============================================================
        // Pattern 1: BFF
        // ============================================================
        overview.put("bff", Map.of(
            "name", "Backend for Frontend (BFF)",
            "problem", "Mobile and web clients need different data shapes. " +
                       "Each client makes multiple calls wasting bandwidth.",
            "solution", "Dedicated backend per client type that aggregates and shapes data.",
            "tradeoffs", List.of(
                "PRO: Optimized payload per client (less over-fetching)",
                "PRO: Fewer client round trips",
                "PRO: Client-specific auth/rate limits",
                "CON: Another service to maintain",
                "CON: Can duplicate logic across BFFs"
            ),
            "demoEndpoints", Map.of(
                "mobile_dashboard", "GET http://localhost:8083/payment-summary/dashboard?customerId=CUST-001",
                "via_gateway",      "GET http://localhost:8080/bff/payment-summary/dashboard?customerId=CUST-001"
            ),
            "paymentDomainExample",
            "Mobile app calls ONE endpoint to get payment history + order status + summary stats. " +
            "BFF calls payment-service AND order-service in PARALLEL, combines results."
        ));

        // ============================================================
        // Pattern 2: API Gateway
        // ============================================================
        overview.put("apiGateway", Map.of(
            "name", "API Gateway",
            "problem", "Clients know ALL service URLs. Auth, logging, rate limiting " +
                       "repeated in every service.",
            "solution", "Single entry point handles cross-cutting concerns. " +
                        "Services only handle business logic.",
            "responsibilities", List.of(
                "ROUTING: /api/v1/payments -> payment-service",
                "AUTH: Validate X-API-Key before forwarding",
                "RATE LIMITING: Global throttling at edge",
                "LOGGING: Centralized access log",
                "CIRCUIT BREAKING: Gateway-level CB with fallback",
                "SSL TERMINATION: HTTPS at gateway, HTTP internally"
            ),
            "demoEndpoints", Map.of(
                "gateway_health",   "GET http://localhost:8080/actuator/health",
                "gateway_routes",   "GET http://localhost:8080/actuator/gateway/routes",
                "payment_via_gw",   "POST http://localhost:8080/api/v1/payments",
                "order_via_gw",     "POST http://localhost:8080/api/v1/orders"
            ),
            "paymentDomainExample",
            "All payment API calls flow through gateway on port 8080. " +
            "Gateway validates API key, logs request, routes to payment-service, " +
            "adds correlation ID for tracing."
        ));

        // ============================================================
        // Pattern 3: Strangler Fig
        // ============================================================
        overview.put("stranglerFig", Map.of(
            "name", "Strangler Fig",
            "problem", "Cannot rewrite monolith at once. Big bang rewrites fail.",
            "solution", "Incrementally extract microservices alongside monolith. " +
                        "Route new features to microservices. Strangle monolith gradually.",
            "steps", List.of(
                "1. Identify feature to extract (e.g., payment processing)",
                "2. Build new payment-service microservice",
                "3. Route /api/v2/payments to new service via gateway",
                "4. /api/v1/payments still hits monolith",
                "5. Migrate clients to v2 gradually",
                "6. When v1 traffic = 0, remove from monolith"
            ),
            "demoEndpoints", Map.of(
                "v1_legacy",    "POST http://localhost:8081/api/v1/payments (old contract)",
                "v2_extracted", "POST http://localhost:8081/api/v2/payments (new microservice)"
            ),
            "paymentDomainExample",
            "Legacy monolith handled payments. v1 API maintained for backward compat. " +
            "New microservice handles v2 with cursor pagination and PSP reference. " +
            "Gateway routes v1 and v2 to same payment-service (both coexist)."
        ));

        // ============================================================
        // Pattern 4: Anti-Corruption Layer
        // ============================================================
        overview.put("antiCorruptionLayer", Map.of(
            "name", "Anti-Corruption Layer (ACL)",
            "problem", "PSP has messy API with bad field names, XML responses, " +
                       "inconsistent error codes. Don't want PSP concepts bleeding " +
                       "into your clean domain model.",
            "solution", "ACL sits between your domain and external system. " +
                        "Translates external model to your domain model.",
            "layers", List.of(
                "External: PSP returns { charge_id: 'ch_123', stat: 'OK', amt: 1000 }",
                "ACL (PspClient): Translates to PspResponse { pspReference, status, amount }",
                "Domain: Payment uses PspResponse cleanly"
            ),
            "demoCode", "See PspClient.java - simulates PSP and translates response",
            "paymentDomainExample",
            "PspClient acts as ACL. External PSP could return XML/JSON/SOAP. " +
            "PspClient always returns clean PspResponse to PaymentService. " +
            "Switching PSP providers = only change PspClient, not PaymentService."
        ));

        // ============================================================
        // Pattern 5: CQRS
        // ============================================================
        overview.put("cqrs", Map.of(
            "name", "CQRS (Command Query Responsibility Segregation)",
            "problem", "Write operations need business rules and validation. " +
                       "Read operations need complex queries and joins. " +
                       "Same model serves both poorly.",
            "solution", "Separate write model (commands) from read model (queries). " +
                        "Each can be optimized independently.",
            "commandSide", Map.of(
                "description", "Handles state changes with business rules",
                "examples", List.of(
                    "POST /payments -> PaymentService.createPayment()",
                    "DELETE /payments/{id} -> PaymentService.cancelPayment()",
                    "POST /payments/{id}/refund -> PaymentService.refundPayment()"
                ),
                "storage", "H2/PostgreSQL normalized tables"
            ),
            "querySide", Map.of(
                "description", "Optimized for reads, may be denormalized",
                "examples", List.of(
                    "GET /payments/{id} -> @Cacheable Redis (read model)",
                    "GET /payments (history) -> cursor pagination query",
                    "GET /bff/dashboard -> aggregated read model"
                ),
                "storage", "Redis cache as denormalized read model"
            ),
            "demoEndpoints", Map.of(
                "command", "POST http://localhost:8081/api/v2/payments",
                "query",   "GET  http://localhost:8081/api/v2/payments/{id}",
                "query_history", "GET  http://localhost:8081/api/v2/payments?customerId=CUST-001"
            )
        ));

        // ============================================================
        // Pattern 6: Event Sourcing
        // ============================================================
        overview.put("eventSourcing", Map.of(
            "name", "Event Sourcing",
            "problem", "How do we know HOW a payment reached its current state? " +
                       "No audit trail. Cannot replay history. Cannot debug past state.",
            "solution", "Store events (facts) instead of current state. " +
                        "Current state = replay of all events from beginning.",
            "events", List.of(
                "PAYMENT_INITIATED:   { paymentId, amount, currency, timestamp }",
                "PAYMENT_PROCESSING:  { paymentId, pspRef, timestamp }",
                "PAYMENT_COMPLETED:   { paymentId, pspRef, timestamp }",
                "PAYMENT_REFUNDED:    { paymentId, reason, timestamp }"
            ),
            "benefits", List.of(
                "Full audit trail (regulatory compliance for payments!)",
                "Replay events to rebuild state",
                "Project events to different read models",
                "Temporal queries: what was payment status at 2PM?"
            ),
            "implementation", "Kafka topic 'payment-events' IS the event log. " +
                              "Payment status derived from latest event.",
            "demoKafka", "See Kafka UI at http://localhost:8090 -> topic: payment-events"
        ));

        // ============================================================
        // Pattern 7: Saga (reference back to Day 3 module)
        // ============================================================
        overview.put("saga", Map.of(
            "name", "Saga (Distributed Transactions)",
            "problem", "Payment and Order are in different databases. " +
                       "Cannot use single ACID transaction. " +
                       "How to maintain consistency?",
            "solution", "Sequence of local transactions with compensating transactions.",
            "styles", Map.of(
                "choreography", Map.of(
                    "description", "Services react to events independently, no coordinator",
                    "demo", "PaymentEventConsumer listens to payment-events, " +
                             "updates order status, publishes order-events",
                    "pros", List.of("Loose coupling", "No SPOF coordinator"),
                    "cons",  List.of("Hard to visualize full flow", "Distributed logic")
                ),
                "orchestration", Map.of(
                    "description", "Central Saga orchestrator directs each step",
                    "example", "SagaOrchestrator: step1=initPayment, step2=confirmOrder",
                    "pros", List.of("Easy to visualize", "Centralized error handling"),
                    "cons",  List.of("Orchestrator is SPOF", "Tighter coupling")
                )
            ),
            "demoFlow", List.of(
                "1. POST http://localhost:8082/api/v1/orders -> get orderId",
                "2. POST http://localhost:8081/api/v1/payments with orderId",
                "3. Watch Kafka: payment-events -> PAYMENT_COMPLETED",
                "4. Watch order-service logs: order CONFIRMED",
                "5. GET http://localhost:8082/api/v1/orders/{orderId} -> CONFIRMED"
            )
        ));

        return ResponseEntity.ok(overview);
    }

    /**
     * Quick reference: which pattern solves which problem
     */
    @Operation(summary = "Pattern selection guide - which pattern for which problem")
    @GetMapping("/guide")
    public ResponseEntity<Map<String, Object>> getPatternGuide() {
        Map<String, Object> guide = new LinkedHashMap<>();

        guide.put("problemToPattern", Map.of(
            "clients_need_different_data_shapes",       "BFF Pattern",
            "all_clients_call_all_services_directly",   "API Gateway",
            "replacing_monolith_is_risky",              "Strangler Fig",
            "external_api_is_messy",                    "Anti-Corruption Layer",
            "reads_and_writes_have_different_needs",    "CQRS",
            "need_full_audit_trail",                    "Event Sourcing",
            "distributed_transaction_across_services",  "Saga",
            "need_aggregated_mobile_response",          "BFF + Gateway",
            "psp_failure_affects_everything",           "Circuit Breaker + Bulkhead",
            "cant_afford_to_lose_events",               "Outbox Pattern (reference)"
        ));

        guide.put("paymentDomainMapping", Map.of(
            "mobile_dashboard",      "BFF -> aggregates payments + orders",
            "all_traffic_entry",     "API Gateway -> gateway-service:8080",
            "psp_integration",       "ACL -> PspClient translates PSP model",
            "payment_read_cache",    "CQRS -> Redis read model for GET /payments",
            "payment_audit_trail",   "Event Sourcing -> Kafka payment-events topic",
            "payment_order_link",    "Saga -> PaymentEventConsumer + compensation",
            "v1_v2_coexistence",     "Strangler Fig -> both versions live together"
        ));

        return ResponseEntity.ok(guide);
    }
}