package com.training.payments.service.config;

import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.*;
import io.swagger.v3.oas.models.security.*;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * TRAINING MODULE: Day 1 - OpenAPI Contract Design
 *
 * Configures the OpenAPI 3.0 specification for payment-service.
 *
 * Contract-first vs Code-first:
 * - CODE-FIRST (this approach): Write code, annotations generate spec
 *   Pro: Always in sync with code
 *   Con: API design is driven by implementation details
 *
 * - CONTRACT-FIRST: Write OpenAPI YAML first, generate stubs
 *   Pro: API design is deliberate and client-focused
 *   Con: Must keep spec and code in sync manually
 *
 * For TRAINING: We use code-first with rich annotations to show both concepts.
 *
 * Access Swagger UI at: http://localhost:8081/swagger-ui.html
 * Access API Docs at:   http://localhost:8081/v3/api-docs
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI paymentServiceOpenAPI() {
        return new OpenAPI()
                // ============================================================
                // API Metadata - part of the contract
                // ============================================================
                .info(new Info()
                        .title("Payment Service API")
                        .description("""
                                ## Payment Service API
                                
                                Core payment processing microservice supporting:
                                - Payment creation with idempotency
                                - Payment status tracking
                                - Payment history with pagination (offset & cursor)
                                - Versioned API (v1 legacy, v2 current)
                                
                                ### Versioning Strategy
                                This API uses **URL path versioning**:
                                - `/api/v1/payments` - Legacy (backward compatible)
                                - `/api/v2/payments` - Current (with cursor pagination)
                                
                                ### Idempotency
                                Always provide `X-Idempotency-Key` header to prevent duplicate payments.
                                
                                ### Rate Limiting
                                - 60 requests/minute per client
                                - 429 Too Many Requests returned when exceeded
                                """)
                        .version("2.0.0")
                        .contact(new Contact()
                                .name("Training Team")
                                .email("training@example.com"))
                        .license(new License()
                                .name("MIT")
                                .url("https://opensource.org/licenses/MIT")))

                // ============================================================
                // Servers - where the API is hosted
                // ============================================================
                .addServersItem(new Server()
                        .url("http://localhost:8081")
                        .description("Local Development"))
                .addServersItem(new Server()
                        .url("http://localhost:8080/payment-service")
                        .description("Via API Gateway (local)"))

                // ============================================================
                // Security Schemes - API Key via header
                // TRAINING Day 4: WAF & Security layer validates this
                // ============================================================
                .addSecurityItem(new SecurityRequirement()
                        .addList("ApiKeyAuth"))
                .components(new Components()
                        .addSecuritySchemes("ApiKeyAuth",
                                new SecurityScheme()
                                        .type(SecurityScheme.Type.APIKEY)
                                        .in(SecurityScheme.In.HEADER)
                                        .name("X-API-Key")
                                        .description("API Key for authentication")));
    }
}