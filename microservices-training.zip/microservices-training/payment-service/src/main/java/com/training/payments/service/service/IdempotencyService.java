package com.training.payments.service.service;

import com.training.payments.common.dto.PaymentResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * TRAINING MODULE: Day 1 - Idempotency Keys & Duplicate Suppression
 *
 * WHAT IS IDEMPOTENCY?
 * An operation is idempotent if performing it multiple times
 * has the same effect as performing it once.
 *
 * WHY CRITICAL FOR PAYMENTS?
 * Scenario without idempotency:
 * 1. Client sends POST /payments (amount=$100)
 * 2. Payment processed, PSP charged $100
 * 3. NETWORK ERROR - client never receives 200 OK
 * 4. Client retries POST /payments
 * 5. DOUBLE CHARGE! Customer billed $200 instead of $100
 *
 * Solution with idempotency keys:
 * 1. Client generates UUID: "idem-key-xyz-123"
 * 2. Client sends POST /payments with X-Idempotency-Key: idem-key-xyz-123
 * 3. Payment processed ($100 charged), response cached against key
 * 4. Network error - client retries with SAME idempotency key
 * 5. Server detects key exists, returns CACHED response
 * 6. No duplicate charge! Client gets same response as first call
 *
 * IMPLEMENTATION APPROACHES:
 * 1. Database unique constraint on idempotency_key (our DB approach)
 * 2. Redis cache with TTL (our cache approach - faster check)
 * 3. Distributed lock during processing (prevents concurrent duplicates)
 *
 * TRAINING: We use BOTH DB constraint (durable) AND Redis cache (fast)
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class IdempotencyService {

    private static final String CACHE_PREFIX = "idempotency:";

    /**
     * Check if we've already processed a request with this idempotency key.
     *
     * @param idempotencyKey Client-provided unique key
     * @return Cached response if duplicate, empty if first time
     */
    @Cacheable(value = "idempotency-keys", key = "#idempotencyKey",
               unless = "#result == null")
    public Optional<PaymentResponse> findExistingResponse(String idempotencyKey) {
        // Cache miss - this is the first time we've seen this key
        // The @Cacheable annotation handles cache hit automatically
        log.debug("[IDEMPOTENCY] Cache miss for key: {} - first request",
                idempotencyKey);
        return Optional.empty();
    }

    /**
     * Store the response for an idempotency key.
     * Called AFTER successful payment processing.
     *
     * @CachePut ALWAYS executes the method AND updates the cache.
     * Contrast with @Cacheable which SKIPS the method on cache hit.
     */
    @CachePut(value = "idempotency-keys", key = "#idempotencyKey")
    public Optional<PaymentResponse> storeResponse(String idempotencyKey,
                                                    PaymentResponse response) {
        log.info("[IDEMPOTENCY] Storing response for key: {} paymentId: {}",
                idempotencyKey, response.getPaymentId());
        // Return wrapped in Optional to match findExistingResponse return type
        return Optional.of(response);
    }

    /**
     * Check if idempotency key is currently being processed.
     * Prevents concurrent duplicate requests racing each other.
     *
     * TRAINING: In production, use Redis SETNX (Set if Not eXists)
     * for distributed lock:
     *   SET idem:key:xyz "processing" EX 30 NX
     *   Returns 1 if set (first), 0 if exists (concurrent duplicate)
     */
    public boolean isProcessing(String idempotencyKey) {
        // Simplified for demo - in production use Redis SETNX
        log.debug("[IDEMPOTENCY] Checking processing status for: {}", idempotencyKey);
        return false; // Demo: never locked
    }

    /**
     * Mark key as currently processing (distributed lock)
     */
    public void markProcessing(String idempotencyKey) {
        log.debug("[IDEMPOTENCY] Marking as processing: {}", idempotencyKey);
        // In production: SET idem:processing:key "1" EX 30 NX
    }

    /**
     * Release processing lock
     */
    public void releaseProcessing(String idempotencyKey) {
        log.debug("[IDEMPOTENCY] Releasing processing lock: {}", idempotencyKey);
        // In production: DEL idem:processing:key
    }
}