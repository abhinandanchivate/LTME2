package com.training.payments.service.psp;

import lombok.*;
import java.math.BigDecimal;

/**
 * TRAINING MODULE: Day 1 - PSP Integration
 * Request sent to Payment Service Provider
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PspChargeRequest {
    private String paymentId;
    private String idempotencyKey;  // PSP also supports idempotency!
    private BigDecimal amount;
    private String currency;
    private String paymentMethod;
    private String cardNumber;      // Only for card payments (raw, encrypted in prod)
    private String customerId;
    private String orderId;
}