# Microservices Training Platform - Payments Domain

A comprehensive, hands-on microservices training project built around a
**Payment Processing Domain**. This project covers 16 training modules
across 4 days, with every concept demonstrated through working code.

---

## Table of Contents

- [Project Overview](#project-overview)
- [Architecture](#architecture)
- [Technology Stack](#technology-stack)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)
- [Service Reference](#service-reference)
- [Training Modules](#training-modules)
- [Demo URLs](#demo-urls)
- [API Reference](#api-reference)
- [Running the Demo](#running-the-demo)
- [Troubleshooting](#troubleshooting)
- [Training Scenarios](#training-scenarios)

---

## Project Overview

This project simulates a real-world **Payment Processing Platform** used
as a vehicle to teach microservices patterns and practices. Every module,
pattern, and concept is demonstrated with **working, runnable code** — not
slides.

### What You Will Learn

| Day | Theme | Key Concepts |
|-----|-------|-------------|
| Day 1 | API Design + Structure | REST modeling, pagination, versioning, idempotency, OpenAPI, multi-module builds |
| Day 2 | Resiliency + Gateway | Circuit breaker, retry, rate limiting, caching, service discovery, API gateway |
| Day 3 | Consistency + Observability | Saga pattern, distributed transactions, tracing, metrics, design patterns |
| Day 4 | Edge + Security | DNS, load balancing, WAF, CDN, DDoS protection |

### Why Payments?

Payments is the **perfect training domain** because it forces you to think about:
- **Idempotency** — double charging a customer is catastrophic
- **Consistency** — payment and order must stay in sync across services
- **Resilience** — PSP downtime must not bring down the entire platform
- **Security** — PCI DSS, injection attacks, rate limiting
- **Observability** — every transaction must be traceable end-to-end

---

## Architecture

```
                         ┌─────────────────────────────────────────┐
                         │           CLIENT (Browser / Mobile)      │
                         └──────────────────┬──────────────────────┘
                                            │ HTTPS
                         ┌──────────────────▼──────────────────────┐
                         │         NGINX (CDN Simulation)           │
                         │    Static files: Cache-Control headers   │
                         │         Port 8084                        │
                         └──────────────────┬──────────────────────┘
                                            │ Dynamic requests only
                         ┌──────────────────▼──────────────────────┐
                         │           API GATEWAY                    │
                         │  Auth │ Routing │ Rate Limit │ CB        │
                         │         Port 8080                        │
                         └────────┬──────────────┬─────────────────┘
                                  │              │
              ┌───────────────────▼──┐    ┌──────▼───────────────┐
              │   PAYMENT SERVICE    │    │    ORDER SERVICE      │
              │  Port 8081           │    │    Port 8082          │
              │  - REST API v1/v2    │    │    - Saga participant │
              │  - Idempotency       │    │    - Event consumer   │
              │  - Circuit Breaker   │    │    - Compensation     │
              │  - Redis Cache       │    └──────────────────────┘
              │  - PSP Integration   │
              └──────────┬───────────┘
                         │                 ┌──────────────────────┐
                         │                 │    BFF SERVICE        │
                         │                 │    Port 8083          │
                         │                 │    - Aggregation      │
                         │                 │    - Mobile optimized │
                         │                 └──────────────────────┘
                         │
              ┌───────────▼──────────────────────────────────────┐
              │              INFRASTRUCTURE                        │
              │  Redis(6379) │ Kafka(9092) │ Zipkin(9411)         │
              │  Prometheus(9090) │ Grafana(3000)                  │
              │  Eureka(8761) │ Kafka-UI(8090)                    │
              └──────────────────────────────────────────────────┘
```

### Saga Choreography Flow

```
Client
│
├──POST /orders──────────────────────► Order Service
│                                          │ status=CREATED
│                                          │ publishes ORDER_CREATED
│
├──POST /payments────────────────────► Payment Service
│                                          │ status=PENDING
│                                          │ calls PSP
│                                          │ publishes PAYMENT_COMPLETED
│                                          │
│                                     Order Service (listener)
│                                          │ status=CONFIRMED
│                                          │ triggers fulfillment
│
│         IF fulfillment fails:
│                                     Order Service
│                                          │ publishes ORDER_FAILED
│                                          │
│                                     Payment Service (listener)
│                                          │ issues REFUND
│                                          │ publishes PAYMENT_REFUNDED
```

---

## Technology Stack

### Application

| Technology | Version | Purpose |
|-----------|---------|---------|
| Java | 17 | Language (records, sealed classes, text blocks) |
| Spring Boot | 3.2.0 | Application framework |
| Spring Cloud | 2023.0.0 | Microservices toolkit |
| Spring Cloud Gateway | 4.1.x | API Gateway (WebFlux reactive) |
| Spring Cloud Netflix Eureka | 4.1.x | Service discovery |
| Spring Data JPA | 3.2.x | Data persistence |
| Spring Data Redis | 3.2.x | Caching layer |
| Spring Kafka | 3.1.x | Event streaming for Saga |
| Resilience4j | 2.1.0 | Circuit breaker, retry, bulkhead |
| Bucket4j | 8.7.0 | Token bucket rate limiting |
| Springdoc OpenAPI | 2.3.0 | API documentation generation |
| Micrometer Tracing | 1.2.0 | Distributed tracing |
| Lombok | 1.18.x | Boilerplate reduction |

### Infrastructure (Docker)

| Service | Image | Port | Purpose |
|---------|-------|------|---------|
| Redis | redis:7.2-alpine | 6379 | Cache + Idempotency store |
| Apache Kafka | confluentinc/cp-kafka:7.5.0 | 9092 | Event streaming |
| Zookeeper | confluentinc/cp-zookeeper:7.5.0 | 2181 | Kafka coordination |
| Zipkin | openzipkin/zipkin:3.1 | 9411 | Distributed tracing UI |
| Prometheus | prom/prometheus:v2.48.0 | 9090 | Metrics collection |
| Grafana | grafana/grafana:10.2.0 | 3000 | Metrics dashboards |
| NGINX | nginx:1.25-alpine | 8084 | CDN simulation |
| Kafka UI | provectuslabs/kafka-ui | 8090 | Kafka topic browser |
| Redis Commander | rediscommander/redis-commander | 8091 | Redis browser |

### Build

| Tool | Version | Purpose |
|------|---------|---------|
| Maven | 3.9+ | Multi-module build |
| Docker Desktop | 27+ | Container runtime |
| Docker Compose | 2.28+ | Infrastructure orchestration |

---

## Project Structure

```
microservices-training/
│
├── pom.xml                          # Parent POM - manages all module versions
│
├── payment-common/                  # Shared library (NO Spring Boot)
│   └── src/main/java/
│       └── com/training/payments/common/
│           ├── model/
│           │   ├── Payment.java         # Core domain model
│           │   └── PaymentStatus.java   # Status state machine enum
│           ├── dto/
│           │   ├── PaymentRequest.java  # API input contract
│           │   ├── PaymentResponse.java # API output contract
│           │   ├── PagedResponse.java   # Pagination wrapper (offset + cursor)
│           │   └── ErrorResponse.java  # Standard error contract
│           ├── event/
│           │   └── PaymentEvent.java    # Kafka event model for Saga
│           └── exception/
│               └── PaymentException.java # Exception hierarchy
│
├── payment-service/                 # Core payment microservice (Port 8081)
│   └── src/main/java/
│       └── com/training/payments/service/
│           ├── PaymentServiceApplication.java
│           ├── config/
│           │   ├── OpenApiConfig.java       # Swagger/OpenAPI setup
│           │   ├── CacheConfig.java         # Redis cache TTL config
│           │   └── ResilienceConfig.java    # CB + Retry + Bulkhead
│           ├── controller/
│           │   ├── PaymentControllerV1.java # v1 API (offset pagination)
│           │   ├── PaymentControllerV2.java # v2 API (cursor pagination)
│           │   └── GlobalExceptionHandler.java
│           ├── service/
│           │   ├── PaymentService.java      # Business logic + Saga events
│           │   └── IdempotencyService.java  # Duplicate detection
│           ├── repository/
│           │   └── PaymentRepository.java   # JPA + cursor query
│           ├── entity/
│           │   └── PaymentEntity.java       # JPA entity
│           ├── mapper/
│           │   └── PaymentMapper.java       # Entity <-> DTO conversion
│           ├── psp/
│           │   ├── PspClient.java           # PSP integration (CB + retry)
│           │   ├── PspChargeRequest.java
│           │   └── PspResponse.java
│           ├── filter/
│           │   └── RateLimitFilter.java     # Token bucket rate limiting
│           ├── observability/
│           │   ├── ObservabilityConfig.java # Metrics + tracing setup
│           │   ├── PaymentMetrics.java      # Golden signals counters
│           │   └── TraceFilter.java         # MDC + trace ID injection
│           ├── patterns/
│           │   └── PatternsController.java  # Design patterns reference API
│           └── edge/
│               └── EdgeSimulationController.java # DNS/WAF/CDN demo API
│
├── order-service/                   # Order microservice + Saga (Port 8082)
│   └── src/main/java/
│       └── com/training/payments/order/
│           ├── OrderServiceApplication.java
│           ├── controller/
│           │   └── OrderController.java
│           ├── service/
│           │   └── OrderService.java        # Order logic + timeout handling
│           ├── saga/
│           │   ├── PaymentEventConsumer.java # Kafka listener - Saga reactions
│           │   └── OrderEventConsumer.java   # Audit listener
│           ├── model/
│           │   ├── Order.java
│           │   └── OrderStatus.java          # Saga state machine
│           ├── event/
│           │   └── OrderEvent.java           # Order domain events
│           ├── repository/
│           │   └── OrderRepository.java
│           └── dto/
│               ├── CreateOrderRequest.java
│               └── OrderResponse.java
│
├── discovery-service/               # Eureka Server (Port 8761)
│   └── src/main/java/
│       └── com/training/payments/discovery/
│           ├── DiscoveryServiceApplication.java
│           └── SecurityConfig.java
│
├── gateway-service/                 # API Gateway - WebFlux (Port 8080)
│   └── src/main/java/
│       └── com/training/payments/gateway/
│           ├── GatewayServiceApplication.java
│           ├── config/
│           │   └── GatewayConfig.java       # Routes + global filters
│           └── controller/
│               └── FallbackController.java  # CB fallback responses
│
├── bff-service/                     # Backend for Frontend (Port 8083)
│   └── src/main/java/
│       └── com/training/payments/bff/
│           ├── BffServiceApplication.java
│           ├── controller/
│           │   └── BffController.java       # Aggregated endpoints
│           ├── service/
│           │   └── PaymentAggregationService.java # Parallel fetch
│           └── dto/
│               └── PaymentDashboardResponse.java  # Mobile-optimised DTO
│
├── infra/
│   ├── redis/
│   │   └── redis.conf               # Redis config (LRU eviction, AOF)
│   ├── prometheus/
│   │   └── prometheus.yml           # Scrape targets for all services
│   ├── nginx/
│   │   ├── nginx.conf               # CDN simulation with cache headers
│   │   └── static/ui/
│   │       └── index.html           # Training hub page
│   └── grafana/
│       ├── provisioning/
│       │   ├── datasources/
│       │   │   └── prometheus.yml   # Auto-configure Prometheus datasource
│       │   └── dashboards/
│       │       └── dashboard.yml    # Auto-load dashboard files
│       └── dashboards/
│           └── payment-dashboard.json  # Golden signals dashboard
│
├── docker-compose.yml               # Full infrastructure stack
├── validate-demo.ps1                # Pre-demo validation script
├── playbook.md                      # Trainer demo walkthrough
└── README.md                        # This file
```

---

## Prerequisites

### Required Software

| Software | Minimum Version | Download |
|---------|----------------|----------|
| Java JDK | 17 | https://adoptium.net/ |
| Apache Maven | 3.9.0 | https://maven.apache.org/download.cgi |
| Docker Desktop | 27.0 | https://www.docker.com/products/docker-desktop/ |
| Git | 2.x | https://git-scm.com/ |

### System Requirements

| Resource | Minimum | Recommended |
|----------|---------|-------------|
| RAM | 8 GB | 16 GB+ |
| Free RAM for demo | 4 GB | 8 GB |
| Disk Space | 5 GB | 10 GB |
| CPU Cores | 4 | 8 |
| OS | Windows 11 | Windows 11 |

### Verify Prerequisites

```powershell
# Run all checks at once
java -version          # Must show: openjdk 17.x.x
mvn -version           # Must show: Apache Maven 3.9.x
docker --version       # Must show: Docker version 27.x.x
docker compose version # Must show: Docker Compose version v2.x.x
```

---

## Quick Start

### First Time Setup (10-15 minutes)

```powershell
# 1. Clone the repository
git clone <repository-url>
cd microservices-training

# 2. Fix any XML encoding issues and build all modules
mvn clean install -DskipTests

# 3. Start all infrastructure containers
docker compose up -d redis zookeeper kafka zipkin prometheus grafana kafka-ui redis-commander nginx-cdn

# 4. Wait for Kafka to be ready (60 seconds)
Start-Sleep -Seconds 60

# 5. Run pre-demo validation
.\validate-demo.ps1 -SkipBuild -SkipInfra

# 6. Open the training hub
Start-Process "http://localhost:8084/ui/index.html"
```

### Starting Application Services

Services are started individually via Maven for training demos
(so logs are visible and services can be stopped/started individually):

```powershell
# Terminal 1 - Discovery (start FIRST, others depend on it)
cd discovery-service
mvn spring-boot:run

# Terminal 2 - Payment Service (main demo service)
cd payment-service
mvn spring-boot:run

# Terminal 3 - Order Service (Saga participant)
cd order-service
mvn spring-boot:run

# Terminal 4 - BFF Service
cd bff-service
mvn spring-boot:run

# Terminal 5 - Gateway (start LAST, after others register in Eureka)
cd gateway-service
mvn spring-boot:run
```

### Validate Everything is Working

```powershell
# Full validation with smoke tests
.\validate-demo.ps1 -SkipBuild -SkipInfra

# If services are not yet started
.\validate-demo.ps1 -SkipBuild -SkipInfra -StartServices
```

---

## Service Reference

### Payment Service (Port 8081)

The core microservice. Demonstrates all Day 1-3 patterns.

| Endpoint | Method | Description | Training Module |
|----------|--------|-------------|----------------|
| `/api/v1/payments` | POST | Create payment with idempotency | Day 1 |
| `/api/v1/payments` | GET | List payments (offset pagination) | Day 1 |
| `/api/v1/payments/{id}` | GET | Get payment (Redis cached) | Day 2 |
| `/api/v1/payments/{id}` | DELETE | Cancel payment | Day 1 |
| `/api/v2/payments` | POST | Create payment (v2 contract) | Day 1 |
| `/api/v2/payments` | GET | List payments (cursor pagination) | Day 1 |
| `/api/v2/payments/{id}` | GET | Get payment with PSP reference | Day 1 |
| `/api/v2/payments/{id}/refund` | POST | Refund - Saga compensation | Day 3 |
| `/api/patterns/overview` | GET | Design patterns reference | Day 3 |
| `/api/patterns/guide` | GET | Pattern selection guide | Day 3 |
| `/api/edge/traffic-flow` | GET | Full DNS-to-service flow | Day 4 |
| `/api/edge/waf-check` | POST | WAF threat simulation | Day 4 |
| `/api/edge/dns-flow` | GET | DNS resolution explanation | Day 4 |
| `/api/edge/cdn-strategy` | GET | CDN caching strategy | Day 4 |
| `/actuator/health` | GET | Health check | All |
| `/actuator/circuitbreakers` | GET | CB state inspection | Day 2 |
| `/actuator/prometheus` | GET | Prometheus metrics | Day 3 |
| `/swagger-ui.html` | GET | Interactive API docs | Day 1 |
| `/v3/api-docs` | GET | OpenAPI spec (JSON) | Day 1 |
| `/h2-console` | GET | Database browser | All |

### Order Service (Port 8082)

| Endpoint | Method | Description | Training Module |
|----------|--------|-------------|----------------|
| `/api/v1/orders` | POST | Create order (start Saga) | Day 3 |
| `/api/v1/orders/{id}` | GET | Get order + Saga status | Day 3 |
| `/api/v1/orders` | GET | List customer orders | Day 3 |
| `/swagger-ui.html` | GET | Interactive API docs | Day 3 |

### BFF Service (Port 8083)

| Endpoint | Method | Description | Training Module |
|----------|--------|-------------|----------------|
| `/payment-summary/dashboard` | GET | Aggregated mobile dashboard | Day 3 |
| `/swagger-ui.html` | GET | Interactive API docs | Day 3 |

### API Gateway (Port 8080)

All client traffic should go through the gateway. The gateway routes to
the appropriate service based on path.

| Path | Routes To | Notes |
|------|-----------|-------|
| `/api/v1/payments/**` | payment-service | Requires X-API-Key header |
| `/api/v2/payments/**` | payment-service | Requires X-API-Key header |
| `/api/v1/orders/**` | order-service | Requires X-API-Key header |
| `/bff/**` | bff-service | Strips /bff prefix |
| `/actuator/gateway/routes` | gateway-service | Route inspection |

---

## Training Modules

### Day 1 - API Design and Microservice Structure

#### Module 1.1 - Payments API Design
```
Concepts: REST resource modeling, URL versioning, pagination tradeoffs
Demo file: PaymentControllerV1.java, PaymentControllerV2.java
Key demo:
  - Offset pagination: GET /api/v1/payments?page=0&size=10
  - Cursor pagination: GET /api/v2/payments?size=10&cursor=BASE64
  - Versioning:        V1 hides pspReference, V2 exposes it
```

#### Module 1.2 - OpenAPI Contract Design
```
Concepts: Contract-first vs code-first, error models, examples
Demo file: OpenApiConfig.java, all @Operation annotations
Key demo:
  - http://localhost:8081/swagger-ui.html
  - http://localhost:8081/v3/api-docs
```

#### Module 1.3 - Microservice Structure
```
Concepts: Multi-module builds, shared models, cyclic dependency prevention
Demo files: pom.xml (parent), payment-common/pom.xml
Key demo:
  - mvn clean install -DskipTests (watch build order)
  - payment-common builds first (no internal dependencies)
```

#### Module 1.4 - Retry and Idempotency
```
Concepts: Idempotency keys, exponential backoff, duplicate suppression
Demo files: IdempotencyService.java, PspClient.java, ResilienceConfig.java
Key demo:
  - Send same request twice with same X-Idempotency-Key
  - Amount $10-$49.99 triggers 30% transient failure (watch retry in logs)
```

### Day 2 - Resiliency and Gateway

#### Module 2.1 - Circuit Breaker
```
Concepts: CLOSED/OPEN/HALF-OPEN states, thresholds, fallback, bulkhead
Demo files: PspClient.java, ResilienceConfig.java
Amount triggers:
  < $10:      Always succeeds    (happy path)
  $10-$49.99: 30% failure        (tests retry)
  $50-$99.99: Always fails       (business error - not retriable)
  >= $100:    3.5s slow response (tests slow-call threshold)
Key demo:
  - Watch CB state: http://localhost:8081/actuator/circuitbreakers
```

#### Module 2.2 - Rate Limiting
```
Concepts: Token bucket, burst handling, per-client limits, DDoS awareness
Demo file: RateLimitFilter.java
Key demo:
  - Send 65 requests rapidly, watch 200 -> 429
  - Check headers: X-RateLimit-Limit, X-RateLimit-Remaining, Retry-After
```

#### Module 2.3 - Caching
```
Concepts: Redis TTL, cache eviction, cache consistency, HTTP vs Spring Cache
Demo files: CacheConfig.java, PaymentService.java (@Cacheable, @CacheEvict)
Key demo:
  - GET payment twice, 2nd call has no "[CACHE MISS]" log
  - Open Redis Commander: http://localhost:8091
  - Cancel payment, watch key evicted from Redis
```

#### Module 2.4 - Gateway and Service Discovery
```
Concepts: API Gateway routing, Eureka registration, blue-green, load balancing
Demo files: GatewayConfig.java, application.yml (gateway-service)
Key demo:
  - Open Eureka: http://localhost:8761
  - All requests via http://localhost:8080 (gateway)
  - Start 2nd payment-service instance: SERVER_PORT=8082 mvn spring-boot:run
  - Watch Eureka show 2 instances, gateway load-balances
```

### Day 3 - Consistency and Observability

#### Module 3.1 - Distributed Transactions
```
Concepts: 2PC problems, Saga pattern, atomicity vs availability
Demo files: PaymentService.java (event publishing), PaymentEventConsumer.java
Key demo:
  1. POST /api/v1/orders (get orderId)
  2. POST /api/v1/payments (amount $9.99 - happy path)
  3. Watch Kafka UI: http://localhost:8090 -> topic: payment-events
  4. GET /api/v1/orders/{id} -> status: CONFIRMED
```

#### Module 3.2 - Saga Styles
```
Concepts: Choreography vs Orchestration, compensation flows, timeout handling
Demo files: PaymentEventConsumer.java, OrderService.java (@Scheduled)
Key demo - compensation:
  1. POST /api/v1/orders with amount $75 (will fail)
  2. POST /api/v1/payments with amount $75 (PSP rejects)
  3. Watch order status -> CANCELLED (compensation executed)
```

#### Module 3.3 - Distributed Tracing
```
Concepts: Trace ID propagation, spans, golden signals, correlation IDs
Demo files: TraceFilter.java, ObservabilityConfig.java, PaymentMetrics.java
Key demo:
  - Make a payment, copy X-Trace-ID from response header
  - Open Zipkin: http://localhost:9411
  - Search by trace ID, see full journey across services
  - Open Grafana: http://localhost:3000 (admin/admin)
```

#### Module 3.4 - Design Patterns
```
Concepts: BFF, API Gateway, Strangler Fig, ACL, CQRS, Event Sourcing, Saga
Demo file: PatternsController.java
Key demo:
  - GET http://localhost:8081/api/patterns/overview
  - GET http://localhost:8083/payment-summary/dashboard?customerId=CUST-001
```

### Day 4 - Edge and Security

#### Module 4.1 - DNS and Traffic
```
Concepts: DNS resolution, CNAME, geo-routing, TTL, CDN edge
Demo file: EdgeSimulationController.java
Key demo:
  - GET http://localhost:8081/api/edge/traffic-flow
  - GET http://localhost:8081/api/edge/dns-flow
  - Add to hosts file: 127.0.0.1 api.payments.local
  - curl -H "X-API-Key: demo-key" http://api.payments.local:8080/api/v1/payments
```

#### Module 4.2 - Load Balancer
```
Concepts: L4 vs L7, TLS termination, health checks, sticky sessions
Demo: Start 2 payment-service instances, watch Eureka, gateway load-balances
Key demo:
  - Kill one instance, requests automatically failover within 30 seconds
```

#### Module 4.3 - WAF and DDoS
```
Concepts: OWASP Top 10, WAF rules, IP blocking, bot detection, rate limiting
Demo file: EdgeSimulationController.java (waf-check endpoint)
Key demo:
  POST /api/edge/waf-check with {"customerId": "1 OR 1=1; DROP TABLE payments;"}
  -> 403 BLOCKED: SQL_INJECTION_DETECTED
```

#### Module 4.4 - CDN and Static Content
```
Concepts: Static vs dynamic caching, Cache-Control headers, CDN offloading
Demo file: infra/nginx/nginx.conf
Key demo:
  - curl -I http://localhost:8084/ui/index.html
    -> Cache-Control: public, max-age=86400
  - curl -I http://localhost:8084/api/v1/payments
    -> Cache-Control: no-store (API never cached)
```

---

## Demo URLs

### Application Services

| Service | Direct URL | Via Gateway |
|---------|-----------|-------------|
| Payment API Swagger | http://localhost:8081/swagger-ui.html | http://localhost:8080/api/v1/payments |
| Order API Swagger | http://localhost:8082/swagger-ui.html | http://localhost:8080/api/v1/orders |
| BFF API Swagger | http://localhost:8083/swagger-ui.html | http://localhost:8080/bff/payment-summary/dashboard |
| Eureka Dashboard | http://localhost:8761 | - |

### Infrastructure Tools

| Tool | URL | Credentials | Training Use |
|------|-----|-------------|-------------|
| Zipkin | http://localhost:9411 | None | Day 3 - Trace search |
| Prometheus | http://localhost:9090 | None | Day 3 - PromQL queries |
| Grafana | http://localhost:3000 | admin / admin | Day 3 - Golden signals dashboard |
| Kafka UI | http://localhost:8090 | None | Day 3 - Event stream browser |
| Redis Commander | http://localhost:8091 | None | Day 2 - Cache inspection |
| CDN Demo | http://localhost:8084/ui/index.html | None | Day 4 - Cache headers |

### Actuator Endpoints

| Endpoint | Purpose | Training Use |
|----------|---------|-------------|
| http://localhost:8081/actuator/health | Service health | All days |
| http://localhost:8081/actuator/circuitbreakers | CB state | Day 2 |
| http://localhost:8081/actuator/metrics | All metrics | Day 3 |
| http://localhost:8081/actuator/prometheus | Prometheus format | Day 3 |
| http://localhost:8081/h2-console | SQL query browser | Day 1 |
| http://localhost:8080/actuator/gateway/routes | Gateway routes | Day 2 |

---

## API Reference

### Create a Payment

```bash
curl -X POST http://localhost:8081/api/v1/payments \
  -H "Content-Type: application/json" \
  -H "X-Idempotency-Key: unique-key-001" \
  -d '{
    "orderId":        "ORDER-001",
    "customerId":     "CUST-001",
    "amount":         9.99,
    "currency":       "USD",
    "paymentMethod":  "CARD",
    "cardNumber":     "4111111111111111",
    "idempotencyKey": "unique-key-001"
  }'
```

### Amount Ranges for Training Demos

| Amount | PSP Behaviour | Demonstrates |
|--------|--------------|-------------|
| < $10 | Always succeeds | Happy path, caching |
| $10 - $49.99 | 30% transient failure | Retry + exponential backoff |
| $50 - $99.99 | Always declined | Business error (not retriable) |
| >= $100 | 3.5 second delay | Circuit breaker slow-call threshold |

### Get Payment (with caching)

```bash
# First call - cache MISS (check logs for [CACHE MISS])
curl http://localhost:8081/api/v2/payments/{paymentId}

# Second call - cache HIT (no [CACHE MISS] log, faster response)
curl http://localhost:8081/api/v2/payments/{paymentId}
```

### Offset Pagination (v1)

```bash
# Page 0, 10 items
curl "http://localhost:8081/api/v1/payments?customerId=CUST-001&page=0&size=10"

# Page 1, filtered by status
curl "http://localhost:8081/api/v1/payments?customerId=CUST-001&page=1&size=10&status=COMPLETED"
```

### Cursor Pagination (v2)

```bash
# First page
curl "http://localhost:8081/api/v2/payments?customerId=CUST-001&size=10"

# Next page (use nextCursor from response)
curl "http://localhost:8081/api/v2/payments?customerId=CUST-001&size=10&cursor=eyJpZCI6Ii4uLiJ9"
```

### Saga Demo (Order + Payment)

```bash
# Step 1: Create order
curl -X POST http://localhost:8082/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{"customerId":"CUST-001","amount":9.99,"currency":"USD","description":"Demo Order"}'

# Step 2: Create payment (use orderId from step 1)
curl -X POST http://localhost:8081/api/v1/payments \
  -H "Content-Type: application/json" \
  -H "X-Idempotency-Key: saga-demo-001" \
  -d '{"orderId":"ORDER-ID-HERE","customerId":"CUST-001","amount":9.99,"currency":"USD","paymentMethod":"CARD","cardNumber":"4111111111111111","idempotencyKey":"saga-demo-001"}'

# Step 3: Check order status (should be CONFIRMED then COMPLETED)
curl http://localhost:8082/api/v1/orders/{orderId}
```

### WAF Demo

```bash
# Clean request - ALLOWED (200)
curl -X POST http://localhost:8081/api/edge/waf-check \
  -H "Content-Type: application/json" \
  -d '{"customerId":"CUST-001"}'

# SQL Injection - BLOCKED (403)
curl -X POST http://localhost:8081/api/edge/waf-check \
  -H "Content-Type: application/json" \
  -d '{"customerId":"1 OR 1=1; DROP TABLE payments;--"}'

# XSS - BLOCKED (403)
curl -X POST http://localhost:8081/api/edge/waf-check \
  -H "Content-Type: application/json" \
  -d '{"description":"<script>alert(\"xss\")</script>"}'

# Blocked IP - BLOCKED (403)
curl -X POST http://localhost:8081/api/edge/waf-check \
  -H "Content-Type: application/json" \
  -H "X-Forwarded-For: 10.0.0.1" \
  -d '{"customerId":"CUST-001"}'
```

---

## Running the Demo

### Pre-Demo Checklist (run validate-demo.ps1)

```powershell
# Full validation
.\validate-demo.ps1

# Quick re-check (already built and infra running)
.\validate-demo.ps1 -SkipBuild -SkipInfra

# Auto-fix missing directories and stub files
.\validate-demo.ps1 -FixIssues -SkipBuild -SkipInfra
```

### Validate Script Flags

| Flag | Description |
|------|-------------|
| `-SkipBuild` | Skip Maven build, just check JARs exist |
| `-SkipInfra` | Skip Docker startup, just check ports |
| `-SkipTests` | Skip unit tests during Maven build |
| `-StartServices` | Auto-start application services via Maven |
| `-FixIssues` | Auto-create missing directories and stub files |
| `-VerboseOutput` | Show pass/fail for every individual file check |

### Daily Startup Sequence

```powershell
# Morning startup (after first time setup is done)
docker compose up -d redis zookeeper kafka zipkin prometheus grafana kafka-ui redis-commander nginx-cdn
Start-Sleep -Seconds 60
.\validate-demo.ps1 -SkipBuild -SkipInfra -StartServices
Start-Process "http://localhost:8084/ui/index.html"
```

### Stopping Everything

```powershell
# Stop Docker infrastructure
docker compose down

# Stop Maven services (close their terminal windows)
# Or find and kill Java processes
Get-Process java | Stop-Process -Force
```

---

## Troubleshooting

### Maven Build Errors

#### `Non-parseable POM: entity reference names can not start with character`
The `&` character in `<name>` tags must be `&amp;` in XML.

```powershell
# Auto-fix all POM files
Get-ChildItem -Recurse -Filter "pom.xml" | Where-Object { $_.FullName -notmatch "\\target\\" } | ForEach-Object {
    $c = Get-Content $_.FullName -Raw
    $f = $c -replace '&(?!amp;|apos;|lt;|gt;|quot;|#)', '&amp;'
    [System.IO.File]::WriteAllText($_.FullName, $f, [System.Text.UTF8Encoding]::new($false))
}
```

#### `Could not resolve dependencies`
```powershell
# Clear Maven local repository cache
Remove-Item -Recurse -Force "$env:USERPROFILE\.m2\repository\com\training"
mvn clean install -DskipTests
```

#### Build fails on payment-service but common succeeds
```powershell
# Build common first, then the failing service
mvn clean install -DskipTests -pl payment-common
mvn clean install -DskipTests -pl payment-service -am
```

### Docker Issues

#### Port already in use
```powershell
# Find what is using the port (e.g., 8081)
netstat -ano | findstr ":8081"
# Kill the process (replace PID)
Stop-Process -Id PID -Force
```

#### Kafka not starting
```powershell
# Check Zookeeper is healthy first
docker exec payments-zookeeper bash -c "echo ruok | nc localhost 2181"
# Expected: imok

# Restart Kafka only
docker compose restart kafka

# Check Kafka logs
docker compose logs kafka --tail 50
```

#### Redis not responding
```powershell
docker exec payments-redis redis-cli ping    # Expected: PONG
docker compose restart redis
```

#### NGINX CDN health check failing
```powershell
# Test the health endpoint directly
curl http://localhost:8084/health
# Expected: {"status":"UP","component":"nginx-cdn"}

# Check NGINX logs
docker compose logs nginx-cdn --tail 20

# Restart NGINX
docker compose restart nginx-cdn
```

### Application Service Issues

#### Service not registering in Eureka
```powershell
# Check discovery service is running first
curl http://localhost:8761/actuator/health

# Check the service application.yml Eureka URL matches
# eureka.client.service-url.defaultZone: http://eureka:eureka-secret@localhost:8761/eureka/
```

#### Circuit breaker not opening
Reduce thresholds in `payment-service/src/main/resources/application.yml`:
```yaml
resilience4j:
  circuitbreaker:
    instances:
      psp-circuit-breaker:
        sliding-window-size: 5        # Was 10
        failure-rate-threshold: 40    # Was 50
        wait-duration-in-open-state: 10s
```
Then use amounts `$50-$99.99` to trigger failures.

#### H2 console login fails
- URL: `jdbc:h2:mem:paymentsdb`
- Username: `sa`
- Password: *(leave blank)*

---

## Training Scenarios

### Scenario 1: Double Charge Prevention

> "Show me how we prevent a customer from being charged twice when the client retries after a timeout."

```bash
# Both requests use the SAME idempotency key
curl -X POST http://localhost:8081/api/v1/payments -H "X-Idempotency-Key: KEY-001" -d '...'
curl -X POST http://localhost:8081/api/v1/payments -H "X-Idempotency-Key: KEY-001" -d '...'
# Both return the SAME paymentId - only charged once!
```

### Scenario 2: PSP Outage Handling

> "What happens when our payment processor goes down?"

```bash
# Send payments with amount >= $100 (3.5s slow calls)
# Watch CB state: CLOSED -> OPEN
curl http://localhost:8081/actuator/circuitbreakers
# When OPEN: new requests get immediate fallback (no waiting!)
# After 10s: CB enters HALF-OPEN, tests with small traffic
```

### Scenario 3: Full Saga Trace

> "Show me a complete payment flow traced across all services."

```bash
# Create order + payment, then find the trace in Zipkin
curl -X POST http://localhost:8082/api/v1/orders -d '...'
curl -X POST http://localhost:8081/api/v1/payments -d '...'
# Copy X-Trace-ID from response header
# Open http://localhost:9411 -> search by trace ID
# See: gateway span -> payment-service span -> PSP span
```

### Scenario 4: Cache Performance

> "How much faster is cached vs database reads?"

```bash
# Measure first call (DB)
Measure-Command { Invoke-WebRequest "http://localhost:8081/api/v2/payments/{id}" }
# Typical: 150-300ms

# Measure second call (Redis cache)
Measure-Command { Invoke-WebRequest "http://localhost:8081/api/v2/payments/{id}" }
# Typical: 5-20ms (10-30x faster)
```

### Scenario 5: Security at the Edge

> "How does the WAF protect our payment APIs?"

```bash
curl -X POST http://localhost:8081/api/edge/waf-check -d '{"sql":"1 OR DROP TABLE"}'
# 403 - SQL_INJECTION_DETECTED

curl -X POST http://localhost:8081/api/edge/waf-check -d '{"xss":"<script>alert(1)</script>"}'
# 403 - XSS_DETECTED

curl -X POST http://localhost:8081/api/edge/waf-check -d '{"ok":"safe data"}'
# 200 - ALLOWED
```

---

## Key Design Decisions

### Why URL Path Versioning?
`/api/v1/payments` vs `/api/v2/payments` — most visible, works with all clients,
easy to route at gateway level. Tradeoff: URL is "dirtier" than header versioning.

### Why Cursor Pagination in v2?
Offset pagination has page drift when new payments are inserted between pages.
Cursor pagination anchors to the last-seen record ID, giving stable results.
Also avoids expensive `COUNT(*)` queries on large tables.

### Why Choreography over Orchestration for Saga?
Loose coupling — payment-service and order-service do not need to know about
each other directly. Each service only knows about the events it cares about.
Tradeoff: harder to visualize the full flow (use Zipkin + Kafka UI for this).

### Why Redis for Both Cache and Idempotency?
Single infrastructure component serves two purposes. Idempotency keys
have 24h TTL, cache entries have 2-10 minute TTL. Both benefit from
Redis's atomic operations (SETNX for idempotency locks).

### Why H2 for Database?
Zero setup for training. Real deployment uses PostgreSQL. The
`PaymentRepository` uses standard Spring Data JPA — swapping to
PostgreSQL requires only a dependency and config change.

---

## License

MIT License — Free for training and educational use.

---

## Support

For training session support, refer to `playbook.md` for the complete
trainer demo walkthrough including all curl commands, expected outputs,
and talking points for each module.
