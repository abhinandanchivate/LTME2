// Labs 1, 4, 7, 8, 10: App config — Standalone API, interceptors, NgRx
import { ApplicationConfig } from '@angular/core';
import {
  provideRouter,
  withComponentInputBinding,
  withEnabledBlockingInitialNavigation,
} from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { provideStoreDevtools } from '@ngrx/store-devtools';

import { routes } from './app.routes';
import { jwtInterceptor } from './core/interceptors/jwt.interceptor';
import { errorInterceptor } from './core/interceptors/error.interceptor';
import { mockPaymentInterceptor } from './core/interceptors/mock-payment.interceptor';
import { paymentReducer } from './state/payments/payment.reducer';
import { PaymentEffects } from './state/payments/payment.effects';
import { environment } from '../environments/environment';

export const appConfig: ApplicationConfig = {
  providers: [
    // Lab 1: Router with standalone component binding
    provideRouter(
      routes,
      withComponentInputBinding(),
      withEnabledBlockingInitialNavigation()
    ),

    // Lab 4: HTTP + functional interceptors (order matters: mock → jwt → error)
    provideHttpClient(
      withInterceptors([
        mockPaymentInterceptor,  // Lab 10: intercepts before real HTTP (useMocks=true)
        jwtInterceptor,          // Lab 4: attaches Bearer token + refresh
        errorInterceptor,        // Lab 4: maps error codes to user messages
      ])
    ),

    provideAnimations(),

    // Lab 7: NgRx Store with payment feature reducer
    provideStore({ payments: paymentReducer }),

    // Lab 8: NgRx Effects for API calls + WebSocket bridge
    provideEffects(PaymentEffects),

    // Lab 7: Redux DevTools (disabled in production)
    provideStoreDevtools({
      maxAge: 50,
      logOnly: environment.production,
      name: 'SecurePayment Gateway',
    }),
  ],
};
