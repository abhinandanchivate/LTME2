// Lab 10: AppComponent — router shell + dev control panel
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { DevControlPanelComponent } from './shared/dev-control-panel/dev-control-panel.component';
import { environment } from '../environments/environment';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, DevControlPanelComponent],
  template: `
    <router-outlet></router-outlet>
    <!-- Lab 10: Dev panel only in non-production builds -->
    <app-dev-control-panel *ngIf="!isProduction"></app-dev-control-panel>
  `,
})
export class AppComponent {
  readonly isProduction = environment.production;
}
