// Lab 7: NgRx Reducer — EntityAdapter<Payment> sorted newest-first
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { createReducer, on } from '@ngrx/store';
import { Payment } from '../../core/models/payment.model';
import { PaymentApiActions } from './payment.actions';

export interface PaymentState extends EntityState<Payment> {
  isLoading: boolean;
  error: string | null;
}

const adapter: EntityAdapter<Payment> = createEntityAdapter<Payment>({
  selectId: p => p.id,
  sortComparer: (a, b) => b.initiatedAt.localeCompare(a.initiatedAt), // Newest first
});

const initialState: PaymentState = adapter.getInitialState({
  isLoading: false,
  error: null,
});

export const paymentReducer = createReducer(
  initialState,

  on(PaymentApiActions.loadPayments, state => ({
    ...state,
    isLoading: true,
    error: null,
  })),

  on(PaymentApiActions.loadPaymentsSuccess, (state, { payments }) =>
    adapter.setAll(payments, { ...state, isLoading: false })
  ),

  on(PaymentApiActions.loadPaymentsFailure, (state, { error }) => ({
    ...state,
    isLoading: false,
    error,
  })),

  on(PaymentApiActions.initiatePaymentSuccess, (state, { payment }) =>
    adapter.addOne(payment, state)
  ),

  on(PaymentApiActions.paymentStatusUpdated, (state, { paymentId, status, updatedAt }) =>
    adapter.updateOne({ id: paymentId, changes: { status, settledAt: updatedAt } }, state)
  )
);

export const { selectAll, selectEntities } = adapter.getSelectors();
