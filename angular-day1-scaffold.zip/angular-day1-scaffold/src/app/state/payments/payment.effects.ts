// Lab 8: NgRx Effects — API calls & WebSocket bridge
import { Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { switchMap, map, catchError, tap, mergeMap } from 'rxjs/operators';
import { of, EMPTY } from 'rxjs';
import { PaymentService } from '../../core/services/payment.service';
import { PaymentStreamService } from '../../core/services/payment-stream.service';
import { PaymentApiActions } from './payment.actions';

@Injectable()
export class PaymentEffects {
  private actions$      = inject(Actions);
  private paymentService = inject(PaymentService);
  private streamService  = inject(PaymentStreamService);
  private router         = inject(Router);

  /** switchMap: cancellable read — newer loadPayments cancels in-flight GET */
  loadPayments$ = createEffect(() =>
    this.actions$.pipe(
      ofType(PaymentApiActions.loadPayments),
      switchMap(() =>
        this.paymentService.getPayments().pipe(
          map(payments => PaymentApiActions.loadPaymentsSuccess({ payments })),
          catchError(error =>
            of(PaymentApiActions.loadPaymentsFailure({
              error: (error as { userMessage?: string }).userMessage ?? error.message ?? 'Failed to load payments',
            }))
          )
        )
      )
    )
  );

  /** mergeMap: non-cancellable write — each initiate runs to completion */
  initiatePayment$ = createEffect(() =>
    this.actions$.pipe(
      ofType(PaymentApiActions.initiatePayment),
      mergeMap(({ request }) =>
        this.paymentService.initiatePayment(request).pipe(
          map(payment => PaymentApiActions.initiatePaymentSuccess({ payment })),
          catchError(error =>
            of(PaymentApiActions.initiatePaymentFailure({
              error: (error as { userMessage?: string }).userMessage ?? error.message,
            }))
          )
        )
      )
    )
  );

  /** Side-effect only: navigate after successful payment initiation */
  navigateAfterSuccess$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(PaymentApiActions.initiatePaymentSuccess),
        tap(() => this.router.navigate(['/payments']))
      ),
    { dispatch: false }
  );

  /** Lifetime effect: bridge WebSocket → store for every status update message */
  streamPaymentUpdates$ = createEffect(() =>
    this.streamService.statusUpdates$.pipe(
      map(update =>
        PaymentApiActions.paymentStatusUpdated({
          paymentId: update.paymentId,
          status:    update.status,
          updatedAt: update.updatedAt,
        })
      ),
      catchError(() => EMPTY)
    )
  );
}
