// Lab 7: Selectors — createFeatureSelector + createSelector
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { PaymentState, selectAll } from './payment.reducer';
import { Payment } from '../../core/models/payment.model';

const selectFeature = createFeatureSelector<PaymentState>('payments');

export const selectAllPayments     = createSelector(selectFeature, selectAll);
export const selectPaymentsLoading = createSelector(selectFeature, s => s.isLoading);
export const selectPaymentsError   = createSelector(selectFeature, s => s.error);

export const selectPendingPayments = createSelector(
  selectAllPayments,
  payments => payments.filter(p => p.status === 'PENDING')
);

/** Aggregates: total, totalAmountInPaise, byStatus, byChannel — single pass */
export const selectPaymentSummary = createSelector(
  selectAllPayments,
  (payments: Payment[]) => {
    const result = {
      total: payments.length,
      totalAmountInPaise: 0,
      byStatus: {} as Record<Payment['status'], number>,
      byChannel: {} as Record<Payment['channel'], number>,
    };
    for (const p of payments) {
      result.totalAmountInPaise += p.amountInPaise;
      result.byStatus[p.status]   = (result.byStatus[p.status]   ?? 0) + 1;
      result.byChannel[p.channel] = (result.byChannel[p.channel] ?? 0) + 1;
    }
    return result;
  }
);

/** Parameterised selector factory: filter + sort */
export const selectFilteredPayments = (
  statusFilter: Payment['status'] | 'ALL',
  sortField: keyof Payment = 'initiatedAt',
  sortDir: 'asc' | 'desc' = 'desc'
) =>
  createSelector(selectAllPayments, payments => {
    const filtered =
      statusFilter === 'ALL'
        ? payments
        : payments.filter(p => p.status === statusFilter);
    return [...filtered].sort((a, b) => {
      const av = String(a[sortField] ?? '');
      const bv = String(b[sortField] ?? '');
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
  });
