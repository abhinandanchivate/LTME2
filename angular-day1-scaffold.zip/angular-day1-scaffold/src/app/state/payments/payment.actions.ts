// Lab 7: NgRx Actions — createActionGroup for type-safe action creators
import { createActionGroup, emptyProps, props } from '@ngrx/store';
import { Payment } from '../../core/models/payment.model';
import { InitiatePaymentRequest } from '../../core/services/payment.service';

export const PaymentApiActions = createActionGroup({
  source: 'Payment API',
  events: {
    'Load Payments':           emptyProps(),
    'Load Payments Success':   props<{ payments: Payment[] }>(),
    'Load Payments Failure':   props<{ error: string }>(),
    'Initiate Payment':        props<{ request: InitiatePaymentRequest }>(),
    'Initiate Payment Success': props<{ payment: Payment }>(),
    'Initiate Payment Failure': props<{ error: string }>(),
    'Payment Status Updated':  props<{
      paymentId: string;
      status: Payment['status'];
      updatedAt: string;
    }>(),
  },
});
