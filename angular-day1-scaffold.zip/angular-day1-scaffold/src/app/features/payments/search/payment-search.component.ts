// Lab 6: Payment search with debounceTime(300) + switchMap + catchError
import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule, AsyncPipe, DecimalPipe } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import {
  Subject, Observable, debounceTime, distinctUntilChanged,
  switchMap, catchError, startWith, map, tap, takeUntil,
} from 'rxjs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatListModule } from '@angular/material/list';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { PaymentService } from '../../../core/services/payment.service';
import { Payment } from '../../../core/models/payment.model';

@Component({
  selector: 'app-payment-search',
  standalone: true,
  imports: [
    CommonModule, AsyncPipe, DecimalPipe, ReactiveFormsModule,
    MatFormFieldModule, MatInputModule, MatProgressSpinnerModule,
    MatListModule, MatChipsModule, MatIconModule,
  ],
  styles: [`
    .search-wrap { padding: 16px; max-width: 640px; }
    .spinner-row { display: flex; justify-content: center; padding: 24px; }
    .empty-msg { text-align: center; color: #9e9e9e; padding: 24px; font-size: 14px; }
    .result-item { border-bottom: 1px solid #f0f0f0; }
    .status-chip { font-size: 11px; font-weight: 700; }
    .amount { color: #1a237e; font-weight: 600; }
  `],
  template: `
    <div class="search-wrap">
      <mat-form-field style="width:100%" appearance="outline">
        <mat-label>Search Payments</mat-label>
        <mat-icon matPrefix>search</mat-icon>
        <input matInput [formControl]="searchControl"
               placeholder="Reference number, account, or channel (min 3 chars)">
        <mat-hint *ngIf="((currentTerm$ | async)?.length ?? 0) < 3">
          Type at least 3 characters to search
        </mat-hint>
      </mat-form-field>

      <div *ngIf="isSearching" class="spinner-row">
        <mat-spinner diameter="32"></mat-spinner>
      </div>

      <ng-container *ngIf="!isSearching">
        <mat-list *ngIf="(searchResults$ | async)?.length; else noResults">
          <mat-list-item class="result-item"
            *ngFor="let p of (searchResults$ | async); trackBy: trackById">
            <mat-icon matListItemIcon>receipt_long</mat-icon>
            <span matListItemTitle>{{ p.referenceNumber }}</span>
            <span matListItemLine class="amount">
              ₹{{ p.amountInPaise / 100 | number:'1.2-2' }} · {{ p.channel }}
            </span>
            <span matListItemMeta>
              <mat-chip class="status-chip"
                [style.background]="statusColor(p.status)"
                [style.color]="'white'">
                {{ p.status }}
              </mat-chip>
            </span>
          </mat-list-item>
        </mat-list>

        <ng-template #noResults>
          <p *ngIf="((currentTerm$ | async)?.length ?? 0) >= 3" class="empty-msg">
            <mat-icon style="vertical-align:middle;margin-right:4px">search_off</mat-icon>
            No payments found for '{{ currentTerm$ | async }}'
          </p>
        </ng-template>
      </ng-container>
    </div>
  `,
})
export class PaymentSearchComponent implements OnInit, OnDestroy {
  private paymentService = inject(PaymentService);
  private destroy$ = new Subject<void>();

  searchControl = new FormControl('');
  isSearching = false;
  searchResults$!: Observable<Payment[]>;
  currentTerm$!: Observable<string>;

  ngOnInit(): void {
    this.currentTerm$ = this.searchControl.valueChanges.pipe(
      startWith(''),
      map(v => v?.trim() ?? ''),
      takeUntil(this.destroy$)
    );

    this.searchResults$ = this.searchControl.valueChanges.pipe(
      debounceTime(300),          // Wait for typing to pause
      distinctUntilChanged(),     // Skip if value hasn't changed
      map(v => v?.trim() ?? ''),
      switchMap(term => {         // Cancel previous request on new input
        if (term.length < 3) {
          this.isSearching = false;
          return startWith([] as Payment[]);
        }
        this.isSearching = true;
        return this.paymentService.searchPayments(term).pipe(
          tap(() => (this.isSearching = false)),
          catchError(err => {
            console.error('Search failed:', err);
            this.isSearching = false;
            return [] as Payment[];  // Emit empty — outer stream stays alive
          })
        );
      }),
      startWith([] as Payment[]),
      takeUntil(this.destroy$)
    );
  }

  trackById(_: number, payment: Payment): string { return payment.id; }

  statusColor(status: Payment['status']): string {
    const map: Record<Payment['status'], string> = {
      SUCCESS: '#2e7d32', FAILED: '#c62828', PENDING: '#f57f17',
      PROCESSING: '#1565c0', REVERSED: '#6a1b9a',
    };
    return map[status] ?? '#666';
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
