// Labs 5, 9: Dashboard wired to NgRx Store — thin component, no HTTP dependency
import { Component, OnInit, inject } from '@angular/core';
import { CommonModule, AsyncPipe, DecimalPipe, DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { PaymentApiActions } from '../../../state/payments/payment.actions';
import {
  selectAllPayments,
  selectPaymentsLoading,
  selectPaymentsError,
  selectPaymentSummary,
} from '../../../state/payments/payment.selectors';
import { Payment } from '../../../core/models/payment.model';
import { PaymentSearchComponent } from '../search/payment-search.component';

@Component({
  selector: 'app-payment-dashboard',
  standalone: true,
  imports: [
    CommonModule, AsyncPipe, DecimalPipe, DatePipe, RouterLink,
    MatTableModule, MatButtonModule, MatCardModule,
    MatProgressSpinnerModule, MatChipsModule, MatIconModule,
    MatTabsModule, PaymentSearchComponent,
  ],
  styles: [`
    .dashboard { padding: 24px; min-height: 100vh; background: #f5f6fa; }
    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .header h2 { margin: 0; color: #1a237e; font-size: 22px; }
    .kpi-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .kpi-card mat-card-content { padding: 16px !important; }
    .kpi-value { font-size: 28px; font-weight: 700; line-height: 1.2; }
    .kpi-label { font-size: 12px; color: #888; text-transform: uppercase; letter-spacing: 0.5px; margin-top: 4px; }
    .kpi-icon { float: right; font-size: 32px; opacity: 0.15; }
    .table-card { background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,0.08); }
    .row-failed     { background: #ffebee !important; }
    .row-success    { background: #e8f5e9 !important; }
    .row-processing { background: #e3f2fd !important; }
    .row-reversed   { background: #f3e5f5 !important; }
    .row-updated    { animation: highlight 2s ease-out; }
    @keyframes highlight { from { background: #fff9c4; } to {} }
    .spinner-center { display: flex; justify-content: center; padding: 64px; }
    .error-banner { background: #fce4ec; color: #c62828; padding: 12px 20px; border-radius: 6px; margin-bottom: 16px; }
    table { width: 100%; }
  `],
  template: `
    <div class="dashboard">
      <!-- Header -->
      <div class="header">
        <h2>🏦 Payment Dashboard</h2>
        <a mat-raised-button color="primary" routerLink="/payments/new">
          <mat-icon>add</mat-icon> New Payment
        </a>
      </div>

      <!-- Loading -->
      <div *ngIf="isLoading$ | async" class="spinner-center">
        <mat-spinner></mat-spinner>
      </div>

      <!-- Error -->
      <div *ngIf="error$ | async as error" class="error-banner">
        <mat-icon style="vertical-align:middle;margin-right:8px">error_outline</mat-icon>
        {{ error }}
      </div>

      <ng-container *ngIf="!(isLoading$ | async)">
        <!-- KPI Cards -->
        <div class="kpi-grid" *ngIf="summary$ | async as s">
          <mat-card class="kpi-card">
            <mat-card-content>
              <mat-icon class="kpi-icon">receipt_long</mat-icon>
              <div class="kpi-value">{{ s.total }}</div>
              <div class="kpi-label">Total Payments</div>
            </mat-card-content>
          </mat-card>
          <mat-card class="kpi-card">
            <mat-card-content>
              <mat-icon class="kpi-icon">currency_rupee</mat-icon>
              <div class="kpi-value">₹{{ s.totalAmountInPaise / 100 | number:'1.0-0' }}</div>
              <div class="kpi-label">Total Volume</div>
            </mat-card-content>
          </mat-card>
          <mat-card class="kpi-card">
            <mat-card-content>
              <mat-icon class="kpi-icon" style="color:#f57f17">pending</mat-icon>
              <div class="kpi-value" style="color:#f57f17">{{ s.byStatus?.['PENDING'] ?? 0 }}</div>
              <div class="kpi-label">Pending</div>
            </mat-card-content>
          </mat-card>
          <mat-card class="kpi-card">
            <mat-card-content>
              <mat-icon class="kpi-icon" style="color:#c62828">cancel</mat-icon>
              <div class="kpi-value" style="color:#c62828">{{ s.byStatus?.['FAILED'] ?? 0 }}</div>
              <div class="kpi-label">Failed</div>
            </mat-card-content>
          </mat-card>
        </div>

        <!-- Tabs: Table + Search -->
        <mat-tab-group>
          <mat-tab label="All Payments">
            <div class="table-card">
              <table mat-table [dataSource]="(payments$ | async) ?? []">
                <ng-container matColumnDef="referenceNumber">
                  <th mat-header-cell *matHeaderCellDef>Reference</th>
                  <td mat-cell *matCellDef="let p" style="font-family:monospace;font-size:12px">{{ p.referenceNumber }}</td>
                </ng-container>
                <ng-container matColumnDef="channel">
                  <th mat-header-cell *matHeaderCellDef>Channel</th>
                  <td mat-cell *matCellDef="let p">{{ p.channel }}</td>
                </ng-container>
                <ng-container matColumnDef="amount">
                  <th mat-header-cell *matHeaderCellDef>Amount (₹)</th>
                  <td mat-cell *matCellDef="let p" style="font-weight:600;color:#1a237e">
                    {{ p.amountInPaise / 100 | number:'1.2-2' }}
                  </td>
                </ng-container>
                <ng-container matColumnDef="status">
                  <th mat-header-cell *matHeaderCellDef>Status</th>
                  <td mat-cell *matCellDef="let p">
                    <mat-chip [style.background]="statusColor(p.status)" style="color:white;font-size:11px;font-weight:700">
                      {{ p.status }}
                    </mat-chip>
                  </td>
                </ng-container>
                <ng-container matColumnDef="initiatedAt">
                  <th mat-header-cell *matHeaderCellDef>Initiated</th>
                  <td mat-cell *matCellDef="let p" style="color:#888;font-size:12px">
                    {{ p.initiatedAt | date:'dd/MM/yyyy HH:mm' }}
                  </td>
                </ng-container>

                <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
                <tr mat-row *matRowDef="let row; columns: displayedColumns"
                    [class.row-failed]="row.status === 'FAILED'"
                    [class.row-success]="row.status === 'SUCCESS'"
                    [class.row-processing]="row.status === 'PROCESSING'"
                    [class.row-reversed]="row.status === 'REVERSED'">
                </tr>
              </table>

              <div *ngIf="(payments$ | async)?.length === 0" style="text-align:center;padding:40px;color:#999">
                No payments yet. <a routerLink="/payments/new">Initiate one.</a>
              </div>
            </div>
          </mat-tab>

          <mat-tab label="Search">
            <app-payment-search></app-payment-search>
          </mat-tab>
        </mat-tab-group>
      </ng-container>
    </div>
  `,
})
export class PaymentDashboardComponent implements OnInit {
  private store = inject(Store);

  // Lab 9: Inject Store only — no PaymentService, no manual subscriptions
  payments$  = this.store.select(selectAllPayments);
  isLoading$ = this.store.select(selectPaymentsLoading);
  error$     = this.store.select(selectPaymentsError);
  summary$   = this.store.select(selectPaymentSummary);

  displayedColumns = ['referenceNumber', 'channel', 'amount', 'status', 'initiatedAt'];

  ngOnInit(): void {
    // Lab 9: Dispatch action — Effect handles HTTP (Lab 8)
    this.store.dispatch(PaymentApiActions.loadPayments());
  }

  trackByPaymentId(_: number, payment: Payment): string { return payment.id; }

  statusColor(status: Payment['status']): string {
    const map: Record<Payment['status'], string> = {
      SUCCESS: '#2e7d32', FAILED: '#c62828', PENDING: '#f57f17',
      PROCESSING: '#1565c0', REVERSED: '#6a1b9a',
    };
    return map[status] ?? '#666';
  }
}
