// Lab 3: Payment form with dynamic channel-based validators
import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ReactiveFormsModule, FormBuilder, FormGroup, FormControl,
  Validators, AbstractControl, ValidationErrors,
} from '@angular/forms';
import { Router } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Store } from '@ngrx/store';
import { PaymentApiActions } from '../../../state/payments/payment.actions';
import { PaymentChannel } from '../../../core/models/payment.model';

// Pure validator functions — testable without component instantiation
function ifscValidator(control: AbstractControl): ValidationErrors | null {
  const ifscPattern = /^[A-Z]{4}0[A-Z0-9]{6}$/;
  if (!control.value) return null;
  return ifscPattern.test(control.value) ? null : { invalidIfsc: { value: control.value } };
}

function vpaValidator(control: AbstractControl): ValidationErrors | null {
  const vpaPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z]{3,}$/;
  if (!control.value) return null;
  return vpaPattern.test(control.value) ? null : { invalidVpa: { value: control.value } };
}

@Component({
  selector: 'app-payment-form',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatSnackBarModule, MatCardModule,
    MatIconModule, MatProgressSpinnerModule,
  ],
  styles: [`
    .form-page { min-height: 100vh; background: #f5f6fa; display: flex; align-items: flex-start; justify-content: center; padding: 40px 16px; }
    .form-card { width: 100%; max-width: 580px; }
    .field { width: 100%; margin-top: 12px; }
    .row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 12px; }
    .submit-btn { width: 100%; margin-top: 24px; height: 48px; font-size: 15px; font-weight: 600; }
    .channel-badge { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 12px; font-weight: 700; margin-left: 8px; }
    .badge-rtgs { background: #e3f2fd; color: #1565c0; }
    .badge-upi  { background: #f3e5f5; color: #7b1fa2; }
    .badge-neft { background: #e8f5e9; color: #2e7d32; }
    .badge-imps { background: #fff3e0; color: #e65100; }
    .section-title { font-size: 13px; font-weight: 600; color: #888; text-transform: uppercase; letter-spacing: 0.5px; margin: 16px 0 4px; }
  `],
  template: `
    <div class="form-page">
      <mat-card class="form-card">
        <mat-card-header>
          <mat-card-title>
            Initiate Payment
            <span class="channel-badge" [class]="'badge-' + f['channel'].value.toLowerCase()">
              {{ f['channel'].value }}
            </span>
          </mat-card-title>
          <mat-card-subtitle>All amounts in Indian Rupees (₹)</mat-card-subtitle>
        </mat-card-header>

        <mat-card-content>
          <form [formGroup]="paymentForm" (ngSubmit)="onSubmit()" novalidate>

            <!-- Channel selector -->
            <p class="section-title">Payment Channel</p>
            <mat-form-field class="field" appearance="outline">
              <mat-label>Channel</mat-label>
              <mat-select formControlName="channel">
                <mat-option *ngFor="let ch of channels" [value]="ch">{{ ch }}</mat-option>
              </mat-select>
            </mat-form-field>

            <!-- Amount -->
            <p class="section-title">Amount</p>
            <mat-form-field class="field" appearance="outline">
              <mat-label>Amount (₹)</mat-label>
              <span matTextPrefix>₹&nbsp;</span>
              <input matInput type="number" formControlName="amountInRupees" min="1">
              <mat-hint *ngIf="isRtgs">RTGS minimum: ₹2,00,000</mat-hint>
              <mat-error *ngIf="f['amountInRupees'].hasError('required')">Amount is required</mat-error>
              <mat-error *ngIf="f['amountInRupees'].hasError('min')">
                {{ isRtgs ? 'RTGS minimum is ₹2,00,000' : 'Amount must be greater than zero' }}
              </mat-error>
            </mat-form-field>

            <!-- UPI path -->
            <ng-container *ngIf="isUpi">
              <p class="section-title">UPI Details</p>
              <mat-form-field class="field" appearance="outline">
                <mat-label>UPI VPA</mat-label>
                <mat-icon matSuffix>account_balance_wallet</mat-icon>
                <input matInput formControlName="vpa" placeholder="yourname@upi">
                <mat-hint>e.g., name&#64;okaxis, mobile&#64;ybl</mat-hint>
                <mat-error *ngIf="f['vpa'].hasError('required')">VPA is required for UPI</mat-error>
                <mat-error *ngIf="f['vpa'].hasError('invalidVpa')">Enter a valid VPA (e.g., name&#64;okaxis)</mat-error>
              </mat-form-field>
            </ng-container>

            <!-- Non-UPI path -->
            <ng-container *ngIf="!isUpi">
              <p class="section-title">Beneficiary Details</p>
              <mat-form-field class="field" appearance="outline">
                <mat-label>Payee Account Number</mat-label>
                <mat-icon matSuffix>account_balance</mat-icon>
                <input matInput formControlName="payeeAccountNumber" inputmode="numeric">
                <mat-error *ngIf="f['payeeAccountNumber'].hasError('required')">Account number is required</mat-error>
                <mat-error *ngIf="f['payeeAccountNumber'].hasError('pattern')">Enter a valid 9–18 digit account number</mat-error>
              </mat-form-field>

              <mat-form-field class="field" appearance="outline">
                <mat-label>IFSC Code</mat-label>
                <input matInput formControlName="payeeIfscCode" maxlength="11" style="text-transform:uppercase">
                <mat-hint>e.g., HDFC0001234</mat-hint>
                <mat-error *ngIf="f['payeeIfscCode'].hasError('required')">IFSC code is required</mat-error>
                <mat-error *ngIf="f['payeeIfscCode'].hasError('invalidIfsc')">Invalid IFSC format (e.g., HDFC0001234)</mat-error>
              </mat-form-field>
            </ng-container>

            <!-- Remarks -->
            <p class="section-title">Remarks</p>
            <mat-form-field class="field" appearance="outline">
              <mat-label>Remarks (optional)</mat-label>
              <input matInput formControlName="remarks" maxlength="140">
              <mat-hint align="end">{{ f['remarks'].value.length }}/140</mat-hint>
            </mat-form-field>

            <button mat-raised-button color="primary" type="submit" class="submit-btn"
                    [disabled]="paymentForm.invalid || isSubmitting">
              <mat-spinner *ngIf="isSubmitting" diameter="20" style="display:inline-block;margin-right:8px"></mat-spinner>
              {{ isSubmitting ? 'Submitting...' : 'Submit Payment' }}
            </button>
          </form>
        </mat-card-content>
      </mat-card>
    </div>
  `,
})
export class PaymentFormComponent implements OnInit, OnDestroy {
  private fb          = inject(FormBuilder);
  private store       = inject(Store);
  private snackBar    = inject(MatSnackBar);
  private destroy$    = new Subject<void>();

  isSubmitting = false;
  readonly channels: PaymentChannel[] = ['NEFT', 'RTGS', 'IMPS', 'UPI'];

  paymentForm!: FormGroup<{
    channel:              FormControl<PaymentChannel>;
    payeeAccountNumber:   FormControl<string>;
    payeeIfscCode:        FormControl<string>;
    vpa:                  FormControl<string>;
    amountInRupees:       FormControl<number>;
    remarks:              FormControl<string>;
  }>;

  ngOnInit(): void {
    this.paymentForm = this.fb.nonNullable.group({
      channel:            this.fb.nonNullable.control<PaymentChannel>('NEFT'),
      payeeAccountNumber: this.fb.nonNullable.control('', [Validators.required, Validators.pattern(/^\d{9,18}$/)]),
      payeeIfscCode:      this.fb.nonNullable.control('', [Validators.required, ifscValidator]),
      vpa:                this.fb.nonNullable.control(''),
      amountInRupees:     this.fb.nonNullable.control(0, [Validators.required, Validators.min(1)]),
      remarks:            this.fb.nonNullable.control('', Validators.maxLength(140)),
    });

    this.paymentForm.controls.channel.valueChanges
      .pipe(takeUntil(this.destroy$))
      .subscribe(channel => this.applyChannelValidators(channel));
  }

  private applyChannelValidators(channel: PaymentChannel): void {
    const { amountInRupees: amt, payeeIfscCode: ifsc, vpa, payeeAccountNumber: acct } = this.paymentForm.controls;

    // Reset to base validators
    amt.setValidators([Validators.required, Validators.min(1)]);
    ifsc.setValidators([Validators.required, ifscValidator]);
    vpa.setValidators([]);
    acct.setValidators([Validators.required, Validators.pattern(/^\d{9,18}$/)]);

    if (channel === 'RTGS') {
      amt.setValidators([Validators.required, Validators.min(200000)]);
    } else if (channel === 'UPI') {
      acct.setValidators([]);
      ifsc.setValidators([]);
      vpa.setValidators([Validators.required, vpaValidator]);
    }

    // Must call updateValueAndValidity after setValidators
    [amt, ifsc, vpa, acct].forEach(c => c.updateValueAndValidity());
  }

  get f() { return this.paymentForm.controls; }
  get isUpi(): boolean  { return this.paymentForm.controls.channel.value === 'UPI'; }
  get isRtgs(): boolean { return this.paymentForm.controls.channel.value === 'RTGS'; }

  onSubmit(): void {
    if (this.paymentForm.invalid || this.isSubmitting) return;
    this.isSubmitting = true;
    const v = this.paymentForm.getRawValue();
    // Lab 3: Math.round — no float arithmetic for monetary conversion
    const amountInPaise = Math.round(v.amountInRupees * 100);

    this.store.dispatch(PaymentApiActions.initiatePayment({
      request: {
        channel:            v.channel,
        payeeAccountNumber: this.isUpi ? '' : v.payeeAccountNumber,
        payeeIfscCode:      this.isUpi ? '' : v.payeeIfscCode,
        vpa:                this.isUpi ? v.vpa : '',
        amountInPaise,
        remarks:            v.remarks,
      },
    }));

    // Navigation handled by NgRx Effect (Lab 8)
    this.isSubmitting = false;
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
