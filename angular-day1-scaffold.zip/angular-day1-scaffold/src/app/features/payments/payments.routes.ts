// Lab 1: Payments feature routes — lazy loaded
import { Routes } from '@angular/router';

export const PAYMENT_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./dashboard/payment-dashboard.component').then(c => c.PaymentDashboardComponent),
    title: 'Dashboard — SecurePayment',
  },
  {
    path: 'new',
    loadComponent: () =>
      import('./payment-form/payment-form.component').then(c => c.PaymentFormComponent),
    title: 'New Payment — SecurePayment',
  },
];
