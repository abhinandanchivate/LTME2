// Lab 2: Login with typed Reactive Forms, per-field validation, API error display
import { Component, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../../core/auth/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatProgressSpinnerModule,
    MatIconModule,
  ],
  styles: [`
    .login-page {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #1a237e 0%, #283593 50%, #4527a0 100%);
    }
    .login-card { width: 400px; padding: 8px; }
    .logo-row { display: flex; align-items: center; gap: 12px; margin-bottom: 4px; }
    .logo-icon { font-size: 40px; }
    .field { width: 100%; margin-top: 12px; }
    .submit-btn { width: 100%; margin-top: 20px; height: 44px; font-size: 15px; }
    .error-msg { color: #f44336; font-size: 13px; margin-top: 8px; padding: 8px 12px; background: #fce4ec; border-radius: 4px; }
    .demo-hint { margin-top: 20px; padding: 12px; background: #f5f5f5; border-radius: 6px; font-size: 12px; color: #666; }
    .demo-hint code { display: block; margin-top: 4px; color: #333; font-family: monospace; }
  `],
  template: `
    <div class="login-page">
      <mat-card class="login-card">
        <mat-card-header>
          <div class="logo-row">
            <span class="logo-icon">🏦</span>
            <div>
              <mat-card-title>SecurePayment Gateway</mat-card-title>
              <mat-card-subtitle>Sign in to continue</mat-card-subtitle>
            </div>
          </div>
        </mat-card-header>

        <mat-card-content>
          <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
            <mat-form-field class="field" appearance="outline">
              <mat-label>Email</mat-label>
              <input matInput type="email" formControlName="username" autocomplete="username">
              <mat-icon matSuffix>email</mat-icon>
              <mat-error *ngIf="loginForm.controls.username.hasError('required')">
                Email is required
              </mat-error>
              <mat-error *ngIf="loginForm.controls.username.hasError('email')">
                Enter a valid email address
              </mat-error>
            </mat-form-field>

            <mat-form-field class="field" appearance="outline">
              <mat-label>Password</mat-label>
              <input matInput [type]="showPassword ? 'text' : 'password'"
                     formControlName="password" autocomplete="current-password">
              <button mat-icon-button matSuffix type="button"
                      (click)="showPassword = !showPassword">
                <mat-icon>{{ showPassword ? 'visibility_off' : 'visibility' }}</mat-icon>
              </button>
              <mat-error *ngIf="loginForm.controls.password.hasError('required')">
                Password is required
              </mat-error>
              <mat-error *ngIf="loginForm.controls.password.hasError('minlength')">
                Password must be at least 8 characters
              </mat-error>
            </mat-form-field>

            <div *ngIf="apiError" class="error-msg">{{ apiError }}</div>

            <button mat-raised-button color="primary" type="submit" class="submit-btn"
                    [disabled]="loginForm.invalid || isSubmitting">
              <mat-spinner *ngIf="isSubmitting" diameter="20" style="display:inline-block;margin-right:8px"></mat-spinner>
              {{ isSubmitting ? 'Signing in...' : 'Sign In' }}
            </button>
          </form>

          <div class="demo-hint">
            <strong>Demo credentials:</strong>
            <code>ops@securepayment.in / Secure@123</code>
          </div>
        </mat-card-content>
      </mat-card>
    </div>
  `,
})
export class LoginComponent implements OnDestroy {
  private fb          = inject(FormBuilder);
  private authService = inject(AuthService);
  private router      = inject(Router);
  private route       = inject(ActivatedRoute);
  private destroy$    = new Subject<void>();

  isSubmitting = false;
  showPassword = false;
  apiError: string | null = null;

  // Lab 2: FormBuilder.nonNullable — no null in form types
  loginForm = this.fb.nonNullable.group({
    username: this.fb.nonNullable.control('', [Validators.required, Validators.email]),
    password: this.fb.nonNullable.control('', [Validators.required, Validators.minLength(8)]),
  });

  onSubmit(): void {
    if (this.loginForm.invalid || this.isSubmitting) return;
    this.isSubmitting = true;
    this.apiError = null;

    this.authService.login(this.loginForm.getRawValue()).pipe(takeUntil(this.destroy$)).subscribe({
      next: () => {
        const returnUrl = this.route.snapshot.queryParams['returnUrl'] ?? '/payments';
        this.router.navigateByUrl(returnUrl);
      },
      error: err => {
        this.isSubmitting = false;
        this.apiError = (err as { userMessage?: string }).userMessage ?? 'Invalid credentials. Please try again.';
      },
    });
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
