// Lab 10: Dev Control Panel — drives mock WebSocket events for testing
import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { Store } from '@ngrx/store';
import { PaymentApiActions } from '../../state/payments/payment.actions';
import { PaymentStreamService } from '../../core/services/payment-stream.service';

@Component({
  selector: 'app-dev-control-panel',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatCardModule, MatIconModule, MatDividerModule],
  styles: [`
    .panel {
      position: fixed; bottom: 16px; right: 16px;
      background: #fff9c4; z-index: 1000;
      width: 240px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.2);
      border-radius: 8px;
      border: 1px solid #ffc107;
    }
    .panel-title { font-size: 13px; font-weight: 700; color: #555; padding: 10px 14px 4px; }
    .panel-body { padding: 0 10px 10px; display: flex; flex-direction: column; gap: 6px; }
    button { font-size: 12px !important; }
  `],
  template: `
    <mat-card class="panel">
      <div class="panel-title">🛠 Dev Controls (mock mode)</div>
      <mat-divider></mat-divider>
      <div class="panel-body" style="margin-top:8px">
        <button mat-stroked-button (click)="simulate('pay-001', 'SUCCESS')">
          <mat-icon style="font-size:16px">check_circle</mat-icon> pay-001 → SUCCESS
        </button>
        <button mat-stroked-button color="warn" (click)="simulate('pay-001', 'FAILED')">
          <mat-icon style="font-size:16px">cancel</mat-icon> pay-001 → FAILED
        </button>
        <button mat-stroked-button (click)="simulate('pay-001', 'PROCESSING')">
          <mat-icon style="font-size:16px">hourglass_empty</mat-icon> pay-001 → PROCESSING
        </button>
        <button mat-stroked-button (click)="simulate('pay-002', 'REVERSED')">
          <mat-icon style="font-size:16px">undo</mat-icon> pay-002 → REVERSED
        </button>
        <mat-divider></mat-divider>
        <button mat-stroked-button (click)="loadPayments()">
          <mat-icon style="font-size:16px">refresh</mat-icon> Reload Payments
        </button>
      </div>
    </mat-card>
  `,
})
export class DevControlPanelComponent {
  private store         = inject(Store);
  private streamService = inject(PaymentStreamService);

  simulate(paymentId: string, status: 'SUCCESS' | 'FAILED' | 'PROCESSING' | 'REVERSED'): void {
    const update = { paymentId, status, updatedAt: new Date().toISOString() };
    // Push through WebSocket mock (Lab 5) AND directly to store (Lab 7)
    this.streamService.pushMockUpdate(update);
    this.store.dispatch(PaymentApiActions.paymentStatusUpdated(update));
  }

  loadPayments(): void {
    this.store.dispatch(PaymentApiActions.loadPayments());
  }
}
