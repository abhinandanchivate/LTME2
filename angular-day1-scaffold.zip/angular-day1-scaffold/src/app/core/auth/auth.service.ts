// Lab 2: AuthService — JWT management via sessionStorage
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private readonly baseUrl = `${environment.apiBaseUrl}/auth`;

  login(credentials: LoginCredentials): Observable<TokenResponse> {
    return this.http.post<TokenResponse>(`${this.baseUrl}/login`, credentials).pipe(
      tap(tokens => {
        // sessionStorage preferred over localStorage for payment apps
        // (cleared when tab closes, reduces XSS exposure window)
        sessionStorage.setItem('access_token', tokens.accessToken);
        sessionStorage.setItem('refresh_token', tokens.refreshToken);
      })
    );
  }

  logout(): void {
    sessionStorage.removeItem('access_token');
    sessionStorage.removeItem('refresh_token');
  }

  getAccessToken(): string | null {
    return sessionStorage.getItem('access_token');
  }

  isAuthenticated(): boolean {
    return !!this.getAccessToken();
  }

  hasRole(role: string): boolean {
    const token = this.getAccessToken();
    if (!token) return false;
    try {
      // Decode JWT payload — DO NOT verify signature on client (server-side only)
      const payload = JSON.parse(atob(token.split('.')[1]));
      return (payload.roles as string[] ?? []).includes(role);
    } catch {
      return false;
    }
  }

  refreshToken(): Observable<TokenResponse> {
    const refreshToken = sessionStorage.getItem('refresh_token');
    return this.http.post<TokenResponse>(`${this.baseUrl}/refresh`, { refreshToken }).pipe(
      tap(tokens => {
        sessionStorage.setItem('access_token', tokens.accessToken);
        sessionStorage.setItem('refresh_token', tokens.refreshToken);
      })
    );
  }
}
