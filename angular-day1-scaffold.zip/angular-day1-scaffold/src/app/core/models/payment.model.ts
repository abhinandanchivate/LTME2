// Lab 1: Core domain models — amountInPaise enforces minor-unit convention
export interface Payment {
  id: string;
  referenceNumber: string;       // UTR / transaction reference (RBI mandate)
  payerAccountNumber: string;
  payeeAccountNumber: string;
  payeeIfscCode: string;
  amountInPaise: number;         // Minor units — no floats for money
  currency: 'INR';
  status: PaymentStatus;
  initiatedAt: string;           // ISO 8601
  settledAt?: string;
  failureReason?: string;
  channel: PaymentChannel;
}

export type PaymentStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'SUCCESS'
  | 'FAILED'
  | 'REVERSED';

export type PaymentChannel = 'NEFT' | 'RTGS' | 'IMPS' | 'UPI';
