// Lab 3: PaymentService — HTTP calls for payment CRUD
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Payment } from '../models/payment.model';
import { environment } from '../../../environments/environment';

export interface InitiatePaymentRequest {
  channel: string;
  payeeAccountNumber: string;
  payeeIfscCode: string;
  vpa: string;
  amountInPaise: number;
  remarks: string;
}

@Injectable({ providedIn: 'root' })
export class PaymentService {
  private http = inject(HttpClient);
  private readonly baseUrl = `${environment.apiBaseUrl}/api/v1/payments`;

  getPayments(): Observable<Payment[]> {
    return this.http.get<Payment[]>(this.baseUrl);
  }

  initiatePayment(req: InitiatePaymentRequest): Observable<Payment> {
    return this.http.post<Payment>(this.baseUrl, req);
  }

  searchPayments(term: string): Observable<Payment[]> {
    const params = new HttpParams().set('q', term);
    return this.http.get<Payment[]>(`${this.baseUrl}/search`, { params });
  }

  getPaymentById(id: string): Observable<Payment> {
    return this.http.get<Payment>(`${this.baseUrl}/${id}`);
  }
}
