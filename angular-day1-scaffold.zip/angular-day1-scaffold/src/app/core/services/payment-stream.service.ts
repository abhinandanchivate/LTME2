// Lab 5: WebSocket stream service with exponential-backoff reconnect
import { Injectable, OnDestroy } from '@angular/core';
import { webSocket, WebSocketSubject } from 'rxjs/webSocket';
import {
  Observable,
  Subject,
  EMPTY,
  timer,
  retry,
  catchError,
  share,
  ReplaySubject,
} from 'rxjs';
import { environment } from '../../../environments/environment';
import { Payment } from '../models/payment.model';

export interface PaymentStatusUpdate {
  paymentId: string;
  status: Payment['status'];
  updatedAt: string;
  failureReason?: string;
}

@Injectable({ providedIn: 'root' })
export class PaymentStreamService implements OnDestroy {
  private socket$: WebSocketSubject<PaymentStatusUpdate> | null = null;
  private destroy$ = new Subject<void>();

  // ReplaySubject(1) allows DevControlPanel to push mock events
  private mockSubject = new ReplaySubject<PaymentStatusUpdate>(1);

  /** Single shared WebSocket connection for all subscribers */
  readonly statusUpdates$: Observable<PaymentStatusUpdate> = environment.useMocks
    ? this.mockSubject.asObservable()
    : this.buildStream().pipe(share());

  private buildStream(): Observable<PaymentStatusUpdate> {
    return new Observable<PaymentStatusUpdate>(observer => {
      this.socket$ = webSocket<PaymentStatusUpdate>({
        url: `${environment.wsBaseUrl}/ws/payment-status`,
        openObserver:  { next: () => console.info('[PaymentStream] Connected') },
        closeObserver: { next: () => console.info('[PaymentStream] Disconnected') },
      });

      const sub = this.socket$.subscribe({
        next:     msg => observer.next(msg),
        error:    err => observer.error(err),
        complete: () => observer.complete(),
      });
      return () => sub.unsubscribe();
    }).pipe(
      retry({
        count: 5,
        delay: (_err, retryCount) => {
          const delayMs = Math.pow(2, retryCount) * 1000;
          console.warn(`[PaymentStream] Retrying in ${delayMs}ms (attempt ${retryCount})`);
          return timer(delayMs);
        },
      }),
      catchError(err => {
        console.error('[PaymentStream] Unrecoverable error, stream closed:', err);
        return EMPTY;
      })
    );
  }

  /** Used by DevControlPanel in mock mode */
  pushMockUpdate(update: PaymentStatusUpdate): void {
    this.mockSubject.next(update);
  }

  ngOnDestroy(): void {
    this.socket$?.complete();
    this.destroy$.next();
    this.destroy$.complete();
  }
}
