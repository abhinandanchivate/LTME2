// Lab 10: Mock interceptor — intercepts all /api/v1/payments calls in dev mode
import { HttpInterceptorFn, HttpResponse } from '@angular/common/http';
import { delay, of } from 'rxjs';
import { Payment } from '../models/payment.model';
import { environment } from '../../../environments/environment';

export const MOCK_PAYMENTS: Payment[] = [
  {
    id: 'pay-001',
    referenceNumber: 'HDFC240227000001',
    payerAccountNumber: '9876543210',
    payeeAccountNumber: '1234567890',
    payeeIfscCode: 'ICIC0001234',
    amountInPaise: 50000000,   // ₹5,00,000
    currency: 'INR',
    status: 'PENDING',
    initiatedAt: new Date(Date.now() - 300000).toISOString(),
    channel: 'RTGS',
  },
  {
    id: 'pay-002',
    referenceNumber: 'NEFT240227000002',
    payerAccountNumber: '9876543210',
    payeeAccountNumber: '5555666677',
    payeeIfscCode: 'SBIN0001111',
    amountInPaise: 1500000,    // ₹15,000
    currency: 'INR',
    status: 'SUCCESS',
    initiatedAt: new Date(Date.now() - 600000).toISOString(),
    settledAt: new Date(Date.now() - 300000).toISOString(),
    channel: 'NEFT',
  },
  {
    id: 'pay-003',
    referenceNumber: 'IMPS240227000003',
    payerAccountNumber: '9876543210',
    payeeAccountNumber: '7777888899',
    payeeIfscCode: 'AXIS0002222',
    amountInPaise: 250000,     // ₹2,500
    currency: 'INR',
    status: 'FAILED',
    initiatedAt: new Date(Date.now() - 900000).toISOString(),
    failureReason: 'INSUFFICIENT_FUNDS',
    channel: 'IMPS',
  },
  {
    id: 'pay-004',
    referenceNumber: 'UPI240227000004',
    payerAccountNumber: '9876543210',
    payeeAccountNumber: '',
    payeeIfscCode: '',
    amountInPaise: 50000,      // ₹500
    currency: 'INR',
    status: 'PROCESSING',
    initiatedAt: new Date(Date.now() - 120000).toISOString(),
    channel: 'UPI',
  },
  {
    id: 'pay-005',
    referenceNumber: 'NEFT240227000005',
    payerAccountNumber: '9876543210',
    payeeAccountNumber: '1111222233',
    payeeIfscCode: 'HDFC0003333',
    amountInPaise: 750000,     // ₹7,500
    currency: 'INR',
    status: 'REVERSED',
    initiatedAt: new Date(Date.now() - 1800000).toISOString(),
    settledAt: new Date(Date.now() - 900000).toISOString(),
    channel: 'NEFT',
  },
];

let nextPaymentId = 6;
const MOCK_LATENCY_MS = 500;

// Mock JWT — payload: { sub: 'ops@securepayment.in', roles: ['OPERATOR'], exp: far future }
const MOCK_TOKEN =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.' +
  btoa(JSON.stringify({
    sub: 'ops@securepayment.in',
    roles: ['OPERATOR'],
    exp: Math.floor(Date.now() / 1000) + 86400,
    iat: Math.floor(Date.now() / 1000),
  })).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_') +
  '.mock-signature';

export const mockPaymentInterceptor: HttpInterceptorFn = (req, next) => {
  if (!environment.useMocks) return next(req);

  // POST /auth/login
  if (req.method === 'POST' && req.url.includes('/auth/login')) {
    const body = req.body as Record<string, string>;
    if (body['username'] === 'ops@securepayment.in' && body['password'] === 'Secure@123') {
      return of(new HttpResponse({
        status: 200,
        body: { accessToken: MOCK_TOKEN, refreshToken: 'mock-refresh-token', expiresIn: 900 },
      })).pipe(delay(300));
    }
    return of(new HttpResponse({
      status: 401,
      body: { errorCode: 'INVALID_CREDENTIALS', message: 'Invalid credentials' },
    })).pipe(delay(300));
  }

  // GET /api/v1/payments/search
  if (req.method === 'GET' && req.url.includes('/api/v1/payments/search')) {
    const term = req.params.get('q')?.toLowerCase() ?? '';
    const results = MOCK_PAYMENTS.filter(
      p => p.referenceNumber.toLowerCase().includes(term) ||
           p.payeeAccountNumber.includes(term) ||
           p.channel.toLowerCase().includes(term)
    );
    return of(new HttpResponse({ status: 200, body: results })).pipe(delay(MOCK_LATENCY_MS));
  }

  // GET /api/v1/payments
  if (req.method === 'GET' && req.url.includes('/api/v1/payments')) {
    return of(new HttpResponse({ status: 200, body: [...MOCK_PAYMENTS] })).pipe(delay(MOCK_LATENCY_MS));
  }

  // POST /api/v1/payments
  if (req.method === 'POST' && req.url.endsWith('/api/v1/payments')) {
    const body = req.body as Record<string, unknown>;
    const newPayment: Payment = {
      id: `pay-00${nextPaymentId++}`,
      referenceNumber: `${body['channel']}${Date.now()}`,
      payerAccountNumber: '9876543210',
      payeeAccountNumber: String(body['payeeAccountNumber'] ?? ''),
      payeeIfscCode: String(body['payeeIfscCode'] ?? ''),
      amountInPaise: Number(body['amountInPaise']),
      currency: 'INR',
      status: 'PENDING',
      initiatedAt: new Date().toISOString(),
      channel: body['channel'] as Payment['channel'],
    };
    MOCK_PAYMENTS.unshift(newPayment);
    return of(new HttpResponse({ status: 201, body: newPayment })).pipe(delay(MOCK_LATENCY_MS));
  }

  return next(req);
};
