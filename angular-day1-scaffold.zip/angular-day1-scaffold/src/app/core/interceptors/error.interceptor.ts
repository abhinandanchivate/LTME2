// Lab 4: Error Interceptor — maps API error codes to user-friendly messages
import {
  HttpInterceptorFn,
  HttpErrorResponse,
} from '@angular/common/http';
import { inject } from '@angular/core';
import { throwError, catchError } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

const PAYMENT_ERROR_MESSAGES: Record<string, string> = {
  INSUFFICIENT_FUNDS:        'Transaction declined: insufficient funds in your account.',
  DUPLICATE_TRANSACTION:     'This payment appears to be a duplicate. Check your payment history.',
  INVALID_BENEFICIARY:       'Beneficiary account not found. Verify IFSC and account number.',
  DAILY_LIMIT_EXCEEDED:      'Daily transaction limit reached. Try again after midnight.',
  ACCOUNT_FROZEN:            'Account temporarily suspended. Contact your branch.',
  NEFT_CUTOFF_PASSED:        'NEFT batch closed. Payment will process next business day.',
  RTGS_AMOUNT_BELOW_MINIMUM: 'RTGS requires a minimum transfer of ₹2,00,000.',
};

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const snackBar = inject(MatSnackBar);
  const router = inject(Router);

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      let userMessage = 'An unexpected error occurred. Please try again.';

      if (error.status === 0) {
        userMessage = 'Unable to reach the server. Check your internet connection.';
      } else if (error.status === 403) {
        userMessage = 'You do not have permission to perform this action.';
        router.navigate(['/access-denied']);
      } else if (error.status === 429) {
        userMessage = 'Too many requests. Please wait before retrying.';
      } else if (error.status >= 400 && error.status < 500) {
        const apiErrorCode = error.error?.errorCode as string;
        userMessage =
          PAYMENT_ERROR_MESSAGES[apiErrorCode] ??
          error.error?.message ??
          userMessage;
      } else if (error.status >= 500) {
        userMessage = 'A server error occurred. Our team has been notified.';
      }

      if (error.status !== 401) {
        snackBar.open(userMessage, 'Dismiss', {
          duration: 8000,
          panelClass: ['snack-error'],
        });
      }

      return throwError(() => ({ ...error, userMessage }));
    })
  );
};
