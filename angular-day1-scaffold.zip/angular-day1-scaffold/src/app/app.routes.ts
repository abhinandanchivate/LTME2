// Lab 1: Root routes — lazy-loaded feature modules
import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'payments', pathMatch: 'full' },
  {
    path: 'auth',
    loadChildren: () => import('./features/auth/auth.routes').then(m => m.AUTH_ROUTES),
  },
  {
    path: 'payments',
    loadChildren: () => import('./features/payments/payments.routes').then(m => m.PAYMENT_ROUTES),
  },
  { path: '**', redirectTo: 'payments' },
];
