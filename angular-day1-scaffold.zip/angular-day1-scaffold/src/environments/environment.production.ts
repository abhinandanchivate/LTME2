export const environment = {
  production: true,
  apiBaseUrl: 'https://api.securepayment.in',
  wsBaseUrl: 'wss://api.securepayment.in',
  useMocks: false,
};
