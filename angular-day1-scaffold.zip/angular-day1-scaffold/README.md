# SecurePayment Gateway — Angular Day 1 Scaffold

> **Angular 17 | NgRx | Reactive Forms | WebSocket | Banking Domain**

All 10 labs pre-implemented and ready to run.

## Quick Start

```bash
npm install
ng serve
# Open: http://localhost:4200
# Login: ops@securepayment.in / Secure@123
```

## Lab Map

| Lab | Feature | Key Files | Concept |
|---|---|---|---|
| 1 | Project structure | `app.config.ts`, `app.routes.ts`, `payment.model.ts` | Standalone API, lazy loading, minor-unit amounts |
| 2 | Login form | `login/login.component.ts` | `FormBuilder.nonNullable`, per-field validation, `takeUntil` |
| 3 | Payment form | `payment-form/payment-form.component.ts` | Dynamic validators, `updateValueAndValidity()`, `Math.round(rupees * 100)` |
| 4 | JWT + Error interceptors | `interceptors/jwt.interceptor.ts`, `error.interceptor.ts` | `HttpInterceptorFn`, refresh lock, `PAYMENT_ERROR_MESSAGES` |
| 5 | WebSocket stream | `services/payment-stream.service.ts` | `webSocket()`, exponential retry, `share()` |
| 6 | Search | `search/payment-search.component.ts` | `debounceTime(300)`, `switchMap`, `catchError` inside inner pipe |
| 7 | NgRx Store | `state/payments/payment.*` | `createActionGroup`, `EntityAdapter`, `createSelector` |
| 8 | NgRx Effects | `state/payments/payment.effects.ts` | `switchMap` for reads, `mergeMap` for writes, WebSocket bridge |
| 9 | Dashboard | `dashboard/payment-dashboard.component.ts` | Thin component — `Store.select()`, `async` pipe only |
| 10 | Capstone | `interceptors/mock-payment.interceptor.ts`, `dev-control-panel/` | Mock API, dev panel, end-to-end flow |

## Architecture Decisions

### Minor-Unit Amounts
- All monetary values stored as **paise** (`amountInPaise: number`)
- UI displays rupees; `Math.round(rupees * 100)` converts on submit
- Prevents floating-point errors (0.1 + 0.2 ≠ 0.3)

### Interceptor Chain
```
Request → mockPaymentInterceptor → jwtInterceptor → errorInterceptor → HTTP
```

### NgRx Data Flow
```
Component dispatch(action)
  → Effect: API call
    → dispatch(successAction)
      → Reducer: update EntityState
        → Selector: memoized projection
          → Component: async pipe
```

### WebSocket (Lab 5)
- `share()` ensures ONE WebSocket connection regardless of subscriber count
- Exponential backoff: 1s → 2s → 4s → 8s → 16s (max 5 retries)
- Mock mode: `ReplaySubject` driven by Dev Control Panel

## Capstone End-to-End Test

1. `ng serve` → opens `http://localhost:4200`
2. Redirects to `/payments` → NgRx loads 5 mock payments
3. Navigate to `/auth/login` → login with demo credentials
4. Dashboard: 5 payments, 4 KPI cards visible
5. Click **+ New Payment** → PaymentForm lazy-loads
6. Select RTGS, enter ₹1,00,000 → validation error shows
7. Switch to IMPS, fill form, submit → new payment appears at top
8. Dev Panel → **pay-001 → SUCCESS** → row turns green instantly
9. Dev Panel → **pay-001 → FAILED** → row turns red, failure alert

## Redux DevTools Action Log (expected)
```
[Payment API] Load Payments
[Payment API] Load Payments Success
[Payment API] Initiate Payment
[Payment API] Initiate Payment Success
[Payment API] Payment Status Updated
```

## Toggle Mock Mode
```ts
// src/environments/environment.ts
useMocks: false  // Uses real backend at apiBaseUrl
```
