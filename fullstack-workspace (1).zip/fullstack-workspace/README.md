# Fullstack Workspace — Angular 17 + Spring Boot 3.2 + Kubernetes

A production-ready monorepo with Angular frontend, Spring REST API, and full Kubernetes secret management.

---

## Project Structure

```
fullstack-workspace/
├── frontend/                   # Angular 17 (standalone, lazy-loaded)
│   ├── src/
│   │   ├── app/
│   │   │   ├── core/
│   │   │   │   └── api.service.ts       # Typed HTTP client
│   │   │   ├── features/items/          # Lazy-loaded CRUD feature
│   │   │   ├── app.config.ts            # Providers (router, HttpClient)
│   │   │   └── app.routes.ts
│   │   └── environments/
│   │       ├── environment.ts           # dev  → localhost:8080
│   │       └── environment.prod.ts      # prod → /api (Ingress proxy)
│   ├── Dockerfile                       # Multi-stage: Node build → Nginx serve
│   ├── nginx.conf                       # SPA routing + /api proxy
│   └── proxy.conf.json                  # Dev proxy to Spring
│
├── backend/                    # Spring Boot 3.2 REST API
│   ├── src/main/java/com/app/
│   │   ├── controller/ApiController.java
│   │   ├── service/ItemService.java
│   │   ├── repository/ItemRepository.java
│   │   ├── model/Item.java
│   │   ├── config/AppConfig.java        # CORS reads from ${CORS_ORIGIN}
│   │   └── exception/
│   │       ├── GlobalExceptionHandler.java
│   │       └── ResourceNotFoundException.java
│   ├── src/main/resources/
│   │   └── application.yml              # All secrets via ${ENV_VAR}
│   └── Dockerfile                       # Multi-stage: Maven build → JRE run
│
├── k8s/                        # Kubernetes manifests
│   ├── namespace.yaml
│   ├── secret.yaml              ⚠ base64-encoded secrets — do not commit real values
│   ├── configmap.yaml           # Non-sensitive config
│   ├── deployment-backend.yaml  # envFrom: secretRef + configMapRef
│   ├── deployment-frontend.yaml
│   ├── service.yaml
│   ├── ingress.yaml             # TLS via cert-manager
│   └── hpa.yaml                 # Autoscaler (CPU + memory)
│
├── docker-compose.yml           # Full local stack with Postgres
└── README.md
```

---

## Secret Management Flow

```
K8s Secret (secret.yaml)
        │
        │  envFrom: secretRef
        ▼
  Pod env vars (DB_URL, DB_PASSWORD, JWT_SECRET …)
        │
        │  ${DB_URL} in application.yml
        ▼
  Spring Boot reads at startup — credentials never in code or config files
```

---

## Quick Start

### 1. Local development (Docker Compose)

```bash
docker compose up --build
# Angular: http://localhost:4200
# Spring:  http://localhost:8080/api/health
```

### 2. Local Angular dev server (with hot reload)

```bash
cd frontend
npm install
npm start          # uses proxy.conf.json → http://localhost:8080
```

### 3. Local Spring dev (H2 in-memory, no Postgres needed)

```bash
cd backend
./mvnw spring-boot:run
# H2 console: http://localhost:8080/h2-console
```

---

## Kubernetes Deployment

### Prerequisites
- `kubectl` configured for your cluster
- `cert-manager` installed (for TLS)
- `nginx-ingress-controller` installed

### Encode your secrets

```bash
echo -n "jdbc:postgresql://your-host:5432/appdb" | base64
echo -n "your-db-password" | base64
echo -n "$(openssl rand -base64 32)" | base64   # JWT secret
```

### Edit and apply

```bash
# 1. Update base64 values in k8s/secret.yaml
vim k8s/secret.yaml

# 2. Deploy in order
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/secret.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/deployment-backend.yaml
kubectl apply -f k8s/deployment-frontend.yaml
kubectl apply -f k8s/service.yaml
kubectl apply -f k8s/ingress.yaml
kubectl apply -f k8s/hpa.yaml

# 3. Verify
kubectl get pods -n production
kubectl logs -f deployment/spring-api -n production
```

---

## API Reference

| Method | Endpoint          | Description         |
|--------|-------------------|---------------------|
| GET    | /api/health       | Health check        |
| GET    | /api/items        | List all items      |
| GET    | /api/items/{id}   | Get item by ID      |
| POST   | /api/items        | Create item         |
| PUT    | /api/items/{id}   | Update item         |
| DELETE | /api/items/{id}   | Delete item         |

---

## Production Secret Management (Beyond K8s Secrets)

For enhanced security, consider:

- **Sealed Secrets** — encrypt secrets in Git with `kubeseal`
- **HashiCorp Vault** + Vault Agent Injector — dynamic secrets
- **External Secrets Operator** — sync from AWS Secrets Manager / GCP Secret Manager / Azure Key Vault

---

## Tech Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| Frontend  | Angular 17, standalone components |
| Backend   | Spring Boot 3.2, Java 17          |
| Database  | PostgreSQL 16 (H2 for local dev)  |
| Container | Docker (multi-stage builds)       |
| Orchestration | Kubernetes                    |
| Proxy     | Nginx                             |
| TLS       | cert-manager + Let's Encrypt      |
| Scaling   | HorizontalPodAutoscaler           |

---

## Complete Kubernetes integration map

```
GitHub Actions CI/CD
  └─ on push to main
       ├─ test-backend  (mvn test with H2)
       ├─ test-frontend (ng build:prod)
       ├─ build-push    (multi-stage Docker → registry)
       └─ deploy
            ├─ kubectl apply -f k8s/  (all manifests in order)
            ├─ kubectl set image      (pin exact SHA tag)
            ├─ kubectl rollout status (wait for health)
            └─ smoke test             (curl /api/health from inside cluster)

Kubernetes cluster (namespace: production)
  ├─ Ingress (nginx)          ← TLS via cert-manager / Let's Encrypt
  │    ├─ /        → angular-app-service:80
  │    └─ /api     → spring-api-service:8080
  │
  ├─ angular-app (Deployment, 2 replicas)
  │    ├─ ServiceAccount: angular-app-sa  (no cluster perms)
  │    ├─ NetworkPolicy: ingress from nginx only, egress to spring-api:8080
  │    └─ PodDisruptionBudget: minAvailable 1
  │
  ├─ spring-api (Deployment, 2 replicas)
  │    ├─ ServiceAccount: spring-api-sa   (no cluster perms)
  │    ├─ envFrom: secretRef (api-secrets) + configMapRef (api-config)
  │    ├─ env override: DB_URL → postgres-service:5432/appdb
  │    ├─ NetworkPolicy: ingress from nginx+angular, egress to postgres:5432
  │    ├─ HPA: 2 → 6 pods on CPU/mem
  │    ├─ PodDisruptionBudget: minAvailable 1
  │    └─ Probes: startup (60s budget) + liveness + readiness
  │
  ├─ postgres (StatefulSet, 1 replica)
  │    ├─ Credentials from api-secrets (DB_USERNAME, DB_PASSWORD)
  │    ├─ NetworkPolicy: ingress from spring-api only, no egress
  │    ├─ PVC: 10Gi ReadWriteOnce
  │    └─ Headless Service: postgres-service (stable DNS)
  │
  ├─ api-secrets (Secret, Opaque)
  │    └─ DB_URL, DB_USERNAME, DB_PASSWORD, JWT_SECRET, CORS_ORIGIN
  │
  └─ api-config (ConfigMap)
       └─ DB_DRIVER, JPA_DDL_AUTO, H2_CONSOLE, SERVER_PORT
```

## New files added

| File | Purpose |
|------|---------|
| `k8s/postgres-statefulset.yaml` | PostgreSQL StatefulSet + headless Service + 10Gi PVC |
| `k8s/cert-manager-issuer.yaml` | Let's Encrypt ClusterIssuer (prod + staging) |
| `k8s/network-policy.yaml` | Zero-trust pod-to-pod traffic rules |
| `k8s/rbac.yaml` | ServiceAccounts with no extra cluster permissions |
| `k8s/pdb.yaml` | PodDisruptionBudgets — safe node drains |
| `k8s/apply-all.sh` | Ordered deploy script with rollout waits |
| `.github/workflows/ci-cd.yaml` | Full CI/CD: test → build → push → deploy |
