package com.app.controller;
import com.app.model.Item;
import com.app.service.ItemService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "${app.cors-origin}")
@RequiredArgsConstructor
public class ApiController {
  private final ItemService itemService;

  /** Injected from K8s Secret env var JWT_SECRET — never returned in responses */
  @Value("${app.jwt-secret:dev-secret}")
  private String jwtSecret;

  @GetMapping("/health")
  public ResponseEntity<Map<String,String>> health() {
    return ResponseEntity.ok(Map.of("status", "ok", "service", "fullstack-api"));
  }

  @GetMapping("/items")
  public List<Item> getItems() { return itemService.findAll(); }

  @GetMapping("/items/{id}")
  public Item getItem(@PathVariable Long id) { return itemService.findById(id); }

  @PostMapping("/items")
  @ResponseStatus(HttpStatus.CREATED)
  public Item createItem(@Valid @RequestBody Item item) { return itemService.create(item); }

  @PutMapping("/items/{id}")
  public Item updateItem(@PathVariable Long id, @Valid @RequestBody Item item) {
    return itemService.update(id, item);
  }

  @DeleteMapping("/items/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  public void deleteItem(@PathVariable Long id) { itemService.delete(id); }
}
