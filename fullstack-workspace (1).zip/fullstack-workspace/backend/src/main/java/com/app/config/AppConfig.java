package com.app.config;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class AppConfig {
  @Value("${app.cors-origin:http://localhost:4200}")
  private String corsOrigin;

  @Bean
  public WebMvcConfigurer corsConfigurer() {
    return new WebMvcConfigurer() {
      @Override
      public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
            .allowedOrigins(corsOrigin)
            .allowedMethods("GET","POST","PUT","DELETE","OPTIONS")
            .allowedHeaders("*").maxAge(3600);
      }
    };
  }
}
