package com.app.service;
import com.app.exception.ResourceNotFoundException;
import com.app.model.Item;
import com.app.repository.ItemRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service @RequiredArgsConstructor @Transactional(readOnly = true)
public class ItemService {
  private final ItemRepository repo;

  public List<Item> findAll() { return repo.findAllByOrderByCreatedAtDesc(); }

  public Item findById(Long id) {
    return repo.findById(id).orElseThrow(() -> new ResourceNotFoundException("Item", id));
  }

  @Transactional public Item create(Item item) { return repo.save(item); }

  @Transactional
  public Item update(Long id, Item updated) {
    Item e = findById(id);
    e.setName(updated.getName());
    e.setDescription(updated.getDescription());
    return repo.save(e);
  }

  @Transactional
  public void delete(Long id) {
    if (!repo.existsById(id)) throw new ResourceNotFoundException("Item", id);
    repo.deleteById(id);
  }
}
