export const environment = {
  production: true,
  apiUrl: '/api'   // proxied through Ingress in production
};
