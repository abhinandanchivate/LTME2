import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', redirectTo: 'items', pathMatch: 'full' },
  {
    path: 'items',
    loadComponent: () =>
      import('./features/items/items.component').then(m => m.ItemsComponent)
  }
];
