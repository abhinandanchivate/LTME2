import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService, Item } from '../../core/api.service';

@Component({
  selector: 'app-items',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.scss']
})
export class ItemsComponent implements OnInit {
  items: Item[] = [];
  newItem: Omit<Item, 'id' | 'createdAt'> = { name: '', description: '' };
  loading = false;
  error: string | null = null;

  constructor(private api: ApiService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.loading = true;
    this.error = null;
    this.api.getItems().subscribe({
      next: items => { this.items = items; this.loading = false; },
      error: err  => { this.error = err.message; this.loading = false; }
    });
  }

  create(): void {
    if (!this.newItem.name.trim()) return;
    this.api.createItem(this.newItem).subscribe({
      next: item => { this.items = [...this.items, item]; this.newItem = { name: '', description: '' }; },
      error: err => { this.error = err.message; }
    });
  }

  delete(id: number): void {
    this.api.deleteItem(id).subscribe({
      next: () => { this.items = this.items.filter(i => i.id !== id); },
      error: err => { this.error = err.message; }
    });
  }
}
