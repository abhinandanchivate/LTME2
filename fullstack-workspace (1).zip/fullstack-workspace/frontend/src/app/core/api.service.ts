import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface Item {
  id?: number;
  name: string;
  description?: string;
  createdAt?: string;
}

@Injectable({ providedIn: 'root' })
export class ApiService {

  private readonly apiUrl = environment.apiUrl;

  private get jsonHeaders(): HttpHeaders {
    return new HttpHeaders({ 'Content-Type': 'application/json' });
  }

  constructor(private http: HttpClient) {}

  /** GET /api/items */
  getItems(): Observable<Item[]> {
    return this.http.get<Item[]>(`${this.apiUrl}/items`).pipe(catchError(this.handleError));
  }

  /** GET /api/items/:id */
  getItem(id: number): Observable<Item> {
    return this.http.get<Item>(`${this.apiUrl}/items/${id}`).pipe(catchError(this.handleError));
  }

  /** POST /api/items */
  createItem(item: Omit<Item, 'id' | 'createdAt'>): Observable<Item> {
    return this.http
      .post<Item>(`${this.apiUrl}/items`, item, { headers: this.jsonHeaders })
      .pipe(catchError(this.handleError));
  }

  /** PUT /api/items/:id */
  updateItem(id: number, item: Partial<Item>): Observable<Item> {
    return this.http
      .put<Item>(`${this.apiUrl}/items/${id}`, item, { headers: this.jsonHeaders })
      .pipe(catchError(this.handleError));
  }

  /** DELETE /api/items/:id */
  deleteItem(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/items/${id}`).pipe(catchError(this.handleError));
  }

  /** GET /api/health */
  health(): Observable<string> {
    return this.http.get(`${this.apiUrl}/health`, { responseType: 'text' });
  }

  private handleError(error: any): Observable<never> {
    console.error('API error:', error);
    return throwError(() => new Error(error.message ?? 'Unknown API error'));
  }
}
