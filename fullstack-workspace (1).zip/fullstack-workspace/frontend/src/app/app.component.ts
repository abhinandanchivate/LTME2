import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <header class="app-header">
      <h1>Fullstack Workspace</h1>
    </header>
    <main>
      <router-outlet />
    </main>
  `,
  styles: [`
    .app-header { background: #1a1a2e; color: white; padding: 1rem 2rem; }
    main { padding: 2rem; }
  `]
})
export class AppComponent {}
