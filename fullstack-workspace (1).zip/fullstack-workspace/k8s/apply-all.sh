#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# apply-all.sh  —  Deploy the full stack to Kubernetes
#
# Usage:
#   chmod +x k8s/apply-all.sh
#   ./k8s/apply-all.sh [--dry-run]
#
# Prerequisites:
#   - kubectl configured and pointing at your cluster
#   - k8s/secret.yaml edited with real base64 values
#   - cert-manager installed
#   - nginx-ingress-controller installed
# ─────────────────────────────────────────────────────────────
set -euo pipefail

NS=production
DRY=${1:-}
FLAGS=""
[[ "$DRY" == "--dry-run" ]] && FLAGS="--dry-run=client"

echo "🔍 Target cluster: $(kubectl config current-context)"
echo "📦 Namespace: $NS"
[[ -n "$FLAGS" ]] && echo "⚠️  Dry-run mode — nothing will be applied"
echo ""

apply() {
  echo "▶ Applying $1"
  kubectl apply -f "$1" $FLAGS
}

# ── 1. Namespace first ─────────────────────────────────────
apply k8s/namespace.yaml

# ── 2. RBAC / ServiceAccounts ──────────────────────────────
apply k8s/rbac.yaml

# ── 3. Secrets & ConfigMaps ────────────────────────────────
apply k8s/secret.yaml
apply k8s/configmap.yaml

# ── 4. Network policies ────────────────────────────────────
apply k8s/network-policy.yaml

# ── 5. Database (StatefulSet + headless Service) ───────────
apply k8s/postgres-statefulset.yaml

echo "⏳ Waiting for Postgres to be ready..."
[[ -z "$FLAGS" ]] && kubectl rollout status statefulset/postgres -n $NS --timeout=120s

# ── 6. Application deployments ─────────────────────────────
apply k8s/deployment-backend.yaml
apply k8s/deployment-frontend.yaml

echo "⏳ Waiting for Spring API rollout..."
[[ -z "$FLAGS" ]] && kubectl rollout status deployment/spring-api -n $NS --timeout=120s

echo "⏳ Waiting for Angular rollout..."
[[ -z "$FLAGS" ]] && kubectl rollout status deployment/angular-app -n $NS --timeout=90s

# ── 7. Services ────────────────────────────────────────────
apply k8s/service.yaml

# ── 8. Ingress + TLS ───────────────────────────────────────
apply k8s/cert-manager-issuer.yaml
apply k8s/ingress.yaml

# ── 9. Autoscaling + disruption budgets ────────────────────
apply k8s/hpa.yaml
apply k8s/pdb.yaml

echo ""
echo "✅ Done! Cluster state:"
kubectl get pods,svc,ingress,hpa,pdb -n $NS
