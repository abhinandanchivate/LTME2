import { Injectable } from '@angular/core';
import { Observable, filter, fromEvent, map } from 'rxjs';

export type MfeEvent =
  | { type: 'ACCOUNT_SELECTED'; payload: { accountId: string; accountName: string } }
  | { type: 'TRANSACTION_CREATED'; payload: { transactionId: string; amount: number; accountId: string } };

const EVENT_NAME = 'securepay:mfe-event';

@Injectable({ providedIn: 'root' })
export class MfeEventBusService {
  emit(event: MfeEvent): void {
    window.dispatchEvent(new CustomEvent<MfeEvent>(EVENT_NAME, { detail: event }));
  }

  on<T extends MfeEvent['type']>(type: T): Observable<Extract<MfeEvent, { type: T }>['payload']> {
    return fromEvent<CustomEvent<MfeEvent>>(window, EVENT_NAME).pipe(
      map(event => event.detail),
      filter((event): event is Extract<MfeEvent, { type: T }> => event.type === type),
      map(event => event.payload)
    );
  }
}
