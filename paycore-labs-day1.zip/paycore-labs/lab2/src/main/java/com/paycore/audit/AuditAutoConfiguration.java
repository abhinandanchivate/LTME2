package com.paycore.audit;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

/**
 * Lab 2: Custom Starter that survives a non-web classpath.
 *
 * KEY INSIGHT:
 * @ConditionalOnClass(name = "...HandlerInterceptor") guards at class-load time.
 * Without it, Spring tries to resolve HandlerInterceptor type references during
 * class loading and throws ClassNotFoundException before conditions are evaluated.
 */
@AutoConfiguration
@ConditionalOnClass(name = "org.springframework.web.servlet.HandlerInterceptor")
@ConditionalOnProperty(prefix = "paycore.audit", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(AuditProperties.class)
public class AuditAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public AuditLogger auditLogger(AuditProperties properties) {
        return new AuditLogger(properties);
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnWebApplication
    public AuditInterceptor auditInterceptor(AuditLogger logger, AuditProperties properties) {
        return new AuditInterceptor(logger, properties);
    }
}
