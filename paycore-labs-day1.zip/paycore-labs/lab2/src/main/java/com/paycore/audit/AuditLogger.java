package com.paycore.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.time.Instant;

public class AuditLogger {
    private static final Logger log = LoggerFactory.getLogger(AuditLogger.class);
    private final AuditProperties properties;

    public AuditLogger(AuditProperties properties) {
        this.properties = properties;
    }

    public void log(AuditEvent event) {
        log.info("[AUDIT] txn={} user={} action={} result={} ts={}",
                event.transactionId(), event.userId(), event.action(), event.result(), Instant.now());
    }

    public record AuditEvent(String transactionId, String userId, String action, String result) {}
}
