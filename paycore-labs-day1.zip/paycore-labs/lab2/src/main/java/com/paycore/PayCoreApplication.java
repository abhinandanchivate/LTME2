package com.paycore;

import com.paycore.audit.AuditLogger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class PayCoreApplication {
    public static void main(String[] args) {
        SpringApplication.run(PayCoreApplication.class, args);
    }

    @Bean
    public CommandLineRunner nonWebAuditCheck(ApplicationContext context) {
        return args -> {
            boolean hasLogger = context.getBeanNamesForType(AuditLogger.class).length > 0;
            boolean hasInterceptor;
            try {
                Class<?> interceptorClass = Class.forName("com.paycore.audit.AuditInterceptor");
                hasInterceptor = context.getBeanNamesForType(interceptorClass).length > 0;
            } catch (ClassNotFoundException e) {
                hasInterceptor = false;
            }
            LoggerFactory.getLogger(PayCoreApplication.class)
                    .info("AuditLogger available: {} | AuditInterceptor available: {}", hasLogger, hasInterceptor);
        };
    }
}
