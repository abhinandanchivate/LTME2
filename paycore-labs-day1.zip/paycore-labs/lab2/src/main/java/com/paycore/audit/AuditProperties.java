package com.paycore.audit;

import org.springframework.boot.context.properties.ConfigurationProperties;
import java.util.List;

@ConfigurationProperties(prefix = "paycore.audit")
public class AuditProperties {
    private boolean enabled = true;
    private List<String> methods = List.of("POST", "PUT", "DELETE", "PATCH");
    private boolean includeBody = false;
    private int maxBodyBytes = 4096;

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
    public List<String> getMethods() { return methods; }
    public void setMethods(List<String> methods) { this.methods = methods; }
    public boolean isIncludeBody() { return includeBody; }
    public void setIncludeBody(boolean includeBody) { this.includeBody = includeBody; }
    public int getMaxBodyBytes() { return maxBodyBytes; }
    public void setMaxBodyBytes(int maxBodyBytes) { this.maxBodyBytes = maxBodyBytes; }
}
