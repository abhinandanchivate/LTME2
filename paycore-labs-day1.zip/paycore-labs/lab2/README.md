# Lab 2 — Custom Starter That Survives a Non-Web Classpath

## Concepts Covered
@ConditionalOnClass(name=...), @ConditionalOnWebApplication, AutoConfiguration.imports

## How to Run
```bash
mvn spring-boot:run
```

## Key Learning Points
- @ConditionalOnClass by CLASS REFERENCE fails at class-load time if class is absent
- @ConditionalOnClass(name = "fully.qualified.ClassName") is safe — evaluated lazily
- This guard must be on the @AutoConfiguration class itself, not just individual @Bean methods
- AuditLogger registers in all environments; AuditInterceptor only in web environments

## Verification
- AuditLogger bean present in context
- AuditInterceptor bean present only in web context
- No ClassNotFoundException on non-web classpath
