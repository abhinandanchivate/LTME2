# PayCore Platform — Spring Boot Advanced Labs (Day 1)

Six independent projects covering Spring Boot auto-configuration and runtime customization.

| Lab | Topic | Key APIs |
|-----|-------|----------|
| Lab 1 | Auto-Configuration Lifecycle Diagnostics | `ConditionEvaluationReport`, `ApplicationReadyEvent` |
| Lab 2 | Custom Starter (non-web safe) | `@ConditionalOnClass(name=...)`, `AutoConfiguration.imports` |
| Lab 3 | Starter Ordering Conflict | `@AutoConfigureAfter`, `@ConditionalOnBean/MissingBean` |
| Lab 4 | Transaction-Aware Datasource Routing | `AbstractRoutingDataSource`, `TransactionSynchronizationManager` |
| Lab 5 | Prototype Scope + Concurrency | `ObjectProvider<T>`, `SCOPE_PROTOTYPE` |
| Lab 6 | Dynamic Bean Registration | `BeanDefinitionRegistryPostProcessor`, `BeanDefinitionBuilder` |

## Prerequisites
- Java 17+
- Maven 3.8+
- Spring Boot 3.2.x

## Running a Lab
```bash
cd lab1   # or lab2, lab3, lab4, lab5, lab6
mvn spring-boot:run
```

## Project Structure
Each lab is a self-contained Maven project under its own directory.
Labs build on each other conceptually, but are independent projects.
