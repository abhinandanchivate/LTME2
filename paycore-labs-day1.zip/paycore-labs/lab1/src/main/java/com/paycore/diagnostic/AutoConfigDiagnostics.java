package com.paycore.diagnostic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionEvaluationReport;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;

@Configuration
@ConditionalOnProperty(prefix = "paycore.diagnostics", name = "enabled", havingValue = "true")
public class AutoConfigDiagnostics {

    private static final Logger log = LoggerFactory.getLogger(AutoConfigDiagnostics.class);

    private final ApplicationContext context;
    private final Environment environment;

    public AutoConfigDiagnostics(ApplicationContext context, Environment environment) {
        this.context = context;
        this.environment = environment;
    }

    @EventListener(ApplicationReadyEvent.class)
    public void reportConditions() {
        try {
            ConditionEvaluationReport report = ConditionEvaluationReport
                    .get(context.getAutowireCapableBeanFactory());

            log.info("=== PayCore Auto-Configuration Report ===");

            // ACTIVE: all conditions matched
            report.getConditionAndOutcomesBySource().entrySet().stream()
                    .filter(e -> e.getValue().isFullMatch())
                    .forEach(e -> log.info("[ACTIVE] {}", simpleName(e.getKey())));

            // BACKED-OFF or SKIPPED: at least one condition failed
            report.getConditionAndOutcomesBySource().entrySet().stream()
                    .filter(e -> !e.getValue().isFullMatch())
                    .forEach(e -> e.getValue().forEach(outcome -> {
                        if (!outcome.getOutcome().isMatch()) {
                            String msg = outcome.getOutcome().getMessage();
                            if (msg != null && msg.contains("@ConditionalOnMissingBean")) {
                                log.info("[BACKED-OFF] {} — {}", simpleName(e.getKey()), msg);
                            } else {
                                log.info("[SKIPPED] {} — {}", simpleName(e.getKey()), msg);
                            }
                        }
                    }));

            // EXCLUDED
            if (!report.getExclusions().isEmpty()) {
                report.getExclusions().forEach(ex -> log.info("[EXCLUDED] {}", simpleName(ex)));
            }

            // Cross-check: warn if JPA properties set but JPA autoconfigure excluded
            boolean jpaExcluded = report.getExclusions().stream()
                    .anyMatch(ex -> ex.contains("HibernateJpaAutoConfiguration"));
            String ddlAuto = environment.getProperty("spring.jpa.hibernate.ddl-auto");
            if (jpaExcluded && ddlAuto != null) {
                log.warn("⚠ WARNING: spring.jpa.hibernate.ddl-auto is set but " +
                        "HibernateJpaAutoConfiguration is excluded — property has no effect");
            }

            log.info("=== End of Report ===");

        } catch (Exception e) {
            log.warn("Could not generate auto-configuration report: {}", e.getMessage());
        }
    }

    private String simpleName(String fqn) {
        int idx = fqn.lastIndexOf('.');
        return idx >= 0 ? fqn.substring(idx + 1) : fqn;
    }
}
