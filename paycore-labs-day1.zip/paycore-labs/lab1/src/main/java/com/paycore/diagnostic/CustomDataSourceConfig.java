package com.paycore.diagnostic;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import javax.sql.DataSource;

@Configuration
public class CustomDataSourceConfig {
    @Bean
    public DataSource dataSource() {
        // Custom DataSource — causes DataSourceAutoConfiguration to back off
        return new EmbeddedDatabaseBuilder()
                .setType(EmbeddedDatabaseType.H2)
                .setName("customDB")
                .build();
    }
}
