# Lab 1 — Lifecycle Visibility: Map the Auto-Configuration Phases

## Concepts Covered
ConditionEvaluationReport, ApplicationReadyEvent, @ConditionalOnProperty

## How to Run
```bash
mvn spring-boot:run
```

## Key Learning Points
- BACKED-OFF, SKIPPED, EXCLUDED map to different lifecycle phases
- ConditionEvaluationReport.get() must be wrapped in try-catch (treat as unstable API)
- Report fires on ApplicationReadyEvent — AFTER full context refresh
- Cross-check: JPA properties with HibernateJpaAutoConfiguration excluded = no effect

## Verification
- Report shows [ACTIVE], [BACKED-OFF], [SKIPPED], [EXCLUDED]
- WARNING appears for spring.jpa.hibernate.ddl-auto when JPA auto-config is excluded
