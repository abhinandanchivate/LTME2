package com.paycore.tenant;

/**
 * Immutable record representing a tenant configuration entry from clients.yaml.
 * The 'disabled' flag controls whether a TenantService bean is registered.
 */
public record TenantConfig(
        String id,
        String settlementCurrency,
        long dailyLimit,
        boolean disabled
) {}
