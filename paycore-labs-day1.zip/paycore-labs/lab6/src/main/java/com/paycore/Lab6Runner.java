package com.paycore;

import com.paycore.tenant.TenantRouter;
import com.paycore.tenant.TenantService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class Lab6Runner implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(Lab6Runner.class);
    private final TenantRouter tenantRouter;

    public Lab6Runner(TenantRouter tenantRouter) {
        this.tenantRouter = tenantRouter;
    }

    @Override
    public void run(String... args) {
        log.info("=== Lab 6: Dynamic Tenant Registration ===");

        // Active tenants — should succeed
        for (String tenantId : new String[]{"ACME_BANK", "APEX_CREDIT"}) {
            TenantService svc = tenantRouter.forTenant(tenantId);
            log.info("TenantService for {} — limit: {} {}", tenantId,
                    svc.getDailyLimitCents(), svc.getSettlementCurrency());
        }

        // Disabled tenant — should throw (was skipped during registration)
        try {
            tenantRouter.forTenant("GLOBAL_BANK");
            log.error("TEST FAILURE: GLOBAL_BANK should have been rejected (was disabled)");
        } catch (IllegalArgumentException e) {
            log.info("✓ Correctly rejected disabled tenant GLOBAL_BANK: {}", e.getMessage());
        }

        // Unknown tenant — should throw
        try {
            tenantRouter.forTenant("UNKNOWN_BANK");
            log.error("TEST FAILURE: UNKNOWN_BANK should have been rejected");
        } catch (IllegalArgumentException e) {
            log.info("✓ Correctly rejected unknown tenant UNKNOWN_BANK: {}", e.getMessage());
        }
    }
}
