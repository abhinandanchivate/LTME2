package com.paycore.tenant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Lab 6: BeanDefinitionRegistryPostProcessor for dynamic tenant registration.
 *
 * CRITICAL RULES for BeanDefinitionRegistryPostProcessor:
 * 1. Declare as top-level @Component (not inner class of @Configuration)
 * 2. Do NOT @Autowire dependencies — they aren't available yet at this phase
 * 3. Use static utilities only (TenantConfigLoader, BeanDefinitionBuilder)
 * 4. Handle all errors gracefully — a crash here kills the entire context
 *
 * Bean naming convention: tenantService_{tenantId.toLowerCase()}
 * e.g. ACME_BANK → tenantService_acme_bank
 */
@Component
public class TenantServiceRegistrar implements BeanDefinitionRegistryPostProcessor {
    private static final Logger log = LoggerFactory.getLogger(TenantServiceRegistrar.class);

    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) throws BeansException {
        List<TenantConfig> tenants = TenantConfigLoader.load();

        if (tenants.isEmpty()) {
            log.warn("No tenants loaded — zero TenantService beans will be registered");
            return;
        }

        for (TenantConfig tenant : tenants) {
            if (tenant.disabled()) {
                log.warn("[SKIPPED] {} — disabled in clients.yaml", tenant.id());
                continue;
            }

            String beanName = "tenantService_" + tenant.id().toLowerCase();
            BeanDefinition def = BeanDefinitionBuilder
                    .genericBeanDefinition(TenantService.class)
                    .addConstructorArgValue(tenant.id())
                    .addConstructorArgValue(tenant.settlementCurrency())
                    .addConstructorArgValue(tenant.dailyLimit())
                    .setScope(BeanDefinition.SCOPE_SINGLETON)
                    .getBeanDefinition();

            registry.registerBeanDefinition(beanName, def);
            log.info("[REGISTERED] {} (limit={}, currency={})",
                    beanName, tenant.dailyLimit(), tenant.settlementCurrency());
        }
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) throws BeansException {
        // No factory-level modifications needed
    }
}
