package com.paycore.tenant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Per-tenant service bean. One instance is registered per active tenant.
 * Bean names follow the convention: tenantService_{tenantId_lowercase}
 * e.g. tenantService_acme_bank, tenantService_apex_credit
 */
public class TenantService {
    private static final Logger log = LoggerFactory.getLogger(TenantService.class);

    private final String tenantId;
    private final String settlementCurrency;
    private final long dailyLimitCents;

    public TenantService(String tenantId, String settlementCurrency, long dailyLimitCents) {
        this.tenantId = tenantId;
        this.settlementCurrency = settlementCurrency;
        this.dailyLimitCents = dailyLimitCents;
        log.info("TenantService initialized for tenant: {}", tenantId);
    }

    public String getTenantId() { return tenantId; }
    public String getSettlementCurrency() { return settlementCurrency; }
    public long getDailyLimitCents() { return dailyLimitCents; }
}
