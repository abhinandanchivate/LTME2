package com.paycore.tenant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * Lab 6: Resilient YAML config loader for the bean definition phase.
 *
 * Design decisions:
 * - Returns empty list (not exception) when clients.yaml is missing
 * - Returns empty list (not exception) when YAML is malformed
 * - Called from BeanDefinitionRegistryPostProcessor — no Spring beans available here
 */
public class TenantConfigLoader {
    private static final Logger log = LoggerFactory.getLogger(TenantConfigLoader.class);

    @SuppressWarnings("unchecked")
    public static List<TenantConfig> load() {
        InputStream stream = TenantConfigLoader.class.getResourceAsStream("/clients.yaml");
        if (stream == null) {
            log.warn("clients.yaml not found — starting with zero tenant registrations");
            return List.of();
        }
        try {
            org.yaml.snakeyaml.Yaml yaml = new org.yaml.snakeyaml.Yaml();
            Map<String, Object> root = yaml.load(stream);
            List<Map<String, Object>> tenants = (List<Map<String, Object>>) root.get("tenants");
            return tenants.stream()
                    .map(m -> new TenantConfig(
                            (String) m.get("id"),
                            (String) m.get("settlementCurrency"),
                            ((Number) m.get("dailyLimit")).longValue(),
                            Boolean.TRUE.equals(m.get("disabled"))
                    ))
                    .toList();
        } catch (Exception e) {
            log.error("Failed to parse clients.yaml — starting with zero tenant registrations: {}", e.getMessage());
            return List.of();
        }
    }
}
