package com.paycore.tenant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

/**
 * Runtime router that resolves TenantService beans by tenant ID.
 * Throws IllegalArgumentException for disabled or unknown tenants.
 */
@Component
public class TenantRouter {
    private static final Logger log = LoggerFactory.getLogger(TenantRouter.class);
    private final ApplicationContext context;

    public TenantRouter(ApplicationContext context) {
        this.context = context;
    }

    public TenantService forTenant(String tenantId) {
        String beanName = "tenantService_" + tenantId.toLowerCase();
        try {
            return context.getBean(beanName, TenantService.class);
        } catch (NoSuchBeanDefinitionException e) {
            log.error("No TenantService for tenant: {}", tenantId);
            throw new IllegalArgumentException("Unknown tenant: " + tenantId, e);
        }
    }
}
