# Lab 6 — BeanDefinitionRegistryPostProcessor: Dynamic Tenant Registration

## Concepts Covered
BeanDefinitionRegistryPostProcessor, BeanDefinitionBuilder, dynamic bean registration

## How to Run
```bash
mvn spring-boot:run
```

## Key Learning Points
- BeanDefinitionRegistryPostProcessor runs BEFORE beans are instantiated
- Do NOT @Autowire dependencies inside it — Spring beans aren't ready yet
- Use static utility methods only (TenantConfigLoader uses static load())
- Declare as top-level @Component, not nested inside @Configuration
- disabled: true in clients.yaml → bean is skipped, not registered

## Edge Case Testing
- Rename clients.yaml → clients.yaml.bak and restart
- App should start cleanly with WARN log and zero tenant beans registered

## Verification
- tenantService_acme_bank and tenantService_apex_credit registered
- GLOBAL_BANK correctly skipped (disabled: true)
- IllegalArgumentException thrown for GLOBAL_BANK and UNKNOWN_BANK at runtime
- Missing clients.yaml handled gracefully (no startup failure)
