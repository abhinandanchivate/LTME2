package com.paycore.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.web.SecurityFilterChain;

public class AuditSecurityBridge {
    private static final Logger log = LoggerFactory.getLogger(AuditSecurityBridge.class);

    public AuditSecurityBridge(SecurityFilterChain filterChain, AuditLogger logger) {
        log.info("AuditSecurityBridge registered (depends on SecurityFilterChain)");
    }
}
