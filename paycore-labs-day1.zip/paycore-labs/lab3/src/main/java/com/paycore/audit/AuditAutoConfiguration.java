package com.paycore.audit;

import com.paycore.security.SecurityAutoConfiguration;
import com.paycore.security.DefaultSecurityFilterChain;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Lab 3: Ordering Conflict Resolution.
 *
 * KEY MECHANISMS:
 * 1. @AutoConfigureAfter(SecurityAutoConfiguration.class) — ensures security runs first
 * 2. @ConditionalOnMissingBean(SecurityFilterChain.class) — fallback only if no chain exists
 * 3. @ConditionalOnBean(SecurityFilterChain.class) — bridge only if chain exists (from any source)
 *
 * WARNING: @AutoConfigureAfter only SUGGESTS ordering — it does NOT guarantee the target ran.
 * Always combine with @ConditionalOnBean to safely express the dependency.
 */
@AutoConfiguration
@AutoConfigureAfter(SecurityAutoConfiguration.class)
@ConditionalOnProperty(prefix = "paycore.audit", name = "enabled", havingValue = "true", matchIfMissing = true)
@EnableConfigurationProperties(AuditProperties.class)
public class AuditAutoConfiguration {
    private static final Logger log = LoggerFactory.getLogger(AuditAutoConfiguration.class);

    @Bean
    @ConditionalOnMissingBean
    public AuditLogger auditLogger(AuditProperties properties) {
        return new AuditLogger(properties);
    }

    // Fallback SecurityFilterChain — only activates if SecurityAutoConfiguration did NOT run
    @Bean("auditDefaultSecurityFilterChain")
    @ConditionalOnMissingBean(SecurityFilterChain.class)
    public SecurityFilterChain fallbackSecurityFilterChain() {
        log.info("Registering fallback SecurityFilterChain (no security starter present)");
        return new DefaultSecurityFilterChain();
    }

    // AuditSecurityBridge — only registers if a SecurityFilterChain exists (from ANY source)
    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnBean(SecurityFilterChain.class)
    public AuditSecurityBridge auditSecurityBridge(SecurityFilterChain filterChain, AuditLogger logger) {
        return new AuditSecurityBridge(filterChain, logger);
    }

    // AuditInterceptor — only in web contexts
    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnWebApplication
    public AuditInterceptor auditInterceptor(AuditLogger logger, AuditProperties properties) {
        return new AuditInterceptor(logger, properties);
    }
}
