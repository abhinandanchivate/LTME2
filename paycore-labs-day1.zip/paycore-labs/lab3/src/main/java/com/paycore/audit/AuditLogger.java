package com.paycore.audit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.time.Instant;

public class AuditLogger {
    private static final Logger log = LoggerFactory.getLogger(AuditLogger.class);
    private final AuditProperties properties;

    public AuditLogger(AuditProperties properties) { this.properties = properties; }

    public void log(String txnId, String userId, String action, String result) {
        log.info("[AUDIT] txn={} user={} action={} result={} ts={}", txnId, userId, action, result, Instant.now());
    }
}
