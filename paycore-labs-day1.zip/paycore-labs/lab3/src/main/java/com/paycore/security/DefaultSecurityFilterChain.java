package com.paycore.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import org.springframework.security.web.SecurityFilterChain;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class DefaultSecurityFilterChain implements SecurityFilterChain {
    @Override
    public boolean matches(jakarta.servlet.http.HttpServletRequest request) { return true; }
    @Override
    public List<jakarta.servlet.Filter> getFilters() { return Collections.emptyList(); }
}
