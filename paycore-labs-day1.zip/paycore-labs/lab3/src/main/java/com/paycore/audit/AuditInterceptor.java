package com.paycore.audit;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

public class AuditInterceptor implements HandlerInterceptor, WebMvcConfigurer {
    private final AuditLogger auditLogger;
    private final AuditProperties properties;

    public AuditInterceptor(AuditLogger auditLogger, AuditProperties properties) {
        this.auditLogger = auditLogger;
        this.properties = properties;
    }

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(this);
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if (!properties.getMethods().contains(request.getMethod())) return true;
        String txnId = getHeader(request, "X-Transaction-Id", "TXN-UNKNOWN");
        String userId = getHeader(request, "X-User-Id", "ANON");
        auditLogger.log(txnId, userId, request.getMethod() + " " + request.getRequestURI(), "INITIATED");
        return true;
    }

    private String getHeader(HttpServletRequest req, String name, String def) {
        String v = req.getHeader(name);
        return v != null && !v.isBlank() ? v : def;
    }
}
