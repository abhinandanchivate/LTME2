# Lab 3 — Ordering Conflict: Two Starters, One Bean, One Winner

## Concepts Covered
@AutoConfigureAfter, @ConditionalOnBean, @ConditionalOnMissingBean, SecurityFilterChain ordering

## How to Run
```bash
mvn spring-boot:run
```

## Key Learning Points
- @AutoConfigureAfter only SUGGESTS ordering — combine with @ConditionalOnBean for safety
- SecurityAutoConfiguration runs first and registers SecurityFilterChain
- AuditAutoConfiguration runs after and skips its fallback (ConditionalOnMissingBean)
- AuditSecurityBridge uses @ConditionalOnBean to safely depend on SecurityFilterChain

## Verification
- Only ONE SecurityFilterChain in context when both starters present
- AuditSecurityBridge is registered
- No NoUniqueBeanDefinitionException
