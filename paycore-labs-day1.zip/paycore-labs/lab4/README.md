# Lab 4 — Transaction-Aware Datasource Routing

## Concepts Covered
AbstractRoutingDataSource, TransactionSynchronizationManager, determineCurrentLookupKey()

## How to Run
```bash
mvn spring-boot:run
```

## Key Learning Points
- determineCurrentLookupKey() runs at CONNECTION ACQUISITION TIME — inside the TX lifecycle
- TransactionSynchronizationManager.isCurrentTransactionReadOnly() is set by @Transactional BEFORE connection is acquired
- This eliminates the aspect ordering problem (no ReadOnlyRoutingAspect needed)
- Two separate H2 in-memory DBs simulate primary/replica split

## Verification
- [TX ACTIVE, readOnly=false] → PRIMARY for @Transactional write
- [TX ACTIVE, readOnly=true]  → REPLICA for @Transactional(readOnly=true)
- [NO ACTIVE TX]              → PRIMARY for non-transactional code
