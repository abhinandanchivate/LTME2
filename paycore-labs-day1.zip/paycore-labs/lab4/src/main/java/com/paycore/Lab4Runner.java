package com.paycore;

import com.paycore.payment.PaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.math.BigDecimal;

@Component
public class Lab4Runner implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(Lab4Runner.class);
    private final PaymentService paymentService;
    private final JdbcTemplate jdbc;

    public Lab4Runner(PaymentService paymentService, DataSource dataSource) {
        this.paymentService = paymentService;
        this.jdbc = new JdbcTemplate(dataSource);
    }

    @Override
    public void run(String... args) {
        log.info("=== Lab 4: Transaction-Aware Datasource Routing ===");

        // Transactional write → PRIMARY
        paymentService.save(new BigDecimal("1500.00"));

        // Transactional read-only → REPLICA
        paymentService.findAll();

        // Non-transactional direct query → defaults to PRIMARY
        log.info("=== Non-transactional query (no @Transactional) ===");
        int count = jdbc.queryForObject("SELECT COUNT(*) FROM payments", Integer.class);
        log.info("Non-transactional count query result: {}", count);
    }
}
