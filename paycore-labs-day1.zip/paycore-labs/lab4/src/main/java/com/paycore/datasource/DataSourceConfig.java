package com.paycore.datasource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

import javax.sql.DataSource;
import java.util.Map;

@Configuration
public class DataSourceConfig {

    @Bean(name = "primaryDataSource")
    public DataSource primaryDataSource() {
        return new EmbeddedDatabaseBuilder()
                .setName("primaryDB")
                .setType(EmbeddedDatabaseType.H2)
                .addScript("classpath:schema.sql")
                .build();
    }

    @Bean(name = "replicaDataSource")
    public DataSource replicaDataSource() {
        return new EmbeddedDatabaseBuilder()
                .setName("replicaDB")
                .setType(EmbeddedDatabaseType.H2)
                .addScript("classpath:schema.sql")
                .build();
    }

    @Primary
    @Bean(name = "routingDataSource")
    public DataSource routingDataSource(
            @Qualifier("primaryDataSource") DataSource primary,
            @Qualifier("replicaDataSource") DataSource replica) {
        RoutingDataSource router = new RoutingDataSource();
        router.setTargetDataSources(Map.of(
                DataSourceContext.DataSourceType.PRIMARY, primary,
                DataSourceContext.DataSourceType.REPLICA, replica
        ));
        router.setDefaultTargetDataSource(primary);
        router.afterPropertiesSet();
        return router;
    }
}
