package com.paycore.datasource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * Lab 4: Transaction-Aware Datasource Routing.
 *
 * KEY INSIGHT: determineCurrentLookupKey() is called at connection acquisition time,
 * AFTER @Transactional has set the readOnly flag on TransactionSynchronizationManager.
 * This avoids the aspect ordering problem entirely — no ReadOnlyRoutingAspect needed.
 *
 * Routing logic:
 *   - Active TX + readOnly=true  → REPLICA
 *   - Active TX + readOnly=false → PRIMARY
 *   - No active TX              → PRIMARY (or ThreadLocal context)
 */
public class RoutingDataSource extends AbstractRoutingDataSource {
    private static final Logger log = LoggerFactory.getLogger(RoutingDataSource.class);

    @Override
    protected Object determineCurrentLookupKey() {
        if (TransactionSynchronizationManager.isActualTransactionActive()) {
            boolean readOnly = TransactionSynchronizationManager.isCurrentTransactionReadOnly();
            DataSourceContext.DataSourceType target = readOnly
                    ? DataSourceContext.DataSourceType.REPLICA
                    : DataSourceContext.DataSourceType.PRIMARY;
            log.info("[TX ACTIVE, readOnly={}] → {}", readOnly, target);
            return target;
        }
        DataSourceContext.DataSourceType target = DataSourceContext.getCurrent();
        log.info("[NO ACTIVE TX] → {} (default)", target);
        return target;
    }
}
