package com.paycore.payment;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class PaymentService {
    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);
    private final JdbcTemplate jdbc;

    public PaymentService(DataSource dataSource) {
        this.jdbc = new JdbcTemplate(dataSource); // Uses the routing datasource (@Primary)
    }

    @Transactional  // readOnly=false → determineCurrentLookupKey → PRIMARY
    public String save(BigDecimal amount) {
        String id = UUID.randomUUID().toString();
        jdbc.update("INSERT INTO payments(id, amount, status) VALUES (?, ?, ?)", id, amount, "PENDING");
        log.info("Saved payment {}", id);
        return id;
    }

    @Transactional(readOnly = true)  // readOnly=true → determineCurrentLookupKey → REPLICA
    public List<Map<String, Object>> findAll() {
        List<Map<String, Object>> rows = jdbc.queryForList("SELECT * FROM payments");
        log.info("Loaded {} payments from replica (expected — separate H2 instance)", rows.size());
        return rows;
    }
}
