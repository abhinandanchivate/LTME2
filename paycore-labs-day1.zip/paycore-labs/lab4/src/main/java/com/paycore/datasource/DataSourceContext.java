package com.paycore.datasource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ThreadLocal context for non-transactional datasource routing fallback.
 * For transactional code, RoutingDataSource reads TransactionSynchronizationManager directly.
 */
public final class DataSourceContext {
    private static final Logger log = LoggerFactory.getLogger(DataSourceContext.class);

    public enum DataSourceType { PRIMARY, REPLICA }

    private static final ThreadLocal<DataSourceType> CONTEXT =
            ThreadLocal.withInitial(() -> DataSourceType.PRIMARY);

    private DataSourceContext() {}

    public static void usePrimary() { CONTEXT.set(DataSourceType.PRIMARY); }
    public static void useReplica() { CONTEXT.set(DataSourceType.REPLICA); }
    public static DataSourceType getCurrent() { return CONTEXT.get(); }

    public static void clear() {
        log.debug("Clearing datasource context — was: {}", CONTEXT.get());
        CONTEXT.remove();
    }
}
