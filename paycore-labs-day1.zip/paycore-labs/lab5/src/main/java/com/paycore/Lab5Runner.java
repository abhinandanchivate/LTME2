package com.paycore;

import com.paycore.fraud.FraudAnalyzer;
import com.paycore.fraud.PaymentProcessingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

@Component
public class Lab5Runner implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(Lab5Runner.class);
    private final PaymentProcessingService service;

    public Lab5Runner(PaymentProcessingService service) {
        this.service = service;
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("=== Lab 5: Prototype Scope Concurrency Test ===");

        ExecutorService pool = Executors.newFixedThreadPool(10);
        List<Future<FraudAnalyzer.FraudResult>> futures = new ArrayList<>();

        // amounts[2]=150000 and amounts[5]=200000 should be REJECTED (>100k)
        BigDecimal[] amounts = {
                new BigDecimal("500"),    // APPROVED
                new BigDecimal("1200"),   // APPROVED
                new BigDecimal("150000"), // REJECTED ← > 100k
                new BigDecimal("750"),    // APPROVED
                new BigDecimal("99000"),  // APPROVED (just under limit)
                new BigDecimal("200000"), // REJECTED ← > 100k
                new BigDecimal("300"),    // APPROVED
                new BigDecimal("45000"),  // APPROVED
                new BigDecimal("5000"),   // APPROVED
                new BigDecimal("800")     // APPROVED
        };

        for (int i = 0; i < 10; i++) {
            final int idx = i;
            futures.add(pool.submit(() ->
                    service.evaluate("PAYMENT-" + String.format("%03d", idx + 1),
                            amounts[idx], "IN")
            ));
        }

        AtomicInteger approved = new AtomicInteger();
        AtomicInteger rejected = new AtomicInteger();

        for (var future : futures) {
            FraudAnalyzer.FraudResult result = future.get(5, TimeUnit.SECONDS);
            if (result.approved()) approved.incrementAndGet();
            else rejected.incrementAndGet();
        }

        pool.shutdown();

        log.info("Total: 10 | Approved: {} | Rejected: {} | No cross-contamination detected",
                approved.get(), rejected.get());

        if (rejected.get() != 2) {
            log.error("ISOLATION FAILURE: expected exactly 2 rejections, got {}. " +
                    "Prototype scope is likely broken.", rejected.get());
        } else {
            log.info("✓ Isolation verified — exactly 2 high-value rejections, no cross-contamination");
        }
    }
}
