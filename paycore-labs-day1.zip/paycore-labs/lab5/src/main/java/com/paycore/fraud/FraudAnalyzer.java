package com.paycore.fraud;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Lab 5: Prototype-scoped FraudAnalyzer.
 *
 * WHY PROTOTYPE:
 * Each payment evaluation must be completely isolated — no shared state between
 * concurrent requests. With prototype scope + ObjectProvider, every getObject()
 * call creates a fresh instance with an empty signals list.
 *
 * ANTI-PATTERN (the broken colleague's fix):
 *   @Autowired FraudAnalyzer fraudAnalyzer  ← Spring resolves ONCE at construction!
 *   fraudAnalyzer.reset()                   ← reset() is a code smell for prototype beans
 *
 * CORRECT PATTERN: ObjectProvider<FraudAnalyzer> — see PaymentProcessingService.
 */
@Component
@Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class FraudAnalyzer {
    private static final Logger log = LoggerFactory.getLogger(FraudAnalyzer.class);

    private final List<String> signals = new ArrayList<>();
    private String paymentId;

    // No reset() method — each instance starts fresh
    public void init(String paymentId) {
        this.paymentId = paymentId;
    }

    public void addSignal(String signal) {
        signals.add(signal);
    }

    public FraudResult evaluate(String paymentId) {
        log.info("Evaluating {} signals for payment {} (amount: {})",
                signals.size(), paymentId,
                signals.stream().filter(s -> s.startsWith("amount:"))
                        .findFirst().map(s -> s.substring(7)).orElse("unknown"));

        boolean highValue = signals.stream()
                .filter(s -> s.startsWith("amount:"))
                .anyMatch(s -> {
                    try {
                        return Double.parseDouble(s.substring(7)) > 100_000;
                    } catch (NumberFormatException e) {
                        return false;
                    }
                });

        if (highValue) {
            return new FraudResult(paymentId, false, "High-value transaction flagged");
        }
        return new FraudResult(paymentId, true, "Approved");
    }

    public record FraudResult(String paymentId, boolean approved, String reason) {}
}
