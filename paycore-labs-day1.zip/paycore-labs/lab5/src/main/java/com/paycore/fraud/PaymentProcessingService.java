package com.paycore.fraud;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

/**
 * Lab 5: Correct use of ObjectProvider for prototype-scoped beans.
 *
 * ObjectProvider.getObject() creates a new FraudAnalyzer instance on each call,
 * ensuring complete isolation between concurrent payment evaluations.
 *
 * BROKEN approach (what the colleague did):
 *   private final FraudAnalyzer fraudAnalyzer;  // single shared instance!
 *   public PaymentProcessingService(FraudAnalyzer fa) { this.fraudAnalyzer = fa; }
 *   // Spring injects the prototype ONCE — it's effectively singleton!
 */
@Service
public class PaymentProcessingService {
    private static final Logger log = LoggerFactory.getLogger(PaymentProcessingService.class);

    // ObjectProvider is prototype-aware — getObject() returns a NEW instance every call
    private final ObjectProvider<FraudAnalyzer> fraudAnalyzerProvider;

    public PaymentProcessingService(ObjectProvider<FraudAnalyzer> fraudAnalyzerProvider) {
        this.fraudAnalyzerProvider = fraudAnalyzerProvider;
    }

    public FraudAnalyzer.FraudResult evaluate(String paymentId, BigDecimal amount, String country) {
        // Fresh instance — zero shared state with other threads
        FraudAnalyzer analyzer = fraudAnalyzerProvider.getObject();
        analyzer.init(paymentId);
        analyzer.addSignal("amount:" + amount.toPlainString());
        analyzer.addSignal("country:" + country);
        analyzer.addSignal("id:" + paymentId);

        FraudAnalyzer.FraudResult result = analyzer.evaluate(paymentId);
        log.info("RESULT {}: {} ({})", paymentId,
                result.approved() ? "APPROVED" : "REJECTED", result.reason());
        return result;
    }
}
