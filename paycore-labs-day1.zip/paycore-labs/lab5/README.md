# Lab 5 — Concurrency and Scope: Prove Isolation Under Load

## Concepts Covered
SCOPE_PROTOTYPE, ObjectProvider<T>, thread isolation, ExecutorService

## How to Run
```bash
mvn spring-boot:run
```

## Key Learning Points
- Direct @Autowired injection of a @Scope(PROTOTYPE) bean is WRONG — Spring injects once!
- ObjectProvider<T>.getObject() creates a NEW instance on every call
- No reset() method needed — prototype beans start fresh by design
- reset() method on a prototype bean is a code smell indicating misuse

## The Broken Pattern (what the colleague did)
```java
// WRONG: Spring resolves FraudAnalyzer ONCE at construction time
private final FraudAnalyzer fraudAnalyzer;
public Service(FraudAnalyzer fa) { this.fraudAnalyzer = fa; }
```

## The Correct Pattern
```java
// RIGHT: ObjectProvider creates a new instance per getObject() call
private final ObjectProvider<FraudAnalyzer> provider;
FraudAnalyzer analyzer = provider.getObject(); // fresh every time
```

## Verification
- 10 concurrent evaluations complete without error
- Exactly 2 REJECTED (amounts > 100,000)
- No cross-contamination between threads
