# NgRx Micro-Frontend — Angular 20

> Module Federation + NgRx Shared State · Shell + 2 MFEs · NgModule pattern

---

## Architecture Overview

```
ngrx-mfe-workspace/
├── shell/                    ← HOST app (port 4200)
│   ├── webpack.config.js     ← Module Federation HOST config
│   ├── src/app/
│   │   ├── app.module.ts     ← Root NgModule, registers NgRx root store
│   │   ├── store/
│   │   │   ├── app.state.ts           ← Shared state interfaces
│   │   │   ├── actions/
│   │   │   │   ├── user.actions.ts    ← loginUser, logoutUser, setCurrentUser
│   │   │   │   └── cart.actions.ts    ← addToCart, removeFromCart, clearCart
│   │   │   ├── reducers/
│   │   │   │   ├── user.reducer.ts
│   │   │   │   ├── cart.reducer.ts
│   │   │   │   └── index.ts           ← ActionReducerMap
│   │   │   ├── effects/
│   │   │   │   └── user.effects.ts    ← Simulated auth API call
│   │   │   └── selectors/
│   │   │       └── app.selectors.ts   ← Shared selectors (user + cart)
│   │   └── core/
│   │       ├── navbar/                ← Reads user + cart from shared store
│   │       ├── home/                  ← Shows live shared state
│   │       └── login/                 ← Dispatches loginUser action
│
├── mfe1-products/            ← REMOTE app (port 4201)
│   ├── webpack.config.js     ← Exposes './Module' → ProductsModule
│   ├── src/app/products/
│   │   ├── products.module.ts         ← ⭐ EXPOSED MODULE
│   │   ├── store/
│   │   │   ├── products.state.ts
│   │   │   ├── actions/products.actions.ts
│   │   │   ├── reducers/products.reducer.ts
│   │   │   ├── effects/products.effects.ts  ← Cross-MFE: dispatches addToCart
│   │   │   └── selectors/products.selectors.ts
│   │   └── components/
│   │       └── products-list.component.ts   ← Reads shell's user + cart state
│
└── mfe2-orders/              ← REMOTE app (port 4202)
    ├── webpack.config.js     ← Exposes './Module' → OrdersModule
    ├── src/app/orders/
    │   ├── orders.module.ts           ← ⭐ EXPOSED MODULE
    │   ├── store/
    │   │   ├── orders.state.ts
    │   │   ├── actions/orders.actions.ts
    │   │   ├── reducers/orders.reducer.ts
    │   │   ├── effects/orders.effects.ts    ← Cross-MFE: dispatches clearCart
    │   │   └── selectors/orders.selectors.ts
    │   └── components/
    │       └── orders-list.component.ts     ← Reads shell's cart + user state
```

---

## How State Sharing Works

### The Key Insight: NgRx as a Singleton

Module Federation's `singleton: true` for `@ngrx/store` means every app
shares **the exact same Store instance** at runtime:

```
Shell bootstraps NgRx root store ──→ { user: UserState, cart: CartState }
                                              │
              ┌───────────────────────────────┤
              ↓                               ↓
     MFE1 (Products)                MFE2 (Orders)
     StoreModule.forFeature(         StoreModule.forFeature(
       'products', reducer)            'orders', reducer)
              │                               │
              └──────── same Store ───────────┘
                    { user, cart, products, orders }
```

### Cross-MFE State Flow

```
User clicks "Add to Cart" in MFE1
         ↓
dispatch(addProductToCart({ productId, price }))   ← MFE1 action
         ↓
ProductsEffects.addToCart$
         ↓
dispatch(addToCart({ item }))   ← Shell's cart action!
         ↓
CartReducer updates state
         ↓
Shell Navbar re-renders cart badge  ← Observable update
MFE2 OrdersListComponent re-renders cart items  ← Observable update
```

---

## Running the Project

### Step 1 — Install dependencies

```bash
cd shell && npm install
cd ../mfe1-products && npm install
cd ../mfe2-orders && npm install
cd .. && npm install   # installs concurrently
```

### Step 2 — Start all apps (run from workspace root)

```bash
# Start all three simultaneously
npm run start:all

# Or individually:
npm run start:mfe1   # http://localhost:4201
npm run start:mfe2   # http://localhost:4202
npm run start:shell  # http://localhost:4200  ← open this
```

### ⚠️ Important: MFEs must be running BEFORE the shell loads their routes

---

## NgRx State Diagram

```
AppState (Root Store — registered in Shell)
├── user: UserState
│   ├── currentUser: User | null
│   ├── isAuthenticated: boolean
│   ├── loading: boolean
│   └── error: string | null
│
└── cart: CartState
    ├── items: CartItem[]
    ├── totalItems: number
    └── totalPrice: number

products: ProductsState  (Feature — registered in MFE1)
├── products: Product[]
├── selectedProduct: Product | null
├── loading: boolean
├── error: string | null
└── filter: string

orders: OrdersState  (Feature — registered in MFE2)
├── orders: Order[]
├── selectedOrder: Order | null
├── loading: boolean
├── placingOrder: boolean
└── error: string | null
```

---

## Module Federation Config Reference

### Shell — webpack.config.js (HOST)

```js
remotes: {
  mfe1Products: 'mfe1Products@http://localhost:4201/remoteEntry.js',
  mfe2Orders:   'mfe2Orders@http://localhost:4202/remoteEntry.js',
}
```

### MFE1 — webpack.config.js (REMOTE)

```js
exposes: {
  './Module': './src/app/products/products.module.ts'
}
```

### MFE2 — webpack.config.js (REMOTE)

```js
exposes: {
  './Module': './src/app/orders/orders.module.ts'
}
```

---

## Key Angular Module Registrations

| App    | NgModule Registration          | Purpose                              |
|--------|-------------------------------|--------------------------------------|
| Shell  | `StoreModule.forRoot(reducers)` | Creates the root store (user, cart)  |
| Shell  | `EffectsModule.forRoot([UserEffects])` | Root effects               |
| MFE1   | `StoreModule.forFeature('products', productsReducer)` | Adds products slice |
| MFE1   | `EffectsModule.forFeature([ProductsEffects])` | Adds products effects  |
| MFE2   | `StoreModule.forFeature('orders', ordersReducer)` | Adds orders slice   |
| MFE2   | `EffectsModule.forFeature([OrdersEffects])` | Adds orders effects    |

---

## NgRx DevTools

Open **Redux DevTools** browser extension to see all state slices and actions
from all MFEs in a single timeline — because they all share one store.

---

## Tech Stack

- **Angular 20** — NgModule (non-standalone) pattern
- **@ngrx/store** v19 — State management
- **@ngrx/effects** v19 — Side effects
- **@ngrx/store-devtools** v19 — DevTools integration
- **@angular-architects/module-federation** v21 — Webpack Module Federation
- **@angular-builders/custom-webpack** — Custom webpack for MF
- **Webpack 5** — Module Federation runtime
