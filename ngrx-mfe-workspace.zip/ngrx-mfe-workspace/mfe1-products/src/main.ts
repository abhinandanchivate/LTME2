// ============================================================
// MFE1: src/main.ts  — deferred bootstrap for Module Federation
// ============================================================

import('./bootstrap').catch((err) => console.error(err));
