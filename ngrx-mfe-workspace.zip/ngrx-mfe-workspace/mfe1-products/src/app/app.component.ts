// ============================================================
// MFE1: src/app/app.component.ts
// ============================================================

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<router-outlet></router-outlet>`,
})
export class AppComponent {
  title = 'mfe1-products';
}
