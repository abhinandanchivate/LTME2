// ============================================================
// MFE1: src/app/products/components/products-list.component.ts
// Reads from MFE1's feature store AND Shell's shared store
// ============================================================

import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Product } from '../store/products.state';
import { loadProducts, selectProduct, setFilter, addProductToCart } from '../store/actions/products.actions';
import { selectFilteredProducts, selectProductsLoading, selectFilter } from '../store/selectors/products.selectors';

// ⭐ Reading SHARED state from the Shell's root store
import { selectUserName, selectIsAuthenticated, selectCartTotalItems } from '../../../../../../../shell/src/app/store/selectors/app.selectors';

@Component({
  selector: 'app-products-list',
  template: `
    <div class="products-page">
      <div class="page-header">
        <div>
          <h1>📦 Products</h1>
          <p class="subtitle">MFE1 · Feature Store + Shared State</p>
        </div>

        <!-- ⭐ Reading from SHELL's root store (shared state) -->
        <div class="shared-state-banner">
          <div class="state-pill">
            <span class="pill-label">Shared User</span>
            <span class="pill-value">👤 {{ userName$ | async }}</span>
          </div>
          <div class="state-pill">
            <span class="pill-label">Cart</span>
            <span class="pill-value cart">🛒 {{ cartCount$ | async }} items</span>
          </div>
        </div>
      </div>

      <div class="search-bar">
        <input
          type="text"
          placeholder="🔍 Search products by name or category..."
          [value]="(filter$ | async) || ''"
          (input)="onFilter($event)"
        />
      </div>

      <div class="loading-state" *ngIf="loading$ | async">
        <div class="spinner"></div>
        <span>Loading products from NgRx store...</span>
      </div>

      <div class="products-grid" *ngIf="!(loading$ | async)">
        <div
          class="product-card"
          *ngFor="let product of products$ | async"
          (click)="onSelectProduct(product)"
        >
          <div class="product-icon">{{ product.imageUrl }}</div>
          <div class="product-info">
            <span class="product-category">{{ product.category }}</span>
            <h3>{{ product.name }}</h3>
            <p>{{ product.description }}</p>
          </div>
          <div class="product-footer">
            <span class="product-price">\${{ product.price }}</span>
            <button
              class="btn-add"
              (click)="onAddToCart($event, product)"
              [disabled]="!(isAuthenticated$ | async)"
            >
              {{ (isAuthenticated$ | async) ? '+ Add to Cart' : '🔒 Login to buy' }}
            </button>
          </div>
          <div class="stock-badge" [class.low]="product.stock < 50">
            {{ product.stock }} in stock
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .products-page { padding: 32px 24px; max-width: 1000px; margin: 0 auto; }
    .page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    h1 { margin: 0 0 4px; font-size: 28px; color: #1e293b; }
    .subtitle { margin: 0; font-size: 13px; color: #94a3b8; }

    .shared-state-banner { display: flex; gap: 12px; }
    .state-pill {
      display: flex;
      flex-direction: column;
      align-items: center;
      background: linear-gradient(135deg, #ede9fe, #e0e7ff);
      border: 1px solid #c4b5fd;
      border-radius: 12px;
      padding: 8px 16px;
      min-width: 120px;
    }
    .pill-label { font-size: 10px; color: #7c3aed; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; }
    .pill-value { font-size: 14px; font-weight: 700; color: #4c1d95; }
    .pill-value.cart { color: #0284c7; }

    .search-bar { margin-bottom: 24px; }
    .search-bar input {
      width: 100%;
      padding: 12px 16px;
      border: 2px solid #e5e7eb;
      border-radius: 12px;
      font-size: 14px;
      outline: none;
      box-sizing: border-box;
      transition: border-color 0.2s;
    }
    .search-bar input:focus { border-color: #7c3aed; }

    .loading-state { display: flex; align-items: center; justify-content: center; gap: 12px; padding: 60px; color: #64748b; }
    .spinner { width: 24px; height: 24px; border: 3px solid #e2e8f0; border-top-color: #7c3aed; border-radius: 50%; animation: spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    .products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; }
    .product-card {
      background: #fff;
      border: 2px solid #e2e8f0;
      border-radius: 16px;
      padding: 20px;
      cursor: pointer;
      transition: all 0.2s;
      position: relative;
      overflow: hidden;
    }
    .product-card:hover { border-color: #7c3aed; box-shadow: 0 8px 24px rgba(124,58,237,0.12); transform: translateY(-2px); }
    .product-icon { font-size: 36px; margin-bottom: 12px; }
    .product-category { font-size: 11px; color: #7c3aed; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; }
    .product-info h3 { margin: 4px 0 8px; font-size: 16px; color: #1e293b; }
    .product-info p { font-size: 13px; color: #64748b; margin: 0 0 16px; }
    .product-footer { display: flex; justify-content: space-between; align-items: center; }
    .product-price { font-size: 20px; font-weight: 800; color: #1e293b; }
    .btn-add {
      background: #7c3aed;
      color: #fff;
      border: none;
      padding: 8px 14px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
    }
    .btn-add:hover:not(:disabled) { background: #6d28d9; }
    .btn-add:disabled { background: #94a3b8; cursor: not-allowed; font-size: 11px; }
    .stock-badge {
      position: absolute;
      top: 12px; right: 12px;
      background: #dcfce7;
      color: #16a34a;
      font-size: 10px;
      font-weight: 600;
      padding: 2px 8px;
      border-radius: 999px;
    }
    .stock-badge.low { background: #fef9c3; color: #b45309; }
  `],
})
export class ProductsListComponent implements OnInit {
  products$!: Observable<Product[]>;
  loading$!: Observable<boolean>;
  filter$!: Observable<string>;

  // ⭐ From Shell's SHARED root store (cross-MFE state reading)
  userName$!: Observable<string>;
  isAuthenticated$!: Observable<boolean>;
  cartCount$!: Observable<number>;

  constructor(private store: Store) {}

  ngOnInit(): void {
    // Feature store selectors
    this.products$ = this.store.select(selectFilteredProducts);
    this.loading$ = this.store.select(selectProductsLoading);
    this.filter$ = this.store.select(selectFilter);

    // Shared shell store selectors
    this.userName$ = this.store.select(selectUserName);
    this.isAuthenticated$ = this.store.select(selectIsAuthenticated);
    this.cartCount$ = this.store.select(selectCartTotalItems);

    this.store.dispatch(loadProducts());
  }

  onFilter(event: Event): void {
    const filter = (event.target as HTMLInputElement).value;
    this.store.dispatch(setFilter({ filter }));
  }

  onSelectProduct(product: Product): void {
    this.store.dispatch(selectProduct({ product }));
  }

  onAddToCart(event: Event, product: Product): void {
    event.stopPropagation();
    // ⭐ This dispatches addProductToCart which the effect
    // translates into addToCart for the Shell's cart store
    this.store.dispatch(
      addProductToCart({
        productId: product.id,
        productName: product.name,
        price: product.price,
      })
    );
  }
}
