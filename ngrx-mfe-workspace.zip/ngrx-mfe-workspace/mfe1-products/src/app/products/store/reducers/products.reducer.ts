// ============================================================
// MFE1: src/app/products/store/reducers/products.reducer.ts
// ============================================================

import { createReducer, on } from '@ngrx/store';
import { ProductsState } from '../products.state';
import * as ProductsActions from '../actions/products.actions';

export const initialProductsState: ProductsState = {
  products: [],
  selectedProduct: null,
  loading: false,
  error: null,
  filter: '',
};

export const productsReducer = createReducer(
  initialProductsState,

  on(ProductsActions.loadProducts, (state) => ({
    ...state,
    loading: true,
    error: null,
  })),

  on(ProductsActions.loadProductsSuccess, (state, { products }) => ({
    ...state,
    products,
    loading: false,
  })),

  on(ProductsActions.loadProductsFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error,
  })),

  on(ProductsActions.selectProduct, (state, { product }) => ({
    ...state,
    selectedProduct: product,
  })),

  on(ProductsActions.clearSelectedProduct, (state) => ({
    ...state,
    selectedProduct: null,
  })),

  on(ProductsActions.setFilter, (state, { filter }) => ({
    ...state,
    filter,
  }))
);
