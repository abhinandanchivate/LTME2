// ============================================================
// MFE1: src/app/products/store/effects/products.effects.ts
// Feature effects + cross-MFE effect dispatching to shell cart
// ============================================================

import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { of } from 'rxjs';
import { catchError, map, switchMap, delay } from 'rxjs/operators';
import * as ProductsActions from '../actions/products.actions';
import { Product } from '../products.state';

// ⭐ KEY: We import cart actions from the SHELL's store path.
// Because @ngrx/store is a singleton (shared via Module Federation),
// dispatching addToCart here updates the Shell's cart state directly.
import { addToCart } from '../../../../../../../../../shell/src/app/store/actions/cart.actions';

const MOCK_PRODUCTS: Product[] = [
  { id: 'p1', name: 'Angular Starter Kit', description: 'Full Angular 20 project template', price: 49.99, category: 'Templates', stock: 100, imageUrl: '📦' },
  { id: 'p2', name: 'NgRx State Manager', description: 'Enterprise NgRx setup with DevTools', price: 79.99, category: 'Libraries', stock: 50, imageUrl: '🗄️' },
  { id: 'p3', name: 'MFE Blueprint', description: 'Module Federation architecture guide', price: 99.99, category: 'Guides', stock: 30, imageUrl: '🏗️' },
  { id: 'p4', name: 'RxJS Operators Pack', description: 'Advanced RxJS patterns and examples', price: 39.99, category: 'Libraries', stock: 200, imageUrl: '⚡' },
  { id: 'p5', name: 'Testing Toolkit', description: 'Jest + Cypress + Testing Library setup', price: 59.99, category: 'Tools', stock: 75, imageUrl: '🧪' },
  { id: 'p6', name: 'UI Component Library', description: 'Custom Angular components with SCSS', price: 129.99, category: 'UI', stock: 60, imageUrl: '🎨' },
];

@Injectable()
export class ProductsEffects {

  loadProducts$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductsActions.loadProducts),
      switchMap(() =>
        of(MOCK_PRODUCTS).pipe(
          delay(600),
          map((products) => ProductsActions.loadProductsSuccess({ products })),
          catchError((error) =>
            of(ProductsActions.loadProductsFailure({ error: error.message }))
          )
        )
      )
    )
  );

  // ⭐ CROSS-MFE STATE SHARING:
  // When user clicks "Add to Cart" in MFE1,
  // this effect dispatches to the SHELL's cart reducer.
  // This works because @ngrx/store is singleton-shared!
  addToCart$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductsActions.addProductToCart),
      map(({ productId, productName, price }) =>
        addToCart({
          item: {
            productId,
            productName,
            price,
            quantity: 1,
          },
        })
      )
    )
  );

  constructor(private actions$: Actions, private store: Store) {}
}
