// ============================================================
// MFE1: src/app/products/store/products.state.ts
// Feature state — only products live here
// Shared state (user, cart) is read from the SHELL's root store
// ============================================================

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  stock: number;
  imageUrl: string;
}

export interface ProductsState {
  products: Product[];
  selectedProduct: Product | null;
  loading: boolean;
  error: string | null;
  filter: string;
}
