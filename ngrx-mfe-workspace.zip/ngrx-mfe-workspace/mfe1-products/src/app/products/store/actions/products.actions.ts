// ============================================================
// MFE1: src/app/products/store/actions/products.actions.ts
// ============================================================

import { createAction, props } from '@ngrx/store';
import { Product } from '../products.state';

export const loadProducts = createAction('[Products] Load Products');

export const loadProductsSuccess = createAction(
  '[Products] Load Products Success',
  props<{ products: Product[] }>()
);

export const loadProductsFailure = createAction(
  '[Products] Load Products Failure',
  props<{ error: string }>()
);

export const selectProduct = createAction(
  '[Products] Select Product',
  props<{ product: Product }>()
);

export const clearSelectedProduct = createAction(
  '[Products] Clear Selected Product'
);

export const setFilter = createAction(
  '[Products] Set Filter',
  props<{ filter: string }>()
);

// This action will be dispatched to the SHELL's cart store
// (shared via Module Federation singleton NgRx store)
export const addProductToCart = createAction(
  '[Products] Add Product To Cart',
  props<{ productId: string; productName: string; price: number }>()
);
