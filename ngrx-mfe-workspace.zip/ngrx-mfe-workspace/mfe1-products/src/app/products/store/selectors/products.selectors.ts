// ============================================================
// MFE1: src/app/products/store/selectors/products.selectors.ts
// ============================================================

import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ProductsState } from '../products.state';

export const selectProductsState =
  createFeatureSelector<ProductsState>('products');

export const selectAllProducts = createSelector(
  selectProductsState,
  (state) => state.products
);

export const selectProductsLoading = createSelector(
  selectProductsState,
  (state) => state.loading
);

export const selectProductsError = createSelector(
  selectProductsState,
  (state) => state.error
);

export const selectSelectedProduct = createSelector(
  selectProductsState,
  (state) => state.selectedProduct
);

export const selectFilter = createSelector(
  selectProductsState,
  (state) => state.filter
);

export const selectFilteredProducts = createSelector(
  selectAllProducts,
  selectFilter,
  (products, filter) => {
    if (!filter) return products;
    const lower = filter.toLowerCase();
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(lower) ||
        p.category.toLowerCase().includes(lower) ||
        p.description.toLowerCase().includes(lower)
    );
  }
);

export const selectProductsCount = createSelector(
  selectAllProducts,
  (products) => products.length
);
