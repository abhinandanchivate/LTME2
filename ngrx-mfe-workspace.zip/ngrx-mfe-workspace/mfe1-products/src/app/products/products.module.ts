// ============================================================
// MFE1: src/app/products/products.module.ts
// ⭐ THIS IS THE EXPOSED MODULE in webpack.config.js
// It registers its own feature store slice via StoreModule.forFeature
// The root store (user, cart) is shared from the shell
// ============================================================

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { productsReducer } from './store/reducers/products.reducer';
import { ProductsEffects } from './store/effects/products.effects';
import { ProductsListComponent } from './components/products-list.component';

const routes: Routes = [
  { path: '', component: ProductsListComponent },
];

@NgModule({
  declarations: [
    ProductsListComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),

    // ── Feature Store Registration ──────────────────────────
    // 'products' is the feature key — added to the root store slice.
    // The root store (user, cart) remains in the shell.
    StoreModule.forFeature('products', productsReducer),
    EffectsModule.forFeature([ProductsEffects]),
  ],
})
export class ProductsModule {}
