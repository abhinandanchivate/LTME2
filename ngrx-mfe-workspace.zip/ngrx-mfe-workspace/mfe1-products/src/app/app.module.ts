// ============================================================
// MFE1: src/app/app.module.ts
// MFE1 standalone bootstrap module.
// When loaded as a remote via Module Federation,
// only ProductsModule is used (not this AppModule).
// This AppModule is for running MFE1 independently in dev.
// ============================================================

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { isDevMode } from '@angular/core';

import { AppComponent } from './app.component';

// When running standalone (not federated), provide a mock root store
// that mirrors the shell's reducers so selectors don't break
import { userReducer } from '../../../../shell/src/app/store/reducers/user.reducer';
import { cartReducer } from '../../../../shell/src/app/store/reducers/cart.reducer';

const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('./products/products.module').then((m) => m.ProductsModule),
  },
];

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    // Provide mock root store for standalone dev mode
    StoreModule.forRoot({ user: userReducer, cart: cartReducer }),
    EffectsModule.forRoot([]),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: !isDevMode() }),
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
