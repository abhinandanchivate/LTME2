// ============================================================
// SHELL: src/app/core/login/login.component.ts
// Dispatches loginUser action to shared NgRx store
// ============================================================

import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { Observable, Subject, takeUntil } from 'rxjs';
import { AppState } from '../../store/app.state';
import { loginUser } from '../../store/actions/user.actions';
import { selectIsAuthenticated, selectUserLoading, selectUserError } from '../../store/selectors/app.selectors';

@Component({
  selector: 'app-login',
  template: `
    <div class="login-page">
      <div class="login-card">
        <div class="login-header">
          <span class="logo">⬡</span>
          <h2>Sign in</h2>
          <p>Login dispatches an NgRx action to the shared root store</p>
        </div>

        <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
          <div class="field">
            <label>Email</label>
            <input type="email" formControlName="email" placeholder="admin@example.com" />
            <small class="hint">Use "admin" in email for admin role</small>
          </div>
          <div class="field">
            <label>Password</label>
            <input type="password" formControlName="password" placeholder="••••••••" />
          </div>

          <div class="error-msg" *ngIf="error$ | async as error">
            ⚠️ {{ error }}
          </div>

          <button type="submit" class="btn-submit" [disabled]="loginForm.invalid || (loading$ | async)">
            <span *ngIf="loading$ | async">Signing in...</span>
            <span *ngIf="!(loading$ | async)">Sign in → dispatch loginUser</span>
          </button>
        </form>

        <div class="store-info">
          <strong>Action dispatched:</strong>
          <code>[Auth] Login User &#123; email, password &#125;</code>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-page {
      min-height: calc(100vh - 64px);
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #f0f4ff 0%, #faf5ff 100%);
    }
    .login-card {
      background: #fff;
      border-radius: 20px;
      padding: 40px;
      width: 100%;
      max-width: 420px;
      box-shadow: 0 20px 60px rgba(79,70,229,0.12);
      border: 1px solid #e0e7ff;
    }
    .login-header { text-align: center; margin-bottom: 32px; }
    .logo { font-size: 40px; }
    .login-header h2 { margin: 8px 0 4px; font-size: 24px; color: #1e293b; }
    .login-header p { font-size: 13px; color: #64748b; margin: 0; }

    .field { margin-bottom: 20px; }
    .field label { display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 6px; }
    .field input {
      width: 100%;
      padding: 10px 14px;
      border: 2px solid #e5e7eb;
      border-radius: 10px;
      font-size: 14px;
      outline: none;
      transition: border-color 0.2s;
      box-sizing: border-box;
    }
    .field input:focus { border-color: #4f46e5; }
    .hint { font-size: 11px; color: #94a3b8; display: block; margin-top: 4px; }

    .error-msg {
      background: #fef2f2;
      border: 1px solid #fecaca;
      border-radius: 8px;
      padding: 10px;
      color: #dc2626;
      font-size: 13px;
      margin-bottom: 16px;
    }
    .btn-submit {
      width: 100%;
      padding: 12px;
      background: linear-gradient(135deg, #4f46e5, #7c3aed);
      color: #fff;
      border: none;
      border-radius: 10px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: opacity 0.2s;
    }
    .btn-submit:disabled { opacity: 0.6; cursor: not-allowed; }
    .btn-submit:hover:not(:disabled) { opacity: 0.9; }

    .store-info {
      margin-top: 24px;
      background: #f8fafc;
      border-radius: 10px;
      padding: 14px;
      font-size: 12px;
      color: #475569;
    }
    .store-info strong { display: block; margin-bottom: 6px; }
    code {
      background: #e0e7ff;
      color: #3730a3;
      padding: 4px 8px;
      border-radius: 6px;
      font-size: 11px;
    }
  `],
})
export class LoginComponent implements OnInit, OnDestroy {
  loginForm!: FormGroup;
  loading$!: Observable<boolean>;
  error$!: Observable<string | null>;

  private destroy$ = new Subject<void>();

  constructor(
    private fb: FormBuilder,
    private store: Store<AppState>,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });

    this.loading$ = this.store.select(selectUserLoading);
    this.error$ = this.store.select(selectUserError);

    // Redirect after successful login
    this.store.select(selectIsAuthenticated)
      .pipe(takeUntil(this.destroy$))
      .subscribe((isAuth) => {
        if (isAuth) this.router.navigate(['/']);
      });
  }

  onSubmit(): void {
    if (this.loginForm.valid) {
      const { email, password } = this.loginForm.value;
      // ✅ Dispatches to shared NgRx store — MFEs can read this state
      this.store.dispatch(loginUser({ email, password }));
    }
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
