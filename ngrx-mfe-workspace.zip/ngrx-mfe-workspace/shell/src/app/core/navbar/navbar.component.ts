// ============================================================
// SHELL: src/app/core/navbar/navbar.component.ts
// Reads shared NgRx state (user + cart) from the root store
// ============================================================

import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AppState } from '../../store/app.state';
import {
  selectUserName,
  selectIsAuthenticated,
  selectCartTotalItems,
} from '../../store/selectors/app.selectors';
import { logoutUser } from '../../store/actions/user.actions';

@Component({
  selector: 'app-navbar',
  template: `
    <nav class="navbar">
      <div class="navbar-brand">
        <span class="brand-icon">⬡</span>
        <span class="brand-name">MFE Store</span>
        <span class="brand-badge">NgRx + MFE</span>
      </div>

      <div class="navbar-links">
        <a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}">Home</a>
        <a routerLink="/products" routerLinkActive="active">Products</a>
        <a routerLink="/orders" routerLinkActive="active">Orders</a>
      </div>

      <div class="navbar-actions">
        <button class="cart-btn" routerLink="/orders">
          🛒
          <span class="cart-badge" *ngIf="(cartCount$ | async)! > 0">
            {{ cartCount$ | async }}
          </span>
        </button>

        <ng-container *ngIf="isAuthenticated$ | async; else guestTpl">
          <span class="user-chip">👤 {{ userName$ | async }}</span>
          <button class="btn-logout" (click)="logout()">Logout</button>
        </ng-container>

        <ng-template #guestTpl>
          <a class="btn-login" routerLink="/login">Login</a>
        </ng-template>
      </div>
    </nav>
  `,
  styles: [`
    .navbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 24px;
      height: 64px;
      background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
      box-shadow: 0 2px 12px rgba(0,0,0,0.3);
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .navbar-brand {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .brand-icon { font-size: 24px; color: #818cf8; }
    .brand-name { color: #fff; font-weight: 700; font-size: 18px; letter-spacing: -0.5px; }
    .brand-badge {
      background: #4f46e5;
      color: #c7d2fe;
      font-size: 10px;
      padding: 2px 8px;
      border-radius: 999px;
      font-weight: 600;
    }
    .navbar-links { display: flex; gap: 8px; }
    .navbar-links a {
      color: #a5b4fc;
      text-decoration: none;
      padding: 6px 16px;
      border-radius: 8px;
      font-weight: 500;
      transition: all 0.2s;
    }
    .navbar-links a:hover, .navbar-links a.active {
      background: rgba(129,140,248,0.2);
      color: #fff;
    }
    .navbar-actions { display: flex; align-items: center; gap: 12px; }
    .cart-btn {
      position: relative;
      background: rgba(255,255,255,0.1);
      border: none;
      color: #fff;
      font-size: 20px;
      width: 40px;
      height: 40px;
      border-radius: 10px;
      cursor: pointer;
      transition: background 0.2s;
    }
    .cart-btn:hover { background: rgba(255,255,255,0.2); }
    .cart-badge {
      position: absolute;
      top: -4px; right: -4px;
      background: #f43f5e;
      color: #fff;
      font-size: 10px;
      font-weight: 700;
      min-width: 18px;
      height: 18px;
      border-radius: 999px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .user-chip {
      color: #c7d2fe;
      font-size: 14px;
      font-weight: 500;
    }
    .btn-logout {
      background: transparent;
      border: 1px solid rgba(165,180,252,0.4);
      color: #a5b4fc;
      padding: 6px 14px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 13px;
      transition: all 0.2s;
    }
    .btn-logout:hover { background: rgba(244,63,94,0.15); border-color: #f43f5e; color: #fda4af; }
    .btn-login {
      background: #4f46e5;
      color: #fff;
      padding: 6px 16px;
      border-radius: 8px;
      text-decoration: none;
      font-size: 14px;
      font-weight: 600;
      transition: background 0.2s;
    }
    .btn-login:hover { background: #4338ca; }
  `],
})
export class NavbarComponent implements OnInit {
  userName$!: Observable<string>;
  isAuthenticated$!: Observable<boolean>;
  cartCount$!: Observable<number>;

  constructor(private store: Store<AppState>) {}

  ngOnInit(): void {
    this.userName$ = this.store.select(selectUserName);
    this.isAuthenticated$ = this.store.select(selectIsAuthenticated);
    this.cartCount$ = this.store.select(selectCartTotalItems);
  }

  logout(): void {
    this.store.dispatch(logoutUser());
  }
}
