// ============================================================
// SHELL: src/app/core/home/home.component.ts
// ============================================================

import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AppState } from '../../store/app.state';
import { selectIsAuthenticated, selectUserName, selectCartTotalItems } from '../../store/selectors/app.selectors';

@Component({
  selector: 'app-home',
  template: `
    <div class="home-container">
      <div class="hero">
        <h1>NgRx Micro-Frontend</h1>
        <p class="subtitle">Angular 20 · Module Federation · Shared State</p>

        <div class="state-panel">
          <h3>📡 Shared State (from Root Store)</h3>
          <div class="state-grid">
            <div class="state-card">
              <span class="label">Authenticated</span>
              <span class="value" [class.true]="isAuthenticated$ | async">
                {{ (isAuthenticated$ | async) ? '✅ Yes' : '❌ No' }}
              </span>
            </div>
            <div class="state-card">
              <span class="label">Current User</span>
              <span class="value">{{ userName$ | async }}</span>
            </div>
            <div class="state-card">
              <span class="label">Cart Items</span>
              <span class="value cart">{{ cartItems$ | async }}</span>
            </div>
          </div>
        </div>

        <div class="arch-diagram">
          <h3>🏗️ Architecture</h3>
          <div class="arch-nodes">
            <div class="node shell">
              <div class="node-title">Shell (Port 4200)</div>
              <div class="node-detail">Host · NgRx Root Store</div>
              <div class="node-features">
                <span>UserReducer</span>
                <span>CartReducer</span>
                <span>UserEffects</span>
              </div>
            </div>
            <div class="arch-arrow">⟵ shared singleton NgRx ⟶</div>
            <div class="mfe-column">
              <div class="node mfe">
                <div class="node-title">MFE1: Products (4201)</div>
                <div class="node-detail">Remote · ProductsModule</div>
                <div class="node-features">
                  <span>ProductsReducer</span>
                  <span>ProductsEffects</span>
                  <span>reads Cart</span>
                </div>
              </div>
              <div class="node mfe">
                <div class="node-title">MFE2: Orders (4202)</div>
                <div class="node-detail">Remote · OrdersModule</div>
                <div class="node-features">
                  <span>OrdersReducer</span>
                  <span>OrdersEffects</span>
                  <span>reads User</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="nav-cards">
          <a routerLink="/login" class="nav-card login">
            <span class="icon">🔐</span>
            <span>Login</span>
            <small>Set shared user state</small>
          </a>
          <a routerLink="/products" class="nav-card products">
            <span class="icon">📦</span>
            <span>Products MFE</span>
            <small>MFE1 · Port 4201</small>
          </a>
          <a routerLink="/orders" class="nav-card orders">
            <span class="icon">📋</span>
            <span>Orders MFE</span>
            <small>MFE2 · Port 4202</small>
          </a>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .home-container {
      max-width: 900px;
      margin: 0 auto;
      padding: 40px 24px;
    }
    .hero { text-align: center; }
    h1 {
      font-size: 42px;
      font-weight: 800;
      background: linear-gradient(135deg, #4f46e5, #818cf8);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin: 0 0 8px;
    }
    .subtitle { color: #64748b; font-size: 16px; margin: 0 0 32px; }

    .state-panel {
      background: #fff;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      padding: 24px;
      margin-bottom: 24px;
      text-align: left;
    }
    .state-panel h3 { margin: 0 0 16px; font-size: 15px; color: #334155; }
    .state-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; }
    .state-card {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .label { font-size: 11px; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.5px; }
    .value { font-weight: 700; color: #1e293b; font-size: 15px; }
    .value.cart { color: #4f46e5; }

    .arch-diagram {
      background: #fff;
      border: 1px solid #e2e8f0;
      border-radius: 16px;
      padding: 24px;
      margin-bottom: 24px;
      text-align: left;
    }
    .arch-diagram h3 { margin: 0 0 16px; font-size: 15px; color: #334155; }
    .arch-nodes { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; justify-content: center; }
    .arch-arrow { color: #94a3b8; font-size: 12px; white-space: nowrap; }
    .mfe-column { display: flex; flex-direction: column; gap: 12px; }
    .node {
      border-radius: 12px;
      padding: 16px;
      min-width: 180px;
    }
    .node.shell { background: linear-gradient(135deg, #ede9fe, #ddd6fe); border: 2px solid #7c3aed; }
    .node.mfe { background: linear-gradient(135deg, #e0f2fe, #bae6fd); border: 2px solid #0284c7; }
    .node-title { font-weight: 700; font-size: 13px; color: #1e293b; margin-bottom: 4px; }
    .node-detail { font-size: 11px; color: #64748b; margin-bottom: 8px; }
    .node-features { display: flex; flex-direction: column; gap: 2px; }
    .node-features span {
      font-size: 11px;
      background: rgba(255,255,255,0.6);
      border-radius: 4px;
      padding: 2px 6px;
      color: #475569;
    }

    .nav-cards { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-top: 24px; }
    .nav-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
      padding: 24px;
      border-radius: 16px;
      text-decoration: none;
      font-weight: 600;
      color: #1e293b;
      transition: transform 0.2s, box-shadow 0.2s;
      border: 2px solid transparent;
    }
    .nav-card:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(0,0,0,0.1); }
    .nav-card.login { background: #fef9c3; border-color: #fbbf24; }
    .nav-card.products { background: #ede9fe; border-color: #7c3aed; }
    .nav-card.orders { background: #dcfce7; border-color: #16a34a; }
    .nav-card .icon { font-size: 32px; }
    .nav-card small { font-size: 11px; color: #64748b; font-weight: 400; }
  `],
})
export class HomeComponent implements OnInit {
  isAuthenticated$!: Observable<boolean>;
  userName$!: Observable<string>;
  cartItems$!: Observable<number>;

  constructor(private store: Store<AppState>) {}

  ngOnInit(): void {
    this.isAuthenticated$ = this.store.select(selectIsAuthenticated);
    this.userName$ = this.store.select(selectUserName);
    this.cartItems$ = this.store.select(selectCartTotalItems);
  }
}
