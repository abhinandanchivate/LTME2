// ============================================================
// SHELL: src/app/app.module.ts
// Root NgModule — bootstraps the shell, registers NgRx store
// ============================================================

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { isDevMode } from '@angular/core';

import { AppComponent } from './app.component';
import { reducers, metaReducers } from './store/reducers';
import { UserEffects } from './store/effects/user.effects';
import { NavbarComponent } from './core/navbar/navbar.component';
import { HomeComponent } from './core/home/home.component';
import { LoginComponent } from './core/login/login.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  {
    path: 'products',
    loadChildren: () =>
      // Module Federation dynamic import — loads mfe1-products at runtime
      (window as any)['mfe1Products'].get('./Module').then(
        (factory: any) => factory()
      ),
  },
  {
    path: 'orders',
    loadChildren: () =>
      // Module Federation dynamic import — loads mfe2-orders at runtime
      (window as any)['mfe2Orders'].get('./Module').then(
        (factory: any) => factory()
      ),
  },
  { path: '**', redirectTo: '' },
];

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),

    // ── NgRx Root Store ──────────────────────────────────────
    // The root store is registered HERE in the shell.
    // MFEs share this same store instance via Module Federation
    // singleton sharing of @ngrx/store.
    StoreModule.forRoot(reducers, { metaReducers }),
    EffectsModule.forRoot([UserEffects]),
    StoreDevtoolsModule.instrument({
      maxAge: 25,
      logOnly: !isDevMode(),
    }),
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
