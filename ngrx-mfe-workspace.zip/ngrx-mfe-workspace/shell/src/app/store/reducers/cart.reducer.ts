// ============================================================
// SHELL: src/app/store/reducers/cart.reducer.ts
// ============================================================

import { createReducer, on } from '@ngrx/store';
import { CartState, CartItem } from '../app.state';
import * as CartActions from '../actions/cart.actions';

export const initialCartState: CartState = {
  items: [],
  totalItems: 0,
  totalPrice: 0,
};

function calculateTotals(items: CartItem[]): { totalItems: number; totalPrice: number } {
  return {
    totalItems: items.reduce((sum, item) => sum + item.quantity, 0),
    totalPrice: items.reduce((sum, item) => sum + item.price * item.quantity, 0),
  };
}

export const cartReducer = createReducer(
  initialCartState,

  on(CartActions.addToCart, (state, { item }) => {
    const existingIndex = state.items.findIndex((i) => i.productId === item.productId);
    let updatedItems: CartItem[];

    if (existingIndex >= 0) {
      updatedItems = state.items.map((i, idx) =>
        idx === existingIndex ? { ...i, quantity: i.quantity + item.quantity } : i
      );
    } else {
      updatedItems = [...state.items, item];
    }

    return {
      ...state,
      items: updatedItems,
      ...calculateTotals(updatedItems),
    };
  }),

  on(CartActions.removeFromCart, (state, { productId }) => {
    const updatedItems = state.items.filter((i) => i.productId !== productId);
    return {
      ...state,
      items: updatedItems,
      ...calculateTotals(updatedItems),
    };
  }),

  on(CartActions.updateCartItemQuantity, (state, { productId, quantity }) => {
    const updatedItems = state.items.map((i) =>
      i.productId === productId ? { ...i, quantity } : i
    );
    return {
      ...state,
      items: updatedItems,
      ...calculateTotals(updatedItems),
    };
  }),

  on(CartActions.clearCart, () => ({
    ...initialCartState,
  })),

  on(CartActions.loadCartSuccess, (state, { items }) => ({
    ...state,
    items,
    ...calculateTotals(items),
  }))
);
