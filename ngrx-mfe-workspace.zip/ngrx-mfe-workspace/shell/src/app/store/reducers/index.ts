// ============================================================
// SHELL: src/app/store/reducers/index.ts
// Root reducer combining all feature reducers
// ============================================================

import { ActionReducerMap, MetaReducer } from '@ngrx/store';
import { AppState } from '../app.state';
import { userReducer } from './user.reducer';
import { cartReducer } from './cart.reducer';
import { isDevMode } from '@angular/core';

export const reducers: ActionReducerMap<AppState> = {
  user: userReducer,
  cart: cartReducer,
};

export const metaReducers: MetaReducer<AppState>[] = isDevMode() ? [] : [];
