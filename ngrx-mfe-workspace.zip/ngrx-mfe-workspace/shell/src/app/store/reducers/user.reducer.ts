// ============================================================
// SHELL: src/app/store/reducers/user.reducer.ts
// ============================================================

import { createReducer, on } from '@ngrx/store';
import { UserState } from '../app.state';
import * as UserActions from '../actions/user.actions';

export const initialUserState: UserState = {
  currentUser: null,
  isAuthenticated: false,
  loading: false,
  error: null,
};

export const userReducer = createReducer(
  initialUserState,

  on(UserActions.loginUser, (state) => ({
    ...state,
    loading: true,
    error: null,
  })),

  on(UserActions.loginUserSuccess, (state, { user }) => ({
    ...state,
    currentUser: user,
    isAuthenticated: true,
    loading: false,
    error: null,
  })),

  on(UserActions.loginUserFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error,
  })),

  on(UserActions.logoutUser, () => ({
    ...initialUserState,
  })),

  on(UserActions.setCurrentUser, (state, { user }) => ({
    ...state,
    currentUser: user,
    isAuthenticated: true,
  }))
);
