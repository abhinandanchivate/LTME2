// ============================================================
// SHELL: src/app/store/selectors/app.selectors.ts
// Shared selectors consumed by shell AND remote MFEs
// ============================================================

import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AppState, UserState, CartState } from '../app.state';

// ── User Selectors ──────────────────────────────────────────
export const selectUserState = createFeatureSelector<UserState>('user');

export const selectCurrentUser = createSelector(
  selectUserState,
  (state) => state.currentUser
);

export const selectIsAuthenticated = createSelector(
  selectUserState,
  (state) => state.isAuthenticated
);

export const selectUserLoading = createSelector(
  selectUserState,
  (state) => state.loading
);

export const selectUserError = createSelector(
  selectUserState,
  (state) => state.error
);

export const selectUserName = createSelector(
  selectCurrentUser,
  (user) => user?.name ?? 'Guest'
);

export const selectUserRole = createSelector(
  selectCurrentUser,
  (user) => user?.role ?? null
);

// ── Cart Selectors ──────────────────────────────────────────
export const selectCartState = createFeatureSelector<CartState>('cart');

export const selectCartItems = createSelector(
  selectCartState,
  (state) => state.items
);

export const selectCartTotalItems = createSelector(
  selectCartState,
  (state) => state.totalItems
);

export const selectCartTotalPrice = createSelector(
  selectCartState,
  (state) => state.totalPrice
);

export const selectCartIsEmpty = createSelector(
  selectCartItems,
  (items) => items.length === 0
);
