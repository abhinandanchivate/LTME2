// ============================================================
// SHELL: src/app/store/effects/user.effects.ts
// ============================================================

import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap, delay } from 'rxjs/operators';
import * as UserActions from '../actions/user.actions';
import { User } from '../app.state';

@Injectable()
export class UserEffects {
  // Simulates an auth API call
  login$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserActions.loginUser),
      switchMap(({ email, password }) =>
        of(null).pipe(
          delay(800), // Simulate network delay
          map(() => {
            // Mock successful login
            const mockUser: User = {
              id: 'usr-001',
              name: email.split('@')[0],
              email,
              role: email.includes('admin') ? 'admin' : 'user',
            };
            return UserActions.loginUserSuccess({ user: mockUser });
          }),
          catchError((error) =>
            of(UserActions.loginUserFailure({ error: error.message }))
          )
        )
      )
    )
  );

  constructor(private actions$: Actions) {}
}
