// ============================================================
// SHELL: src/app/store/actions/user.actions.ts
// ============================================================

import { createAction, props } from '@ngrx/store';
import { User } from '../app.state';

export const loginUser = createAction(
  '[Auth] Login User',
  props<{ email: string; password: string }>()
);

export const loginUserSuccess = createAction(
  '[Auth] Login User Success',
  props<{ user: User }>()
);

export const loginUserFailure = createAction(
  '[Auth] Login User Failure',
  props<{ error: string }>()
);

export const logoutUser = createAction('[Auth] Logout User');

export const setCurrentUser = createAction(
  '[Auth] Set Current User',
  props<{ user: User }>()
);
