// ============================================================
// SHELL: src/app/store/app.state.ts
// Root application state shared across shell and MFEs
// ============================================================

export interface UserState {
  currentUser: User | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
}

export interface CartState {
  items: CartItem[];
  totalItems: number;
  totalPrice: number;
}

export interface AppState {
  user: UserState;
  cart: CartState;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
}

export interface CartItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
}
