// ============================================================
// SHELL: src/bootstrap.ts
// ⭐ Module Federation REQUIRES deferred bootstrapping.
// main.ts does a dynamic import of this file so that
// shared libraries (Angular, NgRx) are resolved FIRST
// before bootstrapping the application.
// ============================================================

import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';

platformBrowserDynamic()
  .bootstrapModule(AppModule)
  .catch((err) => console.error(err));
