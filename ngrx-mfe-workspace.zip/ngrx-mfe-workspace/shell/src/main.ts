// ============================================================
// SHELL: src/main.ts
// ⭐ Module Federation bootstrap pattern:
// Dynamic import defers Angular bootstrap until AFTER
// Module Federation resolves shared singleton packages.
// Without this, you get "Shared module is not available" errors.
// ============================================================

import('./bootstrap').catch((err) => console.error(err));
