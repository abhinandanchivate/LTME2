const {
  shareAll,
  withModuleFederationPlugin,
} = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  name: 'shell',

  remotes: {
    mfe1Products: 'mfe1Products@http://localhost:4201/remoteEntry.js',
    mfe2Orders: 'mfe2Orders@http://localhost:4202/remoteEntry.js',
  },

  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: 'auto',
    }),
  },
});
