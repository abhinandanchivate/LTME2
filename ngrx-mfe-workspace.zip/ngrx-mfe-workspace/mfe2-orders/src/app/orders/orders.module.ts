// ============================================================
// MFE2: src/app/orders/orders.module.ts
// ⭐ THIS IS THE EXPOSED MODULE in webpack.config.js
// ============================================================

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { ordersReducer } from './store/reducers/orders.reducer';
import { OrdersEffects } from './store/effects/orders.effects';
import { OrdersListComponent } from './components/orders-list.component';

const routes: Routes = [
  { path: '', component: OrdersListComponent },
];

@NgModule({
  declarations: [OrdersListComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),

    // ── Feature Store Registration ──────────────────────────
    // Registers 'orders' feature slice into the shared root store.
    StoreModule.forFeature('orders', ordersReducer),
    EffectsModule.forFeature([OrdersEffects]),
  ],
})
export class OrdersModule {}
