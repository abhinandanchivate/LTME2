// ============================================================
// MFE2: src/app/orders/store/effects/orders.effects.ts
// ============================================================

import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { of } from 'rxjs';
import { catchError, map, switchMap, delay, withLatestFrom } from 'rxjs/operators';
import * as OrdersActions from '../actions/orders.actions';
import { Order } from '../orders.state';

// ⭐ Reading from Shell's root store (shared state)
import { selectCurrentUser } from '../../../../../../../../../shell/src/app/store/selectors/app.selectors';
import { clearCart } from '../../../../../../../../../shell/src/app/store/actions/cart.actions';

const MOCK_ORDERS: Order[] = [
  {
    id: 'ord-001',
    userId: 'usr-001',
    items: [
      { productId: 'p1', productName: 'Angular Starter Kit', price: 49.99, quantity: 1 },
      { productId: 'p2', productName: 'NgRx State Manager', price: 79.99, quantity: 2 },
    ],
    totalPrice: 209.97,
    status: 'delivered',
    createdAt: '2025-01-15',
  },
  {
    id: 'ord-002',
    userId: 'usr-001',
    items: [
      { productId: 'p3', productName: 'MFE Blueprint', price: 99.99, quantity: 1 },
    ],
    totalPrice: 99.99,
    status: 'shipped',
    createdAt: '2025-02-20',
  },
];

@Injectable()
export class OrdersEffects {

  loadOrders$ = createEffect(() =>
    this.actions$.pipe(
      ofType(OrdersActions.loadOrders),
      switchMap(() =>
        of(MOCK_ORDERS).pipe(
          delay(700),
          map((orders) => OrdersActions.loadOrdersSuccess({ orders })),
          catchError((error) =>
            of(OrdersActions.loadOrdersFailure({ error: error.message }))
          )
        )
      )
    )
  );

  // ⭐ When an order is placed successfully,
  // dispatch clearCart to the Shell's cart store (shared NgRx)
  placeOrder$ = createEffect(() =>
    this.actions$.pipe(
      ofType(OrdersActions.placeOrder),
      switchMap(({ items, userId }) => {
        const newOrder: Order = {
          id: `ord-${Date.now()}`,
          userId,
          items,
          totalPrice: items.reduce((s, i) => s + i.price * i.quantity, 0),
          status: 'pending',
          createdAt: new Date().toISOString().split('T')[0],
        };
        return of(newOrder).pipe(
          delay(1000),
          map((order) => OrdersActions.placeOrderSuccess({ order })),
          catchError((error) =>
            of(OrdersActions.placeOrderFailure({ error: error.message }))
          )
        );
      })
    )
  );

  // After successful order, clear the shared cart
  clearCartAfterOrder$ = createEffect(() =>
    this.actions$.pipe(
      ofType(OrdersActions.placeOrderSuccess),
      map(() => clearCart())  // ⭐ Dispatches to Shell's cart reducer!
    )
  );

  constructor(private actions$: Actions, private store: Store) {}
}
