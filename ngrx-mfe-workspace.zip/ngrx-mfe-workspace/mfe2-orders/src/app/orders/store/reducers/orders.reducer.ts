// ============================================================
// MFE2: src/app/orders/store/reducers/orders.reducer.ts
// ============================================================

import { createReducer, on } from '@ngrx/store';
import { OrdersState } from '../orders.state';
import * as OrdersActions from '../actions/orders.actions';

export const initialOrdersState: OrdersState = {
  orders: [],
  selectedOrder: null,
  loading: false,
  error: null,
  placingOrder: false,
};

export const ordersReducer = createReducer(
  initialOrdersState,

  on(OrdersActions.loadOrders, (state) => ({
    ...state,
    loading: true,
    error: null,
  })),

  on(OrdersActions.loadOrdersSuccess, (state, { orders }) => ({
    ...state,
    orders,
    loading: false,
  })),

  on(OrdersActions.loadOrdersFailure, (state, { error }) => ({
    ...state,
    loading: false,
    error,
  })),

  on(OrdersActions.placeOrder, (state) => ({
    ...state,
    placingOrder: true,
    error: null,
  })),

  on(OrdersActions.placeOrderSuccess, (state, { order }) => ({
    ...state,
    orders: [order, ...state.orders],
    placingOrder: false,
  })),

  on(OrdersActions.placeOrderFailure, (state, { error }) => ({
    ...state,
    placingOrder: false,
    error,
  })),

  on(OrdersActions.selectOrder, (state, { order }) => ({
    ...state,
    selectedOrder: order,
  })),

  on(OrdersActions.updateOrderStatus, (state, { orderId, status }) => ({
    ...state,
    orders: state.orders.map((o) =>
      o.id === orderId ? { ...o, status: status as any } : o
    ),
  }))
);
