// ============================================================
// MFE2: src/app/orders/store/selectors/orders.selectors.ts
// ============================================================

import { createFeatureSelector, createSelector } from '@ngrx/store';
import { OrdersState } from '../orders.state';

export const selectOrdersState =
  createFeatureSelector<OrdersState>('orders');

export const selectAllOrders = createSelector(
  selectOrdersState,
  (state) => state.orders
);

export const selectOrdersLoading = createSelector(
  selectOrdersState,
  (state) => state.loading
);

export const selectOrdersError = createSelector(
  selectOrdersState,
  (state) => state.error
);

export const selectSelectedOrder = createSelector(
  selectOrdersState,
  (state) => state.selectedOrder
);

export const selectPlacingOrder = createSelector(
  selectOrdersState,
  (state) => state.placingOrder
);

export const selectOrdersCount = createSelector(
  selectAllOrders,
  (orders) => orders.length
);

export const selectOrdersByStatus = (status: string) =>
  createSelector(selectAllOrders, (orders) =>
    orders.filter((o) => o.status === status)
  );

export const selectTotalSpent = createSelector(
  selectAllOrders,
  (orders) =>
    orders
      .filter((o) => o.status !== 'cancelled')
      .reduce((sum, o) => sum + o.totalPrice, 0)
);
