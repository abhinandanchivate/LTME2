// ============================================================
// MFE2: src/app/orders/store/actions/orders.actions.ts
// ============================================================

import { createAction, props } from '@ngrx/store';
import { Order, OrderItem } from '../orders.state';

export const loadOrders = createAction('[Orders] Load Orders');

export const loadOrdersSuccess = createAction(
  '[Orders] Load Orders Success',
  props<{ orders: Order[] }>()
);

export const loadOrdersFailure = createAction(
  '[Orders] Load Orders Failure',
  props<{ error: string }>()
);

export const placeOrder = createAction(
  '[Orders] Place Order',
  props<{ items: OrderItem[]; userId: string }>()
);

export const placeOrderSuccess = createAction(
  '[Orders] Place Order Success',
  props<{ order: Order }>()
);

export const placeOrderFailure = createAction(
  '[Orders] Place Order Failure',
  props<{ error: string }>()
);

export const selectOrder = createAction(
  '[Orders] Select Order',
  props<{ order: Order }>()
);

export const updateOrderStatus = createAction(
  '[Orders] Update Order Status',
  props<{ orderId: string; status: string }>()
);
