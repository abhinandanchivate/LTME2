// ============================================================
// MFE2: src/app/orders/components/orders-list.component.ts
// ⭐ Reads BOTH: MFE2's feature store AND Shell's shared store
// ============================================================

import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Order } from '../store/orders.state';
import { loadOrders, placeOrder, selectOrder } from '../store/actions/orders.actions';
import {
  selectAllOrders,
  selectOrdersLoading,
  selectPlacingOrder,
  selectTotalSpent,
  selectOrdersCount,
} from '../store/selectors/orders.selectors';

// ⭐ Shared state from Shell's root NgRx store
import {
  selectCurrentUser,
  selectIsAuthenticated,
  selectCartItems,
  selectCartTotalItems,
  selectCartTotalPrice,
} from '../../../../../../../shell/src/app/store/selectors/app.selectors';
import { User, CartItem } from '../../../../../../../shell/src/app/store/app.state';

@Component({
  selector: 'app-orders-list',
  template: `
    <div class="orders-page">
      <div class="page-header">
        <div>
          <h1>📋 Orders</h1>
          <p class="subtitle">MFE2 · Feature Store + Shared State</p>
        </div>

        <!-- ⭐ SHARED STATE from Shell's root store -->
        <div class="shared-state-panel">
          <div class="state-item" *ngIf="currentUser$ | async as user">
            <span class="state-icon">👤</span>
            <div>
              <div class="state-label">Shared User (from Shell)</div>
              <div class="state-value">{{ user.name }} · {{ user.role }}</div>
            </div>
          </div>
          <div class="state-item" *ngIf="!(isAuthenticated$ | async)">
            <span class="state-icon">🔒</span>
            <div>
              <div class="state-label">Not authenticated</div>
              <div class="state-value hint">Login in Shell to see user</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Cart Summary from Shared State -->
      <div class="cart-summary" *ngIf="(cartCount$ | async)! > 0">
        <div class="cart-header">
          <h3>🛒 Current Cart <span class="badge">{{ cartCount$ | async }} items</span></h3>
          <span class="cart-total">\${{ (cartTotal$ | async) | number:'1.2-2' }}</span>
        </div>
        <div class="cart-items">
          <div class="cart-item" *ngFor="let item of cartItems$ | async">
            <span class="item-name">{{ item.productName }}</span>
            <span class="item-qty">×{{ item.quantity }}</span>
            <span class="item-price">\${{ (item.price * item.quantity) | number:'1.2-2' }}</span>
          </div>
        </div>
        <button
          class="btn-place-order"
          (click)="onPlaceOrder()"
          [disabled]="(placingOrder$ | async) || !(isAuthenticated$ | async)"
        >
          <span *ngIf="placingOrder$ | async">⏳ Placing order...</span>
          <span *ngIf="!(placingOrder$ | async) && (isAuthenticated$ | async)">✅ Place Order</span>
          <span *ngIf="!(isAuthenticated$ | async)">🔒 Login to place order</span>
        </button>
      </div>

      <!-- Empty cart hint -->
      <div class="empty-cart" *ngIf="(cartCount$ | async) === 0">
        <div class="empty-icon">🛒</div>
        <p>Your cart is empty. Go to <a routerLink="/products">Products</a> to add items.</p>
        <small>Cart state is shared from Shell's NgRx store via Module Federation</small>
      </div>

      <!-- Stats -->
      <div class="stats-bar">
        <div class="stat">
          <span class="stat-number">{{ ordersCount$ | async }}</span>
          <span class="stat-label">Total Orders</span>
        </div>
        <div class="stat">
          <span class="stat-number">\${{ (totalSpent$ | async) | number:'1.2-2' }}</span>
          <span class="stat-label">Total Spent</span>
        </div>
      </div>

      <!-- Loading -->
      <div class="loading-state" *ngIf="loading$ | async">
        <div class="spinner"></div>
        Loading orders...
      </div>

      <!-- Orders List -->
      <div class="orders-list" *ngIf="!(loading$ | async)">
        <div
          class="order-card"
          *ngFor="let order of orders$ | async"
          (click)="onSelectOrder(order)"
        >
          <div class="order-header">
            <span class="order-id">{{ order.id }}</span>
            <span class="order-status" [class]="'status-' + order.status">
              {{ getStatusIcon(order.status) }} {{ order.status | titlecase }}
            </span>
          </div>
          <div class="order-items">
            <span *ngFor="let item of order.items; let last = last">
              {{ item.productName }}{{ !last ? ', ' : '' }}
            </span>
          </div>
          <div class="order-footer">
            <span class="order-date">📅 {{ order.createdAt }}</span>
            <span class="order-total">\${{ order.totalPrice | number:'1.2-2' }}</span>
          </div>
        </div>

        <div class="no-orders" *ngIf="(orders$ | async)?.length === 0">
          <p>No orders yet. Place your first order above!</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .orders-page { padding: 32px 24px; max-width: 900px; margin: 0 auto; }
    .page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 24px; flex-wrap: wrap; gap: 16px; }
    h1 { margin: 0 0 4px; font-size: 28px; color: #1e293b; }
    .subtitle { margin: 0; font-size: 13px; color: #94a3b8; }

    .shared-state-panel {
      background: linear-gradient(135deg, #f0fdf4, #dcfce7);
      border: 1px solid #86efac;
      border-radius: 14px;
      padding: 14px 18px;
    }
    .state-item { display: flex; align-items: center; gap: 10px; }
    .state-icon { font-size: 22px; }
    .state-label { font-size: 10px; color: #16a34a; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; }
    .state-value { font-size: 14px; font-weight: 700; color: #14532d; }
    .state-value.hint { color: #94a3b8; font-weight: 400; }

    .cart-summary {
      background: #fff;
      border: 2px solid #4f46e5;
      border-radius: 16px;
      padding: 20px;
      margin-bottom: 24px;
    }
    .cart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
    .cart-header h3 { margin: 0; font-size: 16px; color: #1e293b; display: flex; align-items: center; gap: 8px; }
    .badge {
      background: #4f46e5;
      color: #fff;
      font-size: 11px;
      padding: 2px 8px;
      border-radius: 999px;
      font-weight: 600;
    }
    .cart-total { font-size: 20px; font-weight: 800; color: #4f46e5; }
    .cart-items { display: flex; flex-direction: column; gap: 8px; margin-bottom: 16px; }
    .cart-item {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 8px 12px;
      background: #f8fafc;
      border-radius: 8px;
    }
    .item-name { flex: 1; font-size: 14px; color: #334155; }
    .item-qty { color: #64748b; font-size: 13px; margin: 0 12px; }
    .item-price { font-weight: 700; color: #1e293b; font-size: 14px; }
    .btn-place-order {
      width: 100%;
      padding: 12px;
      background: linear-gradient(135deg, #4f46e5, #7c3aed);
      color: #fff;
      border: none;
      border-radius: 10px;
      font-size: 15px;
      font-weight: 700;
      cursor: pointer;
      transition: opacity 0.2s;
    }
    .btn-place-order:hover:not(:disabled) { opacity: 0.9; }
    .btn-place-order:disabled { opacity: 0.6; cursor: not-allowed; }

    .empty-cart {
      text-align: center;
      padding: 32px;
      background: #f8fafc;
      border-radius: 16px;
      margin-bottom: 24px;
      border: 2px dashed #e2e8f0;
    }
    .empty-icon { font-size: 48px; margin-bottom: 12px; }
    .empty-cart p { color: #475569; margin: 0 0 8px; }
    .empty-cart a { color: #4f46e5; font-weight: 600; }
    .empty-cart small { color: #94a3b8; font-size: 12px; }

    .stats-bar { display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; margin-bottom: 24px; }
    .stat {
      background: #fff;
      border: 1px solid #e2e8f0;
      border-radius: 12px;
      padding: 16px;
      text-align: center;
    }
    .stat-number { display: block; font-size: 28px; font-weight: 800; color: #1e293b; }
    .stat-label { font-size: 12px; color: #94a3b8; }

    .loading-state { display: flex; align-items: center; justify-content: center; gap: 12px; padding: 60px; color: #64748b; }
    .spinner { width: 24px; height: 24px; border: 3px solid #e2e8f0; border-top-color: #4f46e5; border-radius: 50%; animation: spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }

    .orders-list { display: flex; flex-direction: column; gap: 12px; }
    .order-card {
      background: #fff;
      border: 2px solid #e2e8f0;
      border-radius: 14px;
      padding: 18px;
      cursor: pointer;
      transition: all 0.2s;
    }
    .order-card:hover { border-color: #4f46e5; box-shadow: 0 4px 16px rgba(79,70,229,0.1); }
    .order-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
    .order-id { font-family: monospace; font-size: 13px; color: #64748b; }
    .order-status { font-size: 13px; font-weight: 600; padding: 4px 10px; border-radius: 8px; }
    .status-pending { background: #fef9c3; color: #b45309; }
    .status-processing { background: #dbeafe; color: #1d4ed8; }
    .status-shipped { background: #e0f2fe; color: #0284c7; }
    .status-delivered { background: #dcfce7; color: #16a34a; }
    .status-cancelled { background: #fee2e2; color: #dc2626; }
    .order-items { font-size: 13px; color: #64748b; margin-bottom: 10px; }
    .order-footer { display: flex; justify-content: space-between; align-items: center; }
    .order-date { font-size: 12px; color: #94a3b8; }
    .order-total { font-size: 18px; font-weight: 800; color: #1e293b; }

    .no-orders { text-align: center; padding: 40px; color: #64748b; }
  `],
})
export class OrdersListComponent implements OnInit {
  orders$!: Observable<Order[]>;
  loading$!: Observable<boolean>;
  placingOrder$!: Observable<boolean>;
  ordersCount$!: Observable<number>;
  totalSpent$!: Observable<number>;

  // ⭐ From Shell's SHARED root NgRx store
  currentUser$!: Observable<User | null>;
  isAuthenticated$!: Observable<boolean>;
  cartItems$!: Observable<CartItem[]>;
  cartCount$!: Observable<number>;
  cartTotal$!: Observable<number>;

  constructor(private store: Store) {}

  ngOnInit(): void {
    // MFE2 feature store
    this.orders$ = this.store.select(selectAllOrders);
    this.loading$ = this.store.select(selectOrdersLoading);
    this.placingOrder$ = this.store.select(selectPlacingOrder);
    this.ordersCount$ = this.store.select(selectOrdersCount);
    this.totalSpent$ = this.store.select(selectTotalSpent);

    // ⭐ Shell's shared store
    this.currentUser$ = this.store.select(selectCurrentUser);
    this.isAuthenticated$ = this.store.select(selectIsAuthenticated);
    this.cartItems$ = this.store.select(selectCartItems);
    this.cartCount$ = this.store.select(selectCartTotalItems);
    this.cartTotal$ = this.store.select(selectCartTotalPrice);

    this.store.dispatch(loadOrders());
  }

  onPlaceOrder(): void {
    this.store.select(selectCurrentUser).subscribe((user) => {
      if (!user) return;
      this.store.select(selectCartItems).subscribe((items) => {
        if (items.length === 0) return;
        this.store.dispatch(
          placeOrder({
            userId: user.id,
            items: items.map((i) => ({
              productId: i.productId,
              productName: i.productName,
              price: i.price,
              quantity: i.quantity,
            })),
          })
        );
      }).unsubscribe();
    }).unsubscribe();
  }

  onSelectOrder(order: Order): void {
    this.store.dispatch(selectOrder({ order }));
  }

  getStatusIcon(status: string): string {
    const icons: Record<string, string> = {
      pending: '⏳',
      processing: '⚙️',
      shipped: '🚚',
      delivered: '✅',
      cancelled: '❌',
    };
    return icons[status] ?? '📋';
  }
}
