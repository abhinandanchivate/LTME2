// ============================================================
// MFE2: src/app/app.module.ts
// Standalone bootstrap for running MFE2 independently in dev
// ============================================================

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';

import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { isDevMode } from '@angular/core';

import { AppComponent } from './app.component';

// Mock root store mirroring the shell for standalone dev mode
import { userReducer } from '../../../../shell/src/app/store/reducers/user.reducer';
import { cartReducer } from '../../../../shell/src/app/store/reducers/cart.reducer';

const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('./orders/orders.module').then((m) => m.OrdersModule),
  },
];

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    StoreModule.forRoot({ user: userReducer, cart: cartReducer }),
    EffectsModule.forRoot([]),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: !isDevMode() }),
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
