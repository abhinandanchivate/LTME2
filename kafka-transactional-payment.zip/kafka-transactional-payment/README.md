# Kafka Transactional Payment — Spring Boot

## What this demonstrates

**Transactional Outbox Pattern** — the industry-standard solution for atomically
writing to both a database and Kafka without a distributed transaction (XA).

```
┌────────────────────────────────────────────────────────────────┐
│  @Transactional (DB only)                                      │
│  BEGIN                                                         │
│    1. INSERT payments        ← business write                  │
│    2. INSERT payment_outbox  ← event queued in same DB tx      │
│  COMMIT  ←─ both succeed or both roll back                     │
└────────────────────────────────────────────────────────────────┘
         ↓  (after commit — separate process)
┌────────────────────────────────────────────────────────────────┐
│  OutboxRelayService (scheduled every 1s)                       │
│    - SELECT pending outbox rows                                │
│    - Build Avro PaymentEvent from JSON payload                 │
│    - Publish to Kafka (within Kafka transaction)               │
│    - On success → UPDATE outbox status = SENT                  │
│    - On failure → retry up to 5 times, then FAILED            │
└────────────────────────────────────────────────────────────────┘
```

## Architecture

```
REST API
  └─ PaymentController
       └─ PaymentService          ← @Transactional DB write + outbox insert
            ├─ PaymentRepository  → payments table
            └─ OutboxRepository   → payment_outbox table

Scheduler (every 1s)
  └─ OutboxRelayService
       ├─ reads PENDING outbox rows
       ├─ builds Avro PaymentEvent (schema validated by Schema Registry)
       └─ KafkaTemplate.executeInTransaction() → publishes with Kafka tx

Kafka Consumer
  └─ PaymentEventConsumer
       └─ @KafkaListener → manual ack → processes event
```

## Tech stack

| Component       | Technology                        |
|-----------------|-----------------------------------|
| App framework   | Spring Boot 3.2                   |
| DB              | PostgreSQL 15                     |
| Message broker  | Apache Kafka 7.5 (Confluent)      |
| Schema format   | Apache Avro                       |
| Schema store    | Confluent Schema Registry         |
| Serialisation   | KafkaAvroSerializer (auto-gen)    |
| Transaction     | Transactional Outbox Pattern      |

## Quick start

### 1. Start infrastructure

```bash
docker-compose up -d
```

Wait for all services to be healthy (~30s):
```bash
docker-compose ps
```

### 2. Run the application

```bash
./mvnw spring-boot:run
```

App starts on http://localhost:8090

### 3. View Kafka UI

Open http://localhost:8080 — Kafka UI with Schema Registry browser

---

## Scenarios

### ✅ Scenario 1 — Happy path (DB + Kafka both succeed)

```bash
curl -X POST http://localhost:8090/api/payments \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "user-001",
    "amount": 1500.00,
    "currency": "INR",
    "merchantId": "merchant-42",
    "paymentMethod": "UPI"
  }'
```

**Expected:**
- HTTP 201 Created
- Payment row inserted in `payments` table
- Outbox row inserted in `payment_outbox` table (status=PENDING)
- Within 1s: outbox row updated to SENT, Kafka message published
- Consumer logs the received PaymentEvent

---

### ❌ Scenario 2 — DB failure (both DB and Kafka roll back)

```bash
curl -X POST http://localhost:8090/api/payments \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "user-002",
    "amount": 500.00,
    "currency": "INR",
    "simulateDbFailure": true
  }'
```

**Expected:**
- HTTP 500 — exception thrown INSIDE @Transactional
- Transaction rolls back — NO payment row, NO outbox row
- NO Kafka message (no outbox row = relay has nothing to send)
- Check DB: `SELECT * FROM payments WHERE user_id = 'user-002'` → empty

---

### ⚠️ Scenario 3 — Kafka failure (DB saved, outbox retried)

```bash
curl -X POST http://localhost:8090/api/payments \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "user-003",
    "amount": 750.00,
    "currency": "INR",
    "simulateKafkaFailure": true
  }'
```

**Expected:**
- HTTP 201 Created — DB transaction commits successfully
- Payment row saved, outbox row PENDING
- Relay attempts Kafka publish → simulated failure → retry_count++
- After MAX_RETRIES (5): status = FAILED
- Payment data is safe in DB — no data loss
- Check outbox: `SELECT * FROM payment_outbox ORDER BY created_at DESC LIMIT 5`

---

## Verify in database

```sql
-- See all payments
SELECT id, user_id, amount, currency, status, created_at
FROM payments ORDER BY created_at DESC;

-- See outbox state (PENDING, SENT, FAILED)
SELECT o.id, p.user_id, o.event_type, o.status, o.retry_count, o.sent_at, o.error_message
FROM payment_outbox o
JOIN payments p ON p.id = o.payment_id
ORDER BY o.created_at DESC;
```

Connect with:
```bash
docker exec -it payment-postgres psql -U payments_user -d payments_db
```

## Key configuration explained

| Config | Value | Why |
|--------|-------|-----|
| `acks=all` | Producer waits for all ISR replicas | No data loss on leader failure |
| `enable.idempotence=true` | Deduplicate producer retries | No duplicates from network timeouts |
| `transaction-id-prefix` | Enables Kafka transactions | Atomic multi-partition writes |
| `enable-auto-commit=false` | Manual offset commit | Consumer controls exactly when offset advances |
| `isolation.level=read_committed` | Skip uncommitted messages | Consumer won't read aborted Kafka transactions |

## Schema Registry

The Avro schema is auto-registered on first produce.

View at: http://localhost:8081/subjects

```bash
# See registered schemas
curl http://localhost:8081/subjects

# See PaymentEvent schema
curl http://localhost:8081/subjects/payment-events-value/versions/latest
```
