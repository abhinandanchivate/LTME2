package com.payments;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payments.dto.PaymentDTOs.CreatePaymentRequest;
import com.payments.repository.PaymentOutboxRepository;
import com.payments.repository.PaymentRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Integration tests for all three scenarios:
 *  1. Happy path    — DB + Kafka both succeed
 *  2. DB failure    — transaction rolls back, NO outbox row, NO Kafka message
 *  3. Kafka failure — DB commits, outbox row stays PENDING for retry
 */
@SpringBootTest
@AutoConfigureMockMvc
@EmbeddedKafka(partitions = 1, topics = {"payment-events", "payment-events.DLT"})
@ActiveProfiles("test")
class PaymentIntegrationTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper mapper;
    @Autowired PaymentRepository paymentRepo;
    @Autowired PaymentOutboxRepository outboxRepo;

    @Test
    @DisplayName("Scenario 1 — happy path: DB saved + outbox row PENDING")
    void happyPath() throws Exception {
        long paymentsBefore = paymentRepo.count();
        long outboxBefore   = outboxRepo.count();

        var req = CreatePaymentRequest.builder()
                .userId("test-user-happy")
                .amount(new BigDecimal("1500.00"))
                .currency("INR")
                .merchantId("merchant-test")
                .paymentMethod("UPI")
                .build();

        mvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.userId").value("test-user-happy"))
                .andExpect(jsonPath("$.status").value("INITIATED"));

        // Both DB and outbox rows created
        assertThat(paymentRepo.count()).isEqualTo(paymentsBefore + 1);
        assertThat(outboxRepo.count()).isEqualTo(outboxBefore + 1);
    }

    @Test
    @DisplayName("Scenario 2 — DB failure: transaction rolls back, NO payment row, NO outbox row")
    void dbFailureRollsBackBoth() throws Exception {
        long paymentsBefore = paymentRepo.count();
        long outboxBefore   = outboxRepo.count();

        var req = CreatePaymentRequest.builder()
                .userId("test-user-db-fail")
                .amount(new BigDecimal("500.00"))
                .currency("INR")
                .simulateDbFailure(true)
                .build();

        mvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(req)))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.error").value("Internal Server Error"));

        // NEITHER row created — transaction rolled back atomically
        assertThat(paymentRepo.count()).isEqualTo(paymentsBefore);
        assertThat(outboxRepo.count()).isEqualTo(outboxBefore);
    }

    @Test
    @DisplayName("Scenario 3 — Kafka failure: DB commits, outbox row created for retry")
    void kafkaFailureLeavesOutboxPending() throws Exception {
        long paymentsBefore = paymentRepo.count();
        long outboxBefore   = outboxRepo.count();

        var req = CreatePaymentRequest.builder()
                .userId("test-user-kafka-fail")
                .amount(new BigDecimal("750.00"))
                .currency("INR")
                .simulateKafkaFailure(true)
                .build();

        mvc.perform(post("/api/payments")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(req)))
                .andExpect(status().isCreated());  // HTTP 201 — DB saved OK

        // Payment row saved
        assertThat(paymentRepo.count()).isEqualTo(paymentsBefore + 1);
        // Outbox row created (relay will attempt Kafka, fail, retry)
        assertThat(outboxRepo.count()).isEqualTo(outboxBefore + 1);

        // Outbox row status is PENDING — Kafka not yet delivered
        var latestOutbox = outboxRepo.findAll().stream()
                .filter(o -> "test-user-kafka-fail".equals(o.getPayment().getUserId()))
                .findFirst().orElseThrow();
        assertThat(latestOutbox.getStatus()).isEqualTo("PENDING");
    }
}
