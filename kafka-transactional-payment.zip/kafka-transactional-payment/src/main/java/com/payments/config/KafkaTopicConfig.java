package com.payments.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaAdmin;

import java.util.Map;

@Configuration
public class KafkaTopicConfig {

    @Value("${app.kafka.topics.payment-events}")
    private String paymentEventsTopic;

    @Value("${app.kafka.topics.payment-events-partitions:3}")
    private int partitions;

    @Value("${app.kafka.topics.payment-events-replicas:1}")
    private int replicas;

    /**
     * Declares the topic. KafkaAdmin will create it on startup if it doesn't exist.
     * In production: replication-factor=3, partitions=6+
     */
    @Bean
    public NewTopic paymentEventsTopic() {
        return TopicBuilder.name(paymentEventsTopic)
                .partitions(partitions)
                .replicas(replicas)
                // Retain messages for 7 days
                .config("retention.ms", String.valueOf(7 * 24 * 60 * 60 * 1000L))
                // min.insync.replicas — set to 2 in prod (requires replicas >= 2)
                .config("min.insync.replicas", "1")
                .build();
    }

    // Dead Letter Topic for failed events
    @Bean
    public NewTopic paymentDltTopic() {
        return TopicBuilder.name(paymentEventsTopic + ".DLT")
                .partitions(partitions)
                .replicas(replicas)
                .build();
    }
}
