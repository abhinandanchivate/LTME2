package com.payments.controller;

import com.payments.repository.PaymentOutboxRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/outbox")
@RequiredArgsConstructor
public class OutboxController {

    private final PaymentOutboxRepository outboxRepository;

    /**
     * Monitor outbox health — see PENDING/SENT/FAILED counts.
     * GET http://localhost:8090/api/outbox
     */
    @GetMapping
    public ResponseEntity<List<Map<String, Object>>> listOutbox() {
        var rows = outboxRepository.findAll().stream()
                .map(o -> Map.<String, Object>of(
                        "id", o.getId(),
                        "paymentId", o.getPayment().getId(),
                        "eventType", o.getEventType(),
                        "status", o.getStatus(),
                        "retryCount", o.getRetryCount(),
                        "createdAt", o.getCreatedAt(),
                        "sentAt", o.getSentAt() != null ? o.getSentAt().toString() : "—",
                        "error", o.getErrorMessage() != null ? o.getErrorMessage() : "—"
                )).toList();
        return ResponseEntity.ok(rows);
    }
}
