package com.payments.controller;

import com.payments.dto.PaymentDTOs.*;
import com.payments.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * PaymentController — three scenarios demonstrated:
 *
 *  POST /api/payments                        → happy path (DB + Kafka both succeed)
 *  POST /api/payments?simulateDbFailure=true → DB fails → both DB and Kafka roll back
 *  POST /api/payments?simulateKafkaFailure   → set in request body → DB commits,
 *                                              Kafka retried via outbox
 */
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
@Slf4j
public class PaymentController {

    private final PaymentService paymentService;

    /**
     * Create a payment.
     *
     * Request body examples:
     *
     * Happy path:
     * {
     *   "userId": "user-001",
     *   "amount": 1500.00,
     *   "currency": "INR",
     *   "merchantId": "merchant-42",
     *   "paymentMethod": "UPI"
     * }
     *
     * DB failure (transaction rolls back — no DB row, no Kafka message):
     * { ..., "simulateDbFailure": true }
     *
     * Kafka failure (DB row saved, outbox retried until Kafka recovers):
     * { ..., "simulateKafkaFailure": true }
     */
    @PostMapping
    public ResponseEntity<?> createPayment(@Valid @RequestBody CreatePaymentRequest request) {
        log.info("POST /api/payments — userId={} amount={} {} dbFail={} kafkaFail={}",
                request.getUserId(), request.getAmount(), request.getCurrency(),
                request.isSimulateDbFailure(), request.isSimulateKafkaFailure());
        try {
            PaymentResponse response = paymentService.createPayment(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception ex) {
            log.error("Payment creation failed: {}", ex.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ErrorResponse.builder()
                            .status(500)
                            .error("Payment Failed")
                            .message(ex.getMessage())
                            .timestamp(LocalDateTime.now())
                            .build());
        }
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Payment service is running");
    }
}
