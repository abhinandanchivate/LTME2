package com.payments.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.util.UUID;
import java.time.LocalDateTime;

// ── Request ────────────────────────────────────────────────────────────────
public class PaymentDTOs {

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class CreatePaymentRequest {

        @NotBlank(message = "userId is required")
        private String userId;

        @NotNull(message = "amount is required")
        @DecimalMin(value = "0.01", message = "amount must be greater than 0")
        @Digits(integer = 15, fraction = 4)
        private BigDecimal amount;

        @NotBlank(message = "currency is required")
        @Size(min = 3, max = 3, message = "currency must be a 3-letter ISO code")
        private String currency;

        private String merchantId;
        private String paymentMethod;

        // For testing rollback scenarios
        private boolean simulateDbFailure;
        private boolean simulateKafkaFailure;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class PaymentResponse {
        private UUID id;
        private String userId;
        private BigDecimal amount;
        private String currency;
        private String status;
        private String merchantId;
        private String paymentMethod;
        private LocalDateTime createdAt;
        private String message;
    }

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ErrorResponse {
        private int status;
        private String error;
        private String message;
        private LocalDateTime timestamp;
    }
}
