package com.payments.repository;

import com.payments.entity.PaymentOutbox;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import jakarta.persistence.LockModeType;
import java.util.List;
import java.util.UUID;

@Repository
public interface PaymentOutboxRepository extends JpaRepository<PaymentOutbox, UUID> {

    /**
     * Select PENDING outbox rows with SKIP LOCKED so that multiple app instances
     * don't process the same rows in parallel (safe for horizontal scaling).
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query(value = """
        SELECT o FROM PaymentOutbox o
        WHERE o.status = 'PENDING'
        ORDER BY o.createdAt ASC
        """)
    List<PaymentOutbox> findPendingForUpdate();
}
