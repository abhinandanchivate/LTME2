package com.payments.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.payments.entity.PaymentOutbox;
import com.payments.event.PaymentEvent;
import com.payments.event.PaymentEventType;
import com.payments.repository.PaymentOutboxRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * OutboxRelayService — the bridge between the DB outbox and Kafka.
 *
 * Runs on a fixed schedule. For each PENDING outbox row:
 *   1. Build the Avro PaymentEvent from the JSON payload
 *   2. Publish to Kafka (within a Kafka transaction for exactly-once)
 *   3. On success → mark outbox row SENT
 *   4. On failure → mark outbox row FAILED, increment retry_count
 *
 * The DB transaction in step 3+4 is a LOCAL DB transaction — it only
 * updates the outbox row status. The Kafka transaction is separate and
 * handled by KafkaTemplate.executeInTransaction().
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class OutboxRelayService {

    private final PaymentOutboxRepository outboxRepository;
    private final KafkaTemplate<String, PaymentEvent> kafkaTemplate;
    private final ObjectMapper objectMapper;

    @Value("${app.kafka.topics.payment-events}")
    private String paymentEventsTopic;

    private static final int MAX_RETRIES = 5;

    /**
     * Poll every ${app.outbox.polling-interval-ms} for PENDING outbox rows.
     * Uses @Transactional so that the PESSIMISTIC_WRITE lock on outbox rows
     * and the status update are atomic.
     */
    @Scheduled(fixedDelayString = "${app.outbox.polling-interval-ms:1000}")
    @Transactional
    public void relayPendingEvents() {
        List<PaymentOutbox> pending = outboxRepository.findPendingForUpdate();

        if (pending.isEmpty()) return;

        log.debug("Outbox relay: found {} PENDING row(s)", pending.size());

        for (PaymentOutbox outbox : pending) {
            if (outbox.getRetryCount() >= MAX_RETRIES) {
                log.error("Outbox row {} exceeded max retries. Marking FAILED.", outbox.getId());
                outbox.setStatus("FAILED");
                outbox.setErrorMessage("Max retries exceeded");
                outboxRepository.save(outbox);
                continue;
            }
            publishToKafka(outbox);
        }
    }

    private void publishToKafka(PaymentOutbox outbox) {
        try {
            JsonNode node = objectMapper.readTree(outbox.getPayload());

            // ── Simulate Kafka failure for demo purposes ────────────────────
            if (node.has("simulateKafkaFailure") && node.get("simulateKafkaFailure").asBoolean()) {
                throw new RuntimeException("Simulated Kafka publish failure");
            }

            // ── Build Avro PaymentEvent from outbox JSON payload ────────────
            PaymentEvent event = PaymentEvent.newBuilder()
                    .setEventId(node.get("eventId").asText())
                    .setEventType(PaymentEventType.valueOf(node.get("eventType").asText()))
                    .setPaymentId(node.get("paymentId").asText())
                    .setUserId(node.get("userId").asText())
                    .setAmount(node.get("amount").asDouble())
                    .setCurrency(node.get("currency").asText())
                    .setStatus(node.get("status").asText())
                    .setTimestamp(node.get("timestamp").asLong())
                    .setMerchantId(node.has("merchantId") ? node.get("merchantId").asText() : null)
                    .setPaymentMethod(node.has("paymentMethod") ? node.get("paymentMethod").asText() : null)
                    .setErrorReason(null)
                    .build();

            // ── Publish within a Kafka transaction ─────────────────────────
            // executeInTransaction ensures the Kafka send is atomic.
            // If the send fails mid-way, the Kafka transaction is aborted.
            String messageKey = event.getUserId().toString(); // partition by userId → ordering per user

            kafkaTemplate.executeInTransaction(ops -> {
                var future = ops.send(paymentEventsTopic, messageKey, event);
                future.whenComplete((result, ex) -> {
                    if (ex != null) {
                        log.error("Kafka send failed for outboxId={}: {}", outbox.getId(), ex.getMessage());
                    } else {
                        log.info("Kafka send OK: topic={} partition={} offset={} paymentId={}",
                                result.getRecordMetadata().topic(),
                                result.getRecordMetadata().partition(),
                                result.getRecordMetadata().offset(),
                                event.getPaymentId());
                    }
                });
                return null;
            });

            // ── Mark outbox row SENT ────────────────────────────────────────
            outbox.setStatus("SENT");
            outbox.setSentAt(LocalDateTime.now());
            outboxRepository.save(outbox);
            log.info("Outbox row {} marked SENT for paymentId={}", outbox.getId(), event.getPaymentId());

        } catch (Exception ex) {
            // ── Kafka publish failed → increment retry, keep PENDING ────────
            // The outbox row will be retried on the next poll cycle.
            // The DB record is NOT rolled back — payment data is safe.
            outbox.setRetryCount(outbox.getRetryCount() + 1);
            outbox.setErrorMessage(ex.getMessage());
            outboxRepository.save(outbox);
            log.error("Kafka publish failed for outboxId={} (attempt {}): {}",
                    outbox.getId(), outbox.getRetryCount(), ex.getMessage());
        }
    }
}
