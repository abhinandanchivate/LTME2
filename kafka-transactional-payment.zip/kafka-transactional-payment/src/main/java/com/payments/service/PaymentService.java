package com.payments.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payments.dto.PaymentDTOs.*;
import com.payments.entity.Payment;
import com.payments.entity.PaymentOutbox;
import com.payments.repository.PaymentOutboxRepository;
import com.payments.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * PaymentService — Transactional Outbox Pattern
 *
 * HOW ATOMICITY WORKS:
 * ┌─────────────────────────────────────────────────────┐
 * │  @Transactional                                     │
 * │  BEGIN                                              │
 * │    1. INSERT payments row       ← business data     │
 * │    2. INSERT payment_outbox row ← event to publish  │
 * │  COMMIT  (both succeed or both rollback)            │
 * └─────────────────────────────────────────────────────┘
 *
 * The OutboxRelayService (scheduler) picks up PENDING outbox rows
 * and publishes them to Kafka. On success → SENT. On failure → retry.
 *
 * Guarantees:
 *  • DB tx rolls back  → no outbox row → no Kafka message          ✓
 *  • DB tx commits     → outbox row exists → Kafka publish retried  ✓
 *  • Kafka publish ok  → outbox row marked SENT                    ✓
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final PaymentOutboxRepository outboxRepository;
    private final ObjectMapper objectMapper;

    /**
     * Create a payment and queue its Kafka event atomically.
     * Both the payment row and the outbox row are written in one DB transaction.
     *
     * @param request the create-payment request
     * @return the saved payment response
     */
    @Transactional  // ← single DB transaction covers BOTH inserts
    public PaymentResponse createPayment(CreatePaymentRequest request) {

        // ── Simulate DB failure scenario (for demo/testing) ──────────────────
        if (request.isSimulateDbFailure()) {
            log.warn("Simulating DB failure — transaction will roll back, NO Kafka message will be sent");
            throw new RuntimeException("Simulated DB failure: payment NOT saved, Kafka NOT published");
        }

        // ── Step 1: Save business data ────────────────────────────────────────
        Payment payment = Payment.builder()
                .userId(request.getUserId())
                .amount(request.getAmount())
                .currency(request.getCurrency())
                .status("INITIATED")
                .merchantId(request.getMerchantId())
                .paymentMethod(request.getPaymentMethod())
                .build();

        payment = paymentRepository.save(payment);
        log.info("Payment saved to DB: paymentId={}, userId={}", payment.getId(), payment.getUserId());

        // ── Step 2: Write outbox row (same transaction) ──────────────────────
        // The payload is a JSON snapshot of the event.
        // The relay service will use this to build the Avro PaymentEvent.
        String payload = buildPayload(payment, "PAYMENT_INITIATED",
                request.isSimulateKafkaFailure());

        PaymentOutbox outbox = PaymentOutbox.builder()
                .payment(payment)
                .eventType("PAYMENT_INITIATED")
                .payload(payload)
                .status("PENDING")
                .build();

        outboxRepository.save(outbox);
        log.info("Outbox row queued: outboxId={}, paymentId={}", outbox.getId(), payment.getId());

        // ── Both inserts succeed → transaction commits ────────────────────────
        // Kafka publish happens AFTER this method returns, via OutboxRelayService.
        return mapToResponse(payment, "Payment initiated. Event queued for Kafka.");
    }

    private String buildPayload(Payment payment, String eventType, boolean simulateKafkaFailure) {
        try {
            var node = objectMapper.createObjectNode();
            node.put("eventId", UUID.randomUUID().toString());
            node.put("eventType", eventType);
            node.put("paymentId", payment.getId().toString());
            node.put("userId", payment.getUserId());
            node.put("amount", payment.getAmount().doubleValue());
            node.put("currency", payment.getCurrency());
            node.put("status", payment.getStatus());
            node.put("timestamp", System.currentTimeMillis());
            node.put("simulateKafkaFailure", simulateKafkaFailure); // relay reads this
            if (payment.getMerchantId() != null) node.put("merchantId", payment.getMerchantId());
            if (payment.getPaymentMethod() != null) node.put("paymentMethod", payment.getPaymentMethod());
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            throw new RuntimeException("Failed to serialise outbox payload", e);
        }
    }

    private PaymentResponse mapToResponse(Payment payment, String message) {
        return PaymentResponse.builder()
                .id(payment.getId())
                .userId(payment.getUserId())
                .amount(payment.getAmount())
                .currency(payment.getCurrency())
                .status(payment.getStatus())
                .merchantId(payment.getMerchantId())
                .paymentMethod(payment.getPaymentMethod())
                .createdAt(payment.getCreatedAt())
                .message(message)
                .build();
    }
}
