package com.payments.service;

import com.payments.event.PaymentEvent;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;

/**
 * PaymentEventConsumer — listens to the payment-events topic.
 *
 * In a real microservices setup this would be a separate service (e.g. FraudService).
 * Here it is in the same app to demonstrate the full round-trip.
 *
 * Key settings (from application.yml):
 *   enable-auto-commit: false   → manual ack after processing
 *   isolation.level: read_committed → only reads committed Kafka transactions
 *   specific.avro.reader: true  → deserialises into generated PaymentEvent class
 */
@Service
@Slf4j
public class PaymentEventConsumer {

    @KafkaListener(
            topics = "${app.kafka.topics.payment-events}",
            groupId = "${spring.kafka.consumer.group-id}",
            containerFactory = "kafkaListenerContainerFactory"
    )
    public void onPaymentEvent(ConsumerRecord<String, PaymentEvent> record,
                               Acknowledgment acknowledgment) {

        PaymentEvent event = record.value();

        log.info("""
                ╔══ PaymentEvent received ══════════════════════════
                ║  topic     : {}
                ║  partition : {}
                ║  offset    : {}
                ║  key       : {}
                ║  eventId   : {}
                ║  eventType : {}
                ║  paymentId : {}
                ║  userId    : {}
                ║  amount    : {} {}
                ║  status    : {}
                ╚═══════════════════════════════════════════════════
                """,
                record.topic(), record.partition(), record.offset(),
                record.key(),
                event.getEventId(), event.getEventType(),
                event.getPaymentId(), event.getUserId(),
                event.getAmount(), event.getCurrency(),
                event.getStatus());

        // ── Process the event ───────────────────────────────────────────────
        // e.g. call fraud detection, update read model, trigger notifications
        processPaymentEvent(event);

        // ── Manually acknowledge offset AFTER successful processing ─────────
        // If processing throws an exception, offset is NOT committed →
        // message will be redelivered (at-least-once).
        acknowledgment.acknowledge();
    }

    private void processPaymentEvent(PaymentEvent event) {
        switch (event.getEventType()) {
            case PAYMENT_INITIATED ->
                log.info("Processing PAYMENT_INITIATED: routing to fraud check for paymentId={}", event.getPaymentId());
            case PAYMENT_COMPLETED ->
                log.info("Processing PAYMENT_COMPLETED: updating ledger for paymentId={}", event.getPaymentId());
            case PAYMENT_FAILED ->
                log.warn("Processing PAYMENT_FAILED: reason={} for paymentId={}", event.getErrorReason(), event.getPaymentId());
            default ->
                log.warn("Unknown event type: {}", event.getEventType());
        }
    }
}
