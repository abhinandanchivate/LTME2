package com.payments.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Outbox table row.
 *
 * The Transactional Outbox Pattern works like this:
 *
 *   BEGIN TRANSACTION
 *     INSERT INTO payments (...)       ← business write
 *     INSERT INTO payment_outbox (...)  ← outbox write (same tx)
 *   COMMIT
 *
 * A separate scheduler thread reads PENDING rows and publishes them to Kafka.
 * On successful publish → status = SENT.
 * On failure            → status = FAILED, retry_count++.
 *
 * Result: DB and Kafka are ALWAYS consistent.
 * If the DB tx rolls back → no outbox row → no Kafka message.
 * If Kafka publish fails  → outbox row stays PENDING → retried next poll.
 */
@Entity
@Table(name = "payment_outbox")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class PaymentOutbox {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "payment_id", nullable = false)
    private Payment payment;

    @Column(name = "event_type", nullable = false)
    private String eventType;

    // JSON payload stored in Postgres JSONB column
    @JdbcTypeCode(SqlTypes.JSON)
    @Column(columnDefinition = "jsonb", nullable = false)
    private String payload;

    @Column(nullable = false)
    @Builder.Default
    private String status = "PENDING";   // PENDING | SENT | FAILED

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "sent_at")
    private LocalDateTime sentAt;

    @Column(name = "error_message", columnDefinition = "TEXT")
    private String errorMessage;

    @Column(name = "retry_count", nullable = false)
    @Builder.Default
    private int retryCount = 0;
}
