-- ============================================================
-- Payment DB Schema
-- Uses Transactional Outbox Pattern:
--   1. payment row inserted
--   2. outbox row inserted (same DB transaction)
--   3. outbox relay publishes to Kafka + marks row sent
-- This ensures DB + Kafka are ALWAYS in sync
-- ============================================================

CREATE TABLE IF NOT EXISTS payments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         VARCHAR(100) NOT NULL,
    amount          DECIMAL(19,4) NOT NULL CHECK (amount > 0),
    currency        VARCHAR(3) NOT NULL DEFAULT 'INR',
    status          VARCHAR(50) NOT NULL DEFAULT 'INITIATED',
    merchant_id     VARCHAR(100),
    payment_method  VARCHAR(50),
    created_at      TIMESTAMP NOT NULL DEFAULT now(),
    updated_at      TIMESTAMP NOT NULL DEFAULT now()
);

-- Outbox table — every event that needs to go to Kafka lands here first
-- in the same DB transaction as the business data write
CREATE TABLE IF NOT EXISTS payment_outbox (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payment_id      UUID NOT NULL REFERENCES payments(id),
    event_type      VARCHAR(100) NOT NULL,
    payload         JSONB NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'PENDING',  -- PENDING | SENT | FAILED
    created_at      TIMESTAMP NOT NULL DEFAULT now(),
    sent_at         TIMESTAMP,
    error_message   TEXT,
    retry_count     INT NOT NULL DEFAULT 0
);

CREATE INDEX idx_outbox_status ON payment_outbox(status) WHERE status = 'PENDING';
CREATE INDEX idx_payments_user ON payments(user_id);

-- Seed a test user scenario
INSERT INTO payments (id, user_id, amount, currency, status, merchant_id, payment_method)
VALUES ('00000000-0000-0000-0000-000000000001', 'user-seed-01', 1.00, 'INR', 'COMPLETED', 'merchant-seed', 'UPI')
ON CONFLICT DO NOTHING;
