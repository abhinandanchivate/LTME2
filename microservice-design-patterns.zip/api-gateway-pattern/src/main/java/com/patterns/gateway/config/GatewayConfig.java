package com.patterns.gateway.config;

import com.patterns.gateway.filter.JwtAuthFilter;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * API Gateway Route Configuration
 *
 * Defines routing rules programmatically (alternative to YAML config).
 * Each route specifies:
 *   - predicate: what requests to match
 *   - filters: what transformations to apply
 *   - uri: where to forward the request
 *
 * Routes defined here are in ADDITION to application.yml routes.
 */
@Configuration
public class GatewayConfig {

    private final JwtAuthFilter jwtAuthFilter;

    public GatewayConfig(JwtAuthFilter jwtAuthFilter) {
        this.jwtAuthFilter = jwtAuthFilter;
    }

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()

            // Route 1: Products service with JWT auth + request header transformation
            .route("product-service-secure", r -> r
                .path("/api/products/**")
                .filters(f -> f
                    .filter(jwtAuthFilter.apply(new JwtAuthFilter.Config()))
                    .addRequestHeader("X-Gateway-Source", "api-gateway")
                    .addResponseHeader("X-Response-Time", String.valueOf(System.currentTimeMillis()))
                    .rewritePath("/api/products/(?<segment>.*)", "/products/${segment}") // strip /api prefix
                )
                .uri("lb://product-service") // lb:// = load balanced via service discovery
            )

            // Route 2: Orders service with circuit breaker
            .route("order-service-with-cb", r -> r
                .path("/api/orders/**")
                .filters(f -> f
                    .filter(jwtAuthFilter.apply(new JwtAuthFilter.Config()))
                    .circuitBreaker(config -> config
                        .setName("orderServiceCB")
                        .setFallbackUri("forward:/fallback/orders") // fallback endpoint
                    )
                    .rewritePath("/api/orders/(?<segment>.*)", "/orders/${segment}")
                    .retry(retryConfig -> retryConfig.setRetries(3)) // retry 3 times on failure
                )
                .uri("lb://order-service")
            )

            // Route 3: Public health check - no auth required
            .route("health-check", r -> r
                .path("/health")
                .filters(f -> f
                    .addResponseHeader("Cache-Control", "no-cache")
                )
                .uri("http://localhost:8080") // self
            )

            // Route 4: Users service - with rate limiting (requires Redis)
            .route("user-service", r -> r
                .path("/api/users/**")
                .filters(f -> f
                    .filter(jwtAuthFilter.apply(new JwtAuthFilter.Config()))
                    .rewritePath("/api/users/(?<segment>.*)", "/users/${segment}")
                    // Rate limiting: requestedTokens=1, replenishRate=10, burstCapacity=20
                    // .requestRateLimiter(config -> config.setRateLimiter(redisRateLimiter()))
                )
                .uri("lb://user-service")
            )

            .build();
    }
}
