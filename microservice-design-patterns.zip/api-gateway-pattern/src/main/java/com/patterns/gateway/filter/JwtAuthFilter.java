package com.patterns.gateway.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * JWT Authentication Gateway Filter
 *
 * Applied to protected routes. Validates Bearer token before forwarding.
 * If invalid → 401 Unauthorized returned immediately, downstream never called.
 *
 * Usage in config: filters: - JwtAuthFilter
 */
@Component
public class JwtAuthFilter extends AbstractGatewayFilterFactory<JwtAuthFilter.Config> {

    private static final Logger log = LoggerFactory.getLogger(JwtAuthFilter.class);
    private static final String VALID_TOKEN = "valid-jwt-token-12345"; // Simplified for demo

    public JwtAuthFilter() {
        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            String path = exchange.getRequest().getPath().toString();
            log.info("[Gateway] Auth check for path: {}", path);

            String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                log.warn("[Gateway] Missing or malformed Authorization header");
                exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                return exchange.getResponse().setComplete();
            }

            String token = authHeader.substring(7);

            if (!isValidToken(token)) {
                log.warn("[Gateway] Invalid JWT token rejected");
                exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                return exchange.getResponse().setComplete();
            }

            // Token valid: extract user info and forward as header to downstream
            String userId = extractUserId(token);
            log.info("[Gateway] Auth passed for userId: {}", userId);

            var mutatedRequest = exchange.getRequest().mutate()
                    .header("X-User-Id", userId)
                    .header("X-Auth-Status", "authenticated")
                    .build();

            return chain.filter(exchange.mutate().request(mutatedRequest).build());
        };
    }

    private boolean isValidToken(String token) {
        // Production: decode JWT, verify signature, check expiry
        return VALID_TOKEN.equals(token);
    }

    private String extractUserId(String token) {
        // Production: decode JWT claims and extract subject
        return "user-001";
    }

    public static class Config {
        // Add filter-specific config here if needed
    }
}
