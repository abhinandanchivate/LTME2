package com.patterns.gateway.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Fallback Controller
 *
 * Called by circuit breaker when downstream service is unavailable.
 * Returns graceful degraded responses instead of raw errors.
 *
 * This is the "fallback" in circuit breaker configuration:
 *   .setFallbackUri("forward:/fallback/orders")
 */
@RestController
@RequestMapping("/fallback")
public class FallbackController {

    private static final Logger log = LoggerFactory.getLogger(FallbackController.class);

    @GetMapping("/orders")
    public ResponseEntity<Map<String, Object>> ordersFallback() {
        log.warn("[Gateway] Order service unavailable, returning fallback response");
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(Map.of(
            "status", "degraded",
            "message", "Order service is temporarily unavailable. Please try again in a moment.",
            "retryAfterSeconds", 30,
            "supportEmail", "support@example.com"
        ));
    }

    @GetMapping("/products")
    public ResponseEntity<Map<String, Object>> productsFallback() {
        log.warn("[Gateway] Product service unavailable, returning fallback response");
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(Map.of(
            "status", "degraded",
            "message", "Product catalog is temporarily unavailable.",
            "cachedData", "Please visit our status page at status.example.com"
        ));
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
            "status", "UP",
            "service", "api-gateway",
            "message", "Gateway is running"
        ));
    }
}
