package com.patterns.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * API Gateway Pattern
 *
 * CONCEPT: A single entry point for all clients. The gateway handles:
 *   1. ROUTING: Forward requests to correct microservice
 *   2. AUTHENTICATION: Validate JWT tokens before forwarding
 *   3. RATE LIMITING: Prevent abuse (e.g., 10 req/sec per user)
 *   4. LOAD BALANCING: Distribute requests across instances
 *   5. CIRCUIT BREAKING: Fail fast when downstream services are down
 *   6. REQUEST/RESPONSE TRANSFORMATION: Add/remove headers
 *   7. CORS: Handle cross-origin requests centrally
 *
 * WHY USE IT:
 * - Clients talk to ONE endpoint instead of many microservices
 * - Security concerns (auth, rate limiting) handled centrally
 * - Decouples clients from internal service topology
 * - Enables canary deployments and A/B testing via routing rules
 *
 * FLOW: Client → API Gateway (port 8080)
 *                    ├── /api/products/** → product-service:8090
 *                    ├── /api/orders/**   → order-service:8091
 *                    ├── /api/users/**    → user-service:8092
 *                    └── /api/inventory/**→ inventory-service:8093
 */
@SpringBootApplication
public class ApiGatewayApplication {
    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
}
