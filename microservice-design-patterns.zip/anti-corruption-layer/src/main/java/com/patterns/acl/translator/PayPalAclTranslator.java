package com.patterns.acl.translator;

import com.patterns.acl.external.PayPalOrderResponse;
import com.patterns.acl.internal.PaymentRequest;
import com.patterns.acl.internal.PaymentResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * PayPal Anti-Corruption Layer Translator
 *
 * Translates PayPal's complex nested response structure into your clean domain model.
 * Notice how different this is from Stripe - same concept, completely different API.
 *
 * Key translations:
 *   PayPal nested purchase_units[0].amount.value (String) → Your amount (Double)
 *   PayPal "COMPLETED"                           → Your COMPLETED (happens to match)
 *   PayPal ISO 8601 string                       → Your LocalDateTime
 *   PayPal paypalOrderId                         → Your transactionId
 */
@Component
public class PayPalAclTranslator {

    private static final Logger log = LoggerFactory.getLogger(PayPalAclTranslator.class);
    private static final DateTimeFormatter PAYPAL_DATE_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");

    /**
     * Translate YOUR internal request → PayPal's request format
     */
    public Map<String, Object> toPayPalRequest(PaymentRequest internalRequest) {
        log.debug("[ACL→PayPal] Translating internal PaymentRequest to PayPal format");

        return Map.of(
            "intent", "CAPTURE",
            "purchase_units", List.of(Map.of(
                "reference_id", internalRequest.getOrderId(),
                "amount", Map.of(
                    "currency_code", internalRequest.getCurrency(),    // Already uppercase
                    "value", String.format("%.2f", internalRequest.getAmount())  // Double → String!
                )
            )),
            "payment_source", Map.of(
                "token", Map.of(
                    "id", internalRequest.getCardToken(),
                    "type", "BILLING_AGREEMENT"
                )
            )
        );
    }

    /**
     * Translate PayPal's nested response → YOUR internal PaymentResult
     */
    public PaymentResult fromPayPalResponse(PayPalOrderResponse paypalResponse, String orderId) {
        log.debug("[PayPal→ACL] Translating PayPal response to internal PaymentResult");

        // Navigate PayPal's deeply nested structure
        Double amount = extractAmount(paypalResponse);
        String currency = extractCurrency(paypalResponse);
        String captureId = extractCaptureId(paypalResponse);
        boolean success = "COMPLETED".equals(paypalResponse.getPaypalStatus());

        return PaymentResult.builder()
                .success(success)
                .transactionId(captureId != null ? captureId : paypalResponse.getPaypalOrderId())
                .orderId(orderId)
                .amount(amount)
                .currency(currency)
                .status(mapPayPalStatus(paypalResponse.getPaypalStatus()))
                .failureReason(success ? null : "Payment not approved by PayPal")
                .processedAt(parsePayPalDate(paypalResponse.getCreateTime()))
                .providerName("PAYPAL")
                .build();
    }

    // === Private extraction helpers (deal with PayPal's nested mess) ===

    private Double extractAmount(PayPalOrderResponse response) {
        try {
            String valueStr = response.getPurchaseUnits().get(0).getAmount().getValue();
            return Double.parseDouble(valueStr); // PayPal sends amount as String
        } catch (Exception e) {
            log.warn("[PayPal→ACL] Could not extract amount from PayPal response");
            return 0.0;
        }
    }

    private String extractCurrency(PayPalOrderResponse response) {
        try {
            return response.getPurchaseUnits().get(0).getAmount().getCurrencyCode();
        } catch (Exception e) {
            return "USD";
        }
    }

    private String extractCaptureId(PayPalOrderResponse response) {
        try {
            return response.getPurchaseUnits().get(0).getPayments().getCaptures().get(0).getCaptureId();
        } catch (Exception e) {
            return null;
        }
    }

    private PaymentResult.PaymentStatus mapPayPalStatus(String paypalStatus) {
        return switch (paypalStatus) {
            case "COMPLETED" -> PaymentResult.PaymentStatus.COMPLETED;
            case "APPROVED"  -> PaymentResult.PaymentStatus.PENDING;
            case "VOIDED"    -> PaymentResult.PaymentStatus.FAILED;
            default          -> PaymentResult.PaymentStatus.FAILED;
        };
    }

    private LocalDateTime parsePayPalDate(String dateStr) {
        if (dateStr == null) return LocalDateTime.now();
        try {
            return LocalDateTime.parse(dateStr, PAYPAL_DATE_FORMAT);
        } catch (Exception e) {
            return LocalDateTime.now();
        }
    }
}
