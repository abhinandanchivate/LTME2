package com.patterns.acl.external;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

/**
 * PAYPAL's API response model.
 * Completely different structure from Stripe.
 * Amount is a String in a nested object. Status uses different enum values.
 * We NEVER use this class outside the ACL package.
 */
@Data
public class PayPalOrderResponse {

    @JsonProperty("id")
    private String paypalOrderId;       // "5O190127TN364715T"

    @JsonProperty("status")
    private String paypalStatus;        // "COMPLETED", "APPROVED", "VOIDED" (different from Stripe!)

    @JsonProperty("purchase_units")
    private List<PurchaseUnit> purchaseUnits;  // Nested structure (Stripe is flat)

    @JsonProperty("create_time")
    private String createTime;          // ISO 8601 string (unlike Stripe's Unix timestamp)

    @Data
    public static class PurchaseUnit {
        @JsonProperty("amount")
        private Amount amount;

        @JsonProperty("payments")
        private Payments payments;
    }

    @Data
    public static class Amount {
        @JsonProperty("currency_code")
        private String currencyCode;    // "USD" (uppercase, unlike Stripe's lowercase)

        @JsonProperty("value")
        private String value;           // "29.99" as STRING (unlike Stripe's int cents)
    }

    @Data
    public static class Payments {
        @JsonProperty("captures")
        private List<Capture> captures;
    }

    @Data
    public static class Capture {
        @JsonProperty("id")
        private String captureId;

        @JsonProperty("status")
        private String captureStatus;   // "COMPLETED", "DECLINED", "FAILED"

        @JsonProperty("final_capture")
        private Boolean finalCapture;
    }
}
