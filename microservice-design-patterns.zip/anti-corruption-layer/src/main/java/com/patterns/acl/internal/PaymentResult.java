package com.patterns.acl.internal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

/**
 * YOUR internal domain's payment result.
 * Completely provider-agnostic - doesn't matter if Stripe or PayPal processed it.
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PaymentResult {
    private boolean success;
    private String transactionId;     // Our universal transaction ID
    private String orderId;
    private Double amount;
    private String currency;
    private PaymentStatus status;
    private String failureReason;     // Normalized failure reason
    private LocalDateTime processedAt;
    private String providerName;      // Which provider processed it (for audit)

    public enum PaymentStatus {
        COMPLETED, FAILED, PENDING, REFUNDED
    }
}
