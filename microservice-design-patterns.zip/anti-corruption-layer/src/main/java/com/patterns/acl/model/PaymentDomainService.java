package com.patterns.acl.model;

import com.patterns.acl.external.PayPalOrderResponse;
import com.patterns.acl.external.StripeChargeResponse;
import com.patterns.acl.internal.PaymentRequest;
import com.patterns.acl.internal.PaymentResult;
import com.patterns.acl.translator.PayPalAclTranslator;
import com.patterns.acl.translator.StripeAclTranslator;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Payment Domain Service
 *
 * Your business logic lives here. It ONLY uses internal domain models.
 * It NEVER imports or references Stripe or PayPal classes.
 * The ACL translators handle all provider-specific concerns.
 *
 * This is what "anti-corruption" means for your domain code:
 * it's completely isolated from external provider complexity.
 */
@Service
@RequiredArgsConstructor
public class PaymentDomainService {

    private static final Logger log = LoggerFactory.getLogger(PaymentDomainService.class);

    private final StripeAclTranslator stripeAcl;
    private final PayPalAclTranslator paypalAcl;

    /**
     * Process payment - routes to correct provider via ACL
     * YOUR CODE only works with PaymentRequest and PaymentResult.
     */
    public PaymentResult processPayment(PaymentRequest request) {
        log.info("[Domain] Processing payment for order {} via {}",
                request.getOrderId(), request.getProvider());

        return switch (request.getProvider()) {
            case STRIPE -> processViaStripe(request);
            case PAYPAL -> processViaPayPal(request);
            case SQUARE -> throw new UnsupportedOperationException("Square not yet integrated");
        };
    }

    private PaymentResult processViaStripe(PaymentRequest request) {
        // Step 1: ACL translates YOUR request → Stripe format
        var stripeRequest = stripeAcl.toStripeRequest(request);
        log.info("[Domain→ACL→Stripe] Request translated: {}", stripeRequest);

        // Step 2: Call Stripe API (simulated)
        StripeChargeResponse stripeResponse = simulateStripeCall(request);

        // Step 3: ACL translates Stripe response → YOUR domain model
        PaymentResult result = stripeAcl.fromStripeResponse(stripeResponse, request.getOrderId());
        log.info("[Stripe→ACL→Domain] Response translated. Success={}", result.isSuccess());

        return result;
    }

    private PaymentResult processViaPayPal(PaymentRequest request) {
        // Step 1: ACL translates YOUR request → PayPal format
        var paypalRequest = paypalAcl.toPayPalRequest(request);
        log.info("[Domain→ACL→PayPal] Request translated: {}", paypalRequest);

        // Step 2: Call PayPal API (simulated)
        PayPalOrderResponse paypalResponse = simulatePayPalCall(request);

        // Step 3: ACL translates PayPal response → YOUR domain model
        PaymentResult result = paypalAcl.fromPayPalResponse(paypalResponse, request.getOrderId());
        log.info("[PayPal→ACL→Domain] Response translated. Success={}", result.isSuccess());

        return result;
    }

    // Simulate provider API calls with dummy data
    private StripeChargeResponse simulateStripeCall(PaymentRequest request) {
        var response = new StripeChargeResponse();
        response.setChargeId("ch_3NKp" + System.currentTimeMillis());
        response.setAmountInCents((int)(request.getAmount() * 100));  // Stripe format: cents
        response.setCurrencyCode(request.getCurrency().toLowerCase()); // Stripe format: lowercase
        response.setStripeStatus("succeeded");
        response.setCreatedTimestamp(System.currentTimeMillis() / 1000);
        response.setPaid(true);
        response.setCaptured(true);
        return response;
    }

    private PayPalOrderResponse simulatePayPalCall(PaymentRequest request) {
        var amount = new PayPalOrderResponse.Amount();
        amount.setCurrencyCode(request.getCurrency());              // PayPal: uppercase
        amount.setValue(String.format("%.2f", request.getAmount())); // PayPal: String!

        var capture = new PayPalOrderResponse.Capture();
        capture.setCaptureId("CAP_" + System.currentTimeMillis());
        capture.setCaptureStatus("COMPLETED");
        capture.setFinalCapture(true);

        var payments = new PayPalOrderResponse.Payments();
        payments.setCaptures(List.of(capture));

        var purchaseUnit = new PayPalOrderResponse.PurchaseUnit();
        purchaseUnit.setAmount(amount);
        purchaseUnit.setPayments(payments);

        var response = new PayPalOrderResponse();
        response.setPaypalOrderId("PP_" + System.currentTimeMillis());
        response.setPaypalStatus("COMPLETED");
        response.setPurchaseUnits(List.of(purchaseUnit));
        response.setCreateTime("2024-01-15T10:30:00+0000");

        return response;
    }
}
