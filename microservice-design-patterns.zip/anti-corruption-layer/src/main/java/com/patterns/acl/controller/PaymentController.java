package com.patterns.acl.controller;

import com.patterns.acl.internal.PaymentRequest;
import com.patterns.acl.internal.PaymentResult;
import com.patterns.acl.model.PaymentDomainService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Payment Controller
 *
 * Notice: this controller only uses YOUR internal domain models.
 * No Stripe or PayPal classes anywhere near business logic.
 */
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentDomainService paymentService;

    /**
     * POST /api/payments/process
     *
     * Try with different providers:
     *   { "orderId": "ORD-001", "amount": 99.99, "currency": "USD",
     *     "customerEmail": "test@example.com", "provider": "STRIPE",
     *     "cardToken": "tok_visa" }
     *
     *   { "orderId": "ORD-002", "amount": 149.50, "currency": "USD",
     *     "customerEmail": "test@example.com", "provider": "PAYPAL",
     *     "cardToken": "BA-tokenXYZ" }
     */
    @PostMapping("/process")
    public ResponseEntity<PaymentResult> processPayment(@RequestBody PaymentRequest request) {
        PaymentResult result = paymentService.processPayment(request);
        return ResponseEntity.ok(result);
    }
}
