package com.patterns.acl.external;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * STRIPE's API response model.
 * This is their domain, their naming, their format.
 * Amount is in CENTS. Status uses their own enum values.
 * We NEVER use this class outside the ACL package.
 */
@Data
public class StripeChargeResponse {

    @JsonProperty("id")
    private String chargeId;            // "ch_3NKp..."

    @JsonProperty("amount")
    private Integer amountInCents;      // 2999 means $29.99 (Stripe uses cents!)

    @JsonProperty("currency")
    private String currencyCode;        // lowercase "usd" (not "USD")

    @JsonProperty("status")
    private String stripeStatus;        // "succeeded", "failed", "pending" (their values)

    @JsonProperty("failure_message")
    private String failureMessage;      // "Your card was declined."

    @JsonProperty("failure_code")
    private String failureCode;         // "card_declined", "insufficient_funds"

    @JsonProperty("created")
    private Long createdTimestamp;      // Unix timestamp (not ISO 8601!)

    @JsonProperty("paid")
    private Boolean paid;

    @JsonProperty("captured")
    private Boolean captured;
}
