package com.patterns.acl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Anti-Corruption Layer (ACL) Pattern
 *
 * CONCEPT: A translation/isolation layer that sits between your domain and
 * an external system (third-party API, legacy system, or bounded context with
 * a different domain model). It prevents the external system's concepts,
 * language, and model from "corrupting" your clean domain model.
 *
 * THE PROBLEM WITHOUT ACL:
 * If you directly use an external system's model in your domain:
 *   - Your code becomes tightly coupled to their API structure
 *   - Their naming conventions, data formats, and concepts bleed into your domain
 *   - If they change their API, it breaks your entire domain
 *   - Impossible to swap the external system without rewriting everything
 *
 * THE SOLUTION (ACL):
 * External System Model ←→ [ACL: Translator/Adapter] ←→ Your Domain Model
 *
 * IN THIS EXAMPLE:
 * We integrate with TWO external payment providers (Stripe-like and PayPal-like)
 * each with completely different API models. Our internal order domain never
 * sees their models - only clean internal domain objects.
 *
 * YOUR DOMAIN stays clean:
 *   Order { orderId, amount, currency, paymentStatus }
 *   PaymentResult { success, transactionId, message }
 *
 * EXTERNAL MODELS get isolated in ACL:
 *   StripePaymentResponse { charge_id, amount_cents, currency_code, status, failure_message }
 *   PayPalPaymentResponse { paypal_order_id, purchase_unit_amount, unit_currency, state, reason }
 */
@SpringBootApplication
public class AntiCorruptionLayerApplication {
    public static void main(String[] args) {
        SpringApplication.run(AntiCorruptionLayerApplication.class, args);
    }
}
