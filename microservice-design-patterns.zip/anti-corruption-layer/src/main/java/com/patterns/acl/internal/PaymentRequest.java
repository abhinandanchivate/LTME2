package com.patterns.acl.internal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * YOUR internal domain's payment request.
 * Clean, business-focused, provider-agnostic.
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class PaymentRequest {
    private String orderId;
    private Double amount;           // In dollars, always
    private String currency;         // ISO 4217: "USD", "EUR"
    private String customerEmail;
    private PaymentProvider provider; // Which gateway to use
    private String cardToken;        // Pre-tokenized card reference

    public enum PaymentProvider {
        STRIPE, PAYPAL, SQUARE
    }
}
