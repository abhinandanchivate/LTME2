package com.patterns.acl.translator;

import com.patterns.acl.external.StripeChargeResponse;
import com.patterns.acl.internal.PaymentRequest;
import com.patterns.acl.internal.PaymentResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Map;

/**
 * Stripe Anti-Corruption Layer Translator
 *
 * Translates BETWEEN Stripe's domain model and YOUR domain model.
 * This class is the "corruption shield" - it contains all Stripe-specific logic.
 *
 * Key translations:
 *   Stripe cents (2999) → Your dollars (29.99)
 *   Stripe "succeeded"  → Your COMPLETED status
 *   Stripe Unix ts      → Your LocalDateTime
 *   Stripe charge_id    → Your transactionId
 */
@Component
public class StripeAclTranslator {

    private static final Logger log = LoggerFactory.getLogger(StripeAclTranslator.class);

    // Maps Stripe failure codes → your internal failure reasons
    private static final Map<String, String> FAILURE_CODE_MAP = Map.of(
        "card_declined",       "Payment declined by card issuer",
        "insufficient_funds",  "Insufficient funds on card",
        "expired_card",        "Card has expired",
        "incorrect_cvc",       "Invalid card security code",
        "lost_card",           "Card reported as lost",
        "stolen_card",         "Card reported as stolen"
    );

    /**
     * Translate YOUR internal request → Stripe's request format
     */
    public Map<String, Object> toStripeRequest(PaymentRequest internalRequest) {
        log.debug("[ACL→Stripe] Translating internal PaymentRequest to Stripe format");

        return Map.of(
            "amount", toStripeAmount(internalRequest.getAmount()),    // dollars → cents
            "currency", internalRequest.getCurrency().toLowerCase(),  // "USD" → "usd"
            "source", internalRequest.getCardToken(),
            "description", "Order: " + internalRequest.getOrderId(),
            "receipt_email", internalRequest.getCustomerEmail(),
            "metadata", Map.of("order_id", internalRequest.getOrderId())
        );
    }

    /**
     * Translate Stripe's response → YOUR internal PaymentResult
     * This is where the "anti-corruption" magic happens.
     */
    public PaymentResult fromStripeResponse(StripeChargeResponse stripeResponse, String orderId) {
        log.debug("[Stripe→ACL] Translating Stripe response to internal PaymentResult");

        return PaymentResult.builder()
                .success("succeeded".equals(stripeResponse.getStripeStatus()))
                .transactionId(stripeResponse.getChargeId())          // Their charge_id → our transactionId
                .orderId(orderId)
                .amount(fromStripeCents(stripeResponse.getAmountInCents())) // cents → dollars
                .currency(stripeResponse.getCurrencyCode().toUpperCase())   // "usd" → "USD"
                .status(mapStripeStatus(stripeResponse.getStripeStatus()))
                .failureReason(mapStripeFailureCode(stripeResponse.getFailureCode()))
                .processedAt(fromStripeTimestamp(stripeResponse.getCreatedTimestamp()))
                .providerName("STRIPE")
                .build();
    }

    // === Private translation helpers ===

    private Integer toStripeAmount(Double dollars) {
        return (int)(dollars * 100); // $29.99 → 2999
    }

    private Double fromStripeCents(Integer cents) {
        return cents != null ? cents / 100.0 : 0.0; // 2999 → $29.99
    }

    private PaymentResult.PaymentStatus mapStripeStatus(String stripeStatus) {
        return switch (stripeStatus) {
            case "succeeded" -> PaymentResult.PaymentStatus.COMPLETED;
            case "failed"    -> PaymentResult.PaymentStatus.FAILED;
            case "pending"   -> PaymentResult.PaymentStatus.PENDING;
            default          -> PaymentResult.PaymentStatus.FAILED;
        };
    }

    private String mapStripeFailureCode(String failureCode) {
        if (failureCode == null) return null;
        return FAILURE_CODE_MAP.getOrDefault(failureCode, "Payment processing error");
    }

    private LocalDateTime fromStripeTimestamp(Long unixTimestamp) {
        if (unixTimestamp == null) return LocalDateTime.now();
        return LocalDateTime.ofInstant(Instant.ofEpochSecond(unixTimestamp), ZoneId.systemDefault());
    }
}
