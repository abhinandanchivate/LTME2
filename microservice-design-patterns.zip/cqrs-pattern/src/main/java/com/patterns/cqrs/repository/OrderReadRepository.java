package com.patterns.cqrs.repository;

import com.patterns.cqrs.entity.OrderReadEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Read-side repository - used only by QueryHandler.
 * Rich query methods optimized for display use-cases.
 * Never used for writes.
 */
@Repository
public interface OrderReadRepository extends JpaRepository<OrderReadEntity, String> {

    // Query by customer (no join needed - customerId is in same table)
    List<OrderReadEntity> findByCustomerIdOrderByCreatedAtDesc(String customerId);

    // Query by status
    List<OrderReadEntity> findByStatusOrderByCreatedAtDesc(String status);

    // Search by customer email
    List<OrderReadEntity> findByCustomerEmailContainingIgnoreCase(String email);

    // Dashboard: count by status
    @Query("SELECT e.status, COUNT(e) FROM OrderReadEntity e GROUP BY e.status")
    List<Object[]> countByStatus();

    // High-value orders
    @Query("SELECT e FROM OrderReadEntity e WHERE e.totalAmount >= :minAmount ORDER BY e.totalAmount DESC")
    List<OrderReadEntity> findHighValueOrders(@Param("minAmount") Double minAmount);
}
