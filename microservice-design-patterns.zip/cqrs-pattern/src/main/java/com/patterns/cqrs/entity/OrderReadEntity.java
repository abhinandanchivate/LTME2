package com.patterns.cqrs.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * READ MODEL - Order Summary (denormalized, query-optimized)
 *
 * This is a SEPARATE model optimized for reading.
 * It's flat (no joins needed), pre-computed, and tailored to what UIs need.
 *
 * Key differences from write model:
 * - Flat structure (itemCount and itemSummary instead of separate items table)
 * - Pre-computed fields (itemCount, itemSummary string)
 * - Indexed for common query patterns
 * - Updated asynchronously after write-side changes
 *
 * In production: this could be in Elasticsearch for full-text search,
 * or MongoDB for flexible querying, or Redis for ultra-fast lookups.
 * Here we simulate with a separate H2 table.
 */
@Entity
@Table(name = "order_read_model", indexes = {
    @Index(name = "idx_customer_id", columnList = "customerId"),
    @Index(name = "idx_status", columnList = "status"),
    @Index(name = "idx_created_at", columnList = "createdAt")
})
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OrderReadEntity {

    @Id
    private String orderId;

    // Denormalized: all customer data in one table (no join needed)
    private String customerId;
    private String customerEmail;

    private String status;
    private Double totalAmount;
    private String shippingAddress;

    // Pre-computed summary fields (avoid joins at query time)
    private Integer itemCount;
    private String itemSummary;   // e.g., "Headphones x2, Keyboard x1"

    private String cancellationReason;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
