package com.patterns.cqrs.controller;

import com.patterns.cqrs.entity.OrderReadEntity;
import com.patterns.cqrs.query.handler.OrderQueryHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * QUERY Controller - Handles reads only
 *
 * All endpoints here are READ-ONLY. They:
 * - Never modify state
 * - Return data from the optimized read model
 * - Can be heavily cached (no invalidation concerns)
 * - Can scale independently of the command side
 */
@RestController
@RequestMapping("/queries/orders")
@RequiredArgsConstructor
public class OrderQueryController {

    private final OrderQueryHandler queryHandler;

    /** GET /queries/orders/{id} - Get single order */
    @GetMapping("/{orderId}")
    public ResponseEntity<OrderReadEntity> getOrder(@PathVariable String orderId) {
        return queryHandler.getOrderById(orderId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /** GET /queries/orders - Get all orders */
    @GetMapping
    public ResponseEntity<List<OrderReadEntity>> getAllOrders() {
        return ResponseEntity.ok(queryHandler.getAllOrders());
    }

    /** GET /queries/orders?customerId=CUST-001 */
    @GetMapping(params = "customerId")
    public ResponseEntity<List<OrderReadEntity>> getByCustomer(@RequestParam String customerId) {
        return ResponseEntity.ok(queryHandler.getOrdersByCustomer(customerId));
    }

    /** GET /queries/orders?status=PENDING */
    @GetMapping(params = "status")
    public ResponseEntity<List<OrderReadEntity>> getByStatus(@RequestParam String status) {
        return ResponseEntity.ok(queryHandler.getOrdersByStatus(status));
    }

    /** GET /queries/orders/high-value?minAmount=500 */
    @GetMapping("/high-value")
    public ResponseEntity<List<OrderReadEntity>> getHighValue(
            @RequestParam(defaultValue = "500") Double minAmount) {
        return ResponseEntity.ok(queryHandler.getHighValueOrders(minAmount));
    }

    /** GET /queries/orders/dashboard - Dashboard statistics */
    @GetMapping("/dashboard")
    public ResponseEntity<Map<String, Object>> getDashboard() {
        return ResponseEntity.ok(queryHandler.getDashboardStats());
    }
}
