package com.patterns.cqrs.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * WRITE MODEL - Order Entity (normalized, domain-rich)
 *
 * The write model is designed for:
 * - Enforcing business rules
 * - Maintaining data integrity
 * - Proper normalization (order + order_items are separate tables)
 * - Complex domain operations
 *
 * This is the "truth" store. After writes here, we sync to the read model.
 */
@Entity
@Table(name = "orders")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class OrderWriteEntity {

    @Id
    private String orderId;

    private String customerId;
    private String customerEmail;
    private String status;
    private Double totalAmount;
    private String shippingAddress;
    private String notes;
    private String cancellationReason;

    @Column(updatable = false)
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<OrderItemEntity> items = new ArrayList<>();

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
