package com.patterns.cqrs.query.handler;

import com.patterns.cqrs.entity.OrderReadEntity;
import com.patterns.cqrs.repository.OrderReadRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.ReadOnly;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * QUERY HANDLER - Read Side
 *
 * Handles all read operations. Key rules:
 * 1. NEVER modifies state (pure reads only)
 * 2. Uses READ model only (never touches write repository)
 * 3. Returns view-specific DTOs (not domain entities)
 * 4. Can be heavily cached without consistency concerns
 * 5. @ReadOnly transactions - no accidental writes
 *
 * This can scale independently from the command side.
 * In a high-read system, you can have 10 query instances and 1 command instance.
 */
@Service
@RequiredArgsConstructor
public class OrderQueryHandler {

    private static final Logger log = LoggerFactory.getLogger(OrderQueryHandler.class);

    private final OrderReadRepository readRepository; // ONLY uses read repository

    @ReadOnly
    public Optional<OrderReadEntity> getOrderById(String orderId) {
        log.info("[QUERY] GetOrder by ID: {}", orderId);
        return readRepository.findById(orderId);
    }

    @ReadOnly
    public List<OrderReadEntity> getOrdersByCustomer(String customerId) {
        log.info("[QUERY] GetOrders by customer: {}", customerId);
        return readRepository.findByCustomerIdOrderByCreatedAtDesc(customerId);
    }

    @ReadOnly
    public List<OrderReadEntity> getOrdersByStatus(String status) {
        log.info("[QUERY] GetOrders by status: {}", status);
        return readRepository.findByStatusOrderByCreatedAtDesc(status);
    }

    @ReadOnly
    public List<OrderReadEntity> getAllOrders() {
        log.info("[QUERY] GetAllOrders");
        return readRepository.findAll();
    }

    @ReadOnly
    public List<OrderReadEntity> getHighValueOrders(Double minAmount) {
        log.info("[QUERY] GetHighValueOrders (min: {})", minAmount);
        return readRepository.findHighValueOrders(minAmount);
    }

    /**
     * Dashboard aggregate query - reads from pre-built read model,
     * no complex joins or aggregation at runtime.
     */
    @ReadOnly
    public Map<String, Object> getDashboardStats() {
        log.info("[QUERY] GetDashboardStats");

        List<Object[]> statusCounts = readRepository.countByStatus();
        Map<String, Long> byStatus = new HashMap<>();
        statusCounts.forEach(row -> byStatus.put((String) row[0], (Long) row[1]));

        long totalOrders = readRepository.count();
        double totalRevenue = readRepository.findAll().stream()
                .mapToDouble(o -> o.getTotalAmount() != null ? o.getTotalAmount() : 0)
                .sum();

        return Map.of(
            "totalOrders", totalOrders,
            "totalRevenue", Math.round(totalRevenue * 100.0) / 100.0,
            "ordersByStatus", byStatus,
            "highValueOrders", readRepository.findHighValueOrders(500.0).size()
        );
    }
}
