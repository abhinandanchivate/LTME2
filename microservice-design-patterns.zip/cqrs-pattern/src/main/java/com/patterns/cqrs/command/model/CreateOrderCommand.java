package com.patterns.cqrs.command.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * COMMAND: CreateOrderCommand
 *
 * A command is an INTENT to change state. It is named in the imperative:
 * "Create this order", "Update this status", "Cancel this order".
 *
 * Commands:
 * - Express business intent (not data transfer)
 * - Are validated before being processed
 * - May be rejected (if business rules fail)
 * - Result in state change if accepted
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CreateOrderCommand {
    @NotBlank(message = "Customer ID is required")
    private String customerId;

    @NotBlank(message = "Customer email is required")
    @Email(message = "Must be a valid email")
    private String customerEmail;

    @NotNull(message = "Items cannot be null")
    private List<OrderItemCommand> items;

    private String shippingAddress;
    private String notes;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class OrderItemCommand {
        @NotBlank
        private String productId;
        @NotBlank
        private String productName;
        @Min(1)
        private Integer quantity;
        @NotNull
        private Double unitPrice;
    }
}
