package com.patterns.cqrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * CQRS (Command Query Responsibility Segregation) Pattern
 *
 * CONCEPT: Separate the model for READING data from the model for WRITING data.
 * Instead of one unified model doing everything, you have two sides:
 *
 *   COMMAND SIDE (Write):
 *     - Accepts commands (CreateOrder, UpdateOrderStatus, CancelOrder)
 *     - Validates business rules
 *     - Mutates state
 *     - Optimized for consistency and domain logic
 *     - Uses normalized write model (Order entity with proper relations)
 *
 *   QUERY SIDE (Read):
 *     - Returns data for display/reporting
 *     - Never mutates state
 *     - Optimized for read performance
 *     - Uses denormalized read model (flat, pre-joined for fast queries)
 *     - Can use a different database (e.g., Elasticsearch for search)
 *
 * WHY USE IT:
 * - Read and write workloads scale independently
 * - Read model can be highly optimized (denormalized, indexed, cached)
 * - Write model can enforce strict business rules without read complexity
 * - Enables Event Sourcing (natural fit)
 *
 * FLOW:
 *   POST /commands/orders → CommandHandler → Write DB → [publish event] → Read Model Sync
 *   GET  /queries/orders  → QueryHandler  → Read DB  (never hits write model)
 *
 * SIMULATED IN THIS DEMO:
 * Both models use H2 in memory but separate "tables" to show the separation.
 * In production: PostgreSQL (write) + Elasticsearch or MongoDB (read).
 */
@SpringBootApplication
public class CqrsPatternApplication {
    public static void main(String[] args) {
        SpringApplication.run(CqrsPatternApplication.class, args);
    }
}
