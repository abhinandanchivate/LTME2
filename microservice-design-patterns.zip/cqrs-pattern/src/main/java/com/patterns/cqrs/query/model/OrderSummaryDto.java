package com.patterns.cqrs.query.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.Map;

/**
 * QUERY MODELS - Read-side DTOs
 *
 * These are tailored to specific UI/consumer needs.
 * They do NOT match the write-side entity structure.
 */

// Used for order list views
@Data @Builder @NoArgsConstructor @AllArgsConstructor
class OrderSummaryDto {
    private String orderId;
    private String customerId;
    private String customerEmail;
    private String status;
    private Double totalAmount;
    private Integer itemCount;
    private String itemSummary;
    private LocalDateTime createdAt;
}
