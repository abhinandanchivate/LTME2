package com.patterns.cqrs.controller;

import com.patterns.cqrs.command.handler.OrderCommandHandler;
import com.patterns.cqrs.command.model.CreateOrderCommand;
import com.patterns.cqrs.command.model.UpdateOrderStatusCommand;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * COMMAND Controller - Handles writes only
 *
 * All endpoints here MUTATE state.
 * Returns 201/202 with the ID, not the full object (that's the query side's job).
 * Separated from query controller to make the segregation explicit.
 */
@RestController
@RequestMapping("/commands/orders")
@RequiredArgsConstructor
public class OrderCommandController {

    private final OrderCommandHandler commandHandler;

    /**
     * POST /commands/orders
     * Create a new order.
     *
     * Example body:
     * {
     *   "customerId": "CUST-001",
     *   "customerEmail": "alice@example.com",
     *   "shippingAddress": "123 Main St, Mumbai",
     *   "items": [
     *     {"productId": "PROD-1", "productName": "Headphones", "quantity": 2, "unitPrice": 299.99},
     *     {"productId": "PROD-2", "productName": "Keyboard", "quantity": 1, "unitPrice": 149.00}
     *   ]
     * }
     */
    @PostMapping
    public ResponseEntity<Map<String, String>> createOrder(@Valid @RequestBody CreateOrderCommand command) {
        String orderId = commandHandler.handle(command);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(Map.of(
                    "orderId", orderId,
                    "message", "Order created successfully",
                    "queryUrl", "/queries/orders/" + orderId
                ));
    }

    /**
     * PATCH /commands/orders/{id}/status
     * Update order status.
     *
     * Example body: {"orderId": "ORD-ABC", "newStatus": "CONFIRMED"}
     */
    @PatchMapping("/{orderId}/status")
    public ResponseEntity<Map<String, String>> updateStatus(
            @PathVariable String orderId,
            @Valid @RequestBody UpdateOrderStatusCommand command) {
        command.setOrderId(orderId);
        commandHandler.handle(command);
        return ResponseEntity.ok(Map.of(
            "message", "Status updated to " + command.getNewStatus(),
            "orderId", orderId
        ));
    }
}
