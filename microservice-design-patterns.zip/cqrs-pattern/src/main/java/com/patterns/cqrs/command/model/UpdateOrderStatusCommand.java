package com.patterns.cqrs.command.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * COMMAND: UpdateOrderStatusCommand
 * Expresses intent to change the status of an existing order.
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class UpdateOrderStatusCommand {
    @NotBlank
    private String orderId;

    @NotNull
    private OrderStatus newStatus;

    private String reason; // Required for CANCELLED status

    public enum OrderStatus {
        CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED
    }
}
