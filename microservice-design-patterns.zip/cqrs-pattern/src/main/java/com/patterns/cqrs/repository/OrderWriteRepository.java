package com.patterns.cqrs.repository;

import com.patterns.cqrs.entity.OrderWriteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Write-side repository - used only by CommandHandler.
 * Only handles persistence of commands/mutations.
 */
@Repository
public interface OrderWriteRepository extends JpaRepository<OrderWriteEntity, String> {
}
