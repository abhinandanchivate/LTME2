package com.patterns.cqrs.command.handler;

import com.patterns.cqrs.command.model.CreateOrderCommand;
import com.patterns.cqrs.command.model.UpdateOrderStatusCommand;
import com.patterns.cqrs.entity.OrderItemEntity;
import com.patterns.cqrs.entity.OrderReadEntity;
import com.patterns.cqrs.entity.OrderWriteEntity;
import com.patterns.cqrs.repository.OrderReadRepository;
import com.patterns.cqrs.repository.OrderWriteRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * COMMAND HANDLER - Write Side
 *
 * Processes all commands (mutations). Responsibilities:
 * 1. Validate business rules
 * 2. Persist to write model (normalized)
 * 3. Sync to read model (denormalized) - "eventual consistency"
 *
 * In a full CQRS setup, step 3 would happen via domain events + event bus.
 * Here we do it synchronously for simplicity.
 */
@Service
@RequiredArgsConstructor
public class OrderCommandHandler {

    private static final Logger log = LoggerFactory.getLogger(OrderCommandHandler.class);

    private final OrderWriteRepository writeRepository;
    private final OrderReadRepository readRepository; // For syncing read model

    @Transactional
    public String handle(CreateOrderCommand command) {
        log.info("[COMMAND] CreateOrderCommand received for customer: {}", command.getCustomerId());

        // Step 1: Business rule validation
        validateCreateOrder(command);

        // Step 2: Build write-side entity (normalized)
        String orderId = "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        double totalAmount = command.getItems().stream()
                .mapToDouble(i -> i.getQuantity() * i.getUnitPrice())
                .sum();

        OrderWriteEntity orderEntity = OrderWriteEntity.builder()
                .orderId(orderId)
                .customerId(command.getCustomerId())
                .customerEmail(command.getCustomerEmail())
                .status("PENDING")
                .totalAmount(totalAmount)
                .shippingAddress(command.getShippingAddress())
                .notes(command.getNotes())
                .build();

        List<OrderItemEntity> items = command.getItems().stream()
                .map(item -> OrderItemEntity.builder()
                        .order(orderEntity)
                        .productId(item.getProductId())
                        .productName(item.getProductName())
                        .quantity(item.getQuantity())
                        .unitPrice(item.getUnitPrice())
                        .lineTotal(item.getQuantity() * item.getUnitPrice())
                        .build())
                .toList();
        orderEntity.setItems(items);

        // Step 3: Persist to WRITE model
        writeRepository.save(orderEntity);
        log.info("[COMMAND] Order {} persisted to write model", orderId);

        // Step 4: Sync READ model (in real CQRS: publish OrderCreatedEvent → subscriber updates read model)
        syncReadModel(orderEntity, command);
        log.info("[COMMAND] Order {} synced to read model", orderId);

        return orderId;
    }

    @Transactional
    public void handle(UpdateOrderStatusCommand command) {
        log.info("[COMMAND] UpdateOrderStatusCommand for order: {} → {}", command.getOrderId(), command.getNewStatus());

        // Step 1: Load from write model (source of truth)
        OrderWriteEntity order = writeRepository.findById(command.getOrderId())
                .orElseThrow(() -> new IllegalArgumentException("Order not found: " + command.getOrderId()));

        // Step 2: Business rule validation
        validateStatusTransition(order.getStatus(), command.getNewStatus().name());

        // Step 3: Update write model
        order.setStatus(command.getNewStatus().name());
        if (command.getNewStatus() == UpdateOrderStatusCommand.OrderStatus.CANCELLED) {
            order.setCancellationReason(command.getReason());
        }
        writeRepository.save(order);

        // Step 4: Sync read model
        readRepository.findById(command.getOrderId()).ifPresent(readEntity -> {
            readEntity.setStatus(command.getNewStatus().name());
            readEntity.setCancellationReason(command.getReason());
            readEntity.setUpdatedAt(LocalDateTime.now());
            readRepository.save(readEntity);
        });

        log.info("[COMMAND] Order {} status updated to {}", command.getOrderId(), command.getNewStatus());
    }

    // === Business Rule Validations ===

    private void validateCreateOrder(CreateOrderCommand command) {
        if (command.getItems() == null || command.getItems().isEmpty()) {
            throw new IllegalArgumentException("Order must have at least one item");
        }
        command.getItems().forEach(item -> {
            if (item.getQuantity() <= 0) {
                throw new IllegalArgumentException("Item quantity must be positive: " + item.getProductName());
            }
            if (item.getUnitPrice() <= 0) {
                throw new IllegalArgumentException("Item price must be positive: " + item.getProductName());
            }
        });
    }

    private void validateStatusTransition(String currentStatus, String newStatus) {
        // Business rule: cancelled orders cannot be updated
        if ("CANCELLED".equals(currentStatus)) {
            throw new IllegalStateException("Cannot update status of a cancelled order");
        }
        // Business rule: cannot go back to PENDING from SHIPPED/DELIVERED
        if (("SHIPPED".equals(currentStatus) || "DELIVERED".equals(currentStatus))
                && "PENDING".equals(newStatus)) {
            throw new IllegalStateException("Cannot revert order to PENDING after shipping");
        }
    }

    // === Read Model Sync ===

    private void syncReadModel(OrderWriteEntity order, CreateOrderCommand command) {
        String itemSummary = command.getItems().stream()
                .map(i -> i.getProductName() + " x" + i.getQuantity())
                .collect(Collectors.joining(", "));

        OrderReadEntity readEntity = OrderReadEntity.builder()
                .orderId(order.getOrderId())
                .customerId(order.getCustomerId())
                .customerEmail(order.getCustomerEmail())
                .status(order.getStatus())
                .totalAmount(order.getTotalAmount())
                .shippingAddress(order.getShippingAddress())
                .itemCount(command.getItems().size())
                .itemSummary(itemSummary)      // Pre-computed for fast display
                .createdAt(order.getCreatedAt())
                .updatedAt(order.getUpdatedAt())
                .build();

        readRepository.save(readEntity);
    }
}
