# Spring Boot Microservice Design Patterns

Six complete, runnable Spring Boot projects demonstrating core microservice patterns.

---

## Projects Overview

| # | Pattern | Port | Key Concept |
|---|---------|------|-------------|
| 1 | BFF Pattern | 8081 | Separate backends per client type |
| 2 | API Gateway | 8080 | Single entry point with auth, routing, rate-limiting |
| 3 | Strangler Fig | 8082 | Incremental legacy migration |
| 4 | Anti-Corruption Layer | 8083 | Isolate external domain models |
| 5 | CQRS | 8084 | Separate read and write models |
| 6 | Event Sourcing | 8085 | Store events, not state |

---

## 1. BFF Pattern (`bff-pattern/`)

**Concept:** Create a dedicated backend for each type of frontend client.

**Endpoints (port 8081):**
```
GET /mobile/api/v1/products/1  → 7 fields (lightweight for mobile)
GET /web/api/v1/products/1     → 13 fields + recommendations (rich for web)
GET /admin/api/v1/products/1   → all fields + cost + margin + warehouse (admin)
```

**Key files:**
- `MobileBffService.java` - aggregates and minimizes payload for mobile
- `WebBffService.java` - aggregates from product + recommendation services
- `AdminBffService.java` - aggregates from product + pricing + inventory

---

## 2. API Gateway (`api-gateway-pattern/`)

**Concept:** Single entry point handling auth, routing, rate limiting, circuit breaking.

**Key files:**
- `JwtAuthFilter.java` - validates Bearer tokens on protected routes
- `GlobalLoggingFilter.java` - logs every request/response with timing
- `GatewayConfig.java` - programmatic route definitions with circuit breakers
- `application.yml` - YAML-based routes with CORS config

**Test:**
```bash
# Protected route (needs auth)
curl -H "Authorization: Bearer valid-jwt-token-12345" \
     http://localhost:8080/api/products/1

# Actuator - list all routes
curl http://localhost:8080/actuator/gateway/routes
```

---

## 3. Strangler Fig Pattern (`strangler-pattern/`)

**Concept:** Gradually replace legacy monolith by routing traffic via feature flags.

**Endpoints (port 8082):**
```
GET /api/products/1        → MODERN service (productsMigrated=true)
GET /api/orders/1          → LEGACY monolith (ordersMigrated=false)
GET /api/users/1           → LEGACY monolith
GET /api/migration-status  → shows migration progress
```

**To simulate migration:** change flags in `application.yml`:
```yaml
migration:
  products-migrated: true   # ✅ Migrated
  orders-migrated: false    # ⏳ Still in legacy
```

**Key file:** `StranglerFacadeController.java` - routes based on feature flags

---

## 4. Anti-Corruption Layer (`anti-corruption-layer/`)

**Concept:** Isolate external API models from your clean domain model.

**Endpoint (port 8083):**
```bash
# Via Stripe
curl -X POST http://localhost:8083/api/payments/process \
  -H "Content-Type: application/json" \
  -d '{"orderId":"ORD-001","amount":99.99,"currency":"USD",
       "customerEmail":"test@test.com","provider":"STRIPE","cardToken":"tok_visa"}'

# Via PayPal
curl -X POST http://localhost:8083/api/payments/process \
  -H "Content-Type: application/json" \
  -d '{"orderId":"ORD-002","amount":149.50,"currency":"USD",
       "customerEmail":"test@test.com","provider":"PAYPAL","cardToken":"BA-xyz"}'
```

**Package structure shows the isolation:**
```
external/   ← Stripe + PayPal models (locked away here)
internal/   ← Your clean domain models (PaymentRequest, PaymentResult)
translator/ ← ACL translation layer (StripeAclTranslator, PayPalAclTranslator)
```

---

## 5. CQRS (`cqrs-pattern/`)

**Concept:** Separate read model from write model.

**Command endpoints (writes) - port 8084:**
```bash
# Create order
POST http://localhost:8084/commands/orders
Body: {"customerId":"CUST-001","customerEmail":"alice@example.com",
       "shippingAddress":"Mumbai","items":[
         {"productId":"P1","productName":"Headphones","quantity":2,"unitPrice":299.99}]}

# Update status
PATCH http://localhost:8084/commands/orders/{orderId}/status
Body: {"newStatus":"CONFIRMED"}
```

**Query endpoints (reads) - port 8084:**
```bash
GET http://localhost:8084/queries/orders               # all orders
GET http://localhost:8084/queries/orders/{id}          # by ID
GET http://localhost:8084/queries/orders?status=PENDING # by status
GET http://localhost:8084/queries/orders/dashboard      # stats
```

**H2 Console:** http://localhost:8084/h2-console (URL: `jdbc:h2:mem:cqrsdb`)
- See `orders` table (normalized write model)
- See `order_read_model` table (denormalized read model)

---

## 6. Event Sourcing (`event-sourcing-pattern/`)

**Concept:** Store events (what happened), not current state.

**Full lifecycle demo (port 8085):**
```bash
# 1. Place order → produces OrderPlaced event
POST http://localhost:8085/api/orders
Body: {"customerId":"CUST-001","customerEmail":"alice@test.com",
       "shippingAddress":"Mumbai","totalAmount":599.98,
       "items":[{"productId":"P1","name":"Headphones","qty":2}]}

# 2. Confirm → produces OrderConfirmed event
POST http://localhost:8085/api/orders/{orderId}/confirm
Body: {"confirmedBy":"warehouse"}

# 3. Payment → produces PaymentProcessed event
POST http://localhost:8085/api/orders/{orderId}/payment
Body: {"transactionId":"TXN-001","amount":599.98,"method":"CREDIT_CARD"}

# 4. Ship → produces OrderShipped event
POST http://localhost:8085/api/orders/{orderId}/ship
Body: {"trackingNumber":"DHL-123","carrier":"DHL"}

# 5. Current state (built by replaying 4 events)
GET http://localhost:8085/api/orders/{orderId}

# ★ 6. Complete audit trail (the killer feature!)
GET http://localhost:8085/api/orders/{orderId}/history

# 7. Global event log
GET http://localhost:8085/api/orders/event-log
```

**H2 Console:** http://localhost:8085/h2-console (URL: `jdbc:h2:mem:eventsourcingdb`)
- See `event_store` table — append-only, every event is preserved!

---

## Running the Projects

Each project is standalone. Run any with:
```bash
cd <project-folder>
mvn spring-boot:run
```

Or build a JAR:
```bash
mvn clean package
java -jar target/<project>-1.0.0.jar
```

**Requirements:** Java 17+, Maven 3.8+

---

## Pattern Comparison

| Pattern | Problem Solved | When to Use |
|---------|---------------|-------------|
| BFF | Different clients need different data shapes | Mobile + Web + Admin with very different needs |
| API Gateway | Cross-cutting concerns (auth, rate-limit) scattered | Multiple microservices, need central security |
| Strangler | Legacy modernization is risky | Migrating a monolith safely over time |
| ACL | External APIs corrupt your domain | Integrating with 3rd-party APIs or legacy systems |
| CQRS | Read and write models have conflicting needs | High-read systems, complex queries vs simple writes |
| Event Sourcing | Need audit trail, time travel, or event replay | Finance, compliance, or complex domain events |
