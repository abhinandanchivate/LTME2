package com.patterns.bff.service;

import com.patterns.bff.model.Product;
import com.patterns.bff.model.WebBffResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Web BFF Service
 *
 * Aggregates from: product-service + recommendation-service + session-service
 * Transforms: multiple service payloads → rich web response
 * Key win: single API call for web clients, server-side aggregation
 */
@Service
@RequiredArgsConstructor
public class WebBffService {

    private final ProductService productService;

    public WebBffResponse getProductForWeb(Long productId) {
        // Parallel calls in production (CompletableFuture or WebClient reactive)
        Product product = productService.getProductById(productId);
        List<Product> related = productService.getRelatedProducts(productId);
        List<String> recentlyViewed = List.of("Smart Watch Pro", "USB-C Hub", "Laptop Stand");

        return WebBffResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .description(product.getDescription())
                .price(product.getPrice())
                .imageUrl(product.getImageUrl())
                .category(product.getCategory())
                .stockCount(product.getStockCount())
                .rating(product.getRating())
                .reviewCount(product.getReviewCount())
                .sku(product.getSku())
                .brand(product.getBrand())
                .relatedProducts(related)
                .recentlyViewed(recentlyViewed)
                .build();
    }
}
