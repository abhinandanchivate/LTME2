package com.patterns.bff.service;

import org.springframework.stereotype.Service;

/**
 * Simulates the downstream Pricing microservice.
 * Exposes cost and margin data - only called by AdminBffService.
 */
@Service
public class PricingService {

    public Double getCostPrice(Long productId) {
        return 120.00;
    }

    public Double calculateMargin(Double sellingPrice, Double costPrice) {
        return ((sellingPrice - costPrice) / sellingPrice) * 100;
    }
}
