package com.patterns.bff.service;

import com.patterns.bff.model.MobileBffResponse;
import com.patterns.bff.model.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Mobile BFF Service
 *
 * Aggregates from: product-service ONLY
 * Transforms: full product → minimal mobile payload
 * Key win: single downstream call, minimal data transfer
 */
@Service
@RequiredArgsConstructor
public class MobileBffService {

    private final ProductService productService;

    public MobileBffResponse getProductForMobile(Long productId) {
        Product product = productService.getProductById(productId);

        return MobileBffResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .price(product.getPrice())
                .imageUrl(product.getImageUrl())
                .category(product.getCategory())
                .inStock(product.getStockCount() > 0)  // int → boolean: mobile doesn't need exact count
                .rating(product.getRating())
                .build();
    }
}
