package com.patterns.bff.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class Product {
    private Long id;
    private String name;
    private String description;
    private Double price;
    private String imageUrl;
    private String category;
    private Integer stockCount;
    private Double rating;
    private Integer reviewCount;
    private String sku;
    private String brand;
    private Double weight;
    private String dimensions;
}
