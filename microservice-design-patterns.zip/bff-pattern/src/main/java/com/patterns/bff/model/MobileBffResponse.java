package com.patterns.bff.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Mobile BFF Response - Lightweight, optimized for mobile bandwidth.
 * Contains only essential fields needed by mobile clients.
 * Saves ~60% payload compared to full web response.
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class MobileBffResponse {
    private Long id;
    private String name;
    private Double price;
    private String imageUrl;       // Single image only
    private String category;
    private Boolean inStock;       // Simple boolean instead of count
    private Double rating;
}
