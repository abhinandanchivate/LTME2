package com.patterns.bff.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

/**
 * Web BFF Response - Rich data optimized for web browsers.
 * Contains full product details plus aggregated recommendations.
 * Data is sourced from multiple downstream services.
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class WebBffResponse {
    private Long id;
    private String name;
    private String description;
    private Double price;
    private String imageUrl;
    private String category;
    private Integer stockCount;
    private Double rating;
    private Integer reviewCount;
    private String sku;
    private String brand;
    private List<Product> relatedProducts;  // Sourced from recommendation-service
    private List<String> recentlyViewed;    // Sourced from session/cache service
}
