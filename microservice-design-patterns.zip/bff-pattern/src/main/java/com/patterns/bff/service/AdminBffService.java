package com.patterns.bff.service;

import com.patterns.bff.model.AdminBffResponse;
import com.patterns.bff.model.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Admin BFF Service
 *
 * Aggregates from: product-service + pricing-service + inventory-service
 * Transforms: 3 service payloads → operational admin dashboard response
 * Key win: admins get everything in one call; sensitive data isolated to this BFF
 */
@Service
@RequiredArgsConstructor
public class AdminBffService {

    private final ProductService productService;
    private final PricingService pricingService;
    private final InventoryService inventoryService;

    public AdminBffResponse getProductForAdmin(Long productId) {
        Product product = productService.getProductById(productId);
        Double costPrice = pricingService.getCostPrice(productId);
        Double margin = pricingService.calculateMargin(product.getPrice(), costPrice);
        String warehouseLocation = inventoryService.getWarehouseLocation(productId);
        Integer reorderPoint = inventoryService.getReorderPoint(productId);

        return AdminBffResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .description(product.getDescription())
                .price(product.getPrice())
                .costPrice(costPrice)
                .profitMargin(Math.round(margin * 100.0) / 100.0)
                .stockCount(product.getStockCount())
                .sku(product.getSku())
                .brand(product.getBrand())
                .weight(product.getWeight())
                .dimensions(product.getDimensions())
                .warehouseLocation(warehouseLocation)
                .reorderPoint(reorderPoint)
                .build();
    }
}
