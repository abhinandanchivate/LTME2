package com.patterns.bff.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Admin BFF Response - Full operational data for admin dashboards.
 * Aggregates from product-service, pricing-service, and inventory-service.
 * Includes sensitive financial and logistics data not exposed to other clients.
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AdminBffResponse {
    private Long id;
    private String name;
    private String description;
    private Double price;
    private Double costPrice;           // Admin-only: sourced from pricing-service
    private Double profitMargin;        // Admin-only: calculated field
    private Integer stockCount;
    private String sku;
    private String brand;
    private Double weight;
    private String dimensions;
    private String warehouseLocation;   // Admin-only: sourced from inventory-service
    private Integer reorderPoint;       // Admin-only: inventory management threshold
}
