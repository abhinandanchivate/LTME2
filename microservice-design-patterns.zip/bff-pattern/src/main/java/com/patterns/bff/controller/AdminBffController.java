package com.patterns.bff.controller;

import com.patterns.bff.model.AdminBffResponse;
import com.patterns.bff.service.AdminBffService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Admin BFF Controller
 * Endpoint: GET /admin/api/v1/products/{id}
 * Returns full operational data including cost, margin, warehouse info
 */
@RestController
@RequestMapping("/admin/api/v1")
@RequiredArgsConstructor
public class AdminBffController {

    private final AdminBffService adminBffService;

    @GetMapping("/products/{id}")
    public ResponseEntity<AdminBffResponse> getProduct(@PathVariable Long id) {
        return ResponseEntity.ok(adminBffService.getProductForAdmin(id));
    }
}
