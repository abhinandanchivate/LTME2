package com.patterns.bff.service;

import org.springframework.stereotype.Service;
import java.util.Map;

/**
 * Simulates the downstream Inventory microservice.
 * Only called by AdminBffService - not exposed to mobile or web clients.
 */
@Service
public class InventoryService {

    private static final Map<Long, String> WAREHOUSE = Map.of(
        1L, "A-12-B", 2L, "B-05-C", 3L, "C-08-A"
    );
    private static final Map<Long, Integer> REORDER = Map.of(
        1L, 20, 2L, 10, 3L, 15
    );

    public String getWarehouseLocation(Long productId) {
        return WAREHOUSE.getOrDefault(productId, "UNKNOWN");
    }

    public Integer getReorderPoint(Long productId) {
        return REORDER.getOrDefault(productId, 10);
    }
}
