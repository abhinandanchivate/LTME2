package com.patterns.bff.service;

import com.patterns.bff.model.Product;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Simulates the downstream Product microservice.
 * In production, this would use WebClient to call product-service REST API.
 */
@Service
public class ProductService {

    public Product getProductById(Long id) {
        // Production: webClient.get().uri("http://product-service/products/" + id)...
        return Product.builder()
                .id(id)
                .name("Wireless Bluetooth Headphones")
                .description("Premium noise-cancelling headphones with 30hr battery life and superior sound quality")
                .price(299.99)
                .imageUrl("https://example.com/images/headphones.jpg")
                .category("Electronics")
                .stockCount(45)
                .rating(4.5)
                .reviewCount(1234)
                .sku("WBH-PRO-001")
                .brand("SoundMaster")
                .weight(0.285)
                .dimensions("18x17x8 cm")
                .build();
    }

    public List<Product> getRelatedProducts(Long id) {
        // Production: webClient.get().uri("http://recommendation-service/products/" + id + "/related")...
        return List.of(
            Product.builder().id(2L).name("Earbuds Pro").price(149.99).category("Electronics").rating(4.3).build(),
            Product.builder().id(3L).name("Speaker Portable").price(89.99).category("Electronics").rating(4.1).build()
        );
    }
}
