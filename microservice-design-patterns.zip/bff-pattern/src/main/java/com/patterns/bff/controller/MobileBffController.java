package com.patterns.bff.controller;

import com.patterns.bff.model.MobileBffResponse;
import com.patterns.bff.service.MobileBffService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Mobile BFF Controller
 * Endpoint: GET /mobile/api/v1/products/{id}
 * Returns lightweight JSON optimized for mobile bandwidth
 */
@RestController
@RequestMapping("/mobile/api/v1")
@RequiredArgsConstructor
public class MobileBffController {

    private final MobileBffService mobileBffService;

    @GetMapping("/products/{id}")
    public ResponseEntity<MobileBffResponse> getProduct(@PathVariable Long id) {
        return ResponseEntity.ok(mobileBffService.getProductForMobile(id));
    }
}
