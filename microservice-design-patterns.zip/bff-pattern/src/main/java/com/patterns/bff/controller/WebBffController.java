package com.patterns.bff.controller;

import com.patterns.bff.model.WebBffResponse;
import com.patterns.bff.service.WebBffService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Web BFF Controller
 * Endpoint: GET /web/api/v1/products/{id}
 * Returns rich product data with recommendations for browser clients
 */
@RestController
@RequestMapping("/web/api/v1")
@RequiredArgsConstructor
public class WebBffController {

    private final WebBffService webBffService;

    @GetMapping("/products/{id}")
    public ResponseEntity<WebBffResponse> getProduct(@PathVariable Long id) {
        return ResponseEntity.ok(webBffService.getProductForWeb(id));
    }
}
