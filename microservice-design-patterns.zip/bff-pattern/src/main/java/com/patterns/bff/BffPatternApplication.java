package com.patterns.bff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * BFF (Backend for Frontend) Pattern
 *
 * CONCEPT: Create separate backend services tailored for each type of frontend client
 * (Mobile BFF, Web BFF, Desktop BFF). Each BFF aggregates and transforms data
 * from downstream microservices in a way that best suits its specific client.
 *
 * WHY USE IT:
 * - Different clients have different data needs (mobile needs less data to save bandwidth)
 * - Avoids over-fetching or under-fetching of data
 * - Each team can own their BFF independently
 * - Simplifies client-side logic by moving aggregation to the server
 *
 * FLOW: Client → BFF (client-specific) → Multiple Downstream Services
 */
@SpringBootApplication
public class BffPatternApplication {
    public static void main(String[] args) {
        SpringApplication.run(BffPatternApplication.class, args);
    }
}
