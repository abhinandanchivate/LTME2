package com.patterns.eventsourcing.controller;

import com.patterns.eventsourcing.command.OrderCommandService;
import com.patterns.eventsourcing.projection.OrderProjection;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Order Controller - Event Sourcing endpoints
 *
 * Commands (mutate): POST endpoints → produce events
 * Queries (read):    GET endpoints  → replay events via projection
 */
@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderCommandService commandService;
    private final OrderProjection orderProjection;

    /**
     * POST /api/orders
     * Place a new order → produces OrderPlaced event
     *
     * Body: {
     *   "customerId": "CUST-001",
     *   "customerEmail": "alice@example.com",
     *   "shippingAddress": "123 Main St",
     *   "totalAmount": 599.98,
     *   "items": [{"productId":"P1","name":"Headphones","qty":2,"price":299.99}]
     * }
     */
    @PostMapping
    public ResponseEntity<Map<String, String>> placeOrder(@RequestBody Map<String, Object> request) {
        @SuppressWarnings("unchecked")
        List<Map<String, Object>> items = (List<Map<String, Object>>) request.get("items");

        String orderId = commandService.placeOrder(
                (String) request.get("customerId"),
                (String) request.get("customerEmail"),
                items,
                ((Number) request.get("totalAmount")).doubleValue(),
                (String) request.get("shippingAddress")
        );

        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
            "orderId", orderId,
            "event", "OrderPlaced",
            "message", "Order placed. Replay events at GET /api/orders/" + orderId + "/history"
        ));
    }

    /**
     * POST /api/orders/{id}/confirm
     * Confirm order → produces OrderConfirmed event
     */
    @PostMapping("/{orderId}/confirm")
    public ResponseEntity<Map<String, String>> confirmOrder(
            @PathVariable String orderId,
            @RequestBody(required = false) Map<String, String> body) {
        String confirmedBy = body != null ? body.getOrDefault("confirmedBy", "system") : "system";
        commandService.confirmOrder(orderId, confirmedBy);
        return ResponseEntity.ok(Map.of("event", "OrderConfirmed", "orderId", orderId));
    }

    /**
     * POST /api/orders/{id}/payment
     * Process payment → produces PaymentProcessed event
     */
    @PostMapping("/{orderId}/payment")
    public ResponseEntity<Map<String, String>> processPayment(
            @PathVariable String orderId,
            @RequestBody Map<String, Object> body) {
        commandService.processPayment(
                orderId,
                (String) body.getOrDefault("transactionId", "TXN-" + System.currentTimeMillis()),
                ((Number) body.getOrDefault("amount", 0)).doubleValue(),
                (String) body.getOrDefault("method", "CREDIT_CARD")
        );
        return ResponseEntity.ok(Map.of("event", "PaymentProcessed", "orderId", orderId));
    }

    /**
     * POST /api/orders/{id}/ship
     * Ship order → produces OrderShipped event
     */
    @PostMapping("/{orderId}/ship")
    public ResponseEntity<Map<String, String>> shipOrder(
            @PathVariable String orderId,
            @RequestBody Map<String, String> body) {
        commandService.shipOrder(orderId,
                body.getOrDefault("trackingNumber", "TRK-" + System.currentTimeMillis()),
                body.getOrDefault("carrier", "DHL"),
                body.getOrDefault("estimatedDelivery", "3-5 business days"));
        return ResponseEntity.ok(Map.of("event", "OrderShipped", "orderId", orderId));
    }

    /**
     * POST /api/orders/{id}/deliver
     * Deliver order → produces OrderDelivered event
     */
    @PostMapping("/{orderId}/deliver")
    public ResponseEntity<Map<String, String>> deliverOrder(
            @PathVariable String orderId,
            @RequestBody(required = false) Map<String, String> body) {
        String receivedBy = body != null ? body.getOrDefault("receivedBy", "customer") : "customer";
        commandService.deliverOrder(orderId, receivedBy);
        return ResponseEntity.ok(Map.of("event", "OrderDelivered", "orderId", orderId));
    }

    /**
     * POST /api/orders/{id}/cancel
     * Cancel order → produces OrderCancelled event
     */
    @PostMapping("/{orderId}/cancel")
    public ResponseEntity<Map<String, String>> cancelOrder(
            @PathVariable String orderId,
            @RequestBody Map<String, String> body) {
        commandService.cancelOrder(orderId,
                body.getOrDefault("reason", "Customer request"),
                body.getOrDefault("cancelledBy", "customer"));
        return ResponseEntity.ok(Map.of("event", "OrderCancelled", "orderId", orderId));
    }

    // ===== READ endpoints (replay events via projection) =====

    /**
     * GET /api/orders/{id}
     * Get current order state (by replaying all its events)
     */
    @GetMapping("/{orderId}")
    public ResponseEntity<Map<String, Object>> getOrder(@PathVariable String orderId) {
        return orderProjection.getOrderView(orderId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * GET /api/orders/{id}/history
     * ★ The killer feature of Event Sourcing: complete audit trail!
     * Shows every event that led to current state.
     */
    @GetMapping("/{orderId}/history")
    public ResponseEntity<List<Map<String, Object>>> getOrderHistory(@PathVariable String orderId) {
        return ResponseEntity.ok(orderProjection.getOrderHistory(orderId));
    }

    /**
     * GET /api/orders/event-log
     * Global event log - ALL events across ALL orders
     */
    @GetMapping("/event-log")
    public ResponseEntity<List<Map<String, Object>>> getEventLog() {
        return ResponseEntity.ok(orderProjection.getGlobalEventLog());
    }
}
