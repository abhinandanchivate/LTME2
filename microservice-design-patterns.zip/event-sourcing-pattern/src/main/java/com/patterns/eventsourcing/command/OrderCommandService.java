package com.patterns.eventsourcing.command;

import com.patterns.eventsourcing.aggregate.OrderAggregate;
import com.patterns.eventsourcing.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Order Command Service
 *
 * Orchestrates the event sourcing workflow:
 * 1. Load aggregate (by replaying events)
 * 2. Call aggregate command method (validates + produces events)
 * 3. Save aggregate (persists new events to event store)
 */
@Service
@RequiredArgsConstructor
public class OrderCommandService {

    private static final Logger log = LoggerFactory.getLogger(OrderCommandService.class);
    private final OrderRepository orderRepository;

    public String placeOrder(String customerId, String customerEmail,
                             List<Map<String, Object>> items, Double totalAmount,
                             String shippingAddress) {
        String orderId = "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        log.info("[Command] PlaceOrder: {}", orderId);

        OrderAggregate order = new OrderAggregate();
        order.placeOrder(orderId, customerId, customerEmail, items, totalAmount, shippingAddress);
        orderRepository.save(order);

        return orderId;
    }

    public void confirmOrder(String orderId, String confirmedBy) {
        log.info("[Command] ConfirmOrder: {}", orderId);
        OrderAggregate order = loadOrThrow(orderId);
        order.confirmOrder(confirmedBy);
        orderRepository.save(order);
    }

    public void processPayment(String orderId, String transactionId, Double amount, String method) {
        log.info("[Command] ProcessPayment for order: {}", orderId);
        OrderAggregate order = loadOrThrow(orderId);
        order.processPayment(transactionId, amount, method);
        orderRepository.save(order);
    }

    public void shipOrder(String orderId, String trackingNumber, String carrier, String estimatedDelivery) {
        log.info("[Command] ShipOrder: {}", orderId);
        OrderAggregate order = loadOrThrow(orderId);
        order.shipOrder(trackingNumber, carrier, estimatedDelivery);
        orderRepository.save(order);
    }

    public void deliverOrder(String orderId, String receivedBy) {
        log.info("[Command] DeliverOrder: {}", orderId);
        OrderAggregate order = loadOrThrow(orderId);
        order.deliverOrder(receivedBy);
        orderRepository.save(order);
    }

    public void cancelOrder(String orderId, String reason, String cancelledBy) {
        log.info("[Command] CancelOrder: {}", orderId);
        OrderAggregate order = loadOrThrow(orderId);
        order.cancelOrder(reason, cancelledBy);
        orderRepository.save(order);
    }

    private OrderAggregate loadOrThrow(String orderId) {
        return orderRepository.load(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found: " + orderId));
    }
}
