package com.patterns.eventsourcing.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.patterns.eventsourcing.aggregate.OrderAggregate;
import com.patterns.eventsourcing.event.DomainEvent;
import com.patterns.eventsourcing.event.OrderEvents.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Order Repository - backed by Event Store
 *
 * SAVE = append new events
 * LOAD = replay all events to reconstruct state
 */
@Repository
public class OrderRepository {

    private static final Logger log = LoggerFactory.getLogger(OrderRepository.class);

    private final EventStore eventStore;
    private final ObjectMapper objectMapper;

    public OrderRepository(EventStore eventStore, ObjectMapper objectMapper) {
        this.eventStore = eventStore;
        this.objectMapper = objectMapper;
    }

    /** Persist all uncommitted events from an aggregate */
    public void save(OrderAggregate aggregate) {
        List<DomainEvent> events = aggregate.getUncommittedEvents();
        log.info("[Repository] Appending {} events for order {}", events.size(), aggregate.getOrderId());
        events.forEach(eventStore::append);
        aggregate.markEventsAsCommitted();
    }

    /**
     * Reconstruct aggregate by replaying its events.
     * This is "event replay" - we apply each historical event
     * to a fresh aggregate to get current state.
     */
    public Optional<OrderAggregate> load(String orderId) {
        var records = eventStore.loadForAggregate(orderId);
        if (records.isEmpty()) return Optional.empty();

        log.info("[Repository] Replaying {} events for order {}", records.size(), orderId);
        OrderAggregate aggregate = new OrderAggregate();

        records.forEach(record -> {
            DomainEvent event = deserialize(record.getEventType(), record.getEventData());
            if (event != null) aggregate.replayEvent(event);
        });

        return Optional.of(aggregate);
    }

    /** Load all events as log entries (for audit/projections) */
    public List<EventLogEntry> loadEventLog() {
        return eventStore.loadAll();
    }

    private DomainEvent deserialize(String eventType, String eventData) {
        try {
            return switch (eventType) {
                case "OrderPlaced"      -> objectMapper.readValue(eventData, OrderPlaced.class);
                case "OrderConfirmed"   -> objectMapper.readValue(eventData, OrderConfirmed.class);
                case "PaymentProcessed" -> objectMapper.readValue(eventData, PaymentProcessed.class);
                case "OrderShipped"     -> objectMapper.readValue(eventData, OrderShipped.class);
                case "OrderDelivered"   -> objectMapper.readValue(eventData, OrderDelivered.class);
                case "OrderCancelled"   -> objectMapper.readValue(eventData, OrderCancelled.class);
                default -> { log.warn("Unknown event type: {}", eventType); yield null; }
            };
        } catch (Exception e) {
            log.error("Failed to deserialize {}: {}", eventType, e.getMessage());
            return null;
        }
    }
}
