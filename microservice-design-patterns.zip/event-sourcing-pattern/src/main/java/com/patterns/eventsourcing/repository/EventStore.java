package com.patterns.eventsourcing.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.patterns.eventsourcing.event.DomainEvent;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * THE EVENT STORE - append-only log of all domain events.
 * Records are NEVER updated or deleted - only appended.
 */
@Entity
@Table(name = "event_store", indexes = {
    @Index(name = "idx_aggregate_id", columnList = "aggregateId"),
    @Index(name = "idx_event_type", columnList = "eventType")
})
@Data @Builder @NoArgsConstructor @AllArgsConstructor
class EventStoreRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String eventId;
    private String aggregateId;

    private String eventType;

    @Column(columnDefinition = "TEXT")
    private String eventData;      // JSON-serialized event

    private Long sequenceNumber;   // Position within aggregate stream
    private LocalDateTime occurredAt;
}

@Repository
interface EventStoreRepository extends JpaRepository<EventStoreRecord, Long> {
    List<EventStoreRecord> findByAggregateIdOrderBySequenceNumberAsc(String aggregateId);
    List<EventStoreRecord> findAllByOrderByOccurredAtDesc();
    long countByAggregateId(String aggregateId);
}

/**
 * Event Store Service - Manages appending and loading events
 */
@Component
public class EventStore {
    private final EventStoreRepository repository;
    private final ObjectMapper objectMapper;

    public EventStore(EventStoreRepository repository, ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
    }

    /** Append a new event (never updates existing records) */
    public void append(DomainEvent event) {
        long nextSeq = repository.countByAggregateId(event.getAggregateId()) + 1;
        try {
            EventStoreRecord record = EventStoreRecord.builder()
                    .eventId(event.getEventId())
                    .aggregateId(event.getAggregateId())
                    .eventType(event.getEventType())
                    .eventData(objectMapper.writeValueAsString(event))
                    .sequenceNumber(nextSeq)
                    .occurredAt(event.getOccurredAt())
                    .build();
            repository.save(record);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to serialize event", e);
        }
    }

    /** Load all events for an aggregate (for state reconstruction) */
    public List<EventStoreRecord> loadForAggregate(String aggregateId) {
        return repository.findByAggregateIdOrderBySequenceNumberAsc(aggregateId);
    }

    /** Load all events as EventLogEntry DTOs (for projections/audit) */
    public List<EventLogEntry> loadAll() {
        return repository.findAllByOrderByOccurredAtDesc().stream()
                .map(r -> new EventLogEntry(r.getId(), r.getAggregateId(), r.getEventType(),
                        r.getEventData(), r.getSequenceNumber(), r.getOccurredAt()))
                .collect(Collectors.toList());
    }
}
