package com.patterns.eventsourcing.projection;

import com.patterns.eventsourcing.aggregate.OrderAggregate;
import com.patterns.eventsourcing.repository.OrderRepository;
import com.patterns.eventsourcing.repository.EventLogEntry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Order Projection - Read model built from events
 *
 * Projections are read models derived by replaying events.
 * You can build MULTIPLE projections from the SAME event stream.
 * No schema migrations needed - just replay events into new projections.
 */
@Service
@RequiredArgsConstructor
public class OrderProjection {

    private final OrderRepository orderRepository;

    /** Current state (derived from event replay) */
    public Optional<Map<String, Object>> getOrderView(String orderId) {
        return orderRepository.load(orderId)
                .map(this::toView);
    }

    /** Complete audit trail - every event that happened to an order */
    public List<Map<String, Object>> getOrderHistory(String orderId) {
        return orderRepository.loadEventLog().stream()
                .filter(e -> orderId.equals(e.aggregateId()))
                .map(e -> Map.of(
                    "sequence",    e.sequenceNumber(),
                    "eventType",   e.eventType(),
                    "occurredAt",  e.occurredAt().toString(),
                    "data",        e.eventData()
                ))
                .collect(Collectors.toList());
    }

    /** Global event log - every event across all orders */
    public List<Map<String, Object>> getGlobalEventLog() {
        return orderRepository.loadEventLog().stream()
                .map(e -> Map.of(
                    "id",             e.id(),
                    "aggregateId",    e.aggregateId(),
                    "eventType",      e.eventType(),
                    "sequenceNumber", e.sequenceNumber(),
                    "occurredAt",     e.occurredAt().toString()
                ))
                .collect(Collectors.toList());
    }

    private Map<String, Object> toView(OrderAggregate agg) {
        return Map.of(
            "orderId",         agg.getOrderId(),
            "customerId",      agg.getCustomerId(),
            "customerEmail",   agg.getCustomerEmail(),
            "status",          agg.getStatus(),
            "totalAmount",     agg.getTotalAmount(),
            "shippingAddress", agg.getShippingAddress() != null ? agg.getShippingAddress() : "",
            "trackingNumber",  agg.getTrackingNumber() != null ? agg.getTrackingNumber() : "N/A",
            "version",         agg.getVersion()
        );
    }
}
