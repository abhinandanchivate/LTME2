package com.patterns.eventsourcing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Event Sourcing Pattern
 *
 * CONCEPT: Instead of storing CURRENT STATE, store a sequence of EVENTS
 * that led to that state. The current state is derived by replaying events.
 *
 * Traditional approach (what most apps do):
 *   Database row: { orderId: "ORD-1", status: "SHIPPED", total: 299.99 }
 *   → When status changes, you OVERWRITE. History is lost.
 *
 * Event Sourcing approach:
 *   Event store: [
 *     { event: "OrderPlaced",   data: {total: 299.99}, timestamp: T1 }
 *     { event: "OrderConfirmed",data: {},              timestamp: T2 }
 *     { event: "OrderShipped",  data: {trackingNo: "X"},timestamp: T3 }
 *   ]
 *   → Current state = REPLAY all events in sequence
 *
 * WHY USE IT:
 * - Complete audit trail (who did what, when, and why)
 * - Time travel: reconstruct state at any point in history
 * - Event replay: rebuild projections if read model gets corrupted
 * - Debugging: understand exactly how a bug happened
 * - Compliance: financial systems require immutable audit logs
 * - New projections: add new read models from historical events
 *
 * KEY CONCEPTS:
 * - Event Store:  append-only log of all events (never delete/update)
 * - Aggregate:    domain object that produces/applies events
 * - Projection:   read model built by replaying events
 * - Snapshot:     optimization to avoid replaying all events from scratch
 *
 * FLOW:
 *   Command → Aggregate (validates + produces events)
 *           → Events stored in Event Store (append-only)
 *           → Events applied to rebuild aggregate state
 *           → Projections updated from events
 */
@SpringBootApplication
public class EventSourcingApplication {
    public static void main(String[] args) {
        SpringApplication.run(EventSourcingApplication.class, args);
    }
}
