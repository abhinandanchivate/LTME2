package com.patterns.eventsourcing.repository;

import java.time.LocalDateTime;

/**
 * Simple DTO to expose event log entries to projections.
 * Keeps projection layer decoupled from JPA entity internals.
 */
public record EventLogEntry(
    Long id,
    String aggregateId,
    String eventType,
    String eventData,
    Long sequenceNumber,
    LocalDateTime occurredAt
) {}
