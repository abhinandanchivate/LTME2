package com.patterns.eventsourcing.event;

import lombok.Data;
import lombok.EqualsAndHashCode;
import java.util.List;
import java.util.Map;

/**
 * All concrete domain events for the Order aggregate.
 * Each captures the data needed to reconstruct what happened.
 */
public class OrderEvents {

    /** Fired when a new order is placed */
    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class OrderPlaced extends DomainEvent {
        private String customerId;
        private String customerEmail;
        private List<Map<String, Object>> items;
        private Double totalAmount;
        private String shippingAddress;

        public OrderPlaced(String orderId, String customerId, String customerEmail,
                           List<Map<String, Object>> items, Double totalAmount, String shippingAddress) {
            super(orderId, "OrderPlaced");
            this.customerId = customerId;
            this.customerEmail = customerEmail;
            this.items = items;
            this.totalAmount = totalAmount;
            this.shippingAddress = shippingAddress;
        }
    }

    /** Fired when an order is confirmed by warehouse */
    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class OrderConfirmed extends DomainEvent {
        private String confirmedBy;

        public OrderConfirmed(String orderId, String confirmedBy) {
            super(orderId, "OrderConfirmed");
            this.confirmedBy = confirmedBy;
        }
    }

    /** Fired when payment is processed */
    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class PaymentProcessed extends DomainEvent {
        private String transactionId;
        private Double amountCharged;
        private String paymentMethod;

        public PaymentProcessed(String orderId, String transactionId,
                                 Double amountCharged, String paymentMethod) {
            super(orderId, "PaymentProcessed");
            this.transactionId = transactionId;
            this.amountCharged = amountCharged;
            this.paymentMethod = paymentMethod;
        }
    }

    /** Fired when order is shipped */
    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class OrderShipped extends DomainEvent {
        private String trackingNumber;
        private String carrier;
        private String estimatedDelivery;

        public OrderShipped(String orderId, String trackingNumber, String carrier, String estimatedDelivery) {
            super(orderId, "OrderShipped");
            this.trackingNumber = trackingNumber;
            this.carrier = carrier;
            this.estimatedDelivery = estimatedDelivery;
        }
    }

    /** Fired when order is delivered */
    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class OrderDelivered extends DomainEvent {
        private String receivedBy;

        public OrderDelivered(String orderId, String receivedBy) {
            super(orderId, "OrderDelivered");
            this.receivedBy = receivedBy;
        }
    }

    /** Fired when order is cancelled */
    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class OrderCancelled extends DomainEvent {
        private String reason;
        private String cancelledBy;

        public OrderCancelled(String orderId, String reason, String cancelledBy) {
            super(orderId, "OrderCancelled");
            this.reason = reason;
            this.cancelledBy = cancelledBy;
        }
    }
}
