package com.patterns.eventsourcing.aggregate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.patterns.eventsourcing.event.DomainEvent;
import com.patterns.eventsourcing.event.OrderEvents.*;
import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Order Aggregate - The Event Sourcing core
 *
 * An aggregate in event sourcing:
 * 1. Receives commands
 * 2. Validates business rules against CURRENT state
 * 3. Produces events (does NOT save state directly)
 * 4. Applies events to update its own in-memory state
 *
 * State is DERIVED from events, not stored directly.
 * To load an Order: replay all its events through apply() methods.
 */
@Getter
public class OrderAggregate {

    private static final Logger log = LoggerFactory.getLogger(OrderAggregate.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    // Current state (derived from event replay)
    private String orderId;
    private String customerId;
    private String customerEmail;
    private String status;          // Derived from events
    private Double totalAmount;
    private String shippingAddress;
    private String trackingNumber;
    private String cancellationReason;
    private int version;            // Number of events applied

    // Uncommitted events (produced by commands, not yet persisted)
    private final List<DomainEvent> uncommittedEvents = new ArrayList<>();

    // =========================================================
    // COMMAND HANDLERS - Validate rules, produce events
    // =========================================================

    /** Handle PlaceOrder command */
    public void placeOrder(String orderId, String customerId, String customerEmail,
                           List<Map<String, Object>> items, Double totalAmount, String shippingAddress) {
        // Business rule: total must be positive
        if (totalAmount <= 0) {
            throw new IllegalArgumentException("Order total must be positive");
        }
        if (items == null || items.isEmpty()) {
            throw new IllegalArgumentException("Order must have at least one item");
        }

        // Produce event - do NOT set state directly
        apply(new OrderPlaced(orderId, customerId, customerEmail, items, totalAmount, shippingAddress));
    }

    /** Handle ConfirmOrder command */
    public void confirmOrder(String confirmedBy) {
        if (!"PENDING".equals(status)) {
            throw new IllegalStateException("Can only confirm PENDING orders, current: " + status);
        }
        apply(new OrderConfirmed(orderId, confirmedBy));
    }

    /** Handle ProcessPayment command */
    public void processPayment(String transactionId, Double amount, String paymentMethod) {
        if (!"CONFIRMED".equals(status)) {
            throw new IllegalStateException("Can only process payment for CONFIRMED orders");
        }
        apply(new PaymentProcessed(orderId, transactionId, amount, paymentMethod));
    }

    /** Handle ShipOrder command */
    public void shipOrder(String trackingNumber, String carrier, String estimatedDelivery) {
        if (!"PAYMENT_PROCESSED".equals(status)) {
            throw new IllegalStateException("Can only ship PAYMENT_PROCESSED orders");
        }
        apply(new OrderShipped(orderId, trackingNumber, carrier, estimatedDelivery));
    }

    /** Handle DeliverOrder command */
    public void deliverOrder(String receivedBy) {
        if (!"SHIPPED".equals(status)) {
            throw new IllegalStateException("Can only deliver SHIPPED orders");
        }
        apply(new OrderDelivered(orderId, receivedBy));
    }

    /** Handle CancelOrder command */
    public void cancelOrder(String reason, String cancelledBy) {
        if ("DELIVERED".equals(status) || "CANCELLED".equals(status)) {
            throw new IllegalStateException("Cannot cancel " + status + " order");
        }
        apply(new OrderCancelled(orderId, reason, cancelledBy));
    }

    // =========================================================
    // EVENT APPLIERS - Update in-memory state from events
    // These are called both when producing NEW events AND
    // when REPLAYING events from the event store
    // =========================================================

    private void apply(DomainEvent event) {
        // Apply to in-memory state
        handleEvent(event);
        // Add to uncommitted list (will be persisted by repository)
        uncommittedEvents.add(event);
        version++;
        log.info("[Aggregate] Applied event: {} (version {})", event.getEventType(), version);
    }

    /** Called during event replay from event store */
    public void replayEvent(DomainEvent event) {
        handleEvent(event);
        version++;
    }

    private void handleEvent(DomainEvent event) {
        if (event instanceof OrderPlaced e) {
            this.orderId = e.getAggregateId();
            this.customerId = e.getCustomerId();
            this.customerEmail = e.getCustomerEmail();
            this.totalAmount = e.getTotalAmount();
            this.shippingAddress = e.getShippingAddress();
            this.status = "PENDING";

        } else if (event instanceof OrderConfirmed) {
            this.status = "CONFIRMED";

        } else if (event instanceof PaymentProcessed) {
            this.status = "PAYMENT_PROCESSED";

        } else if (event instanceof OrderShipped e) {
            this.trackingNumber = e.getTrackingNumber();
            this.status = "SHIPPED";

        } else if (event instanceof OrderDelivered) {
            this.status = "DELIVERED";

        } else if (event instanceof OrderCancelled e) {
            this.cancellationReason = e.getReason();
            this.status = "CANCELLED";
        }
    }

    public void markEventsAsCommitted() {
        uncommittedEvents.clear();
    }
}
