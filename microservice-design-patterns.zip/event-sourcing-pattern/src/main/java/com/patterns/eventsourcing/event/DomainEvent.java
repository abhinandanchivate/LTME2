package com.patterns.eventsourcing.event;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * Base class for all domain events.
 *
 * A domain event represents something that HAPPENED in the past.
 * Events are:
 * - Named in the past tense: OrderPlaced, OrderShipped, OrderCancelled
 * - Immutable: once created, never modified
 * - Ordered by sequence number within an aggregate
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public abstract class DomainEvent {
    private String eventId;
    private String aggregateId;
    private String eventType;
    private LocalDateTime occurredAt;
    private Long sequenceNumber;  // Position in the event stream

    protected DomainEvent(String aggregateId, String eventType) {
        this.eventId = UUID.randomUUID().toString();
        this.aggregateId = aggregateId;
        this.eventType = eventType;
        this.occurredAt = LocalDateTime.now();
    }
}
