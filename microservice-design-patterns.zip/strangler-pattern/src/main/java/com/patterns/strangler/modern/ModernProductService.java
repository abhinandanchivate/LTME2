package com.patterns.strangler.modern;

import com.patterns.strangler.model.ProductResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * Modern Product Microservice
 *
 * The NEW system that's replacing the legacy monolith for products.
 * Has proper:
 * - Categorization
 * - Rich metadata
 * - Pagination support
 * - Fast response times
 * - Clean domain model
 */
@Service
public class ModernProductService {

    private static final Logger log = LoggerFactory.getLogger(ModernProductService.class);

    private static final Map<Long, ProductResponse> PRODUCT_DB = Map.of(
        1L, ProductResponse.builder().id(1L).name("Wireless Headphones Pro").price(299.99)
                .category("Electronics").stockCount(45).source("MODERN").build(),
        2L, ProductResponse.builder().id(2L).name("Ergonomic Office Chair").price(549.00)
                .category("Furniture").stockCount(12).source("MODERN").build(),
        3L, ProductResponse.builder().id(3L).name("Standing Desk Electric").price(899.00)
                .category("Furniture").stockCount(8).source("MODERN").build()
    );

    public ProductResponse getProduct(Long id) {
        log.info("[MODERN SERVICE] Fetching product {} from new microservice", id);

        // Modern: fast, from optimized DB/cache
        return PRODUCT_DB.getOrDefault(id,
            ProductResponse.builder().id(id).name("Product " + id).price(0.0)
                .category("General").stockCount(0).source("MODERN").build()
        );
    }

    public List<ProductResponse> getAllProducts(int page, int size) {
        log.info("[MODERN SERVICE] Fetching products - page={}, size={} (with pagination!)", page, size);
        // Modern: supports pagination
        return PRODUCT_DB.values().stream()
                .skip((long) page * size)
                .limit(size)
                .toList();
    }
}
