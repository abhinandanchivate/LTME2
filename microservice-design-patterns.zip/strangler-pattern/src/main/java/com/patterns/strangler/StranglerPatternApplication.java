package com.patterns.strangler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Strangler Fig Pattern
 *
 * CONCEPT: Incrementally replace a legacy monolith by building new microservices
 * alongside it. A "façade" (router) intercepts all calls and directs them to
 * either the legacy system or the new microservice based on which features
 * have been migrated. Over time, the legacy system gets "strangled" as more
 * features move to microservices.
 *
 * Named after the strangler fig tree: it grows around a host tree and eventually
 * replaces it when the host dies.
 *
 * MIGRATION PHASES (simulated in this project):
 *   Phase 1 (LEGACY)   - All traffic → legacy monolith
 *   Phase 2 (PARALLEL) - New product feature built in microservice;
 *                        router sends product calls to new service,
 *                        rest to legacy
 *   Phase 3 (MODERN)   - All features migrated; legacy decommissioned
 *
 * FLOW:
 *   Client → StranglerFacade (router) → Legacy Monolith   (deprecated endpoints)
 *                                     → Modern Service    (new endpoints)
 *
 * WHY USE IT:
 * - Zero big-bang rewrites (too risky)
 * - Legacy keeps running while new service is built
 * - Rollback is easy: just redirect back to legacy
 * - Migrate feature-by-feature at your own pace
 */
@SpringBootApplication
public class StranglerPatternApplication {
    public static void main(String[] args) {
        SpringApplication.run(StranglerPatternApplication.class, args);
    }
}
