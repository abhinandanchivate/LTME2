package com.patterns.strangler.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Unified Product response model.
 * Both legacy and modern services return this same contract,
 * allowing the façade to swap implementations transparently.
 */
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ProductResponse {
    private Long id;
    private String name;
    private Double price;
    private String category;
    private Integer stockCount;
    private String source;  // "LEGACY" or "MODERN" - shows which system served the request
}
