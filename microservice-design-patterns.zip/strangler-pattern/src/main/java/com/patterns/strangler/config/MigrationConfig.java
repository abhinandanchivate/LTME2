package com.patterns.strangler.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Migration Feature Flags
 *
 * Control which features have been migrated to new microservices.
 * Flip these flags to gradually strangle the legacy monolith:
 *   false = route to legacy
 *   true  = route to modern microservice
 *
 * In production: store in ConfigServer or feature flag service (LaunchDarkly etc.)
 */
@Configuration
@ConfigurationProperties(prefix = "migration")
public class MigrationConfig {

    /** Products feature: migrated to new microservice */
    private boolean productsMigrated = true;  // ✅ Products: MIGRATED

    /** Orders feature: still in legacy */
    private boolean ordersMigrated = false;   // ⏳ Orders: IN LEGACY

    /** Users feature: still in legacy */
    private boolean usersMigrated = false;    // ⏳ Users: IN LEGACY

    /** Inventory feature: still in legacy */
    private boolean inventoryMigrated = false; // ⏳ Inventory: IN LEGACY

    public boolean isProductsMigrated() { return productsMigrated; }
    public void setProductsMigrated(boolean productsMigrated) { this.productsMigrated = productsMigrated; }

    public boolean isOrdersMigrated() { return ordersMigrated; }
    public void setOrdersMigrated(boolean ordersMigrated) { this.ordersMigrated = ordersMigrated; }

    public boolean isUsersMigrated() { return usersMigrated; }
    public void setUsersMigrated(boolean usersMigrated) { this.usersMigrated = usersMigrated; }

    public boolean isInventoryMigrated() { return inventoryMigrated; }
    public void setInventoryMigrated(boolean inventoryMigrated) { this.inventoryMigrated = inventoryMigrated; }
}
