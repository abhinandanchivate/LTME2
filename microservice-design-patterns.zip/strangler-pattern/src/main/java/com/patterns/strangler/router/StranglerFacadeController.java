package com.patterns.strangler.router;

import com.patterns.strangler.config.MigrationConfig;
import com.patterns.strangler.legacy.LegacyMonolithService;
import com.patterns.strangler.model.ProductResponse;
import com.patterns.strangler.modern.ModernProductService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Strangler Façade Controller
 *
 * This is the HEART of the Strangler Pattern.
 * It's the single entry point that decides: legacy or modern?
 *
 * Clients always call THIS endpoint. They never know whether they're
 * talking to the legacy system or the new microservice. The migration
 * is completely transparent to them.
 *
 * To migrate a feature:
 *   1. Build it in modern service
 *   2. Test it
 *   3. Flip the feature flag → traffic routes to modern
 *   4. Monitor for issues
 *   5. Eventually decommission legacy code for that feature
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class StranglerFacadeController {

    private static final Logger log = LoggerFactory.getLogger(StranglerFacadeController.class);

    private final MigrationConfig migrationConfig;
    private final LegacyMonolithService legacyService;
    private final ModernProductService modernProductService;

    /**
     * GET /api/products/{id}
     *
     * Routes to: MODERN service (productsMigrated=true)
     * Try: set migration.products-migrated=false → routes to LEGACY
     */
    @GetMapping("/products/{id}")
    public ResponseEntity<ProductResponse> getProduct(@PathVariable Long id) {
        if (migrationConfig.isProductsMigrated()) {
            log.info("[FAÇADE] Products migrated → routing to MODERN service");
            return ResponseEntity.ok(modernProductService.getProduct(id));
        } else {
            log.info("[FAÇADE] Products NOT migrated → routing to LEGACY monolith");
            return ResponseEntity.ok(legacyService.getLegacyProduct(id));
        }
    }

    /**
     * GET /api/products
     *
     * Routes to: MODERN (with pagination) or LEGACY (no pagination)
     */
    @GetMapping("/products")
    public ResponseEntity<?> getAllProducts(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        if (migrationConfig.isProductsMigrated()) {
            log.info("[FAÇADE] Products migrated → routing to MODERN (paginated)");
            List<ProductResponse> products = modernProductService.getAllProducts(page, size);
            return ResponseEntity.ok(products);
        } else {
            log.info("[FAÇADE] Products NOT migrated → routing to LEGACY (no pagination)");
            return ResponseEntity.ok(legacyService.getAllLegacyProducts());
        }
    }

    /**
     * GET /api/orders/{id}
     *
     * Routes to: LEGACY (ordersMigrated=false → not yet migrated)
     */
    @GetMapping("/orders/{id}")
    public ResponseEntity<String> getOrder(@PathVariable Long id) {
        if (migrationConfig.isOrdersMigrated()) {
            // Future: return modernOrderService.getOrder(id)
            return ResponseEntity.ok("Modern order service response");
        } else {
            log.info("[FAÇADE] Orders NOT migrated → routing to LEGACY monolith");
            return ResponseEntity.ok(legacyService.getOrder(id));
        }
    }

    /**
     * GET /api/users/{id}
     *
     * Routes to: LEGACY (usersMigrated=false)
     */
    @GetMapping("/users/{id}")
    public ResponseEntity<String> getUser(@PathVariable Long id) {
        if (migrationConfig.isUsersMigrated()) {
            return ResponseEntity.ok("Modern user service response");
        } else {
            log.info("[FAÇADE] Users NOT migrated → routing to LEGACY monolith");
            return ResponseEntity.ok(legacyService.getUser(id));
        }
    }

    /**
     * GET /api/migration-status
     * Shows current migration progress - useful for ops/monitoring
     */
    @GetMapping("/migration-status")
    public ResponseEntity<Map<String, Object>> getMigrationStatus() {
        return ResponseEntity.ok(Map.of(
            "migrationStatus", Map.of(
                "products",  migrationConfig.isProductsMigrated() ? "✅ MODERN" : "⏳ LEGACY",
                "orders",    migrationConfig.isOrdersMigrated()   ? "✅ MODERN" : "⏳ LEGACY",
                "users",     migrationConfig.isUsersMigrated()    ? "✅ MODERN" : "⏳ LEGACY",
                "inventory", migrationConfig.isInventoryMigrated() ? "✅ MODERN" : "⏳ LEGACY"
            ),
            "migrationProgress", "25% complete (1 of 4 domains migrated)",
            "nextMilestone", "Migrate order management (Q2 2025)"
        ));
    }
}
