package com.patterns.strangler.legacy;

import com.patterns.strangler.model.ProductResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Legacy Monolith Service
 *
 * Represents the OLD system being strangled.
 * In reality this would be a RestTemplate/WebClient call to the legacy monolith,
 * or even the actual legacy code embedded in the same JVM if doing in-process strangling.
 *
 * Characteristics of legacy code (simulated here):
 * - No pagination
 * - Mixed concerns (business logic + data access together)
 * - Returns more data than needed
 * - Slower response times
 * - Old data format (no 'category' field, uses numeric stock levels)
 */
@Service
public class LegacyMonolithService {

    private static final Logger log = LoggerFactory.getLogger(LegacyMonolithService.class);

    public ProductResponse getLegacyProduct(Long id) {
        log.info("[LEGACY SYSTEM] Fetching product {} from legacy monolith database", id);

        // Simulate legacy system latency
        try { Thread.sleep(200); } catch (InterruptedException ignored) {}

        return ProductResponse.builder()
                .id(id)
                .name("LEGACY: Product #" + id + " (Old Format)")
                .price(99.99)
                .category("UNCATEGORIZED") // Legacy didn't have proper categories
                .stockCount(getStockFromLegacyDb(id))
                .source("LEGACY") // Clearly identifies this came from old system
                .build();
    }

    public List<ProductResponse> getAllLegacyProducts() {
        log.info("[LEGACY SYSTEM] Fetching ALL products - no pagination (legacy limitation)");

        // Legacy: dumps entire table, no pagination
        return List.of(
            ProductResponse.builder().id(1L).name("LEGACY: Widget A").price(10.0).source("LEGACY").build(),
            ProductResponse.builder().id(2L).name("LEGACY: Widget B").price(20.0).source("LEGACY").build(),
            ProductResponse.builder().id(3L).name("LEGACY: Widget C").price(30.0).source("LEGACY").build()
        );
    }

    public String getOrder(Long id) {
        log.info("[LEGACY SYSTEM] Fetching order {} - orders NOT migrated yet", id);
        return String.format("LEGACY ORDER #%d: Customer=John, Total=$199.99, Status=Processing", id);
    }

    public String getUser(Long id) {
        log.info("[LEGACY SYSTEM] Fetching user {} - users NOT migrated yet", id);
        return String.format("LEGACY USER #%d: Name=Jane Doe, Email=jane@example.com", id);
    }

    private Integer getStockFromLegacyDb(Long productId) {
        // Simulates slow legacy DB query
        return (int)(Math.random() * 100);
    }
}
