import { Component } from '@angular/core';

declare const require: any;


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'angular-15-mfe';
  protected ngVersion = require('../../package.json').dependencies['@angular/core'];

  protected shellMessage: string | undefined;

  constructor() {
    window.addEventListener('shell', (e:any)=> {
      this.shellMessage = e.detail;
    })
  }
}
