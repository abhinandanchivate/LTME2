package com.securepayment.handler;
import com.securepayment.dto.ErrorResponse;
import com.securepayment.filter.CorrelationIdFilter;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.MDC;
import org.springframework.http.*;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import java.util.*;
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        String cid = MDC.get(CorrelationIdFilter.MDC_KEY);
        String path = request.getDescription(false).replace("uri=", "");
        Map<String, List<String>> fieldErrors = new LinkedHashMap<>();
        for (FieldError fe : ex.getBindingResult().getFieldErrors())
            fieldErrors.computeIfAbsent(fe.getField(), k -> new ArrayList<>()).add(fe.getDefaultMessage());
        ErrorResponse body = ErrorResponse.withFieldErrors(cid, 400, "Validation Failed", "Invalid fields", path, fieldErrors);
        return ResponseEntity.badRequest().header(CorrelationIdFilter.CORRELATION_ID_HEADER, cid).body(body);
    }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleAll(Exception ex, HttpServletRequest req) {
        String cid = MDC.get(CorrelationIdFilter.MDC_KEY);
        logger.error("Unhandled exception correlationId=" + cid, ex);
        return ResponseEntity.status(500)
            .header(CorrelationIdFilter.CORRELATION_ID_HEADER, cid)
            .body(ErrorResponse.of(cid, 500, "Internal Server Error", "Unexpected error", req.getRequestURI()));
    }
}
