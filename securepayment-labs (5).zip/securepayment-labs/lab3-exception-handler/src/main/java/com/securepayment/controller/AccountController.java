package com.securepayment.controller;
import com.securepayment.dto.AccountRegistrationRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController @RequestMapping("/api/accounts")
public class AccountController {
    @PostMapping("/register")
    public ResponseEntity<Map<String,String>> register(@Valid @RequestBody AccountRegistrationRequest req) {
        return ResponseEntity.ok(Map.of("message","Account created","username",req.username()));
    }
    @GetMapping("/error-test")
    public void errorTest() { throw new RuntimeException("Simulated error"); }
}
