package com.securepayment.dto;
import com.securepayment.annotation.ValidPassword;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
public record AccountRegistrationRequest(
    @NotBlank(message="Username required") String username,
    @NotBlank @Email(message="Valid email required") String email,
    @NotBlank(message="Password required") @ValidPassword String password
) {}
