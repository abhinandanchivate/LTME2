package com.securepayment.validator;
import com.securepayment.annotation.ValidPassword;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.util.regex.Pattern;
public class PasswordValidator implements ConstraintValidator<ValidPassword, String> {
    private static final Pattern UC = Pattern.compile("[A-Z]");
    private static final Pattern DG = Pattern.compile("[0-9]");
    private static final Pattern SP = Pattern.compile("[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?]");
    private int minLength; private boolean requireSpecialChar;
    @Override public void initialize(ValidPassword a) { minLength=a.minLength(); requireSpecialChar=a.requireSpecialChar(); }
    @Override public boolean isValid(String pw, ConstraintValidatorContext ctx) {
        if (pw==null||pw.isBlank()) return true;
        boolean valid=true; ctx.disableDefaultConstraintViolation();
        if(pw.length()<minLength){ctx.buildConstraintViolationWithTemplate("Min "+minLength+" chars").addConstraintViolation();valid=false;}
        if(!UC.matcher(pw).find()){ctx.buildConstraintViolationWithTemplate("Needs uppercase").addConstraintViolation();valid=false;}
        if(!DG.matcher(pw).find()){ctx.buildConstraintViolationWithTemplate("Needs digit").addConstraintViolation();valid=false;}
        if(requireSpecialChar&&!SP.matcher(pw).find()){ctx.buildConstraintViolationWithTemplate("Needs special char").addConstraintViolation();valid=false;}
        return valid;
    }
}
