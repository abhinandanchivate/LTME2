package com.securepayment;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
@SpringBootTest @AutoConfigureMockMvc
class CorrelationIdTest {
    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;

    @Test
    void correlationId_isReflectedInResponseHeader() throws Exception {
        String body = """
            {"username":"alice","email":"bad-email","password":"weak"}""";
        MvcResult result = mockMvc.perform(post("/api/accounts/register")
                .contentType(MediaType.APPLICATION_JSON)
                .header("X-Correlation-ID", "test-123")
                .content(body))
            .andExpect(status().isBadRequest())
            .andReturn();
        assertThat(result.getResponse().getHeader("X-Correlation-ID")).isEqualTo("test-123");
        String responseBody = result.getResponse().getContentAsString();
        assertThat(responseBody).contains("test-123");
        assertThat(responseBody).contains("fieldErrors");
    }

    @Test
    void missingCorrelationId_isGeneratedAutomatically() throws Exception {
        String body = """
            {"username":"alice","email":"bad","password":"weak"}""";
        MvcResult result = mockMvc.perform(post("/api/accounts/register")
                .contentType(MediaType.APPLICATION_JSON).content(body))
            .andExpect(status().isBadRequest())
            .andReturn();
        String cid = result.getResponse().getHeader("X-Correlation-ID");
        assertThat(cid).isNotNull().isNotBlank();
    }
}
