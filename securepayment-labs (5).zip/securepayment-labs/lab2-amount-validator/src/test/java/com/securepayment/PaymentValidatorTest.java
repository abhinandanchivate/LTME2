package com.securepayment;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class PaymentValidatorTest {

    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;

    @Test
    void validPayment_returns200() throws Exception {
        String body = """
            {"description":"Test payment","amount":100.00,"cardNumber":"4532015112830366"}
            """;
        mockMvc.perform(post("/api/payments").contentType(MediaType.APPLICATION_JSON).content(body))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.status").value("ACCEPTED"));
    }

    @Test
    void negativeAmount_returns400() throws Exception {
        String body = """
            {"description":"Test","amount":-50.00,"cardNumber":"4532015112830366"}
            """;
        mockMvc.perform(post("/api/payments").contentType(MediaType.APPLICATION_JSON).content(body))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.fieldErrors.amount").isArray());
    }

    @Test
    void invalidCard_returns400() throws Exception {
        String body = """
            {"description":"Test","amount":100.00,"cardNumber":"1234567890123456"}
            """;
        mockMvc.perform(post("/api/payments").contentType(MediaType.APPLICATION_JSON).content(body))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.fieldErrors.cardNumber").isArray());
    }
}
