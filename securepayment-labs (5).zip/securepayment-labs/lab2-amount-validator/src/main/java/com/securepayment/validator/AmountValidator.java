package com.securepayment.validator;

import com.securepayment.annotation.ValidAmount;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

public class AmountValidator implements ConstraintValidator<ValidAmount, BigDecimal> {

    private double max;
    private int scale;

    @Override
    public void initialize(ValidAmount annotation) {
        this.max = annotation.max();
        this.scale = annotation.scale();
    }

    @Override
    public boolean isValid(BigDecimal amount, ConstraintValidatorContext context) {
        if (amount == null) return true; // use @NotNull separately

        boolean valid = true;
        context.disableDefaultConstraintViolation();

        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            context.buildConstraintViolationWithTemplate("Amount must be positive").addConstraintViolation();
            valid = false;
        }
        if (amount.compareTo(BigDecimal.valueOf(max)) > 0) {
            context.buildConstraintViolationWithTemplate(
                "Amount must not exceed " + max
            ).addConstraintViolation();
            valid = false;
        }
        if (amount.scale() > scale) {
            context.buildConstraintViolationWithTemplate(
                "Amount must have at most " + scale + " decimal places"
            ).addConstraintViolation();
            valid = false;
        }
        return valid;
    }
}
