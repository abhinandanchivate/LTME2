package com.securepayment.dto;

import com.securepayment.annotation.ValidAmount;
import com.securepayment.annotation.ValidCreditCard;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.math.BigDecimal;

public record PaymentRequest(
    @NotBlank(message = "Description is required")
    String description,

    @NotNull(message = "Amount is required")
    @ValidAmount(max = 10_000.00)
    BigDecimal amount,

    @NotBlank(message = "Card number is required")
    @ValidCreditCard
    String cardNumber
) {}
