package com.securepayment.validator;

import com.securepayment.annotation.ValidCreditCard;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class CreditCardValidator implements ConstraintValidator<ValidCreditCard, String> {

    @Override
    public boolean isValid(String cardNumber, ConstraintValidatorContext context) {
        if (cardNumber == null || cardNumber.isBlank()) return true;

        // Strip spaces and dashes
        String digits = cardNumber.replaceAll("[\\s\\-]", "");

        if (!digits.matches("\\d{13,19}")) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Card number must be 13-19 digits").addConstraintViolation();
            return false;
        }

        if (!luhnCheck(digits)) {
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate("Card number failed Luhn check").addConstraintViolation();
            return false;
        }
        return true;
    }

    private boolean luhnCheck(String number) {
        int sum = 0;
        boolean alternate = false;
        for (int i = number.length() - 1; i >= 0; i--) {
            int n = number.charAt(i) - '0';
            if (alternate) {
                n *= 2;
                if (n > 9) n -= 9;
            }
            sum += n;
            alternate = !alternate;
        }
        return sum % 10 == 0;
    }
}
