package com.securepayment.controller;

import com.securepayment.dto.PaymentRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @PostMapping
    public ResponseEntity<Map<String, String>> processPayment(
            @Valid @RequestBody PaymentRequest request) {
        return ResponseEntity.ok(Map.of(
            "status", "ACCEPTED",
            "description", request.description(),
            "amount", request.amount().toPlainString()
        ));
    }
}
