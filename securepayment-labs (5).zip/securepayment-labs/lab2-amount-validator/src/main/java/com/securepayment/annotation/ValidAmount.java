package com.securepayment.annotation;

import com.securepayment.validator.AmountValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = AmountValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidAmount {
    String message() default "Invalid payment amount";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
    double max() default 10_000.00;
    int scale() default 2;
}
