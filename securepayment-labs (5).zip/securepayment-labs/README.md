# SecurePayment Gateway — Spring Boot Labs

## Prerequisites
- Java 17+ (`java -version`)
- Maven 3.9+ (`mvn -version`)

## How to Build & Run

Each lab is an independent Spring Boot project. To build and test any lab:

```bash
cd labN-<name>
mvn clean test          # compile + run tests
mvn spring-boot:run     # run the application
```

## Lab Summary

| Lab | Topic | Port | Key Concepts |
|-----|-------|------|--------------|
| 1 | Password Strength Validator | 8081 | `@ValidPassword`, multi-violation collection |
| 2 | Amount + Credit Card Validators | 8082 | `@ValidAmount`, `@ValidCreditCard`, Luhn algorithm |
| 3 | Global Exception Handler + Correlation IDs | 8083 | `X-Correlation-ID`, MDC, `ResponseEntityExceptionHandler` |
| 4 | Domain Exceptions + Security Handlers | 8084 | Sealed exceptions, `AuthenticationEntryPoint`, `AccessDeniedHandler` |
| 5 | ConfigurationProperties + Profiles | 8085 | `@ConfigurationProperties`, `@Validated`, dev/prod profiles |
| 6 | Feature Flags with DB, Cache, Admin API | 8086 | JPA, Flyway, Caffeine cache, `@Cacheable`, rollout % |

## Quick Test Calls

### Lab 1 — Weak Password
```bash
curl -s -X POST http://localhost:8081/api/accounts/register \
  -H "Content-Type: application/json" \
  -d '{"username":"alice","email":"alice@example.com","password":"weak"}' | jq .
```

### Lab 3 — Correlation ID
```bash
curl -s -X POST http://localhost:8083/api/accounts/register \
  -H "Content-Type: application/json" \
  -H "X-Correlation-ID: my-trace-123" \
  -d '{"username":"","email":"bad","password":"weak"}' -v 2>&1 | grep -E "(X-Correlation|fieldErrors)"
```

### Lab 4 — Auth/Domain Exceptions
```bash
# 401 — no credentials
curl -s http://localhost:8084/api/payments/acc1 | jq .
# 404 — account not found
curl -s -u user:user123 http://localhost:8084/api/payments/unknown | jq .
# 409 — duplicate transaction
curl -s -u user:user123 -X POST "http://localhost:8084/api/payments/process?txId=dup-123&amount=100" | jq .
# 422 — insufficient funds
curl -s -u user:user123 -X POST "http://localhost:8084/api/payments/process?txId=tx-1&amount=9999" | jq .
```

### Lab 5 — Config Profiles
```bash
# Run with dev profile
mvn spring-boot:run -Dspring-boot.run.profiles=dev
curl -s http://localhost:8085/api/config | jq .
```

### Lab 6 — Feature Flags
```bash
# List all flags
curl -s http://localhost:8086/api/admin/flags | jq .
# Enable instant-settlement
curl -s -X PUT "http://localhost:8086/api/admin/flags/instant-settlement?enabled=true&updatedBy=admin" | jq .
# Test settlement mode changes
curl -s -X POST "http://localhost:8086/api/settlements?txId=tx1&amount=100" | jq .
```
