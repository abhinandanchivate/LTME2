package com.securepayment.security;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.securepayment.dto.ErrorResponse;
import com.securepayment.filter.CorrelationIdFilter;
import jakarta.servlet.http.*;
import org.slf4j.MDC;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;
import java.io.IOException;
@Component
public class PaymentAuthenticationEntryPoint implements AuthenticationEntryPoint {
    private final ObjectMapper om;
    public PaymentAuthenticationEntryPoint(ObjectMapper om) { this.om=om; }
    @Override
    public void commence(HttpServletRequest req, HttpServletResponse res, AuthenticationException ex) throws IOException {
        String cid = MDC.get(CorrelationIdFilter.MDC_KEY);
        res.setStatus(401); res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        res.setHeader(CorrelationIdFilter.CORRELATION_ID_HEADER, cid);
        om.writeValue(res.getWriter(), ErrorResponse.of(cid, 401, "Unauthorized", "Authentication required", req.getRequestURI()));
    }
}
