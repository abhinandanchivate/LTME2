package com.securepayment.security;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
@Configuration @EnableWebSecurity @EnableMethodSecurity
public class SecurityConfig {
    private final PaymentAuthenticationEntryPoint ep;
    private final PaymentAccessDeniedHandler dh;
    public SecurityConfig(PaymentAuthenticationEntryPoint ep, PaymentAccessDeniedHandler dh){this.ep=ep;this.dh=dh;}
    @Bean public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(c->c.disable())
            .authorizeHttpRequests(a->a
                .requestMatchers("/api/public/**").permitAll()
                .requestMatchers("/api/admin/**").hasRole("ADMIN")
                .anyRequest().authenticated())
            .httpBasic(b->b.authenticationEntryPoint(ep))
            .exceptionHandling(e->e.authenticationEntryPoint(ep).accessDeniedHandler(dh));
        return http.build();
    }
    @Bean public PasswordEncoder passwordEncoder(){ return new BCryptPasswordEncoder(); }
    @Bean public UserDetailsService userDetailsService(PasswordEncoder enc){
        return new InMemoryUserDetailsManager(
            User.builder().username("user").password(enc.encode("user123")).roles("USER").build(),
            User.builder().username("admin").password(enc.encode("admin123")).roles("ADMIN").build());
    }
}
