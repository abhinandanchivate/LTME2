package com.securepayment.controller;
import com.securepayment.exception.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController @RequestMapping("/api")
public class PaymentController {
    @GetMapping("/public/health")
    public ResponseEntity<Map<String,String>> health(){ return ResponseEntity.ok(Map.of("status","UP")); }
    @GetMapping("/payments/{accountId}")
    public ResponseEntity<Map<String,String>> getPayment(@PathVariable String accountId){
        if("unknown".equals(accountId)) throw new AccountNotFoundException(accountId);
        return ResponseEntity.ok(Map.of("accountId",accountId,"balance","1000.00"));
    }
    @PostMapping("/payments/process")
    public ResponseEntity<Map<String,String>> process(@RequestParam String txId, @RequestParam double amount){
        if("dup-123".equals(txId)) throw new DuplicateTransactionException(txId);
        if(amount>5000) throw new InsufficientFundsException(500.0,amount);
        return ResponseEntity.ok(Map.of("txId",txId,"status","PROCESSED"));
    }
    @GetMapping("/admin/reports")
    public ResponseEntity<Map<String,String>> adminReport(){ return ResponseEntity.ok(Map.of("report","sensitive data")); }
}
