package com.securepayment.exception;
public final class AccountNotFoundException extends PaymentException {
    public AccountNotFoundException(String accountId) { super("Account not found: "+accountId); }
}
