package com.securepayment.dto;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.time.Instant;
import java.util.List;
import java.util.Map;
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ErrorResponse(String correlationId, String timestamp, int status,
    String error, String message, String path, Map<String, List<String>> fieldErrors) {
    public static ErrorResponse of(String cid, int status, String error, String message, String path) {
        return new ErrorResponse(cid, Instant.now().toString(), status, error, message, path, null);
    }
    public static ErrorResponse withFieldErrors(String cid, int status, String error,
            String message, String path, Map<String, List<String>> fieldErrors) {
        return new ErrorResponse(cid, Instant.now().toString(), status, error, message, path, fieldErrors);
    }
}
