package com.securepayment.security;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.securepayment.dto.ErrorResponse;
import com.securepayment.filter.CorrelationIdFilter;
import jakarta.servlet.http.*;
import org.slf4j.MDC;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;
import java.io.IOException;
@Component
public class PaymentAccessDeniedHandler implements AccessDeniedHandler {
    private final ObjectMapper om;
    public PaymentAccessDeniedHandler(ObjectMapper om) { this.om=om; }
    @Override
    public void handle(HttpServletRequest req, HttpServletResponse res, AccessDeniedException ex) throws IOException {
        String cid = MDC.get(CorrelationIdFilter.MDC_KEY);
        res.setStatus(403); res.setContentType(MediaType.APPLICATION_JSON_VALUE);
        res.setHeader(CorrelationIdFilter.CORRELATION_ID_HEADER, cid);
        om.writeValue(res.getWriter(), ErrorResponse.of(cid, 403, "Forbidden", "Insufficient privileges", req.getRequestURI()));
    }
}
