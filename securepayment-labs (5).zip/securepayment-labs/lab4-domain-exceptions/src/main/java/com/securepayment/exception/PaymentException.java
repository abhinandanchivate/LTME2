package com.securepayment.exception;
public sealed class PaymentException extends RuntimeException
    permits InsufficientFundsException, DuplicateTransactionException, AccountNotFoundException {
    public PaymentException(String message) { super(message); }
}
