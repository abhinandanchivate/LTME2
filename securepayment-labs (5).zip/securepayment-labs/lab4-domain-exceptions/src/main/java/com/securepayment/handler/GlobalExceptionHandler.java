package com.securepayment.handler;
import com.securepayment.dto.ErrorResponse;
import com.securepayment.exception.*;
import com.securepayment.filter.CorrelationIdFilter;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.MDC;
import org.springframework.http.*;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import java.util.*;
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders h, HttpStatusCode s, WebRequest req) {
        String cid=MDC.get(CorrelationIdFilter.MDC_KEY);
        String path=req.getDescription(false).replace("uri=","");
        Map<String,List<String>> fe=new LinkedHashMap<>();
        for(FieldError f:ex.getBindingResult().getFieldErrors())
            fe.computeIfAbsent(f.getField(),k->new ArrayList<>()).add(f.getDefaultMessage());
        return ResponseEntity.badRequest().body(ErrorResponse.withFieldErrors(cid,400,"Validation Failed","Invalid fields",path,fe));
    }
    @ExceptionHandler(InsufficientFundsException.class)
    public ResponseEntity<ErrorResponse> handleInsufficient(InsufficientFundsException ex, HttpServletRequest req){
        return ResponseEntity.unprocessableEntity().body(ErrorResponse.of(MDC.get(CorrelationIdFilter.MDC_KEY),422,"Unprocessable Entity","Insufficient funds",req.getRequestURI()));
    }
    @ExceptionHandler(DuplicateTransactionException.class)
    public ResponseEntity<ErrorResponse> handleDuplicate(DuplicateTransactionException ex, HttpServletRequest req){
        return ResponseEntity.status(409).body(ErrorResponse.of(MDC.get(CorrelationIdFilter.MDC_KEY),409,"Conflict","Duplicate transaction",req.getRequestURI()));
    }
    @ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<Void> handleNotFound(){ return ResponseEntity.notFound().build(); }
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleAll(Exception ex, HttpServletRequest req){
        String cid=MDC.get(CorrelationIdFilter.MDC_KEY);
        logger.error("Unhandled cid="+cid,ex);
        return ResponseEntity.status(500).body(ErrorResponse.of(cid,500,"Internal Server Error","Unexpected error",req.getRequestURI()));
    }
}
