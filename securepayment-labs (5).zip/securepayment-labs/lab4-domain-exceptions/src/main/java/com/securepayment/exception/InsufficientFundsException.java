package com.securepayment.exception;
public final class InsufficientFundsException extends PaymentException {
    private final double available, required;
    public InsufficientFundsException(double available, double required) {
        super("Insufficient funds"); this.available=available; this.required=required;
    }
    public double getAvailable(){return available;} public double getRequired(){return required;}
}
