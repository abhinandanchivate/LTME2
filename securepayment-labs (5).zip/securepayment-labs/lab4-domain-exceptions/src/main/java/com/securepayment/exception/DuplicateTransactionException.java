package com.securepayment.exception;
public final class DuplicateTransactionException extends PaymentException {
    private final String transactionId;
    public DuplicateTransactionException(String txId) { super("Duplicate: "+txId); this.transactionId=txId; }
    public String getTransactionId(){return transactionId;}
}
