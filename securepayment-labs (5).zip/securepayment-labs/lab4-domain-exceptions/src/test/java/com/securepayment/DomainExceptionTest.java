package com.securepayment;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
@SpringBootTest @AutoConfigureMockMvc
class DomainExceptionTest {
    @Autowired MockMvc mockMvc;

    @Test void publicEndpoint_noAuth_returns200() throws Exception {
        mockMvc.perform(get("/api/public/health")).andExpect(status().isOk());
    }
    @Test void protectedEndpoint_noAuth_returns401JSON() throws Exception {
        mockMvc.perform(get("/api/payments/acc1"))
            .andExpect(status().isUnauthorized())
            .andExpect(jsonPath("$.status").value(401))
            .andExpect(jsonPath("$.error").value("Unauthorized"));
    }
    @Test void unknownAccount_returns404() throws Exception {
        mockMvc.perform(get("/api/payments/unknown").with(httpBasic("user","user123")))
            .andExpect(status().isNotFound());
    }
    @Test void duplicateTransaction_returns409() throws Exception {
        mockMvc.perform(post("/api/payments/process")
                .with(httpBasic("user","user123"))
                .param("txId","dup-123").param("amount","100"))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.status").value(409));
    }
    @Test void insufficientFunds_returns422() throws Exception {
        mockMvc.perform(post("/api/payments/process")
                .with(httpBasic("user","user123"))
                .param("txId","tx-999").param("amount","9999"))
            .andExpect(status().isUnprocessableEntity())
            .andExpect(jsonPath("$.status").value(422));
    }
}
