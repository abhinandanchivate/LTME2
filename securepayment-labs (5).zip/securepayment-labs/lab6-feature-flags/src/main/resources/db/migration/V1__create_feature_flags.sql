CREATE TABLE feature_flags (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    enabled BOOLEAN NOT NULL DEFAULT FALSE,
    description VARCHAR(255),
    rollout_percentage INT NOT NULL DEFAULT 100,
    updated_by VARCHAR(100),
    updated_at TIMESTAMP
);
INSERT INTO feature_flags (name, enabled, description, rollout_percentage) VALUES
    ('instant-settlement', false, 'Enable instant payment settlement', 100),
    ('fraud-ml-model', false, 'Use ML model for fraud detection instead of rules', 0),
    ('new-payment-ui', false, 'Enable new payment UI experience', 50);
