package com.securepayment.controller;
import com.securepayment.entity.FeatureFlag;
import com.securepayment.service.FeatureFlagService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
@RestController @RequestMapping("/api/admin/flags")
public class FeatureFlagController {
    private final FeatureFlagService svc;
    public FeatureFlagController(FeatureFlagService svc){this.svc=svc;}
    @GetMapping public ResponseEntity<List<FeatureFlag>> list(){return ResponseEntity.ok(svc.listAll());}
    @PutMapping("/{name}") public ResponseEntity<FeatureFlag> toggle(
            @PathVariable String name,@RequestParam boolean enabled,
            @RequestParam(defaultValue="system") String updatedBy){
        return ResponseEntity.ok(svc.setFlag(name,enabled,updatedBy));
    }
    @GetMapping("/{name}/check") public ResponseEntity<Map<String,Object>> check(@PathVariable String name){
        return ResponseEntity.ok(Map.of("name",name,"enabled",svc.isEnabled(name)));
    }
}
