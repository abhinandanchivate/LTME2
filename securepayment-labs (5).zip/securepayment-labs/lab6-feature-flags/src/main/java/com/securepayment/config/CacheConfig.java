package com.securepayment.config;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.cache.caffeine.CaffeineCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.concurrent.TimeUnit;
@Configuration
public class CacheConfig {
    @Bean
    public CaffeineCacheManager cacheManager(){
        CaffeineCacheManager mgr=new CaffeineCacheManager("featureFlags");
        mgr.setCaffeine(Caffeine.newBuilder().expireAfterWrite(60,TimeUnit.SECONDS).maximumSize(100));
        return mgr;
    }
}
