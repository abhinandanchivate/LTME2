package com.securepayment.entity;
import jakarta.persistence.*;
import java.time.Instant;
@Entity @Table(name="feature_flags")
public class FeatureFlag {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
    @Column(nullable=false,unique=true) private String name;
    @Column(nullable=false) private boolean enabled;
    private String description;
    private int rolloutPercentage=100;
    @Column(name="updated_by") private String updatedBy;
    @Column(name="updated_at") private Instant updatedAt;
    public Long getId(){return id;} public void setId(Long id){this.id=id;}
    public String getName(){return name;} public void setName(String n){this.name=n;}
    public boolean isEnabled(){return enabled;} public void setEnabled(boolean e){this.enabled=e;}
    public String getDescription(){return description;} public void setDescription(String d){this.description=d;}
    public int getRolloutPercentage(){return rolloutPercentage;} public void setRolloutPercentage(int r){this.rolloutPercentage=r;}
    public String getUpdatedBy(){return updatedBy;} public void setUpdatedBy(String u){this.updatedBy=u;}
    public Instant getUpdatedAt(){return updatedAt;} public void setUpdatedAt(Instant t){this.updatedAt=t;}
}
