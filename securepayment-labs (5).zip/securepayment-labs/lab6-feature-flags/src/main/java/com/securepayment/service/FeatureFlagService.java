package com.securepayment.service;
import com.securepayment.entity.FeatureFlag;
import com.securepayment.repository.FeatureFlagRepository;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Instant;
import java.util.List;
@Service
public class FeatureFlagService {
    private final FeatureFlagRepository repo;
    public FeatureFlagService(FeatureFlagRepository repo){this.repo=repo;}
    @Cacheable(value="featureFlags",key="#name")
    public boolean isEnabled(String name){return repo.findByName(name).map(FeatureFlag::isEnabled).orElse(false);}
    @Cacheable(value="featureFlags",key="#name+'_'+#userId")
    public boolean isEnabledForUser(String name,String userId){
        return repo.findByName(name).map(f->{
            if(!f.isEnabled())return false;
            return Math.abs(userId.hashCode()%100)<f.getRolloutPercentage();
        }).orElse(false);
    }
    @CacheEvict(value="featureFlags",allEntries=true)
    @Transactional
    public FeatureFlag setFlag(String name,boolean enabled,String updatedBy){
        FeatureFlag f=repo.findByName(name).orElseThrow(()->new IllegalArgumentException("Flag not found: "+name));
        f.setEnabled(enabled); f.setUpdatedBy(updatedBy); f.setUpdatedAt(Instant.now());
        return repo.save(f);
    }
    public List<FeatureFlag> listAll(){return repo.findAll();}
}
