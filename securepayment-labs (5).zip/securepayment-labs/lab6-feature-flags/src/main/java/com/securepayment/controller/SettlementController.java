package com.securepayment.controller;
import com.securepayment.service.SettlementService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Map;
@RestController @RequestMapping("/api/settlements")
public class SettlementController {
    private final SettlementService svc;
    public SettlementController(SettlementService svc){this.svc=svc;}
    @PostMapping public ResponseEntity<Map<String,Object>> settle(@RequestParam String txId,@RequestParam BigDecimal amount){
        return ResponseEntity.ok(svc.settle(txId,amount));
    }
}
