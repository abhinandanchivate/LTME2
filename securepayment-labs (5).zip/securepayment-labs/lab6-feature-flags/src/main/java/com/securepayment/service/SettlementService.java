package com.securepayment.service;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.Map;
@Service
public class SettlementService {
    private final FeatureFlagService flags;
    public SettlementService(FeatureFlagService flags){this.flags=flags;}
    public Map<String,Object> settle(String txId,BigDecimal amount){
        boolean instant=flags.isEnabled("instant-settlement");
        return Map.of("txId",txId,"amount",amount,"settlementMode",instant?"INSTANT":"BATCH_24H","status","QUEUED");
    }
}
