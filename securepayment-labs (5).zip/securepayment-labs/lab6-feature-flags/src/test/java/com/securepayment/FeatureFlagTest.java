package com.securepayment;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
@SpringBootTest @AutoConfigureMockMvc
class FeatureFlagTest {
    @Autowired MockMvc mockMvc;

    @Test void listFlags_returnsAll() throws Exception {
        mockMvc.perform(get("/api/admin/flags"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$").isArray())
            .andExpect(jsonPath("$[0].name").isString());
    }

    @Test void toggleFlag_enablesAndDisables() throws Exception {
        // Enable
        mockMvc.perform(put("/api/admin/flags/instant-settlement")
                .param("enabled","true").param("updatedBy","test-user"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.enabled").value(true));
        // Check
        mockMvc.perform(get("/api/admin/flags/instant-settlement/check"))
            .andExpect(jsonPath("$.enabled").value(true));
        // Disable
        mockMvc.perform(put("/api/admin/flags/instant-settlement")
                .param("enabled","false").param("updatedBy","test-user"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.enabled").value(false));
    }

    @Test void settlement_reflectsFeatureFlag() throws Exception {
        // With flag disabled
        mockMvc.perform(post("/api/settlements").param("txId","tx1").param("amount","100.00"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.settlementMode").value("BATCH_24H"));
        // Enable flag then retry
        mockMvc.perform(put("/api/admin/flags/instant-settlement").param("enabled","true").param("updatedBy","test"));
        mockMvc.perform(post("/api/settlements").param("txId","tx2").param("amount","100.00"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.settlementMode").value("INSTANT"));
    }
}
