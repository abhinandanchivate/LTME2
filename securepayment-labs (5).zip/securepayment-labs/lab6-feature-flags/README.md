# Lab6 Feature Flags

## Build
```bash
mvn clean test          # compile + run all tests
mvn spring-boot:run     # start the application
```

## Test Endpoints
See the root README.md for curl examples.
