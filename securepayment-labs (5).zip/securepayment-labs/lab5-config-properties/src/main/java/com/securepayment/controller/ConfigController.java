package com.securepayment.controller;
import com.securepayment.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Map;
@RestController @RequestMapping("/api")
public class ConfigController {
    private final PaymentService svc;
    public ConfigController(PaymentService svc){this.svc=svc;}
    @GetMapping("/config") public ResponseEntity<Map<String,Object>> cfg(){return ResponseEntity.ok(svc.getConfig());}
    @PostMapping("/payments/process") public ResponseEntity<Map<String,Object>> process(@RequestParam BigDecimal amount){
        return ResponseEntity.ok(svc.processPayment(amount));
    }
}
