package com.securepayment.service;
import com.securepayment.config.PaymentProperties;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.Map;
@Service
public class PaymentService {
    private final PaymentProperties props;
    public PaymentService(PaymentProperties p){this.props=p;}
    public Map<String,Object> processPayment(BigDecimal amount){
        if(amount.compareTo(props.maxTransactionAmount())>0)
            throw new IllegalArgumentException("Amount exceeds max: "+props.maxTransactionAmount());
        return Map.of("gateway",props.gatewayUrl(),"amount",amount,
            "fraudCheckEnabled",props.fraudDetection().enabled(),"status","PROCESSED");
    }
    public Map<String,Object> getConfig(){
        return Map.of("gatewayUrl",props.gatewayUrl(),"timeoutSeconds",props.timeoutSeconds(),
            "maxRetries",props.maxRetries(),"maxTransactionAmount",props.maxTransactionAmount(),
            "fraudDetectionEnabled",props.fraudDetection().enabled(),
            "riskThreshold",props.fraudDetection().riskThreshold(),
            "dailyTransactionLimit",props.fraudDetection().dailyTransactionLimit());
    }
}
