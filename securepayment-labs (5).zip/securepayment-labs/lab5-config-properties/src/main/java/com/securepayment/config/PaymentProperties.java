package com.securepayment.config;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;
import java.math.BigDecimal;
@ConfigurationProperties(prefix="payment") @Validated
public record PaymentProperties(
    @NotBlank String gatewayUrl,
    @NotNull @Positive Integer timeoutSeconds,
    @NotNull @Positive Integer maxRetries,
    @NotNull @DecimalMin("0.01") BigDecimal maxTransactionAmount,
    @NotNull @Valid FraudDetectionProperties fraudDetection) {
    public record FraudDetectionProperties(
        @NotNull boolean enabled,
        @NotNull @DecimalMin("0.0") @DecimalMax("1.0") Double riskThreshold,
        @NotNull @Positive Integer dailyTransactionLimit) {}
}
