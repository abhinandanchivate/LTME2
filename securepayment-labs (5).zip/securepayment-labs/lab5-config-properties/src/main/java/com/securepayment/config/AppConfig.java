package com.securepayment.config;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
@Configuration @EnableConfigurationProperties(PaymentProperties.class)
public class AppConfig {}
