package com.securepayment;
import com.securepayment.config.PaymentProperties;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
@SpringBootTest @AutoConfigureMockMvc
class ConfigPropertiesTest {
    @Autowired MockMvc mockMvc;
    @Autowired PaymentProperties props;

    @Test void propertiesLoaded() {
        assertThat(props.gatewayUrl()).isNotBlank();
        assertThat(props.timeoutSeconds()).isPositive();
        assertThat(props.fraudDetection()).isNotNull();
    }

    @Test void configEndpoint_returnsProperties() throws Exception {
        mockMvc.perform(get("/api/config"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.gatewayUrl").isString())
            .andExpect(jsonPath("$.timeoutSeconds").isNumber())
            .andExpect(jsonPath("$.fraudDetectionEnabled").isBoolean());
    }
}
