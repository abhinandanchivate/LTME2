package com.securepayment.dto;

public record RegistrationResponse(String message, String username) {}
