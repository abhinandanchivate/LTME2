package com.securepayment.controller;

import com.securepayment.dto.AccountRegistrationRequest;
import com.securepayment.dto.RegistrationResponse;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {

    @PostMapping("/register")
    public ResponseEntity<RegistrationResponse> register(
            @Valid @RequestBody AccountRegistrationRequest request) {
        return ResponseEntity.ok(
            new RegistrationResponse("Account registered successfully", request.username())
        );
    }
}
