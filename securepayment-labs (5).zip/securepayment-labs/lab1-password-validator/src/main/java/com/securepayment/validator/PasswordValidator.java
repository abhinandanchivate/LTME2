package com.securepayment.validator;

import com.securepayment.annotation.ValidPassword;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import org.springframework.stereotype.Component;
import java.util.regex.Pattern;

@Component
public class PasswordValidator implements ConstraintValidator<ValidPassword, String> {

    private static final Pattern UPPERCASE    = Pattern.compile("[A-Z]");
    private static final Pattern LOWERCASE    = Pattern.compile("[a-z]");
    private static final Pattern DIGIT        = Pattern.compile("[0-9]");
    private static final Pattern SPECIAL_CHAR = Pattern.compile("[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?]");

    private int minLength;
    private boolean requireSpecialChar;

    @Override
    public void initialize(ValidPassword annotation) {
        this.minLength = annotation.minLength();
        this.requireSpecialChar = annotation.requireSpecialChar();
    }

    @Override
    public boolean isValid(String password, ConstraintValidatorContext context) {
        // Null/blank is handled by @NotBlank separately
        if (password == null || password.isBlank()) {
            return true;
        }

        boolean valid = true;
        context.disableDefaultConstraintViolation();

        if (password.length() < minLength) {
            context.buildConstraintViolationWithTemplate(
                "Password must be at least " + minLength + " characters long"
            ).addConstraintViolation();
            valid = false;
        }
        if (!UPPERCASE.matcher(password).find()) {
            context.buildConstraintViolationWithTemplate(
                "Password must contain at least one uppercase letter"
            ).addConstraintViolation();
            valid = false;
        }
        if (!LOWERCASE.matcher(password).find()) {
            context.buildConstraintViolationWithTemplate(
                "Password must contain at least one lowercase letter"
            ).addConstraintViolation();
            valid = false;
        }
        if (!DIGIT.matcher(password).find()) {
            context.buildConstraintViolationWithTemplate(
                "Password must contain at least one digit"
            ).addConstraintViolation();
            valid = false;
        }
        if (requireSpecialChar && !SPECIAL_CHAR.matcher(password).find()) {
            context.buildConstraintViolationWithTemplate(
                "Password must contain at least one special character"
            ).addConstraintViolation();
            valid = false;
        }
        return valid;
    }
}
