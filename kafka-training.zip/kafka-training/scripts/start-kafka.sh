#!/bin/bash
# ============================================================
# Start Kafka Training Environment - macOS/Linux
# Starts: Zookeeper, 3 Kafka Brokers, Schema Registry, Kafka UI
# ============================================================

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DOCKER_DIR="$(dirname "$SCRIPT_DIR")/docker"

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Starting Kafka Training Cluster...${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""

# Navigate to docker directory
cd "$DOCKER_DIR"

# Detect docker-compose command (v1 vs v2)
if command -v docker-compose &> /dev/null; then
    COMPOSE_CMD="docker-compose"
elif docker compose version &> /dev/null 2>&1; then
    COMPOSE_CMD="docker compose"
else
    echo -e "${RED}docker-compose not found!${NC}"
    exit 1
fi

echo -e "  ${CYAN}→ Using: $COMPOSE_CMD${NC}"
echo -e "  ${CYAN}→ Docker directory: $DOCKER_DIR${NC}"
echo ""

# Pull images first (shows progress)
echo "Pulling Docker images (first run may take a few minutes)..."
$COMPOSE_CMD pull --quiet 2>/dev/null || true
echo ""

# Start all services
echo "Starting services..."
$COMPOSE_CMD up -d

echo ""
echo "Waiting for cluster to be healthy..."

# Wait for Kafka to be ready with progress indicator
MAX_WAIT=90
WAIT=0
echo -n "  Checking broker health"

while [ $WAIT -lt $MAX_WAIT ]; do
    if docker exec kafka-broker-1 kafka-topics \
        --bootstrap-server localhost:9092 \
        --list &> /dev/null 2>&1; then
        echo ""
        break
    fi
    echo -n "."
    sleep 3
    WAIT=$((WAIT + 3))
done

if [ $WAIT -ge $MAX_WAIT ]; then
    echo ""
    echo -e "${YELLOW}  ⚠ Timeout waiting for Kafka. Check: docker logs kafka-broker-1${NC}"
else
    echo -e "  ${GREEN}✓ Kafka broker is ready!${NC}"
fi

# Check Schema Registry
echo -n "  Checking Schema Registry"
SR_WAIT=0
while [ $SR_WAIT -lt 60 ]; do
    if curl -s http://localhost:8081/subjects &> /dev/null; then
        echo ""
        echo -e "  ${GREEN}✓ Schema Registry is ready!${NC}"
        break
    fi
    echo -n "."
    sleep 2
    SR_WAIT=$((SR_WAIT + 2))
done

# Show running containers
echo ""
echo "Running containers:"
docker ps --format "  {{.Names}}\t{{.Status}}\t{{.Ports}}" | \
    grep -E "kafka|zookeeper|schema" | \
    awk '{printf "  %-25s %-20s %s\n", $1, $2, $3}'

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Cluster Ready!${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""
echo -e "  ${GREEN}Kafka Brokers:${NC}"
echo -e "    Broker 1:        localhost:9092"
echo -e "    Broker 2:        localhost:9093"
echo -e "    Broker 3:        localhost:9094"
echo ""
echo -e "  ${GREEN}Web Interfaces:${NC}"
echo -e "    Kafka UI:        ${CYAN}http://localhost:8080${NC}"
echo -e "    Schema Registry: ${CYAN}http://localhost:8081${NC}"
echo ""
echo -e "  ${YELLOW}Next: Run ./scripts/create-topics.sh${NC}"
echo ""