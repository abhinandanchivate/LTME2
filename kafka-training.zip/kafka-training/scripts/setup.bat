@echo off
REM ============================================================
REM Kafka Training Environment Setup Script
REM Windows 11 + Java 17 + Docker Desktop
REM ============================================================
echo ============================================================
echo  Kafka Training - Environment Setup
echo ============================================================

echo.
echo [1] Checking Java 17...
java -version 2>&1 | findstr "17"
if %errorlevel% neq 0 (
    echo ERROR: Java 17 not found. Please install Java 17.
    pause
    exit /b 1
)
echo Java 17 OK

echo.
echo [2] Checking Docker...
docker --version
if %errorlevel% neq 0 (
    echo ERROR: Docker not found. Please install Docker Desktop.
    pause
    exit /b 1
)
echo Docker OK

echo.
echo [3] Checking Maven...
mvn --version
if %errorlevel% neq 0 (
    echo ERROR: Maven not found. Please install Maven.
    pause
    exit /b 1
)
echo Maven OK

echo.
echo [4] Building project...
cd ..
mvn clean package -DskipTests
if %errorlevel% neq 0 (
    echo ERROR: Maven build failed.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Setup Complete! Run start-kafka.bat to start the cluster.
echo ============================================================
pause