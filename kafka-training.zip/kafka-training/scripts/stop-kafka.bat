@echo off
REM ============================================================
REM Stop Kafka Training Environment
REM ============================================================
echo ============================================================
echo  Stopping Kafka Training Cluster...
echo ============================================================
cd ..\docker
docker-compose down
echo.
echo ============================================================
echo  Kafka cluster stopped.
echo  Data volumes preserved (use 'docker-compose down -v' to clear)
echo ============================================================
pause