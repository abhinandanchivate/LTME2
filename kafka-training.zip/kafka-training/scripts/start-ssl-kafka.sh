#!/bin/bash
# ============================================================
# Start SSL Kafka Environment - macOS/Linux
# Used for Day 2 - Module 2: Security
# ============================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
NC='\033[0m'

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DOCKER_DIR="$(dirname "$SCRIPT_DIR")/docker"
SSL_DIR="$DOCKER_DIR/ssl"

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Starting SSL Kafka Environment${NC}"
echo -e "${BLUE}  Day 2 - Module 2: Kafka Security${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""

# ── Check certificates exist ───────────────────────────────────
echo "Checking SSL certificates..."

MISSING=false
for CERT_FILE in \
    "kafka.server.keystore.jks" \
    "kafka.server.truststore.jks" \
    "kafka.client.keystore.jks" \
    "kafka.client.truststore.jks"; do

    CERT_PATH="$SSL_DIR/$CERT_FILE"
    if [ ! -f "$CERT_PATH" ] || [ ! -s "$CERT_PATH" ]; then
        echo -e "  ${RED}✗ Missing: $CERT_FILE${NC}"
        MISSING=true
    else
        echo -e "  ${GREEN}✓ Found: $CERT_FILE ($(wc -c < "$CERT_PATH") bytes)${NC}"
    fi
done

if [ "$MISSING" = true ]; then
    echo ""
    echo -e "${YELLOW}SSL certificates missing!${NC}"
    echo -e "Generating certificates now..."
    echo ""
    chmod +x "$SSL_DIR/generate-certs.sh"
    "$SSL_DIR/generate-certs.sh"
fi

# ── Start SSL Docker Compose ───────────────────────────────────
echo ""
echo "Starting SSL Kafka broker..."

cd "$DOCKER_DIR"

if command -v docker-compose &> /dev/null; then
    COMPOSE_CMD="docker-compose"
else
    COMPOSE_CMD="docker compose"
fi

$COMPOSE_CMD -f docker-compose-ssl.yml up -d

echo ""
echo "Waiting for SSL broker to be ready..."
sleep 10

# ── Verify SSL connection ──────────────────────────────────────
echo ""
echo "Verifying SSL broker..."
MAX_WAIT=60
WAIT=0
while [ $WAIT -lt $MAX_WAIT ]; do
    if docker exec kafka-ssl kafka-topics \
        --bootstrap-server localhost:9095 \
        --list &> /dev/null 2>&1; then
        echo -e "  ${GREEN}✓ SSL Kafka broker is ready!${NC}"
        break
    fi
    echo -n "."
    sleep 3
    WAIT=$((WAIT + 3))
done

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  SSL Kafka Ready!${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo "  PLAINTEXT (admin):  localhost:9095"
echo "  SSL (client-facing): localhost:9096"
echo ""
echo -e "  ${CYAN}→ Run SSL Producer:${NC}"
echo "    mvn exec:java -Dexec.mainClass=\"com.kafka.training.Day2Module2_Security.SSLProducerDemo\""
echo ""
echo -e "  ${CYAN}→ Run SSL Consumer:${NC}"
echo "    mvn exec:java -Dexec.mainClass=\"com.kafka.training.Day2Module2_Security.SSLConsumerDemo\""
echo ""