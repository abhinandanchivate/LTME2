#!/bin/bash
# ============================================================
# Consumer Group Status & Lag Monitor - macOS/Linux
# ============================================================

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

BOOTSTRAP="localhost:9092"

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Consumer Group Status and Lag Monitor${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""

echo -e "${CYAN}[1] All Consumer Groups:${NC}"
echo "─────────────────────────────────────────────────────────"
docker exec kafka-broker-1 kafka-consumer-groups \
    --bootstrap-server $BOOTSTRAP \
    --list

echo ""
echo -e "${CYAN}[2] Fraud Detection Service Lag:${NC}"
echo "─────────────────────────────────────────────────────────"
docker exec kafka-broker-1 kafka-consumer-groups \
    --bootstrap-server $BOOTSTRAP \
    --describe \
    --group fraud-detection-service-group 2>/dev/null || \
    echo -e "${YELLOW}  Group not found (FraudService not started yet)${NC}"

echo ""
echo -e "${CYAN}[3] Settlement Service Lag:${NC}"
echo "─────────────────────────────────────────────────────────"
docker exec kafka-broker-1 kafka-consumer-groups \
    --bootstrap-server $BOOTSTRAP \
    --describe \
    --group settlement-service-group 2>/dev/null || \
    echo -e "${YELLOW}  Group not found (SettlementService not started yet)${NC}"

echo ""
echo -e "${CYAN}[4] Topic Partition Details - payment-created:${NC}"
echo "─────────────────────────────────────────────────────────"
docker exec kafka-broker-1 kafka-topics \
    --bootstrap-server $BOOTSTRAP \
    --describe \
    --topic payment-created

echo ""
echo -e "${CYAN}[5] Topic Partition Details - fraud-result:${NC}"
echo "─────────────────────────────────────────────────────────"
docker exec kafka-broker-1 kafka-topics \
    --bootstrap-server $BOOTSTRAP \
    --describe \
    --topic fraud-result

echo ""
echo -e "${CYAN}[6] Cluster Overview:${NC}"
echo "─────────────────────────────────────────────────────────"
docker exec kafka-broker-1 kafka-broker-api-versions \
    --bootstrap-server $BOOTSTRAP 2>/dev/null | \
    head -5 || echo -e "${YELLOW}  Cluster info unavailable${NC}"

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  LAG EXPLANATION:${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo "  LOG-END-OFFSET  = Latest message offset in topic"
echo "  CURRENT-OFFSET  = Last offset committed by consumer"
echo "  LAG             = LOG-END-OFFSET - CURRENT-OFFSET"
echo ""
echo "  LAG = 0  → Consumer is fully caught up ✓"
echo "  LAG > 0  → Consumer is behind (backlog exists)"
echo "  LAG growing → Consumer too slow → scale up!"
echo ""
echo -e "  ${CYAN}→ View real-time in Kafka UI: http://localhost:8080${NC}"
echo ""