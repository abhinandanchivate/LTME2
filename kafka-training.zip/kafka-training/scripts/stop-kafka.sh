#!/bin/bash
# ============================================================
# Stop Kafka Training Environment - macOS/Linux
# ============================================================

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DOCKER_DIR="$(dirname "$SCRIPT_DIR")/docker"

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Stopping Kafka Training Cluster...${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""

cd "$DOCKER_DIR"

# Detect compose command
if command -v docker-compose &> /dev/null; then
    COMPOSE_CMD="docker-compose"
else
    COMPOSE_CMD="docker compose"
fi

echo "Stopping all services..."
$COMPOSE_CMD down

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  Cluster stopped.${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo -e "  ${YELLOW}Data volumes preserved.${NC}"
echo -e "  To also remove volumes (clean slate):"
echo -e "    cd docker && $COMPOSE_CMD down -v"
echo ""