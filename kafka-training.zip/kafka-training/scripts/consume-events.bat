@echo off
REM ============================================================
REM CLI Consumer Demo Script
REM Used for: Day 1 Module 3 - CLI demonstration
REM ============================================================
echo ============================================================
echo  Kafka CLI Consumer Demo
echo  Topic: payment-created
echo  Consumer Group: cli-demo-group
echo  Reading from: BEGINNING
echo ============================================================
echo.
docker exec kafka-broker-1 kafka-console-consumer ^
  --bootstrap-server localhost:9092 ^
  --topic payment-created ^
  --group cli-demo-group ^
  --from-beginning ^
  --property "print.key=true" ^
  --property "print.timestamp=true" ^
  --property "key.separator= | " ^
  --max-messages 20