@echo off
REM ============================================================
REM Start Kafka Training Environment
REM ============================================================
echo ============================================================
echo  Starting Kafka Training Cluster...
echo ============================================================
cd ..\docker
docker-compose up -d

echo.
echo Waiting for cluster to be ready (30 seconds)...
timeout /t 30 /nobreak

echo.
echo ============================================================
echo  Kafka UI available at: http://localhost:8080
echo  Schema Registry at:    http://localhost:8081
echo  Brokers:
echo    Broker 1: localhost:9092
echo    Broker 2: localhost:9093
echo    Broker 3: localhost:9094
echo ============================================================
pause