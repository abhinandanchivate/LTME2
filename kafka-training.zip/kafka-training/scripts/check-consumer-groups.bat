@echo off
REM ============================================================
REM Consumer Group Status Check
REM Shows lag for all consumer groups
REM ============================================================
echo ============================================================
echo  Consumer Group Status and Lag
echo ============================================================
echo.
echo [1] List all consumer groups:
docker exec kafka-broker-1 kafka-consumer-groups ^
  --bootstrap-server localhost:9092 ^
  --list

echo.
echo [2] Describe fraud-detection-service-group lag:
docker exec kafka-broker-1 kafka-consumer-groups ^
  --bootstrap-server localhost:9092 ^
  --describe ^
  --group fraud-detection-service-group

echo.
echo [3] Describe settlement-service-group lag:
docker exec kafka-broker-1 kafka-consumer-groups ^
  --bootstrap-server localhost:9092 ^
  --describe ^
  --group settlement-service-group

echo.
echo [4] Topic partition details:
docker exec kafka-broker-1 kafka-topics ^
  --bootstrap-server localhost:9092 ^
  --describe ^
  --topic payment-created
pause