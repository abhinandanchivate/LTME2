@echo off
REM ============================================================
REM Create All Training Topics
REM ============================================================
echo ============================================================
echo  Creating Kafka Training Topics...
echo ============================================================

echo Creating payment-created topic (3 partitions, RF=3)...
docker exec kafka-broker-1 kafka-topics ^
  --bootstrap-server localhost:9092 ^
  --create ^
  --topic payment-created ^
  --partitions 3 ^
  --replication-factor 3 ^
  --config retention.ms=604800000

echo Creating payment-settled topic...
docker exec kafka-broker-1 kafka-topics ^
  --bootstrap-server localhost:9092 ^
  --create ^
  --topic payment-settled ^
  --partitions 3 ^
  --replication-factor 3

echo Creating payment-fraud-check topic...
docker exec kafka-broker-1 kafka-topics ^
  --bootstrap-server localhost:9092 ^
  --create ^
  --topic payment-fraud-check ^
  --partitions 3 ^
  --replication-factor 3

echo Creating fraud-result topic...
docker exec kafka-broker-1 kafka-topics ^
  --bootstrap-server localhost:9092 ^
  --create ^
  --topic fraud-result ^
  --partitions 3 ^
  --replication-factor 3

echo Creating payment-dlq topic (Dead Letter Queue)...
docker exec kafka-broker-1 kafka-topics ^
  --bootstrap-server localhost:9092 ^
  --create ^
  --topic payment-dlq ^
  --partitions 1 ^
  --replication-factor 3

echo.
echo Listing all topics:
docker exec kafka-broker-1 kafka-topics ^
  --bootstrap-server localhost:9092 ^
  --list

echo.
echo Describing payment-created topic:
docker exec kafka-broker-1 kafka-topics ^
  --bootstrap-server localhost:9092 ^
  --describe ^
  --topic payment-created

echo ============================================================
echo  Topics Created Successfully!
echo ============================================================
pause