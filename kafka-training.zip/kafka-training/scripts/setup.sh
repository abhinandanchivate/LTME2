#!/bin/bash
# ============================================================
# Kafka Training Environment Setup Script
# macOS / Linux
# Requirements: Java 17, Maven 3.8+, Docker Desktop for Mac
# ============================================================

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

print_header() {
    echo ""
    echo -e "${BLUE}============================================================${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}============================================================${NC}"
}

print_ok() {
    echo -e "  ${GREEN}✓ $1${NC}"
}

print_warn() {
    echo -e "  ${YELLOW}⚠ $1${NC}"
}

print_error() {
    echo -e "  ${RED}✗ $1${NC}"
}

print_info() {
    echo -e "  ${CYAN}→ $1${NC}"
}

print_header "Kafka Training - Environment Setup (macOS)"

# ── Check Java 17 ─────────────────────────────────────────────
echo ""
echo "[1] Checking Java 17..."
if ! command -v java &> /dev/null; then
    print_error "Java not found!"
    print_info "Install via Homebrew: brew install openjdk@17"
    print_info "Or download from: https://adoptium.net"
    exit 1
fi

JAVA_VERSION=$(java -version 2>&1 | awk -F '"' '/version/ {print $2}' | cut -d'.' -f1)
if [ "$JAVA_VERSION" -lt "17" ]; then
    print_error "Java 17+ required. Found: $(java -version 2>&1 | head -1)"
    print_info "Install: brew install openjdk@17"
    print_info "Then: export JAVA_HOME=\$(brew --prefix openjdk@17)"
    exit 1
fi
print_ok "Java $(java -version 2>&1 | awk -F '"' '/version/ {print $2}') found"

# ── Check Docker ───────────────────────────────────────────────
echo ""
echo "[2] Checking Docker..."
if ! command -v docker &> /dev/null; then
    print_error "Docker not found!"
    print_info "Install Docker Desktop for Mac from: https://www.docker.com/products/docker-desktop"
    exit 1
fi

if ! docker info &> /dev/null; then
    print_error "Docker daemon not running!"
    print_info "Start Docker Desktop from Applications folder"
    exit 1
fi
print_ok "Docker $(docker --version | awk '{print $3}' | tr -d ',') running"

# ── Check Docker Compose ───────────────────────────────────────
echo ""
echo "[3] Checking Docker Compose..."
if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    print_error "Docker Compose not found!"
    print_info "Included with Docker Desktop - ensure it's updated"
    exit 1
fi
print_ok "Docker Compose found"

# ── Check Maven ────────────────────────────────────────────────
echo ""
echo "[4] Checking Maven..."
if ! command -v mvn &> /dev/null; then
    print_warn "Maven not found in PATH"
    print_info "Install via Homebrew: brew install maven"
    print_info "Or download from: https://maven.apache.org/download.cgi"

    # Check if Maven is installed but not in PATH
    if [ -f "/usr/local/bin/mvn" ] || [ -f "/opt/homebrew/bin/mvn" ]; then
        print_info "Maven may be installed but not in PATH"
        print_info "Add to ~/.zshrc: export PATH=\$PATH:/opt/homebrew/bin"
    fi
    exit 1
fi
print_ok "Maven $(mvn --version | head -1 | awk '{print $3}') found"

# ── Check keytool (for SSL certs) ─────────────────────────────
echo ""
echo "[5] Checking keytool (for SSL certificates)..."
if ! command -v keytool &> /dev/null; then
    print_warn "keytool not found in PATH"
    print_info "keytool comes with Java JDK"
    print_info "Add JAVA_HOME/bin to PATH:"
    print_info "  export PATH=\$JAVA_HOME/bin:\$PATH"
else
    print_ok "keytool found (bundled with Java)"
fi

# ── Check available ports ──────────────────────────────────────
echo ""
echo "[6] Checking required ports..."
PORTS=(2181 9092 9093 9094 8080 8081)
ALL_CLEAR=true

for PORT in "${PORTS[@]}"; do
    if lsof -i ":$PORT" &> /dev/null 2>&1; then
        print_warn "Port $PORT is in use! Check: lsof -i :$PORT"
        ALL_CLEAR=false
    else
        print_ok "Port $PORT available"
    fi
done

if [ "$ALL_CLEAR" = false ]; then
    print_warn "Some ports are in use. Stop conflicting services before starting Kafka."
fi

# ── Build Project ──────────────────────────────────────────────
echo ""
echo "[7] Building Maven project..."
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"
print_info "Building from: $PROJECT_DIR"

mvn clean package -DskipTests -q
if [ $? -ne 0 ]; then
    print_error "Maven build failed!"
    echo "Run manually: cd $PROJECT_DIR && mvn clean package -DskipTests"
    exit 1
fi
print_ok "Project built successfully"

# ── Make scripts executable ────────────────────────────────────
echo ""
echo "[8] Setting script permissions..."
chmod +x "$SCRIPT_DIR"/*.sh
print_ok "Scripts are now executable"

# ── Done ───────────────────────────────────────────────────────
echo ""
print_header "Setup Complete!"
echo ""
echo -e "  ${GREEN}Next steps:${NC}"
print_info "Start Kafka cluster:    ./scripts/start-kafka.sh"
print_info "Create topics:          ./scripts/create-topics.sh"
print_info "Open Kafka UI:          http://localhost:8080"
print_info "Open Schema Registry:   http://localhost:8081"
echo ""