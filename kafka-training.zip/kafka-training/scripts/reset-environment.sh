#!/bin/bash
# ============================================================
# Reset Training Environment - macOS/Linux
# Stops everything, removes volumes, starts fresh
# Use this between training sessions
# ============================================================

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DOCKER_DIR="$(dirname "$SCRIPT_DIR")/docker"

echo ""
echo -e "${RED}============================================================${NC}"
echo -e "${RED}  RESET: This will DELETE all Kafka data and volumes!${NC}"
echo -e "${RED}============================================================${NC}"
echo ""
echo -n -e "${YELLOW}Are you sure? (yes/no): ${NC}"
read -r CONFIRM

if [ "$CONFIRM" != "yes" ]; then
    echo "Reset cancelled."
    exit 0
fi

cd "$DOCKER_DIR"

if command -v docker-compose &> /dev/null; then
    COMPOSE_CMD="docker-compose"
else
    COMPOSE_CMD="docker compose"
fi

echo ""
echo "Stopping all Kafka containers..."
$COMPOSE_CMD down -v --remove-orphans 2>/dev/null || true
$COMPOSE_CMD -f docker-compose-ssl.yml down -v --remove-orphans 2>/dev/null || true
$COMPOSE_CMD -f docker-compose-schema.yml down -v --remove-orphans 2>/dev/null || true

echo "Removing unused Docker volumes..."
docker volume prune -f 2>/dev/null || true

echo ""
echo -e "${GREEN}Environment reset complete!${NC}"
echo ""
echo "Starting fresh cluster..."
"$SCRIPT_DIR/start-kafka.sh"
sleep 5
"$SCRIPT_DIR/create-topics.sh"
echo ""
echo -e "${GREEN}Fresh environment ready!${NC}"