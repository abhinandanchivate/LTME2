#!/bin/bash
# ============================================================
# CLI Producer Demo - macOS/Linux
# Used for: Day 1 Module 3 - CLI demonstration
# ============================================================

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Kafka CLI Producer Demo${NC}"
echo -e "${BLUE}  Topic: payment-created${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""
echo -e "${YELLOW}Format: key:value  (key=paymentId)${NC}"
echo ""
echo -e "${CYAN}Example messages to type:${NC}"
echo '  PAY-CLI-001:{"paymentId":"PAY-CLI-001","customerId":"CUST-1","amount":500.00}'
echo '  PAY-CLI-002:{"paymentId":"PAY-CLI-002","customerId":"CUST-2","amount":1200.00}'
echo '  PAY-CLI-003:{"paymentId":"PAY-CLI-003","customerId":"CUST-1","amount":250.00}'
echo ""
echo -e "${YELLOW}Press Ctrl+C to stop${NC}"
echo ""

docker exec -it kafka-broker-1 kafka-console-producer \
    --bootstrap-server localhost:9092 \
    --topic payment-created \
    --property "parse.key=true" \
    --property "key.separator=:"