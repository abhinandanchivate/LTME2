@echo off
REM ============================================================
REM CLI Producer Demo Script
REM Used for: Day 1 Module 3 - CLI demonstration
REM ============================================================
echo ============================================================
echo  Kafka CLI Producer Demo
echo  Topic: payment-created
echo  Type messages and press Enter (Ctrl+C to stop)
echo ============================================================
echo.
echo Example messages to type:
echo   {"paymentId":"PAY-CLI-001","amount":500}
echo   {"paymentId":"PAY-CLI-002","amount":1200}
echo.
docker exec -it kafka-broker-1 kafka-console-producer ^
  --bootstrap-server localhost:9092 ^
  --topic payment-created ^
  --property "parse.key=true" ^
  --property "key.separator=:"