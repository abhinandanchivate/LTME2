#!/bin/bash
# ============================================================
# CLI Consumer Demo - macOS/Linux
# Used for: Day 1 Module 3 - CLI demonstration
# ============================================================

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

TOPIC="${1:-payment-created}"
GROUP="${2:-cli-demo-group}"
MAX_MSGS="${3:-20}"

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Kafka CLI Consumer Demo${NC}"
echo -e "${BLUE}  Topic:          $TOPIC${NC}"
echo -e "${BLUE}  Consumer Group: $GROUP${NC}"
echo -e "${BLUE}  Max Messages:   $MAX_MSGS${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""
echo -e "${CYAN}Reading from BEGINNING...${NC}"
echo ""

docker exec kafka-broker-1 kafka-console-consumer \
    --bootstrap-server localhost:9092 \
    --topic "$TOPIC" \
    --group "$GROUP" \
    --from-beginning \
    --property "print.key=true" \
    --property "print.timestamp=true" \
    --property "print.partition=true" \
    --property "print.offset=true" \
    --property "key.separator= | " \
    --max-messages "$MAX_MSGS"

echo ""
echo -e "${GREEN}Done consuming $MAX_MSGS messages.${NC}"
echo ""