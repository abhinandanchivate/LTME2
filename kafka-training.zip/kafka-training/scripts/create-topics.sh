#!/bin/bash
# ============================================================
# Create All Kafka Training Topics - macOS/Linux
# ============================================================

set -e

GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

BROKER="kafka-broker-1"
BOOTSTRAP="localhost:9092"

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Creating Kafka Training Topics${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""

# ── Helper function ────────────────────────────────────────────
create_topic() {
    local TOPIC=$1
    local PARTITIONS=$2
    local RF=$3
    local EXTRA_CONFIG=$4

    echo -n "  Creating '$TOPIC' (partitions=$PARTITIONS, RF=$RF)..."

    # Check if topic already exists
    EXISTING=$(docker exec $BROKER kafka-topics \
        --bootstrap-server $BOOTSTRAP \
        --list 2>/dev/null | grep -w "^$TOPIC$" || true)

    if [ -n "$EXISTING" ]; then
        echo -e " ${YELLOW}already exists (skipped)${NC}"
        return
    fi

    # Build the create command
    CMD="docker exec $BROKER kafka-topics \
        --bootstrap-server $BOOTSTRAP \
        --create \
        --topic $TOPIC \
        --partitions $PARTITIONS \
        --replication-factor $RF"

    if [ -n "$EXTRA_CONFIG" ]; then
        CMD="$CMD --config $EXTRA_CONFIG"
    fi

    if eval $CMD &> /dev/null; then
        echo -e " ${GREEN}✓ created${NC}"
    else
        echo -e " ${RED}✗ FAILED${NC}"
        return 1
    fi
}

# ── Wait for broker to be ready ────────────────────────────────
echo "Checking broker connectivity..."
MAX_WAIT=30
WAIT=0
while [ $WAIT -lt $MAX_WAIT ]; do
    if docker exec $BROKER kafka-topics \
        --bootstrap-server $BOOTSTRAP \
        --list &> /dev/null 2>&1; then
        echo -e "  ${GREEN}✓ Broker is ready${NC}"
        break
    fi
    echo -n "."
    sleep 2
    WAIT=$((WAIT + 2))
done

if [ $WAIT -ge $MAX_WAIT ]; then
    echo -e "${RED}Broker not responding. Run: ./scripts/start-kafka.sh first${NC}"
    exit 1
fi

echo ""
echo "Creating payment processing topics..."
echo ""

# ── Create Topics ──────────────────────────────────────────────

# Core payment event topics
create_topic "payment-created"      3  3  "retention.ms=604800000"
create_topic "payment-settled"      3  3  "retention.ms=604800000"
create_topic "payment-fraud-check"  3  3  "retention.ms=86400000"
create_topic "fraud-result"         3  3  "retention.ms=86400000"

# Pipeline topics
create_topic "payment-commands"     3  3  "retention.ms=3600000"
create_topic "payment-command-replies" 3 3 "retention.ms=3600000"

# Partition demo topic
create_topic "payment-partition-demo" 6 3 "retention.ms=3600000"

# Dead Letter Queue
create_topic "payment-dlq"          1  3  "retention.ms=2592000000"

echo ""
echo "Verifying created topics..."
echo ""

docker exec $BROKER kafka-topics \
    --bootstrap-server $BOOTSTRAP \
    --list | while read TOPIC; do
    echo -e "  ${CYAN}→${NC} $TOPIC"
done

echo ""
echo "Topic details for payment-created:"
echo "─────────────────────────────────────────────────────────"
docker exec $BROKER kafka-topics \
    --bootstrap-server $BOOTSTRAP \
    --describe \
    --topic payment-created

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  All topics created successfully!${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo -e "  ${CYAN}→ View topics in Kafka UI: http://localhost:8080${NC}"
echo ""