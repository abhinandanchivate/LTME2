#!/bin/bash
# ============================================================
# Universal Demo Runner - macOS/Linux
# Interactive menu to run any training demo
# ============================================================

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

run_demo() {
    local CLASS=$1
    local DESCRIPTION=$2
    echo ""
    echo -e "${BLUE}============================================================${NC}"
    echo -e "${BLUE}  Running: $DESCRIPTION${NC}"
    echo -e "${CYAN}  Class: $CLASS${NC}"
    echo -e "${BLUE}============================================================${NC}"
    echo ""
    cd "$PROJECT_DIR"
    mvn exec:java \
        -Dexec.mainClass="$CLASS" \
        -q 2>/dev/null || \
    mvn exec:java \
        -Dexec.mainClass="$CLASS"
}

while true; do
    clear
    echo ""
    echo -e "${BOLD}${BLUE}╔══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}${BLUE}║         KAFKA TRAINING - DEMO RUNNER (macOS)            ║${NC}"
    echo -e "${BOLD}${BLUE}╚══════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "${BOLD}${YELLOW}  DAY 1${NC}"
    echo ""
    echo -e "  ${CYAN}[1]${NC}  Module 1: Why Kafka (KafkaEcosystemDemo)"
    echo -e "  ${CYAN}[2]${NC}  Module 2: Broker Architecture"
    echo -e "  ${CYAN}[3]${NC}  Module 2: Partition & Replication"
    echo -e "  ${CYAN}[4]${NC}  Module 3: Payment Producer"
    echo -e "  ${CYAN}[5]${NC}  Module 3: Payment Consumer"
    echo -e "  ${CYAN}[6]${NC}  Module 3: Consumer Groups"
    echo -e "  ${CYAN}[7]${NC}  Module 3: Offset Management"
    echo -e "  ${CYAN}[8]${NC}  Module 4: Acknowledgements (ACKs)"
    echo -e "  ${CYAN}[9]${NC}  Module 4: Idempotent Producer"
    echo -e "  ${CYAN}[10]${NC} Module 4: Key-Based Partitioning"
    echo ""
    echo -e "${BOLD}${YELLOW}  DAY 2${NC}"
    echo ""
    echo -e "  ${CYAN}[11]${NC} Module 1: Schema Registry"
    echo -e "  ${CYAN}[12]${NC} Module 1: Avro Producer"
    echo -e "  ${CYAN}[13]${NC} Module 1: Avro Consumer"
    echo -e "  ${CYAN}[14]${NC} Module 2: SSL Producer"
    echo -e "  ${CYAN}[15]${NC} Module 2: SSL Consumer"
    echo -e "  ${CYAN}[16]${NC} Module 3: Commands vs Events"
    echo -e "  ${CYAN}[17]${NC} Module 3: Payment Events (Pub-Sub)"
    echo -e "  ${CYAN}[18]${NC} Module 3: Saga Pattern"
    echo -e "  ${CYAN}[19]${NC} Module 4: FULL PIPELINE (All Services)"
    echo ""
    echo -e "${BOLD}${YELLOW}  UTILITIES${NC}"
    echo ""
    echo -e "  ${CYAN}[s]${NC}  Start Kafka cluster"
    echo -e "  ${CYAN}[t]${NC}  Create topics"
    echo -e "  ${CYAN}[c]${NC}  Check consumer group lag"
    echo -e "  ${CYAN}[p]${NC}  CLI Producer"
    echo -e "  ${CYAN}[C]${NC}  CLI Consumer"
    echo -e "  ${CYAN}[q]${NC}  Quit"
    echo ""
    echo -n -e "${BOLD}  Select demo [1-19, s, t, c, p, C, q]: ${NC}"
    read -r CHOICE

    case $CHOICE in
        1)  run_demo "com.kafka.training.Day1Module1_WhyKafka.KafkaEcosystemDemo" \
                     "Day 1 - Module 1: Why Kafka" ;;
        2)  run_demo "com.kafka.training.Day1Module2_Architecture.BrokerArchitectureDemo" \
                     "Day 1 - Module 2: Broker Architecture" ;;
        3)  run_demo "com.kafka.training.Day1Module2_Architecture.PartitionReplicationDemo" \
                     "Day 1 - Module 2: Partition & Replication" ;;
        4)  run_demo "com.kafka.training.Day1Module3_ProducersConsumers.PaymentProducer" \
                     "Day 1 - Module 3: Payment Producer" ;;
        5)  run_demo "com.kafka.training.Day1Module3_ProducersConsumers.PaymentConsumer" \
                     "Day 1 - Module 3: Payment Consumer" ;;
        6)  run_demo "com.kafka.training.Day1Module3_ProducersConsumers.ConsumerGroupDemo" \
                     "Day 1 - Module 3: Consumer Groups" ;;
        7)  run_demo "com.kafka.training.Day1Module3_ProducersConsumers.OffsetManagementDemo" \
                     "Day 1 - Module 3: Offset Management" ;;
        8)  run_demo "com.kafka.training.Day1Module4_Reliability.AcknowledgementDemo" \
                     "Day 1 - Module 4: Acknowledgements" ;;
        9)  run_demo "com.kafka.training.Day1Module4_Reliability.IdempotentProducerDemo" \
                     "Day 1 - Module 4: Idempotent Producer" ;;
        10) run_demo "com.kafka.training.Day1Module4_Reliability.KeyBasedPartitioningDemo" \
                     "Day 1 - Module 4: Key-Based Partitioning" ;;
        11) run_demo "com.kafka.training.Day2Module1_Schema.SchemaRegistryDemo" \
                     "Day 2 - Module 1: Schema Registry" ;;
        12) run_demo "com.kafka.training.Day2Module1_Schema.AvroProducer" \
                     "Day 2 - Module 1: Avro Producer" ;;
        13) run_demo "com.kafka.training.Day2Module1_Schema.AvroConsumer" \
                     "Day 2 - Module 1: Avro Consumer" ;;
        14) run_demo "com.kafka.training.Day2Module2_Security.SSLProducerDemo" \
                     "Day 2 - Module 2: SSL Producer" ;;
        15) run_demo "com.kafka.training.Day2Module2_Security.SSLConsumerDemo" \
                     "Day 2 - Module 2: SSL Consumer" ;;
        16) run_demo "com.kafka.training.Day2Module3_EDA.PaymentCommandDemo" \
                     "Day 2 - Module 3: Commands vs Events" ;;
        17) run_demo "com.kafka.training.Day2Module3_EDA.PaymentEventDemo" \
                     "Day 2 - Module 3: Payment Events (Pub-Sub)" ;;
        18) run_demo "com.kafka.training.Day2Module3_EDA.SagaPatternDemo" \
                     "Day 2 - Module 3: Saga Pattern" ;;
        19) run_demo "com.kafka.training.Day2Module4_Pipeline.PipelineOrchestrator" \
                     "Day 2 - Module 4: FULL PIPELINE" ;;
        s)  "$SCRIPT_DIR/start-kafka.sh" ;;
        t)  "$SCRIPT_DIR/create-topics.sh" ;;
        c)  "$SCRIPT_DIR/check-consumer-groups.sh" ;;
        p)  "$SCRIPT_DIR/produce-events.sh" ;;
        C)  "$SCRIPT_DIR/consume-events.sh" ;;
        q)  echo ""; echo -e "${GREEN}Goodbye!${NC}"; echo ""; exit 0 ;;
        *)  echo -e "${RED}Invalid choice. Press Enter to continue.${NC}"; read ;;
    esac

    echo ""
    echo -n -e "${YELLOW}Press Enter to return to menu...${NC}"
    read
done