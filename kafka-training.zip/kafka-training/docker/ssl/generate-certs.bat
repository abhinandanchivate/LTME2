@echo off
REM ============================================================
REM SSL Certificate Generation for Kafka Training
REM Windows 11 + Java 17
REM
REM WHAT THIS CREATES:
REM   kafka.ca.jks               - Certificate Authority keystore
REM   ca.crt                     - CA public certificate
REM   kafka.server.keystore.jks  - Broker keystore (private key + cert)
REM   kafka.server.truststore.jks- Broker truststore (trusts CA)
REM   kafka.client.keystore.jks  - Client keystore (private key + cert)
REM   kafka.client.truststore.jks- Client truststore (trusts CA)
REM
REM RUN THIS ONCE before starting the SSL demo:
REM   cd docker\ssl
REM   generate-certs.bat
REM ============================================================

setlocal enabledelayedexpansion

echo.
echo ============================================================
echo  Kafka Training - SSL Certificate Generation
echo  Java keytool version:
echo ============================================================
keytool -version
echo.

REM ── Configuration ────────────────────────────────────────────
set CERT_DIR=%~dp0
set VALIDITY=3650
set KEYSTORE_PASS=kafka-training-pass
set KEY_PASS=kafka-training-pass
set CA_PASS=kafka-training-pass
set CA_ALIAS=kafka-training-ca
set SERVER_ALIAS=kafka-server
set CLIENT_ALIAS=kafka-client
set CA_DN=CN=Kafka-Training-CA,OU=Training,O=KafkaTraining,L=Singapore,ST=Singapore,C=SG
set SERVER_DN=CN=kafka-broker-1,OU=Kafka,O=KafkaTraining,L=Singapore,ST=Singapore,C=SG
set CLIENT_DN=CN=kafka-client,OU=Client,O=KafkaTraining,L=Singapore,ST=Singapore,C=SG

REM ── Clean up old files ────────────────────────────────────────
echo [Cleanup] Removing old certificate files...
if exist "%CERT_DIR%*.jks" del /q "%CERT_DIR%*.jks"
if exist "%CERT_DIR%*.crt" del /q "%CERT_DIR%*.crt"
if exist "%CERT_DIR%*.csr" del /q "%CERT_DIR%*.csr"
if exist "%CERT_DIR%*.pem" del /q "%CERT_DIR%*.pem"
echo [Cleanup] Done.
echo.

REM ── STEP 1: Generate CA Key and Self-Signed Certificate ───────
echo [STEP 1/10] Generating Certificate Authority (CA)...
keytool -genkeypair ^
  -alias %CA_ALIAS% ^
  -keyalg RSA ^
  -keysize 4096 ^
  -sigalg SHA256withRSA ^
  -dname "%CA_DN%" ^
  -keypass %CA_PASS% ^
  -keystore "%CERT_DIR%kafka.ca.jks" ^
  -storepass %CA_PASS% ^
  -storetype JKS ^
  -validity %VALIDITY% ^
  -ext bc=ca:true ^
  -ext KeyUsage=digitalSignature,keyCertSign,cRLSign

if %errorlevel% neq 0 (
    echo ERROR: Failed to generate CA. Is Java 17 in PATH?
    pause & exit /b 1
)
echo [STEP 1/10] CA keystore created: kafka.ca.jks
echo.

REM ── STEP 2: Export CA Certificate ────────────────────────────
echo [STEP 2/10] Exporting CA public certificate...
keytool -exportcert ^
  -alias %CA_ALIAS% ^
  -keystore "%CERT_DIR%kafka.ca.jks" ^
  -storepass %CA_PASS% ^
  -rfc ^
  -file "%CERT_DIR%ca.crt"

if %errorlevel% neq 0 (echo ERROR: Step 2 failed & pause & exit /b 1)
echo [STEP 2/10] CA certificate exported: ca.crt
echo.

REM ── STEP 3: Generate Kafka Server (Broker) Key Pair ──────────
echo [STEP 3/10] Generating Kafka broker key pair...
keytool -genkeypair ^
  -alias %SERVER_ALIAS% ^
  -keyalg RSA ^
  -keysize 2048 ^
  -sigalg SHA256withRSA ^
  -dname "%SERVER_DN%" ^
  -keypass %KEY_PASS% ^
  -keystore "%CERT_DIR%kafka.server.keystore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -storetype JKS ^
  -validity %VALIDITY%

if %errorlevel% neq 0 (echo ERROR: Step 3 failed & pause & exit /b 1)
echo [STEP 3/10] Server keystore created: kafka.server.keystore.jks
echo.

REM ── STEP 4: Generate Server Certificate Signing Request ───────
echo [STEP 4/10] Generating server CSR...
keytool -certreq ^
  -alias %SERVER_ALIAS% ^
  -keystore "%CERT_DIR%kafka.server.keystore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -keypass %KEY_PASS% ^
  -file "%CERT_DIR%kafka-server.csr"

if %errorlevel% neq 0 (echo ERROR: Step 4 failed & pause & exit /b 1)
echo [STEP 4/10] Server CSR created: kafka-server.csr
echo.

REM ── STEP 5: Sign Server Certificate with CA ──────────────────
echo [STEP 5/10] Signing server certificate with CA...
keytool -gencert ^
  -alias %CA_ALIAS% ^
  -keystore "%CERT_DIR%kafka.ca.jks" ^
  -storepass %CA_PASS% ^
  -keypass %CA_PASS% ^
  -infile "%CERT_DIR%kafka-server.csr" ^
  -outfile "%CERT_DIR%kafka-server-signed.crt" ^
  -validity %VALIDITY% ^
  -rfc ^
  -ext SAN=DNS:kafka-broker-1,DNS:kafka-broker-2,DNS:kafka-broker-3,DNS:kafka-ssl,DNS:localhost,IP:127.0.0.1 ^
  -ext KeyUsage=digitalSignature,keyEncipherment ^
  -ext ExtendedKeyUsage=serverAuth

if %errorlevel% neq 0 (echo ERROR: Step 5 failed & pause & exit /b 1)
echo [STEP 5/10] Server certificate signed: kafka-server-signed.crt
echo.

REM ── STEP 6: Import CA + Signed Cert into Server Keystore ─────
echo [STEP 6/10] Importing CA certificate into server keystore...
keytool -importcert ^
  -alias %CA_ALIAS% ^
  -keystore "%CERT_DIR%kafka.server.keystore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -file "%CERT_DIR%ca.crt" ^
  -noprompt

if %errorlevel% neq 0 (echo ERROR: Step 6a failed & pause & exit /b 1)

echo Importing signed server certificate into server keystore...
keytool -importcert ^
  -alias %SERVER_ALIAS% ^
  -keystore "%CERT_DIR%kafka.server.keystore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -keypass %KEY_PASS% ^
  -file "%CERT_DIR%kafka-server-signed.crt" ^
  -noprompt

if %errorlevel% neq 0 (echo ERROR: Step 6b failed & pause & exit /b 1)
echo [STEP 6/10] Server keystore complete (CA + signed cert imported)
echo.

REM ── STEP 7: Create Server Truststore ──────────────────────────
echo [STEP 7/10] Creating server truststore (trusts CA)...
keytool -importcert ^
  -alias %CA_ALIAS% ^
  -keystore "%CERT_DIR%kafka.server.truststore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -storetype JKS ^
  -file "%CERT_DIR%ca.crt" ^
  -noprompt

if %errorlevel% neq 0 (echo ERROR: Step 7 failed & pause & exit /b 1)
echo [STEP 7/10] Server truststore created: kafka.server.truststore.jks
echo.

REM ── STEP 8: Generate Client Key Pair ─────────────────────────
echo [STEP 8/10] Generating Kafka client key pair...
keytool -genkeypair ^
  -alias %CLIENT_ALIAS% ^
  -keyalg RSA ^
  -keysize 2048 ^
  -sigalg SHA256withRSA ^
  -dname "%CLIENT_DN%" ^
  -keypass %KEY_PASS% ^
  -keystore "%CERT_DIR%kafka.client.keystore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -storetype JKS ^
  -validity %VALIDITY%

if %errorlevel% neq 0 (echo ERROR: Step 8 failed & pause & exit /b 1)
echo [STEP 8/10] Client keystore created: kafka.client.keystore.jks
echo.

REM ── STEP 9: Sign Client Certificate with CA ──────────────────
echo [STEP 9/10] Generating and signing client certificate...

keytool -certreq ^
  -alias %CLIENT_ALIAS% ^
  -keystore "%CERT_DIR%kafka.client.keystore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -keypass %KEY_PASS% ^
  -file "%CERT_DIR%kafka-client.csr"

keytool -gencert ^
  -alias %CA_ALIAS% ^
  -keystore "%CERT_DIR%kafka.ca.jks" ^
  -storepass %CA_PASS% ^
  -keypass %CA_PASS% ^
  -infile "%CERT_DIR%kafka-client.csr" ^
  -outfile "%CERT_DIR%kafka-client-signed.crt" ^
  -validity %VALIDITY% ^
  -rfc ^
  -ext KeyUsage=digitalSignature ^
  -ext ExtendedKeyUsage=clientAuth

keytool -importcert ^
  -alias %CA_ALIAS% ^
  -keystore "%CERT_DIR%kafka.client.keystore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -file "%CERT_DIR%ca.crt" ^
  -noprompt

keytool -importcert ^
  -alias %CLIENT_ALIAS% ^
  -keystore "%CERT_DIR%kafka.client.keystore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -keypass %KEY_PASS% ^
  -file "%CERT_DIR%kafka-client-signed.crt" ^
  -noprompt

if %errorlevel% neq 0 (echo ERROR: Step 9 failed & pause & exit /b 1)
echo [STEP 9/10] Client keystore complete: kafka.client.keystore.jks
echo.

REM ── STEP 10: Create Client Truststore ─────────────────────────
echo [STEP 10/10] Creating client truststore (trusts CA)...
keytool -importcert ^
  -alias %CA_ALIAS% ^
  -keystore "%CERT_DIR%kafka.client.truststore.jks" ^
  -storepass %KEYSTORE_PASS% ^
  -storetype JKS ^
  -file "%CERT_DIR%ca.crt" ^
  -noprompt

if %errorlevel% neq 0 (echo ERROR: Step 10 failed & pause & exit /b 1)
echo [STEP 10/10] Client truststore created: kafka.client.truststore.jks
echo.

REM ── Verification ─────────────────────────────────────────────
echo ============================================================
echo  VERIFICATION - Listing keystore contents:
echo ============================================================
echo.
echo [Server Keystore Contents]:
keytool -list -keystore "%CERT_DIR%kafka.server.keystore.jks" -storepass %KEYSTORE_PASS% -v 2>nul | findstr "Alias\|Entry type\|Valid"
echo.
echo [Client Keystore Contents]:
keytool -list -keystore "%CERT_DIR%kafka.client.keystore.jks" -storepass %KEYSTORE_PASS% -v 2>nul | findstr "Alias\|Entry type\|Valid"
echo.
echo [Server Truststore Contents]:
keytool -list -keystore "%CERT_DIR%kafka.server.truststore.jks" -storepass %KEYSTORE_PASS% 2>nul | findstr "kafka-training-ca"
echo.
echo [Client Truststore Contents]:
keytool -list -keystore "%CERT_DIR%kafka.client.truststore.jks" -storepass %KEYSTORE_PASS% 2>nul | findstr "kafka-training-ca"
echo.

REM ── File Size Check ───────────────────────────────────────────
echo ============================================================
echo  FILE SIZES (all should be non-zero):
echo ============================================================
for %%f in ("%CERT_DIR%*.jks") do (
    echo   %%~nxf : %%~zf bytes
)
echo.

REM ── Summary ───────────────────────────────────────────────────
echo ============================================================
echo  SSL CERTIFICATE GENERATION COMPLETE!
echo ============================================================
echo.
echo  Files created in: %CERT_DIR%
echo.
echo  BROKER FILES:
echo    kafka.server.keystore.jks    (broker private key + signed cert)
echo    kafka.server.truststore.jks  (trusts our CA for client certs)
echo.
echo  CLIENT FILES:
echo    kafka.client.keystore.jks    (client private key + signed cert)
echo    kafka.client.truststore.jks  (trusts our CA for broker certs)
echo.
echo  CA FILES:
echo    kafka.ca.jks                 (CA keystore - keep private!)
echo    ca.crt                       (CA public cert - share freely)
echo.
echo  PASSWORD FOR ALL FILES: %KEYSTORE_PASS%
echo.
echo  NEXT STEPS:
echo    1. Start SSL Kafka cluster:
echo       docker-compose -f docker\docker-compose-ssl.yml up -d
echo    2. Run SSL demo:
echo       mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module2_Security.SSLProducerDemo"
echo ============================================================
echo.
pause