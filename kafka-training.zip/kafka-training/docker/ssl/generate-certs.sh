#!/bin/bash
# ============================================================
# SSL Certificate Generation for Kafka Training
# macOS / Linux
#
# WHAT THIS CREATES:
#   kafka.ca.jks               - Certificate Authority keystore
#   ca.crt                     - CA public certificate
#   kafka.server.keystore.jks  - Broker keystore
#   kafka.server.truststore.jks- Broker truststore
#   kafka.client.keystore.jks  - Client keystore
#   kafka.client.truststore.jks- Client truststore
#
# USAGE:
#   cd docker/ssl
#   chmod +x generate-certs.sh
#   ./generate-certs.sh
#
# REQUIREMENTS:
#   - Java 17 (keytool bundled with JDK)
#   - keytool must be in PATH
# ============================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

print_step() {
    echo ""
    echo -e "${CYAN}[STEP $1/$2] $3${NC}"
}

print_ok() {
    echo -e "  ${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "  ${RED}✗ $1${NC}"
    exit 1
}

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Kafka Training - SSL Certificate Generation (macOS)${NC}"
echo -e "${BLUE}============================================================${NC}"

# ── Determine script directory ─────────────────────────────────
CERT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo ""
echo -e "  ${CYAN}→ Certificate directory: $CERT_DIR${NC}"

# ── Check keytool ──────────────────────────────────────────────
echo ""
echo "Checking prerequisites..."
if ! command -v keytool &> /dev/null; then
    print_error "keytool not found! Ensure Java 17 JDK is installed and JAVA_HOME/bin is in PATH"
fi
echo -e "  ${GREEN}✓ keytool found: $(which keytool)${NC}"
echo -e "  ${GREEN}✓ keytool version: $(keytool -help 2>&1 | head -1 | tr -d '\n')${NC}"

# ── Configuration ──────────────────────────────────────────────
VALIDITY=3650
KEYSTORE_PASS="kafka-training-pass"
KEY_PASS="kafka-training-pass"
CA_PASS="kafka-training-pass"
CA_ALIAS="kafka-training-ca"
SERVER_ALIAS="kafka-server"
CLIENT_ALIAS="kafka-client"
CA_DN="CN=Kafka-Training-CA,OU=Training,O=KafkaTraining,L=Singapore,ST=Singapore,C=SG"
SERVER_DN="CN=kafka-broker-1,OU=Kafka,O=KafkaTraining,L=Singapore,ST=Singapore,C=SG"
CLIENT_DN="CN=kafka-client,OU=Client,O=KafkaTraining,L=Singapore,ST=Singapore,C=SG"

echo ""
echo "Configuration:"
echo "  Validity:    $VALIDITY days"
echo "  Password:    $KEYSTORE_PASS"
echo "  CA DN:       $CA_DN"
echo "  Server DN:   $SERVER_DN"
echo "  Client DN:   $CLIENT_DN"

# ── Clean old files ────────────────────────────────────────────
echo ""
echo "Cleaning up old certificate files..."
rm -f "$CERT_DIR"/*.jks \
      "$CERT_DIR"/*.crt \
      "$CERT_DIR"/*.csr \
      "$CERT_DIR"/*.pem \
      "$CERT_DIR"/*.p12
print_ok "Old files removed"

TOTAL_STEPS=10

# ── STEP 1: Generate CA ────────────────────────────────────────
print_step 1 $TOTAL_STEPS "Generating Certificate Authority (CA)"

keytool -genkeypair \
    -alias "$CA_ALIAS" \
    -keyalg RSA \
    -keysize 4096 \
    -sigalg SHA256withRSA \
    -dname "$CA_DN" \
    -keypass "$CA_PASS" \
    -keystore "$CERT_DIR/kafka.ca.jks" \
    -storepass "$CA_PASS" \
    -storetype JKS \
    -validity $VALIDITY \
    -ext bc=ca:true \
    -ext KeyUsage=digitalSignature,keyCertSign,cRLSign \
    2>/dev/null

print_ok "CA keystore created: kafka.ca.jks"

# ── STEP 2: Export CA certificate ─────────────────────────────
print_step 2 $TOTAL_STEPS "Exporting CA public certificate"

keytool -exportcert \
    -alias "$CA_ALIAS" \
    -keystore "$CERT_DIR/kafka.ca.jks" \
    -storepass "$CA_PASS" \
    -rfc \
    -file "$CERT_DIR/ca.crt" \
    2>/dev/null

print_ok "CA certificate exported: ca.crt"

# ── STEP 3: Generate Kafka Broker key pair ─────────────────────
print_step 3 $TOTAL_STEPS "Generating Kafka broker key pair"

keytool -genkeypair \
    -alias "$SERVER_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -sigalg SHA256withRSA \
    -dname "$SERVER_DN" \
    -keypass "$KEY_PASS" \
    -keystore "$CERT_DIR/kafka.server.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -storetype JKS \
    -validity $VALIDITY \
    2>/dev/null

print_ok "Server keystore created: kafka.server.keystore.jks"

# ── STEP 4: Generate server CSR ────────────────────────────────
print_step 4 $TOTAL_STEPS "Generating server Certificate Signing Request"

keytool -certreq \
    -alias "$SERVER_ALIAS" \
    -keystore "$CERT_DIR/kafka.server.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEY_PASS" \
    -file "$CERT_DIR/kafka-server.csr" \
    2>/dev/null

print_ok "Server CSR created: kafka-server.csr"

# ── STEP 5: Sign server cert with CA ──────────────────────────
print_step 5 $TOTAL_STEPS "Signing server certificate with CA"

# Build SAN extension for macOS compatibility
SAN="dns:kafka-broker-1,dns:kafka-broker-2,dns:kafka-broker-3"
SAN="$SAN,dns:kafka-ssl,dns:localhost,ip:127.0.0.1"

keytool -gencert \
    -alias "$CA_ALIAS" \
    -keystore "$CERT_DIR/kafka.ca.jks" \
    -storepass "$CA_PASS" \
    -keypass "$CA_PASS" \
    -infile "$CERT_DIR/kafka-server.csr" \
    -outfile "$CERT_DIR/kafka-server-signed.crt" \
    -validity $VALIDITY \
    -rfc \
    -ext "SAN=$SAN" \
    -ext "KeyUsage=digitalSignature,keyEncipherment" \
    -ext "ExtendedKeyUsage=serverAuth" \
    2>/dev/null

print_ok "Server certificate signed: kafka-server-signed.crt"

# ── STEP 6: Import CA + signed cert into server keystore ───────
print_step 6 $TOTAL_STEPS "Importing certificates into server keystore"

keytool -importcert \
    -alias "$CA_ALIAS" \
    -keystore "$CERT_DIR/kafka.server.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -file "$CERT_DIR/ca.crt" \
    -noprompt \
    2>/dev/null

print_ok "CA cert imported into server keystore"

keytool -importcert \
    -alias "$SERVER_ALIAS" \
    -keystore "$CERT_DIR/kafka.server.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEY_PASS" \
    -file "$CERT_DIR/kafka-server-signed.crt" \
    -noprompt \
    2>/dev/null

print_ok "Signed server cert imported into server keystore"

# ── STEP 7: Create server truststore ──────────────────────────
print_step 7 $TOTAL_STEPS "Creating server truststore"

keytool -importcert \
    -alias "$CA_ALIAS" \
    -keystore "$CERT_DIR/kafka.server.truststore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -storetype JKS \
    -file "$CERT_DIR/ca.crt" \
    -noprompt \
    2>/dev/null

print_ok "Server truststore created: kafka.server.truststore.jks"

# ── STEP 8: Generate client key pair ──────────────────────────
print_step 8 $TOTAL_STEPS "Generating Kafka client key pair"

keytool -genkeypair \
    -alias "$CLIENT_ALIAS" \
    -keyalg RSA \
    -keysize 2048 \
    -sigalg SHA256withRSA \
    -dname "$CLIENT_DN" \
    -keypass "$KEY_PASS" \
    -keystore "$CERT_DIR/kafka.client.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -storetype JKS \
    -validity $VALIDITY \
    2>/dev/null

print_ok "Client keystore created: kafka.client.keystore.jks"

# ── STEP 9: Sign client certificate ───────────────────────────
print_step 9 $TOTAL_STEPS "Generating and signing client certificate"

keytool -certreq \
    -alias "$CLIENT_ALIAS" \
    -keystore "$CERT_DIR/kafka.client.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEY_PASS" \
    -file "$CERT_DIR/kafka-client.csr" \
    2>/dev/null

keytool -gencert \
    -alias "$CA_ALIAS" \
    -keystore "$CERT_DIR/kafka.ca.jks" \
    -storepass "$CA_PASS" \
    -keypass "$CA_PASS" \
    -infile "$CERT_DIR/kafka-client.csr" \
    -outfile "$CERT_DIR/kafka-client-signed.crt" \
    -validity $VALIDITY \
    -rfc \
    -ext "KeyUsage=digitalSignature" \
    -ext "ExtendedKeyUsage=clientAuth" \
    2>/dev/null

keytool -importcert \
    -alias "$CA_ALIAS" \
    -keystore "$CERT_DIR/kafka.client.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -file "$CERT_DIR/ca.crt" \
    -noprompt \
    2>/dev/null

keytool -importcert \
    -alias "$CLIENT_ALIAS" \
    -keystore "$CERT_DIR/kafka.client.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -keypass "$KEY_PASS" \
    -file "$CERT_DIR/kafka-client-signed.crt" \
    -noprompt \
    2>/dev/null

print_ok "Client keystore complete: kafka.client.keystore.jks"

# ── STEP 10: Create client truststore ─────────────────────────
print_step 10 $TOTAL_STEPS "Creating client truststore"

keytool -importcert \
    -alias "$CA_ALIAS" \
    -keystore "$CERT_DIR/kafka.client.truststore.jks" \
    -storepass "$KEYSTORE_PASS" \
    -storetype JKS \
    -file "$CERT_DIR/ca.crt" \
    -noprompt \
    2>/dev/null

print_ok "Client truststore created: kafka.client.truststore.jks"

# ── Verification ───────────────────────────────────────────────
echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Verification${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""

echo "Keystore contents:"
echo ""
echo "  [Server Keystore]:"
keytool -list \
    -keystore "$CERT_DIR/kafka.server.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    2>/dev/null | grep -E "Alias|Entry|Valid" | sed 's/^/    /'

echo ""
echo "  [Client Keystore]:"
keytool -list \
    -keystore "$CERT_DIR/kafka.client.keystore.jks" \
    -storepass "$KEYSTORE_PASS" \
    2>/dev/null | grep -E "Alias|Entry|Valid" | sed 's/^/    /'

echo ""
echo "File sizes (all must be > 0):"
for FILE in \
    "kafka.server.keystore.jks" \
    "kafka.server.truststore.jks" \
    "kafka.client.keystore.jks" \
    "kafka.client.truststore.jks" \
    "ca.crt"; do

    FILEPATH="$CERT_DIR/$FILE"
    if [ -f "$FILEPATH" ]; then
        SIZE=$(wc -c < "$FILEPATH")
        if [ "$SIZE" -gt 0 ]; then
            echo -e "  ${GREEN}✓${NC} $FILE: $SIZE bytes"
        else
            echo -e "  ${RED}✗${NC} $FILE: EMPTY! Generation failed."
        fi
    else
        echo -e "  ${RED}✗${NC} $FILE: NOT FOUND!"
    fi
done

# ── Done ───────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  SSL Certificate Generation Complete!${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo "  BROKER FILES:"
echo "    kafka.server.keystore.jks    - Broker private key + signed cert"
echo "    kafka.server.truststore.jks  - Broker trusts our CA for clients"
echo ""
echo "  CLIENT FILES:"
echo "    kafka.client.keystore.jks    - Client private key + signed cert"
echo "    kafka.client.truststore.jks  - Client trusts our CA for brokers"
echo ""
echo "  CA FILES:"
echo "    kafka.ca.jks                 - CA keystore (keep private!)"
echo "    ca.crt                       - CA public cert"
echo ""
echo -e "  ${YELLOW}Password for all files: $KEYSTORE_PASS${NC}"
echo ""
echo "  NEXT STEPS:"
echo "    1. Start SSL Kafka cluster:"
echo "       cd docker && docker-compose -f docker-compose-ssl.yml up -d"
echo ""
echo "    2. Run SSL demo:"
echo "       mvn exec:java -Dexec.mainClass=\"com.kafka.training.Day2Module2_Security.SSLProducerDemo\""
echo ""