package com.kafka.training.Day2Module3_EDA;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/**
 * ============================================================
 * DAY 2 - MODULE 3: EVENT-DRIVEN ARCHITECTURE
 * Sub-Demo 2: Saga Pattern Introduction
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - Saga pattern for distributed transactions
 * - Choreography-based Saga
 * - Compensating transactions (rollback via events)
 * - Payment Saga: Authorize → Reserve → Settle OR Rollback
 *
 * TRAINER NOTES:
 * "Distributed transactions across microservices are hard.
 *  Traditional 2-phase commit doesn't work well at scale.
 *
 *  The Saga pattern solves this:
 *  - Break the transaction into steps
 *  - Each step publishes an event on success
 *  - On failure, publish COMPENSATING events to undo previous steps
 *
 *  PAYMENT SAGA STEPS:
 *  1. PaymentCreated → authorize card
 *  2. CardAuthorized → reserve funds
 *  3. FundsReserved → process settlement
 *  4. Settled → release reservation, notify customer
 *
 *  COMPENSATION (if step fails):
 *  3. SettlementFailed → release fund reservation
 *  2. ReservationReleased → reverse authorization
 *  1. AuthorizationReversed → notify customer of failure"
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module3_EDA.SagaPatternDemo"
 * ============================================================
 */
public class SagaPatternDemo {

    private static final Logger logger = LoggerFactory.getLogger(SagaPatternDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    // Saga topics
    private static final String TOPIC_PAYMENT_CREATED = "payment-created";
    private static final String TOPIC_FRAUD_RESULT = "fraud-result";
    private static final String TOPIC_PAYMENT_SETTLED = "payment-settled";
    private static final String TOPIC_PAYMENT_DLQ = "payment-dlq";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 3: Saga Pattern Demo");
        logger.info("============================================================");

        SagaPatternDemo demo = new SagaPatternDemo();

        // DEMO 1: Explain Saga concept
        demo.explainSagaPattern();

        // DEMO 2: Happy path Saga
        demo.demonstrateHappyPathSaga();

        // DEMO 3: Compensating transaction (failure path)
        demo.demonstrateCompensatingSaga();

        logger.info("============================================================");
        logger.info("  Saga Pattern Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Saga Pattern Explained
     */
    private void explainSagaPattern() {
        logger.info("");
        logger.info("--- DEMO 1: Saga Pattern Explanation ---");
        logger.info("");
        logger.info("PROBLEM: How to maintain data consistency across services?");
        logger.info("  Service A updates its DB, calls Service B, Service B fails...");
        logger.info("  Service A's DB has the change but Service B doesn't → INCONSISTENT!");
        logger.info("");
        logger.info("SAGA SOLUTION: Series of local transactions with compensations");
        logger.info("");
        logger.info("HAPPY PATH (all succeed):");
        logger.info("  [PaymentService]     PaymentCreated    → topic: payment-created");
        logger.info("  [FraudService]       FraudApproved     → topic: fraud-result");
        logger.info("  [SettlementService]  PaymentSettled    → topic: payment-settled");
        logger.info("  [LedgerService]      AccountDebited    → (DB update done)");
        logger.info("");
        logger.info("FAILURE PATH (compensation):");
        logger.info("  [PaymentService]     PaymentCreated    → topic: payment-created");
        logger.info("  [FraudService]       FraudRejected     → topic: fraud-result");
        logger.info("  [PaymentService]     PaymentRejected   → (notify customer)");
        logger.info("  NO compensations needed (no downstream steps were taken)");
        logger.info("");
        logger.info("LATE FAILURE (compensation required):");
        logger.info("  [PaymentService]     PaymentCreated    → payment-created");
        logger.info("  [FraudService]       FraudApproved     → fraud-result");
        logger.info("  [SettlementService]  SettlementFailed  → payment-dlq");
        logger.info("  [FraudService]       COMPENSATION: ReverseApproval");
        logger.info("  [PaymentService]     COMPENSATION: PaymentFailed → notify customer");
    }

    /**
     * DEMO 2: Happy Path Saga
     */
    private void demonstrateHappyPathSaga() throws Exception {
        logger.info("");
        logger.info("--- DEMO 2: Happy Path Saga ---");
        logger.info("Payment → Fraud Approved → Settled → Ledger Updated");
        logger.info("");

        String paymentId = "PAY-SAGA-HAPPY-001";
        String customerId = "CUST-SAGA-001";

        // STEP 1: Payment Created
        logger.info("STEP 1: PaymentService publishes PaymentCreated");
        String paymentEvent = buildSagaEvent(paymentId, customerId, 1000.00, "CREATED", null);
        publishEvent(TOPIC_PAYMENT_CREATED, paymentId, paymentEvent);
        Thread.sleep(500);

        // STEP 2: Fraud Check (simulated approval)
        logger.info("STEP 2: FraudService processes PaymentCreated → publishes FraudApproved");
        String fraudEvent = buildFraudEvent(paymentId, customerId, false, 0.05, "APPROVED");
        publishEvent(TOPIC_FRAUD_RESULT, paymentId, fraudEvent);
        Thread.sleep(500);

        // STEP 3: Settlement
        logger.info("STEP 3: SettlementService processes FraudApproved → publishes PaymentSettled");
        String settlementEvent = buildSagaEvent(paymentId, customerId, 1000.00, "SETTLED", null);
        publishEvent(TOPIC_PAYMENT_SETTLED, paymentId, settlementEvent);
        Thread.sleep(500);

        logger.info("");
        logger.info("✓ HAPPY PATH SAGA COMPLETE:");
        logger.info("  PaymentCreated → FraudApproved → PaymentSettled");
        logger.info("  All steps succeeded, no compensation needed");
        logger.info("  Customer's payment of $1000.00 processed successfully");
    }

    /**
     * DEMO 3: Compensating Transaction Saga (Failure Path)
     *
     * TRAINER SCRIPT:
     * "Now let's see what happens when fraud is detected.
     *  We publish a FraudRejected event instead of FraudApproved.
     *  Services listening for 'rejected' events trigger compensations."
     */
    private void demonstrateCompensatingSaga() throws Exception {
        logger.info("");
        logger.info("--- DEMO 3: Compensating Saga (Fraud Detected) ---");
        logger.info("Payment → Fraud REJECTED → Compensate → Notify Customer");
        logger.info("");

        String paymentId = "PAY-SAGA-FRAUD-001";
        String customerId = "CUST-SAGA-999";

        // STEP 1: Payment Created
        logger.info("STEP 1: PaymentService publishes PaymentCreated");
        String paymentEvent = buildSagaEvent(paymentId, customerId, 99999.99, "CREATED", null);
        publishEvent(TOPIC_PAYMENT_CREATED, paymentId, paymentEvent);
        Thread.sleep(500);

        // STEP 2: Fraud check FAILS (high amount triggers fraud)
        logger.info("STEP 2: FraudService detects FRAUD → publishes FraudRejected");
        logger.info("  Amount: $99,999.99 → SUSPICIOUS! Risk score: 0.95");
        String fraudEvent = buildFraudEvent(paymentId, customerId, true, 0.95, "REJECTED");
        publishEvent(TOPIC_FRAUD_RESULT, paymentId, fraudEvent);
        Thread.sleep(500);

        // STEP 3: Compensating transaction
        logger.info("STEP 3: PaymentService receives FraudRejected → COMPENSATES");
        logger.info("  Compensation: Mark payment as REJECTED");
        logger.info("  Compensation: Send rejection notification to customer");
        logger.info("  Compensation: Release any reserved funds");

        // Send to DLQ for visibility
        String rejectedEvent = buildSagaEvent(paymentId, customerId, 99999.99, "REJECTED",
            "Fraud detected: risk score 0.95");
        publishEvent(TOPIC_PAYMENT_DLQ, paymentId, rejectedEvent);
        Thread.sleep(500);

        logger.info("");
        logger.info("✓ COMPENSATING SAGA COMPLETE:");
        logger.info("  PaymentCreated → FraudRejected → PaymentRejected (compensation)");
        logger.info("  No partial state: payment cleanly rolled back");
        logger.info("  Customer notified: 'Payment declined - security check failed'");
        logger.info("");
        logger.info("KEY INSIGHT: Sagas use EVENTS for both forward and backward flow");
        logger.info("            No distributed locks, no 2-phase commit needed!");
    }

    private String buildSagaEvent(String paymentId, String customerId,
                                   double amount, String status, String failureReason) {
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("paymentId", paymentId);
            node.put("customerId", customerId);
            node.put("amount", amount);
            node.put("status", status);
            node.put("timestamp", System.currentTimeMillis());
            if (failureReason != null) node.put("failureReason", failureReason);
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) { return "{}"; }
    }

    private String buildFraudEvent(String paymentId, String customerId,
                                    boolean fraudDetected, double riskScore, String decision) {
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("paymentId", paymentId);
            node.put("customerId", customerId);
            node.put("fraudDetected", fraudDetected);
            node.put("riskScore", riskScore);
            node.put("decision", decision);
            node.put("timestamp", System.currentTimeMillis());
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) { return "{}"; }
    }

    private void publishEvent(String topic, String key, String value) throws Exception {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all");

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            RecordMetadata meta = producer.send(
                new ProducerRecord<>(topic, key, value)).get();
            logger.info("  → Published to {}: partition={}, offset={}",
                topic, meta.partition(), meta.offset());
        }
    }
}