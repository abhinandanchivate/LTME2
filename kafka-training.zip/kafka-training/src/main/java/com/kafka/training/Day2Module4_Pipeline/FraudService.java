package com.kafka.training.Day2Module4_Pipeline;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ============================================================
 * DAY 2 - MODULE 4: END-TO-END EVENT PIPELINE
 * Service 2: Fraud Detection Service (Consumer + Producer)
 * ============================================================
 *
 * ROLE IN PIPELINE:
 * FraudService is a CONSUMER-PRODUCER service.
 * It reads from payment-created, applies fraud rules,
 * and publishes results to fraud-result.
 *
 * PIPELINE POSITION:
 * [payment-created] → FraudService → [fraud-result]
 *
 * FRAUD DETECTION RULES (simplified for demo):
 * 1. Amount > $10,000 → HIGH RISK (risk score 0.85)
 * 2. Amount > $50,000 → FRAUD DETECTED (risk score 0.95)
 * 3. Customer on blocklist → FRAUD DETECTED (risk score 1.0)
 * 4. Normal amounts → APPROVED (risk score 0.1-0.3)
 *
 * FEATURES DEMONSTRATED:
 * - Consumer-producer pattern (read-process-write)
 * - Manual offset commit (at-least-once)
 * - Exactly-once semantics using transactions
 * - Error handling and retry
 * - Metrics and monitoring
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module4_Pipeline.FraudService"
 * ============================================================
 */
public class FraudService {

    private static final Logger logger = LoggerFactory.getLogger(FraudService.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";

    // Topics this service reads from
    private static final String TOPIC_PAYMENT_CREATED = "payment-created";

    // Topics this service writes to
    private static final String TOPIC_FRAUD_RESULT = "fraud-result";
    private static final String TOPIC_PAYMENT_DLQ = "payment-dlq";

    // Consumer group
    private static final String GROUP_ID = "fraud-detection-service-group";

    // Fraud rules thresholds
    private static final double HIGH_RISK_THRESHOLD = 10_000.0;
    private static final double FRAUD_THRESHOLD = 50_000.0;

    // Simulated blocklist
    private static final Set<String> BLOCKLISTED_CUSTOMERS = Set.of(
        "CUST-BLOCKED-001", "CUST-BLOCKED-002"
    );

    // Metrics
    private final AtomicInteger approved = new AtomicInteger(0);
    private final AtomicInteger rejected = new AtomicInteger(0);
    private final AtomicInteger highRisk = new AtomicInteger(0);
    private final AtomicInteger errors = new AtomicInteger(0);

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private volatile boolean running = true;

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 4: Fraud Detection Service");
        logger.info("============================================================");

        FraudService service = new FraudService();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("[FraudService] Shutdown signal received...");
            service.running = false;
        }));

        service.run();
    }

    /**
     * Main service loop
     *
     * TRAINER SCRIPT:
     * "FraudService is a classic Kafka Streams-style processor.
     *  It reads payment events, applies ML-like fraud rules,
     *  and publishes the fraud decision.
     *
     *  We use MANUAL commit to ensure exactly-once processing:
     *  1. Read payment event
     *  2. Run fraud check
     *  3. Write fraud result to fraud-result topic
     *  4. THEN commit the payment-created offset
     *  If step 3 or 4 fails → retry from step 1 (idempotent)"
     */
    public void run() throws Exception {
        logger.info("[FraudService] Starting up...");
        logger.info("[FraudService] Consuming from: {}", TOPIC_PAYMENT_CREATED);
        logger.info("[FraudService] Publishing to:   {}", TOPIC_FRAUD_RESULT);
        logger.info("[FraudService] Fraud Threshold: ${}", FRAUD_THRESHOLD);
        logger.info("");

        Properties consumerProps = buildConsumerConfig();
        Properties producerProps = buildProducerConfig();

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(consumerProps);
             KafkaProducer<String, String> producer = new KafkaProducer<>(producerProps)) {

            consumer.subscribe(Collections.singletonList(TOPIC_PAYMENT_CREATED));
            logger.info("[FraudService] Subscribed to {}", TOPIC_PAYMENT_CREATED);

            while (running) {
                ConsumerRecords<String, String> records =
                    consumer.poll(Duration.ofMillis(1000));

                if (records.isEmpty()) {
                    logger.debug("[FraudService] Waiting for payment events...");
                    continue;
                }

                for (ConsumerRecord<String, String> record : records) {
                    processPaymentEvent(record, producer);
                }

                // Manual commit AFTER all records in batch are processed
                try {
                    consumer.commitSync();
                } catch (CommitFailedException e) {
                    logger.warn("[FraudService] Commit failed - will reprocess: {}",
                        e.getMessage());
                }

                // Print metrics every 5 processed records
                int totalProcessed = approved.get() + rejected.get();
                if (totalProcessed > 0 && totalProcessed % 5 == 0) {
                    printMetrics();
                }
            }
        }

        logger.info("[FraudService] Shutdown complete.");
        printMetrics();
    }

    /**
     * Process a single payment event through fraud detection
     */
    private void processPaymentEvent(ConsumerRecord<String, String> record,
                                      KafkaProducer<String, String> producer) {
        String paymentId = record.key();

        try {
            // Parse the payment JSON
            JsonNode payment = objectMapper.readTree(record.value());

            String customerId = payment.get("customerId").asText();
            double amount = payment.get("amount").asDouble();
            String correlationId = payment.has("correlationId")
                ? payment.get("correlationId").asText() : "UNKNOWN";

            logger.info("[FraudService] Checking: paymentId={}, amount=${}, customer={}",
                paymentId, String.format("%.2f", amount), customerId);

            // Simulate processing time (ML model inference)
            Thread.sleep(100 + (long)(Math.random() * 200));

            // Apply fraud detection rules
            FraudDecision decision = runFraudDetection(paymentId, customerId, amount);

            // Publish fraud result
            publishFraudResult(producer, paymentId, customerId, amount,
                correlationId, decision);

            // Log the decision
            String emoji = decision.approved ? "✓" : "✗";
            logger.info("[FraudService] {} Decision: paymentId={}, result={}, " +
                "riskScore={}, reason={}",
                emoji, paymentId, decision.approved ? "APPROVED" : "REJECTED",
                String.format("%.2f", decision.riskScore), decision.reason);

            if (decision.approved) {
                approved.incrementAndGet();
            } else {
                rejected.incrementAndGet();
            }

        } catch (Exception e) {
            errors.incrementAndGet();
            logger.error("[FraudService] Error processing paymentId={}: {}",
                paymentId, e.getMessage());
            sendErrorToDLQ(producer, record, e.getMessage());
        }
    }

    /**
     * Fraud Detection Logic
     *
     * TRAINER SCRIPT:
     * "In production this would be an ML model call.
     *  For this demo we use simple rule-based detection.
     *  The principles are the same: input=payment, output=risk score + decision."
     */
    private FraudDecision runFraudDetection(String paymentId,
                                              String customerId, double amount) {
        FraudDecision decision = new FraudDecision();

        // Rule 1: Blocklisted customer
        if (BLOCKLISTED_CUSTOMERS.contains(customerId)) {
            decision.riskScore = 1.0;
            decision.approved = false;
            decision.reason = "Customer on fraud blocklist";
            return decision;
        }

        // Rule 2: Extremely high amount - definite fraud
        if (amount >= FRAUD_THRESHOLD) {
            decision.riskScore = 0.95;
            decision.approved = false;
            decision.reason = "Amount exceeds fraud threshold: $" + amount;
            highRisk.incrementAndGet();
            return decision;
        }

        // Rule 3: High value - flag for review but approve
        if (amount >= HIGH_RISK_THRESHOLD) {
            decision.riskScore = 0.75;
            decision.approved = true;
            decision.reason = "High value payment - flagged for review";
            highRisk.incrementAndGet();
            return decision;
        }

        // Rule 4: Normal payment - approve
        decision.riskScore = 0.05 + (Math.random() * 0.25); // 0.05 to 0.30
        decision.approved = true;
        decision.reason = "Payment within normal parameters";
        return decision;
    }

    /**
     * Publish fraud decision to fraud-result topic
     */
    private void publishFraudResult(KafkaProducer<String, String> producer,
                                     String paymentId, String customerId,
                                     double amount, String correlationId,
                                     FraudDecision decision) throws Exception {
        ObjectNode fraudEvent = objectMapper.createObjectNode();
        fraudEvent.put("fraudCheckId", UUID.randomUUID().toString());
        fraudEvent.put("paymentId", paymentId);
        fraudEvent.put("customerId", customerId);
        fraudEvent.put("amount", amount);
        fraudEvent.put("correlationId", correlationId);
        fraudEvent.put("approved", decision.approved);
        fraudEvent.put("riskScore", decision.riskScore);
        fraudEvent.put("reason", decision.reason);
        fraudEvent.put("checkedAt", System.currentTimeMillis());
        fraudEvent.put("decision", decision.approved ? "APPROVED" : "REJECTED");

        String fraudJson = objectMapper.writeValueAsString(fraudEvent);

        ProducerRecord<String, String> record =
            new ProducerRecord<>(TOPIC_FRAUD_RESULT, paymentId, fraudJson);

        // Add tracing headers
        record.headers().add("correlationId", correlationId.getBytes());
        record.headers().add("sourceService", "FraudService".getBytes());

        producer.send(record).get(); // Sync for reliability
    }

    /**
     * Send error events to DLQ for investigation
     */
    private void sendErrorToDLQ(KafkaProducer<String, String> producer,
                                  ConsumerRecord<String, String> originalRecord,
                                  String errorMessage) {
        try {
            ObjectNode dlqEvent = objectMapper.createObjectNode();
            dlqEvent.put("source", "FraudService");
            dlqEvent.put("originalKey", originalRecord.key());
            dlqEvent.put("originalTopic", originalRecord.topic());
            dlqEvent.put("originalOffset", originalRecord.offset());
            dlqEvent.put("errorMessage", errorMessage);
            dlqEvent.put("failedAt", System.currentTimeMillis());
            dlqEvent.put("originalValue", originalRecord.value());

            producer.send(new ProducerRecord<>(
                TOPIC_PAYMENT_DLQ,
                "DLQ-" + originalRecord.key(),
                objectMapper.writeValueAsString(dlqEvent)
            ));

            logger.warn("[FraudService] Error event sent to DLQ for: {}",
                originalRecord.key());
        } catch (Exception e) {
            logger.error("[FraudService] CRITICAL: Cannot write to DLQ!", e);
        }
    }

    private void printMetrics() {
        logger.info("");
        logger.info("[FraudService] ── Metrics ──────────────────────────");
        logger.info("[FraudService]   Approved:    {}", approved.get());
        logger.info("[FraudService]   Rejected:    {}", rejected.get());
        logger.info("[FraudService]   High Risk:   {}", highRisk.get());
        logger.info("[FraudService]   Errors:      {}", errors.get());
        int total = approved.get() + rejected.get();
        if (total > 0) {
            logger.info("[FraudService]   Fraud Rate:  {:.1f}%",
                (double) rejected.get() / total * 100);
        }
        logger.info("[FraudService] ─────────────────────────────────────");
        logger.info("");
    }

    private Properties buildConsumerConfig() {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false"); // Manual commit
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "10");
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, "3000");
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "45000");
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, "300000");
        return props;
    }

    private Properties buildProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
        props.put(ProducerConfig.RETRIES_CONFIG, "3");
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "fraud-service-producer");
        return props;
    }

    // Inner class for fraud decision result
    static class FraudDecision {
        boolean approved;
        double riskScore;
        String reason;
    }
}