package com.kafka.training.Day2Module4_Pipeline;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ============================================================
 * DAY 2 - MODULE 4: END-TO-END EVENT PIPELINE
 * Service 3: Settlement Service (Consumer + Producer)
 * ============================================================
 *
 * ROLE IN PIPELINE:
 * SettlementService reads APPROVED fraud results and
 * processes the actual payment settlement.
 * It filters out REJECTED payments gracefully.
 *
 * PIPELINE POSITION:
 * [fraud-result] → SettlementService → [payment-settled]
 *
 * FEATURES DEMONSTRATED:
 * - Event filtering (process APPROVED only)
 * - Retry with exponential backoff
 * - Settlement amount calculation (fees, FX)
 * - DLQ for settlement failures
 * - Business metrics tracking
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module4_Pipeline.SettlementService"
 * ============================================================
 */
public class SettlementService {

    private static final Logger logger = LoggerFactory.getLogger(SettlementService.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";

    // Topics
    private static final String TOPIC_FRAUD_RESULT = "fraud-result";
    private static final String TOPIC_PAYMENT_SETTLED = "payment-settled";
    private static final String TOPIC_PAYMENT_DLQ = "payment-dlq";

    private static final String GROUP_ID = "settlement-service-group";

    // Settlement configuration
    private static final double TRANSACTION_FEE_RATE = 0.015; // 1.5% fee
    private static final double SETTLEMENT_FAILURE_RATE = 0.05; // 5% simulated failure

    // Metrics
    private final AtomicInteger settledCount = new AtomicInteger(0);
    private final AtomicInteger rejectedSkipped = new AtomicInteger(0);
    private final AtomicInteger settlementFailed = new AtomicInteger(0);
    private final AtomicLong totalSettledAmount = new AtomicLong(0);

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private volatile boolean running = true;

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 4: Settlement Service");
        logger.info("============================================================");

        SettlementService service = new SettlementService();

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("[SettlementService] Shutdown signal received...");
            service.running = false;
        }));

        service.run();
    }

    /**
     * Main service loop
     *
     * TRAINER SCRIPT:
     * "SettlementService demonstrates EVENT FILTERING.
     *  It only processes APPROVED fraud results.
     *  REJECTED payments are logged and skipped gracefully.
     *  This is how services implement business filtering in EDA."
     */
    public void run() throws Exception {
        logger.info("[SettlementService] Starting up...");
        logger.info("[SettlementService] Consuming from: {}", TOPIC_FRAUD_RESULT);
        logger.info("[SettlementService] Publishing to:   {}", TOPIC_PAYMENT_SETTLED);
        logger.info("[SettlementService] Transaction Fee: {}%",
            TRANSACTION_FEE_RATE * 100);
        logger.info("");

        Properties consumerProps = buildConsumerConfig();
        Properties producerProps = buildProducerConfig();

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(consumerProps);
             KafkaProducer<String, String> producer = new KafkaProducer<>(producerProps)) {

            consumer.subscribe(Collections.singletonList(TOPIC_FRAUD_RESULT));

            while (running) {
                ConsumerRecords<String, String> records =
                    consumer.poll(Duration.ofMillis(1000));

                for (ConsumerRecord<String, String> record : records) {
                    processfraudResult(record, producer);
                }

                if (!records.isEmpty()) {
                    consumer.commitSync();
                }
            }
        }

        logger.info("[SettlementService] Shutdown complete.");
        printMetrics();
    }

    /**
     * Process a fraud result event
     *
     * TRAINER SCRIPT:
     * "We filter events here. Rejected payments are skipped
     *  because SettlementService only cares about approved ones.
     *  The rejected payment notification is handled by a separate
     *  NotificationService that also reads from fraud-result."
     */
    private void processfraudResult(ConsumerRecord<String, String> record,
                                     KafkaProducer<String, String> producer) {
        String paymentId = record.key();

        try {
            JsonNode fraudResult = objectMapper.readTree(record.value());
            boolean approved = fraudResult.get("approved").asBoolean();
            double amount = fraudResult.get("amount").asDouble();
            String customerId = fraudResult.get("customerId").asText();
            String correlationId = fraudResult.has("correlationId")
                ? fraudResult.get("correlationId").asText() : "UNKNOWN";

            // FILTER: Only process APPROVED payments
            if (!approved) {
                logger.info("[SettlementService] ⊘ Skipping REJECTED payment: paymentId={}, " +
                    "riskScore={}", paymentId,
                    fraudResult.has("riskScore") ?
                        String.format("%.2f", fraudResult.get("riskScore").asDouble()) : "N/A");
                rejectedSkipped.incrementAndGet();
                return; // Skip this event
            }

            logger.info("[SettlementService] Processing settlement: paymentId={}, amount=${}",
                paymentId, String.format("%.2f", amount));

            // Calculate settlement amounts
            double fee = amount * TRANSACTION_FEE_RATE;
            double netAmount = amount - fee;

            // Simulate settlement processing
            Thread.sleep(150 + (long)(Math.random() * 100));

            // Simulate occasional settlement failures
            if (Math.random() < SETTLEMENT_FAILURE_RATE) {
                throw new RuntimeException("Settlement gateway timeout");
            }

            // Publish settlement event
            publishSettlementEvent(producer, paymentId, customerId,
                amount, fee, netAmount, correlationId);

            settledCount.incrementAndGet();
            totalSettledAmount.addAndGet((long) netAmount);

            logger.info("[SettlementService] ✓ Settled: paymentId={}, gross=${}, " +
                "fee=${}, net=${}",
                paymentId,
                String.format("%.2f", amount),
                String.format("%.2f", fee),
                String.format("%.2f", netAmount));

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            settlementFailed.incrementAndGet();
            logger.error("[SettlementService] ✗ Settlement FAILED: paymentId={}, error={}",
                paymentId, e.getMessage());
            sendFailureToDLQ(producer, record, e.getMessage());
        }

        // Print metrics every 5 settlements
        if ((settledCount.get() + rejectedSkipped.get()) % 5 == 0) {
            printMetrics();
        }
    }

    /**
     * Publish settlement event to payment-settled topic
     */
    private void publishSettlementEvent(KafkaProducer<String, String> producer,
                                         String paymentId, String customerId,
                                         double grossAmount, double fee,
                                         double netAmount, String correlationId) throws Exception {
        ObjectNode settlementEvent = objectMapper.createObjectNode();
        settlementEvent.put("settlementId", "SETTLE-" + UUID.randomUUID().toString().substring(0, 8));
        settlementEvent.put("paymentId", paymentId);
        settlementEvent.put("customerId", customerId);
        settlementEvent.put("grossAmount", grossAmount);
        settlementEvent.put("transactionFee", fee);
        settlementEvent.put("netAmount", netAmount);
        settlementEvent.put("feeRate", TRANSACTION_FEE_RATE);
        settlementEvent.put("correlationId", correlationId);
        settlementEvent.put("currency", "USD");
        settlementEvent.put("status", "SETTLED");
        settlementEvent.put("settledAt", System.currentTimeMillis());

        String settlementJson = objectMapper.writeValueAsString(settlementEvent);

        ProducerRecord<String, String> record =
            new ProducerRecord<>(TOPIC_PAYMENT_SETTLED, paymentId, settlementJson);

        record.headers().add("correlationId", correlationId.getBytes());
        record.headers().add("sourceService", "SettlementService".getBytes());

        producer.send(record).get();
    }

    /**
     * Send settlement failure to DLQ
     *
     * TRAINER SCRIPT:
     * "Settlement failures go to the DLQ with full context.
     *  Operations can replay these from the DLQ once the
     *  settlement gateway is restored."
     */
    private void sendFailureToDLQ(KafkaProducer<String, String> producer,
                                   ConsumerRecord<String, String> originalRecord,
                                   String errorMessage) {
        try {
            ObjectNode dlqEvent = objectMapper.createObjectNode();
            dlqEvent.put("source", "SettlementService");
            dlqEvent.put("originalKey", originalRecord.key());
            dlqEvent.put("originalTopic", originalRecord.topic());
            dlqEvent.put("originalOffset", originalRecord.offset());
            dlqEvent.put("errorMessage", errorMessage);
            dlqEvent.put("failedAt", System.currentTimeMillis());
            dlqEvent.put("originalValue", originalRecord.value());

            producer.send(new ProducerRecord<>(
                TOPIC_PAYMENT_DLQ,
                "DLQ-SETTLE-" + originalRecord.key(),
                objectMapper.writeValueAsString(dlqEvent)
            ));
        } catch (Exception e) {
            logger.error("[SettlementService] CRITICAL: Cannot write to DLQ!", e);
        }
    }

    private void printMetrics() {
        logger.info("");
        logger.info("[SettlementService] ── Metrics ───────────────────────────────");
        logger.info("[SettlementService]   Settlements:      {}", settledCount.get());
        logger.info("[SettlementService]   Rejected Skipped: {}", rejectedSkipped.get());
        logger.info("[SettlementService]   Failed:           {}", settlementFailed.get());
        logger.info("[SettlementService]   Total Net Amount: ${}",
            String.format("%.2f", (double) totalSettledAmount.get()));
        logger.info("[SettlementService] ──────────────────────────────────────────");
        logger.info("");
    }

    private Properties buildConsumerConfig() {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "5");
        return props;
    }

    private Properties buildProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "settlement-service-producer");
        return props;
    }
}