package com.kafka.training.Day2Module3_EDA;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/**
 * ============================================================
 * DAY 2 - MODULE 3: EVENT-DRIVEN ARCHITECTURE
 * Sub-Demo: Commands vs Events - Contrast Demo
 * ============================================================
 *
 * PURPOSE:
 * This demo explicitly contrasts COMMAND-driven vs EVENT-driven
 * communication patterns using the payment processing domain.
 *
 * It shows BOTH approaches side by side so trainers can clearly
 * demonstrate the difference and why EDA is preferred.
 *
 * CONCEPTS COVERED:
 * 1. Command-driven (synchronous, coupled) - the OLD WAY
 * 2. Event-driven (asynchronous, decoupled) - the KAFKA WAY
 * 3. Benefits of events over commands
 * 4. When commands ARE appropriate (query responses)
 * 5. Command → Event transformation pattern
 *
 * TRAINER NOTES:
 * ─────────────────────────────────────────────────────────
 * COMMAND (Imperative):
 *   "ProcessPayment" → TELL someone to do something NOW
 *   Sender knows receiver, waits for response
 *   Tight coupling: sender depends on receiver being UP
 *
 * EVENT (Declarative):
 *   "PaymentCreated" → ANNOUNCE something that HAPPENED
 *   Sender doesn't know or care who listens
 *   Loose coupling: receiver can be down, catches up later
 * ─────────────────────────────────────────────────────────
 *
 * ANALOGY FOR STUDENTS:
 * COMMAND = Calling a colleague on the phone and waiting for them to answer
 * EVENT   = Sending an email announcement to a mailing list
 *           You don't wait, anyone can read it, new people can subscribe
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module3_EDA.PaymentCommandDemo"
 * ============================================================
 */
public class PaymentCommandDemo {

    private static final Logger logger = LoggerFactory.getLogger(PaymentCommandDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    // Topics used in this demo
    private static final String TOPIC_PAYMENT_COMMANDS = "payment-commands";
    private static final String TOPIC_PAYMENT_EVENTS = "payment-created";
    private static final String TOPIC_COMMAND_REPLY = "payment-command-replies";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 3: Commands vs Events Demo");
        logger.info("  Understanding the core difference in EDA");
        logger.info("============================================================");

        PaymentCommandDemo demo = new PaymentCommandDemo();

        // ── PART 1: Show the Command Pattern (and its problems) ────
        logger.info("");
        logger.info("╔══════════════════════════════════════════════════════════╗");
        logger.info("║  PART 1: COMMAND PATTERN (Synchronous, Coupled)         ║");
        logger.info("╚══════════════════════════════════════════════════════════╝");
        demo.demonstrateCommandPattern();

        Thread.sleep(2000);

        // ── PART 2: Show the Event Pattern (the Kafka way) ─────────
        logger.info("");
        logger.info("╔══════════════════════════════════════════════════════════╗");
        logger.info("║  PART 2: EVENT PATTERN (Asynchronous, Decoupled)        ║");
        logger.info("╚══════════════════════════════════════════════════════════╝");
        demo.demonstrateEventPattern();

        Thread.sleep(2000);

        // ── PART 3: Command → Event Transformation ──────────────────
        logger.info("");
        logger.info("╔══════════════════════════════════════════════════════════╗");
        logger.info("║  PART 3: TRANSFORMATION - Command to Event              ║");
        logger.info("╚══════════════════════════════════════════════════════════╝");
        demo.demonstrateCommandToEventTransformation();

        Thread.sleep(2000);

        // ── PART 4: Request-Reply Pattern (when you need a response) ─
        logger.info("");
        logger.info("╔══════════════════════════════════════════════════════════╗");
        logger.info("║  PART 4: REQUEST-REPLY PATTERN (Async with Response)    ║");
        logger.info("╚══════════════════════════════════════════════════════════╝");
        demo.demonstrateRequestReplyPattern();

        Thread.sleep(2000);

        // ── PART 5: Side-by-side comparison ─────────────────────────
        logger.info("");
        logger.info("╔══════════════════════════════════════════════════════════╗");
        logger.info("║  PART 5: COMMAND vs EVENT - Complete Comparison         ║");
        logger.info("╚══════════════════════════════════════════════════════════╝");
        demo.printFullComparison();

        logger.info("");
        logger.info("============================================================");
        logger.info("  Commands vs Events Demo Complete!");
        logger.info("  KEY TAKEAWAY: Prefer EVENTS for microservice communication");
        logger.info("  Use COMMANDS only when you need an immediate response");
        logger.info("============================================================");
    }

    /**
     * PART 1: Demonstrate the Command Pattern
     *
     * TRAINER SCRIPT:
     * "Let me show you the COMMAND approach first - this is what
     * most teams start with when they first try to use Kafka.
     *
     * A COMMAND is a message that says: 'DO THIS NOW'
     * - It targets a specific service
     * - The sender expects a response
     * - The sender is BLOCKED waiting for the receiver
     *
     * In Kafka terms: using topics like RPC calls is an ANTI-PATTERN
     * because you lose all the benefits of async messaging."
     */
    private void demonstrateCommandPattern() throws Exception {
        logger.info("");
        logger.info("COMMAND PATTERN CHARACTERISTICS:");
        logger.info("  Structure:   Verb + Noun (Imperative)");
        logger.info("  Examples:    ProcessPayment, ValidateCard, DebitAccount");
        logger.info("  Direction:   Sender → specific Receiver");
        logger.info("  Coupling:    TIGHT - sender knows receiver");
        logger.info("  Waiting:     YES - sender waits for response");
        logger.info("");

        // Simulate the Command structure
        logger.info("SIMULATING COMMAND-DRIVEN PAYMENT FLOW:");
        logger.info("─────────────────────────────────────────");
        logger.info("");

        // Command 1: ProcessPayment
        String processPaymentCmd = buildCommand(
            "ProcessPayment",
            "CMD-001",
            "PAY-CMD-001",
            "CUST-001",
            500.00,
            "FraudService"  // Commands target a specific service
        );

        logger.info("PaymentService → sends COMMAND to FraudService:");
        logger.info("  Command: {}", processPaymentCmd);
        logger.info("  PaymentService is now BLOCKED waiting for FraudService response...");
        logger.info("  [simulating 500ms wait for FraudService response]");
        Thread.sleep(500); // Simulate blocking wait
        logger.info("  FraudService responded after 500ms: APPROVED");
        logger.info("");

        // Command 2: DebitAccount (after fraud approval)
        String debitCmd = buildCommand(
            "DebitAccount",
            "CMD-002",
            "PAY-CMD-001",
            "CUST-001",
            500.00,
            "LedgerService"
        );

        logger.info("PaymentService → sends COMMAND to LedgerService:");
        logger.info("  Command: {}", debitCmd);
        logger.info("  PaymentService BLOCKED again waiting for LedgerService...");
        logger.info("  [simulating 300ms wait]");
        Thread.sleep(300);
        logger.info("  LedgerService responded after 300ms: Account debited");
        logger.info("");

        logger.info("COMMAND PATTERN PROBLEMS OBSERVED:");
        logger.info("  ✗ PaymentService waited 800ms total (500 + 300)");
        logger.info("  ✗ If FraudService was DOWN → payment FAILS immediately");
        logger.info("  ✗ PaymentService must know FraudService's address");
        logger.info("  ✗ PaymentService must know LedgerService's address");
        logger.info("  ✗ Adding NotificationService requires changing PaymentService");
        logger.info("  ✗ Cascading failures: one service down breaks the chain");
        logger.info("");

        // Simulate what happens when a service is down
        logger.info("SIMULATING FRAUD SERVICE OUTAGE:");
        logger.info("  PaymentService → sends ProcessPayment to FraudService");
        logger.info("  FraudService is DOWN (maintenance, crash, etc.)");
        logger.info("  [simulating connection timeout - 30 seconds in real life...]");
        logger.info("  Result: Payment FAILS with 'Connection refused'");
        logger.info("  Customer sees: 'Payment processing error - please try again'");
        logger.info("  Revenue LOST. Customer frustrated.");
    }

    /**
     * PART 2: Demonstrate the Event Pattern
     *
     * TRAINER SCRIPT:
     * "Now let me show the EVENT approach - the Kafka way.
     *
     * An EVENT says: 'THIS HAPPENED'
     * - It's a FACT about the past (past tense)
     * - No specific target - anyone can listen
     * - Sender publishes and moves on immediately
     * - Receiver processes at its own pace"
     */
    private void demonstrateEventPattern() throws Exception {
        logger.info("");
        logger.info("EVENT PATTERN CHARACTERISTICS:");
        logger.info("  Structure:   Noun + Past Verb (Declarative)");
        logger.info("  Examples:    PaymentCreated, CardValidated, AccountDebited");
        logger.info("  Direction:   Publisher → Topic ← ANY subscriber");
        logger.info("  Coupling:    LOOSE - publisher doesn't know subscribers");
        logger.info("  Waiting:     NO - publisher fires and moves on");
        logger.info("");

        logger.info("SIMULATING EVENT-DRIVEN PAYMENT FLOW:");
        logger.info("─────────────────────────────────────────");
        logger.info("");

        // Start listeners BEFORE publishing (simulates running services)
        ExecutorService executor = Executors.newFixedThreadPool(3);
        CountDownLatch eventsReceived = new CountDownLatch(3);

        // FraudService listener
        executor.submit(() -> simulateServiceListening(
            "FraudService", "fraud-check-grp", TOPIC_PAYMENT_EVENTS,
            "Running fraud model... risk score: 0.12 → APPROVED",
            eventsReceived));

        // AuditService listener
        executor.submit(() -> simulateServiceListening(
            "AuditService", "audit-log-grp", TOPIC_PAYMENT_EVENTS,
            "Writing to immutable audit log... entry #4821",
            eventsReceived));

        // AnalyticsService listener
        executor.submit(() -> simulateServiceListening(
            "AnalyticsService", "analytics-grp", TOPIC_PAYMENT_EVENTS,
            "Updating revenue dashboard... $500 added to daily total",
            eventsReceived));

        Thread.sleep(1000); // Give services time to subscribe

        // PaymentService publishes ONE event
        logger.info("PaymentService → publishes PaymentCreated EVENT to Kafka:");
        String paymentEvent = buildPaymentEvent("PAY-EVENT-001", "CUST-001", 500.00);
        logger.info("  Event: {}", paymentEvent);

        long publishStart = System.currentTimeMillis();
        publishToTopic(TOPIC_PAYMENT_EVENTS, "PAY-EVENT-001", paymentEvent);
        long publishTime = System.currentTimeMillis() - publishStart;

        logger.info("  ✓ PaymentService published in {}ms and MOVED ON!", publishTime);
        logger.info("  PaymentService has ZERO knowledge of FraudService, AuditService, AnalyticsService");
        logger.info("  It just published a fact: 'A payment was created'");
        logger.info("");

        // Wait for all services to process
        eventsReceived.await(10, TimeUnit.SECONDS);
        executor.shutdownNow();

        logger.info("");
        logger.info("EVENT PATTERN BENEFITS OBSERVED:");
        logger.info("  ✓ PaymentService published in ~{}ms (non-blocking)", publishTime);
        logger.info("  ✓ All 3 services processed the event independently");
        logger.info("  ✓ If AuditService was DOWN → event queued → processed on recovery");
        logger.info("  ✓ Adding NotificationService = ZERO changes to PaymentService");
        logger.info("  ✓ Each service scales independently based on its own load");
        logger.info("  ✓ Services can be written in ANY language (Java, Python, Go...)");
    }

    /**
     * PART 3: Command to Event Transformation
     *
     * TRAINER SCRIPT:
     * "In practice, you often receive a COMMAND (HTTP POST from client)
     * and need to TRANSFORM it into an EVENT for Kafka.
     *
     * This is the ANTI-CORRUPTION LAYER pattern.
     * External systems speak commands.
     * Internal systems speak events."
     */
    private void demonstrateCommandToEventTransformation() throws Exception {
        logger.info("");
        logger.info("REAL-WORLD SCENARIO:");
        logger.info("  Client sends HTTP POST /payments (a COMMAND)");
        logger.info("  PaymentService transforms it to a Kafka EVENT");
        logger.info("");

        // Step 1: Receive HTTP Command (simulated)
        logger.info("STEP 1: HTTP Request received (COMMAND from external client)");
        logger.info("  POST /api/v1/payments");
        logger.info("  Body: {\"amount\": 750.00, \"currency\": \"USD\",");
        logger.info("         \"merchantId\": \"MERCHANT-001\",");
        logger.info("         \"customerId\": \"CUST-123\"}");
        logger.info("  This is a COMMAND: 'Create a payment'");
        logger.info("");

        Thread.sleep(500);

        // Step 2: Validate and enrich
        logger.info("STEP 2: PaymentService validates and enriches");
        logger.info("  ✓ Validate customer exists");
        logger.info("  ✓ Validate merchant exists");
        logger.info("  ✓ Generate unique paymentId: PAY-TXN-20240115-001");
        logger.info("  ✓ Add correlationId for distributed tracing");
        logger.info("  ✓ Add timestamp");
        logger.info("");

        Thread.sleep(300);

        // Step 3: Persist locally first (important pattern!)
        logger.info("STEP 3: Persist payment LOCALLY first (Outbox Pattern)");
        logger.info("  → Save to payments DB: status=PENDING");
        logger.info("  → This is the SOURCE OF TRUTH");
        logger.info("  → Even if Kafka is down, payment is recorded");
        logger.info("");

        Thread.sleep(300);

        // Step 4: Transform Command → Event and publish
        logger.info("STEP 4: Transform COMMAND → EVENT and publish to Kafka");
        String kafkaEvent = buildPaymentEvent("PAY-TXN-20240115-001", "CUST-123", 750.00);
        logger.info("  Command name:  'CreatePayment'  (imperative, past not recorded)");
        logger.info("  Event name:    'PaymentCreated' (past tense, fact that occurred)");
        logger.info("  Event payload: {}", kafkaEvent);
        logger.info("");

        publishToTopic(TOPIC_PAYMENT_EVENTS, "PAY-TXN-20240115-001", kafkaEvent);
        logger.info("  ✓ EVENT published to Kafka topic: payment-created");
        logger.info("");

        Thread.sleep(300);

        // Step 5: Return response to client
        logger.info("STEP 5: Return HTTP 202 Accepted to client");
        logger.info("  Response: {\"paymentId\": \"PAY-TXN-20240115-001\",");
        logger.info("             \"status\": \"PENDING\",");
        logger.info("             \"message\": \"Payment accepted for processing\"}");
        logger.info("  Note: 202 ACCEPTED (not 200 OK) - processing is ASYNC!");
        logger.info("");

        logger.info("TRANSFORMATION PATTERN SUMMARY:");
        logger.info("  HTTP Command → Validate → Persist → Publish Event → 202 Accepted");
        logger.info("  ─────────────────────────────────────────────────────────────────");
        logger.info("  External world: Commands  (HTTP, gRPC)");
        logger.info("  Internal world: Events    (Kafka)");
        logger.info("  Boundary:       PaymentService API layer");
    }

    /**
     * PART 4: Request-Reply Pattern
     *
     * TRAINER SCRIPT:
     * "Sometimes you genuinely need a response - for example,
     * a payment status query. Kafka supports this with the
     * Request-Reply pattern using a correlation ID and reply topic.
     *
     * But prefer event-driven for most flows. Only use request-reply
     * when you truly need a synchronous response."
     */
    private void demonstrateRequestReplyPattern() throws Exception {
        logger.info("");
        logger.info("WHEN YOU NEED A RESPONSE: Request-Reply Pattern");
        logger.info("Use case: 'What is the current status of payment PAY-001?'");
        logger.info("");
        logger.info("HOW IT WORKS:");
        logger.info("");
        logger.info("  ┌──────────────────────────────────────────────────────┐");
        logger.info("  │                Request-Reply Flow                     │");
        logger.info("  └──────────────────────────────────────────────────────┘");
        logger.info("");
        logger.info("  1. Requester generates unique correlationId");
        logger.info("  2. Requester publishes to [payment-commands] topic:");
        logger.info("     { type: 'GetPaymentStatus',");
        logger.info("       paymentId: 'PAY-001',");
        logger.info("       correlationId: 'CORR-ABC-123',    ← unique per request");
        logger.info("       replyTo: 'payment-command-replies' ← where to send response");
        logger.info("     }");
        logger.info("  3. Requester subscribes to [payment-command-replies]");
        logger.info("     and waits for message where correlationId = 'CORR-ABC-123'");
        logger.info("  4. PaymentService reads command, looks up status");
        logger.info("  5. PaymentService publishes to [payment-command-replies]:");
        logger.info("     { correlationId: 'CORR-ABC-123',");
        logger.info("       paymentId: 'PAY-001',");
        logger.info("       status: 'SETTLED',");
        logger.info("       settledAt: 1705123456789");
        logger.info("     }");
        logger.info("  6. Requester receives reply by matching correlationId");
        logger.info("");

        // Simulate the request
        String correlationId = UUID.randomUUID().toString().substring(0, 8);
        logger.info("SIMULATING Request-Reply:");
        logger.info("  Generating correlationId: {}", correlationId);

        String command = buildStatusQueryCommand("PAY-001", correlationId);
        logger.info("  Publishing query command: {}", command);
        publishToTopic(TOPIC_PAYMENT_COMMANDS, correlationId, command);

        Thread.sleep(500);

        // Simulate the reply (in reality, another service would do this)
        String reply = buildStatusReply("PAY-001", correlationId, "SETTLED");
        logger.info("  [PaymentService received query, looking up status...]");
        Thread.sleep(200);
        logger.info("  Publishing reply: {}", reply);
        publishToTopic(TOPIC_COMMAND_REPLY, correlationId, reply);

        logger.info("");
        logger.info("  Requester matched correlationId '{}' → status=SETTLED", correlationId);
        logger.info("  ✓ Request-Reply complete!");
        logger.info("");

        logger.info("REQUEST-REPLY vs REST API:");
        logger.info("  REST API query:      GET /payments/PAY-001/status");
        logger.info("  Kafka request-reply: Publish query → wait for reply");
        logger.info("");
        logger.info("  When to use Kafka Request-Reply:");
        logger.info("  ✓ When the responder is always a Kafka service");
        logger.info("  ✓ When you want audit trail of queries");
        logger.info("  ✓ When load balancing across multiple responders");
        logger.info("");
        logger.info("  When to use REST instead:");
        logger.info("  ✓ Simple synchronous queries");
        logger.info("  ✓ External clients (mobile apps, browsers)");
        logger.info("  ✓ When latency requirements < 50ms");
    }

    /**
     * PART 5: Complete Comparison Table
     */
    private void printFullComparison() {
        logger.info("");
        logger.info("COMMANDS vs EVENTS - Complete Comparison");
        logger.info("══════════════════════════════════════════════════════════════════");
        logger.info("");
        logger.info("  Aspect              │ COMMAND                  │ EVENT");
        logger.info("  ──────────────────  │  ──────────────────────  │  ─────────────────────");
        logger.info("  Naming              │ CreatePayment            │ PaymentCreated");
        logger.info("  Tense               │ Imperative (future)      │ Past tense (happened)");
        logger.info("  Target              │ Specific service         │ Anyone subscribed");
        logger.info("  Coupling            │ TIGHT                    │ LOOSE");
        logger.info("  Sender waits?       │ YES (synchronous)        │ NO (async)");
        logger.info("  Receiver must be up?│ YES                      │ NO (messages queue)");
        logger.info("  Kafka topic style   │ payment-commands         │ payment-created");
        logger.info("  Multiple receivers? │ NO (one handler)         │ YES (many groups)");
        logger.info("  Replay?             │ Awkward                  │ Natural");
        logger.info("  Failure impact      │ Cascades upstream        │ Isolated");
        logger.info("  Add new consumer    │ Change sender code       │ Zero code change");
        logger.info("  Testing             │ Mock dependencies        │ Just check events");
        logger.info("  Audit trail         │ Requires extra work      │ Built-in (immutable log)");
        logger.info("");
        logger.info("══════════════════════════════════════════════════════════════════");
        logger.info("");
        logger.info("PAYMENT SYSTEM DESIGN GUIDELINES:");
        logger.info("");
        logger.info("  USE COMMANDS (HTTP/gRPC) for:");
        logger.info("  → Client-facing APIs (mobile app → PaymentService)");
        logger.info("  → Real-time queries (check payment status)");
        logger.info("  → Operations that need immediate confirmation");
        logger.info("");
        logger.info("  USE EVENTS (Kafka) for:");
        logger.info("  → Service-to-service communication (PaymentService → FraudService)");
        logger.info("  → State changes (PaymentCreated, PaymentSettled)");
        logger.info("  → Notifications (trigger downstream workflows)");
        logger.info("  → Data replication (update read models)");
        logger.info("  → Audit and compliance (immutable event log)");
        logger.info("");
        logger.info("  GOLDEN RULE:");
        logger.info("  ┌─────────────────────────────────────────────────────────┐");
        logger.info("  │  'If in doubt, use an EVENT.                            │");
        logger.info("  │   Events are the language of business processes.        │");
        logger.info("  │   Commands are just implementation details.'            │");
        logger.info("  │                    - Domain-Driven Design principle     │");
        logger.info("  └─────────────────────────────────────────────────────────┘");
    }

    // ── Helper Methods ──────────────────────────────────────────────────────

    /**
     * Simulate a service listening to a topic in a separate thread
     */
    private void simulateServiceListening(String serviceName, String groupId,
                                           String topic, String action,
                                           CountDownLatch latch) {
        Properties props = buildConsumerConfig(groupId);

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Collections.singletonList(topic));

            long deadline = System.currentTimeMillis() + 10_000;

            while (System.currentTimeMillis() < deadline
                    && !Thread.currentThread().isInterrupted()) {

                ConsumerRecords<String, String> records =
                    consumer.poll(Duration.ofMillis(500));

                for (ConsumerRecord<String, String> record : records) {
                    logger.info("  [{}] ← Received event: key={}", serviceName, record.key());

                    try { Thread.sleep(150); } // Simulate processing
                    catch (InterruptedException e) { return; }

                    logger.info("  [{}] ✓ Processing: {}", serviceName, action);
                    latch.countDown();
                    return;
                }
            }
        } catch (Exception e) {
            if (!Thread.currentThread().isInterrupted()) {
                logger.debug("[{}] Listener ended: {}", serviceName, e.getMessage());
            }
        }
    }

    /**
     * Build a command JSON structure
     */
    private String buildCommand(String commandType, String commandId,
                                 String paymentId, String customerId,
                                 double amount, String targetService) {
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("commandType", commandType);
            node.put("commandId", commandId);
            node.put("paymentId", paymentId);
            node.put("customerId", customerId);
            node.put("amount", amount);
            node.put("targetService", targetService);    // Commands target a specific service
            node.put("replyTo", TOPIC_COMMAND_REPLY);   // Where to send the response
            node.put("correlationId", UUID.randomUUID().toString());
            node.put("issuedAt", System.currentTimeMillis());
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            return "{}";
        }
    }

    /**
     * Build a payment event JSON structure
     * Note: PAST TENSE name, no targetService field
     */
    private String buildPaymentEvent(String paymentId, String customerId, double amount) {
        try {
            ObjectNode node = objectMapper.createObjectNode();
            // Events are FACTS - past tense
            node.put("eventType", "PaymentCreated");     // NOT "CreatePayment"!
            node.put("eventId", UUID.randomUUID().toString());
            node.put("paymentId", paymentId);
            node.put("customerId", customerId);
            node.put("amount", amount);
            node.put("currency", "USD");
            node.put("status", "CREATED");
            node.put("merchantId", "MERCHANT-001");
            node.put("correlationId", UUID.randomUUID().toString());
            node.put("occurredAt", System.currentTimeMillis()); // Events have 'occurredAt'
            // NOTE: No 'targetService' field - events don't care who listens!
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            return "{}";
        }
    }

    /**
     * Build a status query command (for Request-Reply pattern)
     */
    private String buildStatusQueryCommand(String paymentId, String correlationId) {
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("commandType", "GetPaymentStatus");
            node.put("paymentId", paymentId);
            node.put("correlationId", correlationId);
            node.put("replyTo", TOPIC_COMMAND_REPLY);
            node.put("issuedAt", System.currentTimeMillis());
            node.put("timeoutMs", 5000);
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            return "{}";
        }
    }

    /**
     * Build a status query reply
     */
    private String buildStatusReply(String paymentId, String correlationId, String status) {
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("replyType", "PaymentStatusResponse");
            node.put("paymentId", paymentId);
            node.put("correlationId", correlationId);   // MUST match request correlationId
            node.put("status", status);
            node.put("settledAt", System.currentTimeMillis() - 60000);
            node.put("repliedAt", System.currentTimeMillis());
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            return "{}";
        }
    }

    /**
     * Publish a message to a Kafka topic
     */
    private void publishToTopic(String topic, String key, String value) throws Exception {
        Properties props = buildProducerConfig();

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            ProducerRecord<String, String> record =
                new ProducerRecord<>(topic, key, value);

            RecordMetadata metadata = producer.send(record).get();
            logger.debug("  Published to {}: partition={}, offset={}",
                topic, metadata.partition(), metadata.offset());
        }
    }

    // ── Producer / Consumer Configuration ───────────────────────────────────

    private Properties buildProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "command-event-demo-producer");
        return props;
    }

    private Properties buildConsumerConfig(String groupId) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "5");
        return props;
    }
}