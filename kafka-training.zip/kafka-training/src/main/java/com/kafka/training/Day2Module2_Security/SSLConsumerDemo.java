package com.kafka.training.Day2Module2_Security;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

/**
 * ============================================================
 * DAY 2 - MODULE 2: KAFKA SECURITY
 * Sub-Demo 2: SSL/TLS Consumer + ACL Explanation
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - SSL consumer configuration
 * - ACL (Access Control List) for topic authorization
 * - SASL (Simple Authentication and Security Layer) overview
 * - Security best practices for payment systems
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module2_Security.SSLConsumerDemo"
 * (Run SSLProducerDemo first!)
 * ============================================================
 */
public class SSLConsumerDemo {

    private static final Logger logger = LoggerFactory.getLogger(SSLConsumerDemo.class);
    private static final String BOOTSTRAP_SERVERS_SSL = "localhost:9096";
    private static final String SSL_DIR = "docker/ssl/";
    private static final String KEYSTORE_PATH = SSL_DIR + "kafka.client.keystore.jks";
    private static final String TRUSTSTORE_PATH = SSL_DIR + "kafka.client.truststore.jks";
    private static final String SSL_PASSWORD = "kafka-training-pass";
    private static final String TOPIC = "payment-created";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 2: SSL/TLS Consumer Demo");
        logger.info("============================================================");

        SSLConsumerDemo demo = new SSLConsumerDemo();

        // DEMO 1: SSL Consumer
        demo.consumeWithSSL();

        // DEMO 2: ACL Explanation
        demo.explainACLs();

        // DEMO 3: Security Architecture
        demo.explainSecurityArchitecture();

        logger.info("============================================================");
        logger.info("  SSL Consumer Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: SSL Consumer
     */
    private void consumeWithSSL() throws Exception {
        logger.info("");
        logger.info("--- DEMO 1: Consuming Payment Events with SSL/TLS ---");

        File keystore = new File(KEYSTORE_PATH);
        if (!keystore.exists()) {
            logger.warn("SSL certs not found - skipping SSL consume demo");
            logger.warn("Run generate-certs.bat and docker-compose-ssl.yml first");
            demoSSLConfig();
            return;
        }

        Properties props = buildSSLConsumerConfig("ssl-payment-consumer-group");

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Collections.singletonList(TOPIC));
            logger.info("Connected via SSL to: {}", BOOTSTRAP_SERVERS_SSL);
            logger.info("Polling for secure payment events...");
            logger.info("");

            int count = 0;
            long endTime = System.currentTimeMillis() + 10_000;

            while (count < 5 && System.currentTimeMillis() < endTime) {
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(2000));

                for (ConsumerRecord<String, String> record : records) {
                    logger.info("✓ [SSL] Secure message consumed:");
                    logger.info("    partition={}, offset={}", record.partition(), record.offset());
                    logger.info("    key={}", record.key());
                    logger.info("    value={}", record.value());
                    count++;
                }

                if (records.isEmpty()) {
                    logger.info("  No messages (ensure SSLProducerDemo ran first)");
                }
            }

            consumer.commitSync();
            logger.info("");
            logger.info("✓ Consumed {} messages over encrypted TLS channel", count);

        } catch (Exception e) {
            logger.error("SSL connection failed: {}", e.getMessage());
            logger.info("Ensure SSL broker is running:");
            logger.info("  docker-compose -f docker/docker-compose-ssl.yml up -d");
        }
    }

    /**
     * Show SSL config even without certs (for trainer reference)
     */
    private void demoSSLConfig() {
        logger.info("");
        logger.info("SSL Consumer Configuration (for reference):");
        logger.info("  security.protocol=SSL");
        logger.info("  ssl.keystore.location=/path/to/kafka.client.keystore.jks");
        logger.info("  ssl.keystore.password=<password>");
        logger.info("  ssl.key.password=<password>");
        logger.info("  ssl.truststore.location=/path/to/kafka.client.truststore.jks");
        logger.info("  ssl.truststore.password=<password>");
    }

    /**
     * DEMO 2: ACL (Access Control List) Explanation
     *
     * TRAINER SCRIPT:
     * "ACLs control WHO can do WHAT on WHICH resource.
     *  Without ACLs, any authenticated client can read/write ANY topic.
     *  With ACLs, we restrict:
     *  - PaymentService: Write to payment-created only
     *  - FraudService: Read payment-created, Write fraud-result
     *  - AuditService: Read ALL topics, Write NONE"
     */
    private void explainACLs() {
        logger.info("");
        logger.info("--- DEMO 2: Kafka ACLs (Access Control Lists) ---");
        logger.info("");
        logger.info("ACL STRUCTURE: Principal → Operation → Resource");
        logger.info("");
        logger.info("PAYMENT SYSTEM ACL DESIGN:");
        logger.info("");
        logger.info("  PaymentService (CN=payment-service):");
        logger.info("    ALLOW WRITE  payment-created     (produce new payments)");
        logger.info("    ALLOW READ   payment-created     (read own events)");
        logger.info("    DENY  *      fraud-result        (cannot read fraud data)");
        logger.info("");
        logger.info("  FraudService (CN=fraud-service):");
        logger.info("    ALLOW READ   payment-created     (read payments to check)");
        logger.info("    ALLOW WRITE  fraud-result        (write fraud decisions)");
        logger.info("    DENY  *      payment-settled     (cannot touch settlements)");
        logger.info("");
        logger.info("  SettlementService (CN=settlement-service):");
        logger.info("    ALLOW READ   fraud-result        (read approved payments)");
        logger.info("    ALLOW WRITE  payment-settled     (write settlement events)");
        logger.info("");
        logger.info("  AuditService (CN=audit-service):");
        logger.info("    ALLOW READ   *                   (read ALL topics)");
        logger.info("    DENY  WRITE  *                   (cannot write anything)");
        logger.info("");
        logger.info("CLI COMMANDS TO SET ACLs:");
        logger.info("  # Allow payment-service to write to payment-created:");
        logger.info("  docker exec kafka-broker-1 kafka-acls \\");
        logger.info("    --bootstrap-server localhost:9092 \\");
        logger.info("    --add \\");
        logger.info("    --allow-principal 'User:CN=payment-service' \\");
        logger.info("    --operation Write \\");
        logger.info("    --topic payment-created");
        logger.info("");
        logger.info("  # List all ACLs:");
        logger.info("  docker exec kafka-broker-1 kafka-acls \\");
        logger.info("    --bootstrap-server localhost:9092 --list");
    }

    /**
     * DEMO 3: Complete Security Architecture
     */
    private void explainSecurityArchitecture() {
        logger.info("");
        logger.info("--- DEMO 3: Kafka Security Architecture for Payments ---");
        logger.info("");
        logger.info("LAYER 1: Network Security");
        logger.info("  - Kafka brokers in PRIVATE subnet (no public internet access)");
        logger.info("  - Only payment microservices can reach Kafka port 9096");
        logger.info("  - Security Groups / Firewall rules enforce this");
        logger.info("");
        logger.info("LAYER 2: Transport Security (SSL/TLS)");
        logger.info("  - All client ↔ broker communication encrypted");
        logger.info("  - Mutual TLS: both sides authenticate");
        logger.info("  - TLS 1.3 preferred (strongest available)");
        logger.info("");
        logger.info("LAYER 3: Authentication (Who are you?)");
        logger.info("  Option A: mTLS (client certificates) ← Our demo");
        logger.info("  Option B: SASL/PLAIN (username/password)");
        logger.info("  Option C: SASL/SCRAM (hashed credentials)");
        logger.info("  Option D: SASL/OAUTHBEARER (JWT tokens from OAuth2 server)");
        logger.info("  Recommendation: SASL/OAUTHBEARER for microservices");
        logger.info("");
        logger.info("LAYER 4: Authorization (What can you do?)");
        logger.info("  - Kafka ACLs (built-in)");
        logger.info("  - OR external authorization (Ranger, OPA)");
        logger.info("");
        logger.info("LAYER 5: Data Security");
        logger.info("  - Encrypt PII fields before producing (application-level encryption)");
        logger.info("  - Use field-level encryption for card numbers, SSN, etc.");
        logger.info("  - Kafka itself doesn't encrypt at rest by default");
        logger.info("  - Use encrypted EBS volumes (AWS) or encrypted PVCs (K8s)");
        logger.info("");
        logger.info("LAYER 6: Audit & Monitoring");
        logger.info("  - Log all authentication events");
        logger.info("  - Alert on ACL violations");
        logger.info("  - Monitor for unusual consumption patterns");
    }

    private Properties buildSSLConsumerConfig(String groupId) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS_SSL);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");

        // SSL Configuration
        props.put("security.protocol", "SSL");
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
            new File(KEYSTORE_PATH).getAbsolutePath());
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, SSL_PASSWORD);
        props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, SSL_PASSWORD);
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
            new File(TRUSTSTORE_PATH).getAbsolutePath());
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, SSL_PASSWORD);
        props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "https");

        return props;
    }
}