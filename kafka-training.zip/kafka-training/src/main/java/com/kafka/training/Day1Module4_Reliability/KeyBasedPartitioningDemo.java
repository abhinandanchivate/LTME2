package com.kafka.training.Day1Module4_Reliability;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.Cluster;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * ============================================================
 * DAY 1 - MODULE 4: RELIABILITY & ORDERING
 * Sub-Demo 3: Key-Based Partitioning & Ordering Guarantees
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - Kafka ordering guarantees (within partition only)
 * - Key-based partitioning for ordered streams
 * - Custom partitioners
 * - Hot partition problem and solutions
 * - Partitioning strategy for payment transactions
 *
 * TRAINER NOTES:
 * KEY INSIGHT: Kafka guarantees order WITHIN a partition only.
 * To maintain order for a specific entity (customer/payment),
 * all events for that entity must go to the SAME partition.
 * Solution: Use the entity ID as the message key.
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module4_Reliability.KeyBasedPartitioningDemo"
 * ============================================================
 */
public class KeyBasedPartitioningDemo {

    private static final Logger logger = LoggerFactory.getLogger(KeyBasedPartitioningDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final String TOPIC = "payment-created";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 4: Key-Based Partitioning & Ordering");
        logger.info("============================================================");

        KeyBasedPartitioningDemo demo = new KeyBasedPartitioningDemo();

        // DEMO 1: Ordering guarantees explained
        demo.explainOrderingGuarantees();

        // DEMO 2: Key-based partitioning for payment ordering
        demo.demonstrateKeyBasedPartitioning();

        // DEMO 3: Custom partitioner for VIP customers
        demo.demonstrateCustomPartitioner();

        // DEMO 4: Design a partitioning strategy
        demo.designPartitioningStrategy();

        logger.info("============================================================");
        logger.info("  Key-Based Partitioning Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Ordering Guarantees
     *
     * TRAINER SCRIPT:
     * "Kafka ONLY guarantees order within a single partition.
     *  Across partitions, there is NO ordering guarantee.
     *
     *  For payments: all events for CUST-001 must go to the same partition
     *  so we know: CREATED → FRAUD_CHECK → APPROVED → SETTLED in order."
     */
    private void explainOrderingGuarantees() {
        logger.info("");
        logger.info("--- DEMO 1: Kafka Ordering Guarantees ---");
        logger.info("");
        logger.info("ORDERING RULE: Order is guaranteed WITHIN a partition, NOT across partitions");
        logger.info("");
        logger.info("EXAMPLE - Payment lifecycle events for CUST-001:");
        logger.info("");
        logger.info("  ✓ CORRECT (same partition, ordered):");
        logger.info("  Partition 0: [CREATED] → [FRAUD_CHECK] → [APPROVED] → [SETTLED]");
        logger.info("               offset=1      offset=2         offset=3     offset=4");
        logger.info("  Consumer reads in EXACT ORDER: CREATED, FRAUD_CHECK, APPROVED, SETTLED");
        logger.info("");
        logger.info("  ✗ WRONG (different partitions, no order):");
        logger.info("  Partition 0: [CREATED]  offset=1");
        logger.info("  Partition 1: [APPROVED] offset=7");
        logger.info("  Partition 2: [SETTLED]  offset=3");
        logger.info("  Consumer might read: APPROVED, SETTLED, CREATED (wrong order!)");
        logger.info("");
        logger.info("SOLUTION: Use customerId or paymentId as the KEY");
        logger.info("  hash(key) % numPartitions = partition assignment");
        logger.info("  Same key → Same partition → Ordered events");
    }

    /**
     * DEMO 2: Key-Based Partitioning
     */
    private void demonstrateKeyBasedPartitioning() throws Exception {
        logger.info("");
        logger.info("--- DEMO 2: Key-Based Partitioning for Payment Ordering ---");
        logger.info("");

        Properties props = buildProducerConfig();

        // Payment event sequence for 3 different customers
        List<PaymentEvent> paymentEvents = Arrays.asList(
            // Customer AAA: CREATED → FRAUD_CHECK → APPROVED → SETTLED
            new PaymentEvent("PAY-AAA-001", "CUST-AAA", "CREATED", 500.00),
            new PaymentEvent("PAY-BBB-001", "CUST-BBB", "CREATED", 1200.00),
            new PaymentEvent("PAY-CCC-001", "CUST-CCC", "CREATED", 75.00),
            new PaymentEvent("PAY-AAA-001", "CUST-AAA", "FRAUD_CHECK", 500.00),
            new PaymentEvent("PAY-BBB-001", "CUST-BBB", "FRAUD_CHECK", 1200.00),
            new PaymentEvent("PAY-AAA-001", "CUST-AAA", "APPROVED", 500.00),
            new PaymentEvent("PAY-CCC-001", "CUST-CCC", "FRAUD_CHECK", 75.00),
            new PaymentEvent("PAY-BBB-001", "CUST-BBB", "APPROVED", 1200.00),
            new PaymentEvent("PAY-AAA-001", "CUST-AAA", "SETTLED", 500.00),
            new PaymentEvent("PAY-CCC-001", "CUST-CCC", "APPROVED", 75.00),
            new PaymentEvent("PAY-BBB-001", "CUST-BBB", "SETTLED", 1200.00),
            new PaymentEvent("PAY-CCC-001", "CUST-CCC", "SETTLED", 75.00)
        );

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            for (PaymentEvent event : paymentEvents) {
                String paymentJson = String.format(
                    "{\"paymentId\":\"%s\",\"customerId\":\"%s\",\"status\":\"%s\",\"amount\":%.2f}",
                    event.paymentId, event.customerId, event.status, event.amount
                );

                // KEY = customerId: all events for same customer → same partition
                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC, event.customerId, paymentJson);

                RecordMetadata metadata = producer.send(record).get();

                logger.info("  Produced: customerId={}, status={} → partition={}, offset={}",
                    event.customerId,
                    event.status,
                    metadata.partition(),
                    metadata.offset());
            }
        }

        logger.info("");
        logger.info("OBSERVE: All events for CUST-AAA → same partition (ordered!)");
        logger.info("         All events for CUST-BBB → same partition (ordered!)");
        logger.info("         All events for CUST-CCC → same partition (ordered!)");
    }

    /**
     * DEMO 3: Custom Partitioner for VIP customers
     *
     * TRAINER SCRIPT:
     * "Custom partitioners let you implement business logic for
     *  partition assignment. For example: VIP payments always go to
     *  partition 0 which has a dedicated consumer for fast processing."
     */
    private void demonstrateCustomPartitioner() throws Exception {
        logger.info("");
        logger.info("--- DEMO 3: Custom Partitioner (VIP Customer Priority) ---");
        logger.info("VIP customers → Partition 0 (dedicated fast-path consumer)");
        logger.info("Regular customers → Partitions 1, 2 (round-robin)");
        logger.info("");

        Properties props = buildProducerConfig();
        // Override with custom partitioner
        props.put(ProducerConfig.PARTITIONER_CLASS_CONFIG,
            VIPPaymentPartitioner.class.getName());

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            // VIP customers
            String[] vipCustomers = {"VIP-PLATINUM-001", "VIP-GOLD-002"};
            // Regular customers
            String[] regularCustomers = {"REG-001", "REG-002", "REG-003", "REG-004"};

            // Produce VIP payments
            for (String custId : vipCustomers) {
                String paymentJson = String.format(
                    "{\"paymentId\":\"PAY-%s\",\"customerId\":\"%s\",\"tier\":\"VIP\",\"amount\":50000.00}",
                    custId, custId
                );
                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC, custId, paymentJson);
                RecordMetadata metadata = producer.send(record).get();
                logger.info("  VIP Customer {}: → partition={} (FAST LANE)", custId, metadata.partition());
            }

            // Produce Regular payments
            for (String custId : regularCustomers) {
                String paymentJson = String.format(
                    "{\"paymentId\":\"PAY-%s\",\"customerId\":\"%s\",\"tier\":\"REG\",\"amount\":150.00}",
                    custId, custId
                );
                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC, custId, paymentJson);
                RecordMetadata metadata = producer.send(record).get();
                logger.info("  Regular Customer {}: → partition={} (STANDARD)", custId, metadata.partition());
            }
        }
    }

    /**
     * DEMO 4: Partitioning Strategy Design
     *
     * TRAINER SCRIPT:
     * "Let me walk you through designing a partitioning strategy
     *  for our payment system."
     */
    private void designPartitioningStrategy() {
        logger.info("");
        logger.info("--- DEMO 4: Payment Partitioning Strategy Design ---");
        logger.info("");
        logger.info("STEP 1: Identify your ordering requirements");
        logger.info("  Q: Do we need events for the SAME PAYMENT ordered?");
        logger.info("  A: YES → Key = paymentId");
        logger.info("  Q: Do we need events for the SAME CUSTOMER ordered?");
        logger.info("  A: YES → Key = customerId");
        logger.info("  Q: Do we need events for the SAME MERCHANT ordered?");
        logger.info("  A: MAYBE → Consider merchantId as key for merchant reporting");
        logger.info("");
        logger.info("STEP 2: Consider partition count");
        logger.info("  - More partitions = more parallelism but more overhead");
        logger.info("  - Rule of thumb: partitions = max(expected_consumer_count * 2, 10)");
        logger.info("  - For payments: 12-24 partitions is common");
        logger.info("  - Partitions can be INCREASED but not decreased");
        logger.info("");
        logger.info("STEP 3: Avoid hot partitions");
        logger.info("  HOT PARTITION PROBLEM:");
        logger.info("  - If Amazon uses your platform, key=merchantId would put ALL");
        logger.info("    Amazon events on ONE partition → bottleneck!");
        logger.info("  SOLUTIONS:");
        logger.info("  a) Use paymentId (more uniform distribution)");
        logger.info("  b) Use composite key: merchantId + paymentId hash");
        logger.info("  c) Use custom partitioner with skew detection");
        logger.info("");
        logger.info("FINAL RECOMMENDATION for payment-created topic:");
        logger.info("  Key:        paymentId (most uniform, guarantees per-payment order)");
        logger.info("  Partitions: 12 (room to scale to 12 consumer instances)");
        logger.info("  RF:         3 (tolerates 1 broker failure)");
        logger.info("  Min ISR:    2");
    }

    private Properties buildProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
        return props;
    }

    // Simple data class for payment events
    static class PaymentEvent {
        String paymentId;
        String customerId;
        String status;
        double amount;

        PaymentEvent(String paymentId, String customerId, String status, double amount) {
            this.paymentId = paymentId;
            this.customerId = customerId;
            this.status = status;
            this.amount = amount;
        }
    }
}

/**
 * Custom Partitioner: VIP customers get dedicated partition
 *
 * TRAINER NOTES:
 * "Implementing Partitioner interface gives full control over
 *  which partition a message goes to."
 */
class VIPPaymentPartitioner implements Partitioner {

    private static final Logger logger = LoggerFactory.getLogger(VIPPaymentPartitioner.class);

    @Override
    public int partition(String topic, Object key, byte[] keyBytes,
                         Object value, byte[] valueBytes, Cluster cluster) {
        String customerId = key.toString();
        int numPartitions = cluster.partitionCountForTopic(topic);

        // VIP customers → always partition 0
        if (customerId.startsWith("VIP-")) {
            logger.debug("VIP Customer {} → Partition 0 (FAST LANE)", customerId);
            return 0;
        }

        // Regular customers → distribute across remaining partitions (1 to N-1)
        int hash = Math.abs(customerId.hashCode());
        int partition = (hash % (numPartitions - 1)) + 1;
        logger.debug("Regular Customer {} → Partition {} (STANDARD)", customerId, partition);
        return partition;
    }

    @Override
    public void close() {
        // No resources to close
    }

    @Override
    public void configure(Map<String, ?> configs) {
        // No configuration needed
    }
}