package com.kafka.training.Day1Module3_ProducersConsumers;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/**
 * ============================================================
 * DAY 1 - MODULE 3: PRODUCERS & CONSUMERS
 * Sub-Demo 3: Consumer Groups
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - Consumer groups and partition assignment
 * - Horizontal scaling of consumers
 * - Rebalancing when consumers join/leave
 * - Multiple independent consumer groups
 *
 * TRAINER NOTES:
 * This is a KEY demo! Show students:
 * 1. One consumer reads ALL partitions
 * 2. Add second consumer → partitions are SPLIT
 * 3. Add third consumer → further split
 * 4. MORE consumers than partitions → some consumers idle
 *
 * ANALOGY:
 * "A consumer group is like a team of workers sharing a pile of work.
 *  If there are 3 partitions and 3 workers, each gets 1 partition.
 *  If there are 3 partitions and 6 workers, 3 workers sit idle."
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module3_ProducersConsumers.ConsumerGroupDemo"
 * ============================================================
 */
public class ConsumerGroupDemo {

    private static final Logger logger = LoggerFactory.getLogger(ConsumerGroupDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final String TOPIC = "payment-created";
    private static final String GROUP_ID = "payment-fraud-check-group";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 3: Consumer Group Demo");
        logger.info("============================================================");

        ConsumerGroupDemo demo = new ConsumerGroupDemo();

        logger.info("");
        logger.info("SCENARIO: Payment Fraud Check Service");
        logger.info("Topic 'payment-created' has 3 partitions");
        logger.info("We will scale the Fraud Check service from 1 to 3 instances");
        logger.info("");

        // PHASE 1: Single consumer reads all 3 partitions
        logger.info("=== PHASE 1: Single Consumer Instance ===");
        logger.info("Consumer-1 will handle ALL 3 partitions (max throughput = 1x)");
        demo.runSingleConsumer();

        Thread.sleep(3000);

        // PHASE 2: Two consumers split the partitions
        logger.info("");
        logger.info("=== PHASE 2: Two Consumer Instances (Scale Out) ===");
        logger.info("Partitions will be SPLIT: Consumer-1→P0,P1  Consumer-2→P2");
        demo.runTwoConsumers();

        Thread.sleep(3000);

        // PHASE 3: Three consumers - one per partition (maximum parallelism)
        logger.info("");
        logger.info("=== PHASE 3: Three Consumer Instances (Maximum Parallelism) ===");
        logger.info("Each consumer gets EXACTLY 1 partition");
        demo.runThreeConsumers();

        logger.info("");
        logger.info("============================================================");
        logger.info("  Consumer Group Demo Complete!");
        logger.info("  KEY INSIGHT: Max parallelism = number of partitions");
        logger.info("  More consumers than partitions = idle consumers");
        logger.info("============================================================");
    }

    /**
     * PHASE 1: Single Consumer - handles all partitions
     */
    private void runSingleConsumer() throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(1);
        CountDownLatch latch = new CountDownLatch(1);

        executor.submit(() -> {
            runConsumerInstance("Consumer-1", GROUP_ID + "-phase1", latch);
        });

        // Let it run for 8 seconds
        latch.await(8, TimeUnit.SECONDS);
        executor.shutdownNow();
        executor.awaitTermination(3, TimeUnit.SECONDS);
    }

    /**
     * PHASE 2: Two Consumers - partitions split between them
     */
    private void runTwoConsumers() throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(2);
        CountDownLatch latch = new CountDownLatch(1);

        // Start both consumers with SAME group ID
        executor.submit(() -> runConsumerInstance("Consumer-1", GROUP_ID + "-phase2", latch));

        // Small delay so Consumer-1 starts first
        Thread.sleep(1000);
        executor.submit(() -> runConsumerInstance("Consumer-2", GROUP_ID + "-phase2", latch));

        // Let them run for 10 seconds (watch for rebalance log)
        latch.await(10, TimeUnit.SECONDS);
        executor.shutdownNow();
        executor.awaitTermination(3, TimeUnit.SECONDS);
    }

    /**
     * PHASE 3: Three Consumers - maximum parallelism
     */
    private void runThreeConsumers() throws Exception {
        ExecutorService executor = Executors.newFixedThreadPool(3);
        CountDownLatch latch = new CountDownLatch(1);

        String groupId = GROUP_ID + "-phase3";

        executor.submit(() -> runConsumerInstance("Consumer-1", groupId, latch));
        Thread.sleep(500);
        executor.submit(() -> runConsumerInstance("Consumer-2", groupId, latch));
        Thread.sleep(500);
        executor.submit(() -> runConsumerInstance("Consumer-3", groupId, latch));

        // Let them run for 10 seconds
        latch.await(10, TimeUnit.SECONDS);
        executor.shutdownNow();
        executor.awaitTermination(3, TimeUnit.SECONDS);
    }

    /**
     * Individual consumer instance runner
     *
     * TRAINER SCRIPT:
     * "Watch the logs when new consumers join!
     *  You'll see 'Rebalance' - that's Kafka redistributing partitions.
     *  The group coordinator (one of the brokers) manages this."
     */
    private void runConsumerInstance(String consumerName, String groupId, CountDownLatch latch) {
        Properties props = buildConsumerConfig(groupId, consumerName);

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {

            // Add a rebalance listener to log partition assignments
            consumer.subscribe(
                Collections.singletonList(TOPIC),
                new ConsumerRebalanceListener() {
                    @Override
                    public void onPartitionsRevoked(Collection<TopicPartition> partitions) {
                        logger.info("[{}] ⚠ REBALANCE: Partitions REVOKED: {}",
                            consumerName, partitions);
                    }

                    @Override
                    public void onPartitionsAssigned(Collection<TopicPartition> partitions) {
                        logger.info("[{}] ✓ REBALANCE: Partitions ASSIGNED: {}",
                            consumerName, partitions);
                    }
                }
            );

            while (!Thread.currentThread().isInterrupted()) {
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));

                for (ConsumerRecord<String, String> record : records) {
                    logger.info("[{}] Consumed: partition={}, offset={}, key={}",
                        consumerName,
                        record.partition(),
                        record.offset(),
                        record.key());

                    // Simulate processing time
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
            }

        } catch (Exception e) {
            if (!e.getMessage().contains("interrupted")) {
                logger.error("[{}] Consumer error: {}", consumerName, e.getMessage());
            }
        }
    }

    private Properties buildConsumerConfig(String groupId, String clientId) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.CLIENT_ID_CONFIG, clientId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "5");
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, "1000");
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "10000");
        return props;
    }
}