package com.kafka.training.Day2Module4_Pipeline;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.*;

/**
 * ============================================================
 * DAY 2 - MODULE 4: END-TO-END EVENT PIPELINE
 * Pipeline Orchestrator - Runs ALL services simultaneously
 * ============================================================
 *
 * OVERVIEW:
 * This class starts all 3 pipeline services concurrently
 * to demonstrate the complete end-to-end event flow:
 *
 *   PaymentService → [payment-created]
 *                         ↓
 *                    FraudService → [fraud-result]
 *                                       ↓
 *                                  SettlementService → [payment-settled]
 *
 * WHAT TO OBSERVE:
 * 1. PaymentService generates payments every 2 seconds
 * 2. FraudService immediately processes each payment
 * 3. High-value payments (>$50k) are rejected
 * 4. Approved payments flow to SettlementService
 * 5. SettlementService calculates fees and settles
 * 6. All services are INDEPENDENT - no direct coupling
 *
 * TRAINER NOTES:
 * Run this as the MAIN DEMO for Day 2 Module 4.
 * Open Kafka UI (http://localhost:8080) alongside this.
 * Show:
 * - Messages flowing through each topic in real-time
 * - Consumer group lag
 * - Partition distribution
 * - DLQ accumulating failed/rejected events
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module4_Pipeline.PipelineOrchestrator"
 * Press Ctrl+C to stop all services
 * ============================================================
 */
public class PipelineOrchestrator {

    private static final Logger logger = LoggerFactory.getLogger(PipelineOrchestrator.class);

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 4: End-to-End Payment Pipeline");
        logger.info("  Starting ALL services simultaneously...");
        logger.info("============================================================");

        printPipelineArchitecture();

        // Thread pool for all services
        ExecutorService executor = Executors.newFixedThreadPool(3);

        // Shared latch for graceful shutdown
        CountDownLatch shutdownLatch = new CountDownLatch(1);

        // Register shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("");
            logger.info("============================================================");
            logger.info("  Shutdown signal received - stopping all services...");
            logger.info("============================================================");
            executor.shutdownNow();
            shutdownLatch.countDown();
        }));

        logger.info("");
        logger.info("Starting services in parallel...");
        logger.info("Open http://localhost:8080 to watch the pipeline in Kafka UI");
        logger.info("Press Ctrl+C to stop");
        logger.info("");
        Thread.sleep(2000); // Brief pause for readability

        // ─────────────────────────────────────────────────────
        // START SERVICE 1: PaymentService
        // ─────────────────────────────────────────────────────
        Future<?> paymentFuture = executor.submit(() -> {
            try {
                logger.info("[Orchestrator] Starting PaymentService...");
                new PaymentService().runPaymentSimulation();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                logger.info("[Orchestrator] PaymentService stopped");
            } catch (Exception e) {
                logger.error("[Orchestrator] PaymentService error: {}", e.getMessage());
            }
        });

        // Brief delay so PaymentService starts and produces some events first
        Thread.sleep(1000);

        // ─────────────────────────────────────────────────────
        // START SERVICE 2: FraudService
        // ─────────────────────────────────────────────────────
        Future<?> fraudFuture = executor.submit(() -> {
            try {
                logger.info("[Orchestrator] Starting FraudService...");
                new FraudService().run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                logger.info("[Orchestrator] FraudService stopped");
            } catch (Exception e) {
                logger.error("[Orchestrator] FraudService error: {}", e.getMessage());
            }
        });

        // Brief delay
        Thread.sleep(500);

        // ─────────────────────────────────────────────────────
        // START SERVICE 3: SettlementService
        // ─────────────────────────────────────────────────────
        Future<?> settlementFuture = executor.submit(() -> {
            try {
                logger.info("[Orchestrator] Starting SettlementService...");
                new SettlementService().run();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                logger.info("[Orchestrator] SettlementService stopped");
            } catch (Exception e) {
                logger.error("[Orchestrator] SettlementService error: {}", e.getMessage());
            }
        });

        logger.info("");
        logger.info("============================================================");
        logger.info("  ALL SERVICES RUNNING!");
        logger.info("  Pipeline Flow:");
        logger.info("  PaymentService → [payment-created]");
        logger.info("       → FraudService → [fraud-result]");
        logger.info("            → SettlementService → [payment-settled]");
        logger.info("  Failures → [payment-dlq]");
        logger.info("============================================================");
        logger.info("");
        logger.info("  TRAINER DEMO POINTS:");
        logger.info("  1. Watch logs - see the event chain in action");
        logger.info("  2. Open http://localhost:8080 - watch topics fill");
        logger.info("  3. Payment #7 is high-value → fraud rejected");
        logger.info("  4. SettlementService skips rejected payments");
        logger.info("  5. payment-dlq accumulates failures");
        logger.info("");

        // Wait for shutdown signal
        try {
            shutdownLatch.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Cleanup
        executor.shutdown();
        try {
            if (!executor.awaitTermination(10, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }

        logger.info("============================================================");
        logger.info("  Pipeline Orchestrator stopped. All services shut down.");
        logger.info("============================================================");
    }

    /**
     * Print the pipeline architecture for trainer demo
     */
    private static void printPipelineArchitecture() {
        logger.info("");
        logger.info("  PIPELINE ARCHITECTURE:");
        logger.info("  ┌─────────────────────────────────────────────────────────┐");
        logger.info("  │                Payment Processing Pipeline               │");
        logger.info("  └─────────────────────────────────────────────────────────┘");
        logger.info("");
        logger.info("  ┌──────────────────┐");
        logger.info("  │  PaymentService  │ ← Simulates payment gateway");
        logger.info("  │  (Producer)      │   Generates 1 payment/2 sec");
        logger.info("  └────────┬─────────┘");
        logger.info("           │ PaymentCreated events");
        logger.info("           ▼");
        logger.info("  [payment-created topic]  (3 partitions, RF=3)");
        logger.info("           │");
        logger.info("           ▼");
        logger.info("  ┌──────────────────┐");
        logger.info("  │  FraudService    │ ← ML-like fraud detection");
        logger.info("  │  (Consumer +     │   Approves or rejects");
        logger.info("  │   Producer)      │   >$50k → REJECTED");
        logger.info("  └────────┬─────────┘");
        logger.info("           │ FraudResult events");
        logger.info("           ▼");
        logger.info("  [fraud-result topic]     (3 partitions, RF=3)");
        logger.info("           │");
        logger.info("           ▼");
        logger.info("  ┌──────────────────┐");
        logger.info("  │ SettlementService│ ← Processes APPROVED only");
        logger.info("  │  (Consumer +     │   Calculates 1.5% fee");
        logger.info("  │   Producer)      │   Settles net amount");
        logger.info("  └────────┬─────────┘");
        logger.info("           │ PaymentSettled events");
        logger.info("           ▼");
        logger.info("  [payment-settled topic]  (3 partitions, RF=3)");
        logger.info("");
        logger.info("  [payment-dlq topic] ← ALL failures land here");
        logger.info("                         For manual investigation");
        logger.info("");
    }
}