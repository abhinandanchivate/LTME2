package com.kafka.training.Day2Module2_Security;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.Properties;

/**
 * ============================================================
 * DAY 2 - MODULE 2: KAFKA SECURITY
 * Sub-Demo 1: SSL/TLS Producer
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - SSL/TLS encryption for Kafka
 * - Client certificates (mutual TLS / mTLS)
 * - Keystore and truststore configuration
 * - Secure topic access for payment producers
 *
 * TRAINER NOTES:
 * "Payment data is highly sensitive (PCI-DSS compliance).
 *  We need:
 *  1. Encryption in transit (SSL/TLS) - prevents eavesdropping
 *  2. Server authentication - client verifies broker identity
 *  3. Client authentication (mTLS) - broker verifies client identity
 *
 *  This prevents:
 *  - Man-in-the-middle attacks
 *  - Unauthorized producers writing fake payments
 *  - Unauthorized consumers reading payment data"
 *
 * PRE-REQUISITES:
 * - Run docker/ssl/generate-certs.bat first
 * - Run: docker-compose -f docker-compose-ssl.yml up -d
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module2_Security.SSLProducerDemo"
 * ============================================================
 */
public class SSLProducerDemo {

    private static final Logger logger = LoggerFactory.getLogger(SSLProducerDemo.class);

    // SSL Broker endpoint
    private static final String BOOTSTRAP_SERVERS_SSL = "localhost:9096";

    // SSL certificate paths (relative to project root)
    private static final String SSL_DIR = "docker/ssl/";
    private static final String KEYSTORE_PATH = SSL_DIR + "kafka.client.keystore.jks";
    private static final String TRUSTSTORE_PATH = SSL_DIR + "kafka.client.truststore.jks";
    private static final String SSL_PASSWORD = "kafka-training-pass";

    private static final String TOPIC = "payment-created";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 2: SSL/TLS Producer Demo");
        logger.info("============================================================");

        SSLProducerDemo demo = new SSLProducerDemo();

        // DEMO 1: Explain SSL concepts
        demo.explainSSLConcepts();

        // DEMO 2: Verify SSL setup
        demo.verifySSLSetup();

        // DEMO 3: Produce with SSL
        demo.produceWithSSL();

        // DEMO 4: Show what happens without SSL
        demo.demonstrateWithoutSSL();

        logger.info("============================================================");
        logger.info("  SSL Producer Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: SSL Concepts Explanation
     *
     * TRAINER SCRIPT:
     * "Let me walk through the SSL handshake process in Kafka."
     */
    private void explainSSLConcepts() {
        logger.info("");
        logger.info("--- DEMO 1: SSL/TLS Concepts for Kafka ---");
        logger.info("");
        logger.info("WHY SSL FOR PAYMENTS?");
        logger.info("  PCI-DSS Requirement 4: Encrypt transmission of cardholder data");
        logger.info("  Without SSL: anyone on the network can read payment amounts,");
        logger.info("               customer IDs, merchant IDs from Kafka traffic");
        logger.info("");
        logger.info("TLS HANDSHAKE PROCESS:");
        logger.info("  1. Client connects to broker:9096 (SSL port)");
        logger.info("  2. Broker presents its CERTIFICATE (signed by CA)");
        logger.info("  3. Client verifies certificate using TRUSTSTORE");
        logger.info("     (truststore contains the CA certificate)");
        logger.info("  4. Client presents ITS certificate (mutual TLS)");
        logger.info("  5. Broker verifies client cert using its TRUSTSTORE");
        logger.info("  6. Secure encrypted channel established");
        logger.info("  7. All data flows encrypted with AES/ChaCha20");
        logger.info("");
        logger.info("FILES INVOLVED:");
        logger.info("  kafka.server.keystore.jks   → Broker's private key + certificate");
        logger.info("  kafka.server.truststore.jks → Brokers trust this CA for clients");
        logger.info("  kafka.client.keystore.jks   → Client's private key + certificate");
        logger.info("  kafka.client.truststore.jks → Client trusts this CA for brokers");
        logger.info("  ca.crt                      → The Certificate Authority cert");
    }

    /**
     * DEMO 2: Verify SSL Setup
     */
    private void verifySSLSetup() {
        logger.info("");
        logger.info("--- DEMO 2: Verifying SSL Certificate Files ---");

        File keystore = new File(KEYSTORE_PATH);
        File truststore = new File(TRUSTSTORE_PATH);

        logger.info("Client Keystore:   {} → {}", KEYSTORE_PATH,
            keystore.exists() ? "✓ EXISTS" : "✗ MISSING - run generate-certs.bat");
        logger.info("Client Truststore: {} → {}", TRUSTSTORE_PATH,
            truststore.exists() ? "✓ EXISTS" : "✗ MISSING - run generate-certs.bat");

        if (!keystore.exists() || !truststore.exists()) {
            logger.warn("");
            logger.warn("SSL certificates not found!");
            logger.warn("Please run: docker/ssl/generate-certs.bat");
            logger.warn("Then run: docker-compose -f docker/docker-compose-ssl.yml up -d");
            logger.warn("Skipping SSL producer demo...");
            return;
        }

        logger.info("");
        logger.info("✓ SSL certificates found");
        logger.info("  SSL Broker: {}", BOOTSTRAP_SERVERS_SSL);
        logger.info("  Protocol:   TLSv1.3 (preferred), TLSv1.2 (fallback)");
        logger.info("  Auth:       Mutual TLS (broker AND client authenticate)");
    }

    /**
     * DEMO 3: Produce with SSL
     *
     * TRAINER SCRIPT:
     * "The SSL configuration is just additional properties.
     *  The rest of the producer code is IDENTICAL to the non-SSL version.
     *  SSL is transparent to your business logic!"
     */
    private void produceWithSSL() throws Exception {
        logger.info("");
        logger.info("--- DEMO 3: Producing Payment Events with SSL/TLS ---");

        File keystore = new File(KEYSTORE_PATH);
        if (!keystore.exists()) {
            logger.warn("SSL certs not found - skipping SSL produce demo");
            logger.warn("Run generate-certs.bat and docker-compose-ssl.yml first");
            return;
        }

        Properties props = buildSSLProducerConfig();

        logger.info("SSL Producer Configuration:");
        logger.info("  security.protocol: SSL");
        logger.info("  ssl.keystore.location: {}", KEYSTORE_PATH);
        logger.info("  ssl.truststore.location: {}", TRUSTSTORE_PATH);
        logger.info("  ssl.endpoint.identification.algorithm: https");
        logger.info("");

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            for (int i = 1; i <= 5; i++) {
                String paymentId = "PAY-SSL-" + String.format("%04d", i);
                String paymentJson = String.format(
                    "{\"paymentId\":\"%s\",\"amount\":%.2f,\"encrypted\":true,\"timestamp\":%d}",
                    paymentId, 500.0 * i, System.currentTimeMillis()
                );

                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC, paymentId, paymentJson);

                final String pid = paymentId;
                producer.send(record, (metadata, exception) -> {
                    if (exception == null) {
                        logger.info("✓ [SSL] Secure payment sent: paymentId={} → partition={}, offset={}",
                            pid, metadata.partition(), metadata.offset());
                    } else {
                        logger.error("✗ [SSL] Failed: paymentId={}, error={}",
                            pid, exception.getMessage());
                    }
                });
            }

            producer.flush();
            logger.info("");
            logger.info("✓ Payments transmitted over encrypted TLS channel");
            logger.info("  Wireshark would show only encrypted binary data");
            logger.info("  No payment data visible to network observers");

        } catch (Exception e) {
            logger.error("SSL connection failed: {}", e.getMessage());
            logger.error("Ensure SSL broker is running: docker-compose -f docker-compose-ssl.yml up -d");
        }
    }

    /**
     * DEMO 4: What Happens Without SSL
     *
     * TRAINER SCRIPT:
     * "Without SSL, anyone on the same network can intercept
     *  payment data. Let me show what that looks like conceptually."
     */
    private void demonstrateWithoutSSL() {
        logger.info("");
        logger.info("--- DEMO 4: Security Risk Without SSL ---");
        logger.info("");
        logger.info("WITHOUT SSL (plaintext Kafka on port 9092):");
        logger.info("  An attacker running Wireshark would see:");
        logger.info("");
        logger.info("  Captured Kafka packet:");
        logger.info("  {\"paymentId\":\"PAY-0001\",\"customerId\":\"CUST-1234\",");
        logger.info("   \"amount\":5000.00,\"cardLast4\":\"1234\",");
        logger.info("   \"merchantId\":\"MERCHANT-AMAZON\"}");
        logger.info("");
        logger.info("  → FULL payment data visible in plaintext!");
        logger.info("  → PCI-DSS VIOLATION!");
        logger.info("  → GDPR Breach (customer data exposed)!");
        logger.info("");
        logger.info("WITH SSL (encrypted Kafka on port 9096):");
        logger.info("  An attacker running Wireshark would see:");
        logger.info("");
        logger.info("  Captured Kafka packet:");
        logger.info("  [0x17 0x03 0x03 0x01 0x4a 0x3f 0x8b 0x2c...]  (encrypted binary)");
        logger.info("");
        logger.info("  → Completely unreadable without private key");
        logger.info("  → PCI-DSS Requirement 4 SATISFIED");
        logger.info("");
        logger.info("ADDITIONAL SECURITY LAYERS:");
        logger.info("  1. ACLs: Control which clients can read/write which topics");
        logger.info("     kafka-acls --add --allow-principal User:CN=payment-service");
        logger.info("              --operation Write --topic payment-created");
        logger.info("  2. Quotas: Limit producer/consumer throughput per client");
        logger.info("  3. Audit Logging: Log all authentication events");
        logger.info("  4. Network Segmentation: Kafka in private subnet only");
    }

    /**
     * Build SSL-enabled producer configuration
     */
    private Properties buildSSLProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS_SSL);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all");

        // --------------------------------------------------------
        // SSL SECURITY CONFIGURATION
        // --------------------------------------------------------
        // Use SSL protocol
        props.put("security.protocol", "SSL");

        // Client's private key + signed certificate
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
            new File(KEYSTORE_PATH).getAbsolutePath());
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, SSL_PASSWORD);
        props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, SSL_PASSWORD);

        // CA certificate to verify broker's identity
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
            new File(TRUSTSTORE_PATH).getAbsolutePath());
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, SSL_PASSWORD);

        // Verify broker hostname matches certificate CN
        props.put(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "https");

        // Preferred TLS versions
        props.put(SslConfigs.SSL_ENABLED_PROTOCOLS_CONFIG, "TLSv1.3,TLSv1.2");

        return props;
    }
}