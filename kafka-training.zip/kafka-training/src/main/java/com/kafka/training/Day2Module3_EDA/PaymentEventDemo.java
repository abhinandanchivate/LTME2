package com.kafka.training.Day2Module3_EDA;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/**
 * ============================================================
 * DAY 2 - MODULE 3: EVENT-DRIVEN ARCHITECTURE
 * Sub-Demo 1: Events vs Commands + Pub-Sub Pattern
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - Events vs Commands (tell vs ask)
 * - Publish-Subscribe pattern
 * - Choreography vs Orchestration
 * - Payment to Order to Ledger event flow
 * - Temporal decoupling of services
 *
 * TRAINER NOTES:
 * KEY DISTINCTIONS:
 * COMMAND: "ProcessPayment" → tells someone to DO something
 *          - Direct call (HTTP/RPC)
 *          - Sender knows the receiver
 *          - Tightly coupled
 *
 * EVENT:   "PaymentCreated" → announces something HAPPENED
 *          - Published to topic
 *          - Sender doesn't know who listens
 *          - Loosely coupled
 *
 * ANALOGY:
 * "Events are like a newspaper. The journalist writes the news,
 *  publishes it, and doesn't care who reads it.
 *  Readers subscribe and read when ready.
 *  No direct connection between journalist and reader."
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module3_EDA.PaymentEventDemo"
 * ============================================================
 */
public class PaymentEventDemo {

    private static final Logger logger = LoggerFactory.getLogger(PaymentEventDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    // Topics representing our event-driven payment flow
    private static final String TOPIC_PAYMENT_CREATED = "payment-created";
    private static final String TOPIC_FRAUD_CHECK = "payment-fraud-check";
    private static final String TOPIC_FRAUD_RESULT = "fraud-result";
    private static final String TOPIC_PAYMENT_SETTLED = "payment-settled";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 3: Event-Driven Architecture Demo");
        logger.info("============================================================");

        PaymentEventDemo demo = new PaymentEventDemo();

        // DEMO 1: Events vs Commands
        demo.explainEventsVsCommands();

        // DEMO 2: Pub-Sub Pattern
        demo.demonstratePubSub();

        // DEMO 3: Choreography pattern
        demo.demonstrateChoreography();

        // DEMO 4: Choreography vs Orchestration comparison
        demo.compareChoreographyVsOrchestration();

        logger.info("============================================================");
        logger.info("  EDA Demo Complete! Next: SagaPatternDemo.java");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Events vs Commands
     *
     * TRAINER SCRIPT:
     * "This is the most important concept in EDA.
     *  A COMMAND says: 'Do this NOW' - it's an instruction
     *  An EVENT says: 'This HAPPENED' - it's a fact
     *
     *  Events are:
     *  - Past tense: PaymentCreated, FraudDetected, PaymentSettled
     *  - Immutable: once published, cannot be changed
     *  - Factual: represent something that really happened"
     */
    private void explainEventsVsCommands() {
        logger.info("");
        logger.info("--- DEMO 1: Events vs Commands ---");
        logger.info("");
        logger.info("COMMANDS (Synchronous, Coupled):");
        logger.info("  PaymentService.processPayment(payment)  ← HTTP POST");
        logger.info("  FraudService.checkFraud(payment)        ← HTTP POST");
        logger.info("  LedgerService.debitAccount(payment)     ← HTTP POST");
        logger.info("");
        logger.info("  PROBLEM: PaymentService must know FraudService and LedgerService URLs");
        logger.info("           If FraudService is down → Payment fails immediately");
        logger.info("           All services must be available simultaneously");
        logger.info("");
        logger.info("EVENTS (Asynchronous, Decoupled):");
        logger.info("  PaymentService publishes: PaymentCreated  → [payment-created topic]");
        logger.info("  FraudService consumes:    PaymentCreated, publishes FraudChecked");
        logger.info("  LedgerService consumes:   PaymentApproved → updates ledger");
        logger.info("");
        logger.info("  BENEFIT: PaymentService has ZERO knowledge of downstream services");
        logger.info("           FraudService can be down for hours → events queue up → catches up");
        logger.info("           New service can subscribe without changing PaymentService");
        logger.info("");
        logger.info("EVENT NAMING CONVENTION (Past Tense):");
        logger.info("  ✓ PaymentCreated, FraudDetected, PaymentSettled, AccountDebited");
        logger.info("  ✗ CreatePayment, CheckFraud, SettlePayment (those are commands!)");
    }

    /**
     * DEMO 2: Publish-Subscribe Pattern
     *
     * TRAINER SCRIPT:
     * "Let's publish a PaymentCreated event and see multiple
     *  services consuming it INDEPENDENTLY."
     */
    private void demonstratePubSub() throws Exception {
        logger.info("");
        logger.info("--- DEMO 2: Publish-Subscribe Pattern ---");
        logger.info("");
        logger.info("SCENARIO: PaymentCreated event consumed by 3 independent services");
        logger.info("");

        ExecutorService executor = Executors.newFixedThreadPool(4);
        CountDownLatch consumersReady = new CountDownLatch(3);
        CountDownLatch demoComplete = new CountDownLatch(1);

        // Start 3 independent consumers BEFORE publishing
        executor.submit(() -> runServiceConsumer(
            "FraudService",
            "fraud-check-group",
            TOPIC_PAYMENT_CREATED,
            "→ Running ML fraud check",
            consumersReady, demoComplete));

        executor.submit(() -> runServiceConsumer(
            "AuditService",
            "audit-group",
            TOPIC_PAYMENT_CREATED,
            "→ Writing to audit log",
            consumersReady, demoComplete));

        executor.submit(() -> runServiceConsumer(
            "AnalyticsService",
            "analytics-group",
            TOPIC_PAYMENT_CREATED,
            "→ Updating revenue dashboard",
            consumersReady, demoComplete));

        // Wait a moment for consumers to start
        Thread.sleep(2000);

        // Now publish a payment event
        executor.submit(() -> {
            try {
                logger.info("PaymentService: Publishing PaymentCreated event...");
                publishEvent(TOPIC_PAYMENT_CREATED, "PAY-EDA-001",
                    buildPaymentEvent("PAY-EDA-001", "CUST-EDA-001", 750.00, "CREATED"));
                logger.info("PaymentService: Event published! (PaymentService is DONE)");
                logger.info("PaymentService: It has NO IDEA who will consume this event");
                Thread.sleep(3000);
                demoComplete.countDown();
            } catch (Exception e) {
                logger.error("Error: {}", e.getMessage());
            }
        });

        demoComplete.await(15, TimeUnit.SECONDS);
        executor.shutdownNow();

        logger.info("");
        logger.info("PUB-SUB OBSERVATION:");
        logger.info("  All 3 services processed the SAME event INDEPENDENTLY");
        logger.info("  PaymentService didn't call any of them directly");
        logger.info("  Adding a 4th consumer requires ZERO changes to PaymentService");
    }

    /**
     * DEMO 3: Choreography Pattern
     *
     * TRAINER SCRIPT:
     * "In choreography, each service reacts to events and produces new events.
     *  No central coordinator. Services 'dance' together based on events.
     *
     *  Payment → FraudCheck → Settlement (if approved) → Ledger Update"
     */
    private void demonstrateChoreography() throws Exception {
        logger.info("");
        logger.info("--- DEMO 3: Choreography Pattern ---");
        logger.info("");
        logger.info("EVENT CHAIN: Payment → Fraud → Settlement → Ledger");
        logger.info("");
        logger.info("Each service:");
        logger.info("  1. Subscribes to upstream topic");
        logger.info("  2. Processes the event");
        logger.info("  3. Publishes result to downstream topic");
        logger.info("  4. Knows NOTHING about other services");
        logger.info("");

        // Show the choreography flow without running all services
        // (Full pipeline is in Day2Module4)
        logger.info("CHOREOGRAPHY FLOW:");
        logger.info("┌─────────────────────────────────────────────────────────┐");
        logger.info("│  PaymentService                                          │");
        logger.info("│    PaymentCreated → [payment-created topic]             │");
        logger.info("└─────────────────────────────────────────────────────────┘");
        logger.info("         ↓ (no direct connection)");
        logger.info("┌─────────────────────────────────────────────────────────┐");
        logger.info("│  FraudService                                            │");
        logger.info("│    Reads: [payment-created topic]                       │");
        logger.info("│    Writes: FraudChecked → [fraud-result topic]          │");
        logger.info("└─────────────────────────────────────────────────────────┘");
        logger.info("         ↓ (no direct connection)");
        logger.info("┌─────────────────────────────────────────────────────────┐");
        logger.info("│  SettlementService                                       │");
        logger.info("│    Reads: [fraud-result topic] (approved only)          │");
        logger.info("│    Writes: PaymentSettled → [payment-settled topic]     │");
        logger.info("└─────────────────────────────────────────────────────────┘");
        logger.info("         ↓ (no direct connection)");
        logger.info("┌─────────────────────────────────────────────────────────┐");
        logger.info("│  LedgerService                                           │");
        logger.info("│    Reads: [payment-settled topic]                       │");
        logger.info("│    Updates: Account balances in database                │");
        logger.info("└─────────────────────────────────────────────────────────┘");

        // Produce one payment to show the start
        publishEvent(TOPIC_PAYMENT_CREATED, "PAY-CHOREO-001",
            buildPaymentEvent("PAY-CHOREO-001", "CUST-CHOREO-001", 2500.00, "CREATED"));
        logger.info("");
        logger.info("✓ PaymentCreated event published to start the choreography chain");
        logger.info("  Run Day2Module4 pipeline to see the full chain in action!");
    }

    /**
     * DEMO 4: Choreography vs Orchestration Comparison
     *
     * TRAINER SCRIPT:
     * "Both patterns have their place. Let me compare them."
     */
    private void compareChoreographyVsOrchestration() {
        logger.info("");
        logger.info("--- DEMO 4: Choreography vs Orchestration ---");
        logger.info("");
        logger.info("CHOREOGRAPHY (Event-Driven, Kafka-based):");
        logger.info("  + Services are loosely coupled");
        logger.info("  + Easy to add new services (just subscribe to events)");
        logger.info("  + No single point of failure");
        logger.info("  + Services can be developed and deployed independently");
        logger.info("  - Hard to track the overall business flow");
        logger.info("  - Difficult to implement complex conditional logic");
        logger.info("  - Debugging requires tracing events across topics");
        logger.info("  Use: Simple, linear event flows");
        logger.info("");
        logger.info("ORCHESTRATION (Saga Orchestrator pattern):");
        logger.info("  + Centralized visibility of business process state");
        logger.info("  + Easy to implement complex branching logic");
        logger.info("  + Simple to add compensating transactions on failure");
        logger.info("  - Orchestrator is a central dependency");
        logger.info("  - Can become complex 'god' service");
        logger.info("  Use: Complex business processes with compensating transactions");
        logger.info("");
        logger.info("PAYMENT SYSTEM RECOMMENDATION:");
        logger.info("  Use CHOREOGRAPHY for simple flows:");
        logger.info("    PaymentCreated → FraudCheck → Settlement");
        logger.info("  Use ORCHESTRATION (Saga) for complex flows with compensations:");
        logger.info("    PaymentCreated → [Reserve Funds → Ship → Charge → Settle]");
        logger.info("    If shipping fails → [Refund → Cancel]");
    }

    /**
     * Helper: Run a service consumer in a thread
     */
    private void runServiceConsumer(String serviceName, String groupId,
                                     String topic, String actionMessage,
                                     CountDownLatch consumersReady,
                                     CountDownLatch demoComplete) {
        Properties props = buildConsumerConfig(groupId);
        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Collections.singletonList(topic));
            consumersReady.countDown();
            logger.info("[{}] Started, waiting for events on topic: {}", serviceName, topic);

            while (!Thread.currentThread().isInterrupted()) {
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(500));
                for (ConsumerRecord<String, String> record : records) {
                    logger.info("[{}] Received event: key={}", serviceName, record.key());
                    logger.info("[{}] Processing {} {}", serviceName, record.key(), actionMessage);
                    try { Thread.sleep(200); } catch (InterruptedException e) { return; }
                    logger.info("[{}] ✓ Processing complete for: {}", serviceName, record.key());
                }
            }
        } catch (Exception e) {
            if (!e.getMessage().contains("interrupted")) {
                logger.error("[{}] Error: {}", serviceName, e.getMessage());
            }
        }
    }

    /**
     * Helper: Publish an event to a topic
     */
    private void publishEvent(String topic, String key, String value) throws Exception {
        Properties props = buildProducerConfig();
        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            ProducerRecord<String, String> record = new ProducerRecord<>(topic, key, value);
            RecordMetadata metadata = producer.send(record).get();
            logger.info("  Published to topic={}, partition={}, offset={}",
                topic, metadata.partition(), metadata.offset());
        }
    }

    private String buildPaymentEvent(String paymentId, String customerId,
                                      double amount, String status) {
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("paymentId", paymentId);
            node.put("customerId", customerId);
            node.put("amount", amount);
            node.put("currency", "USD");
            node.put("status", status);
            node.put("merchantId", "MERCHANT-001");
            node.put("timestamp", System.currentTimeMillis());
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            return "{}";
        }
    }

    private Properties buildProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        return props;
    }

    private Properties buildConsumerConfig(String groupId) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
        return props;
    }
}