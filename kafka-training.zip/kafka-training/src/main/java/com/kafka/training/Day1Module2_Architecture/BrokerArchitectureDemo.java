package com.kafka.training.Day1Module2_Architecture;

import org.apache.kafka.clients.admin.*;
import org.apache.kafka.common.TopicPartitionInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.ExecutionException;

/**
 * ============================================================
 * DAY 1 - MODULE 2: KAFKA ARCHITECTURE
 * Sub-Demo 1: Broker Architecture
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - What is a Kafka Broker?
 * - Cluster of Brokers
 * - Topics and Partitions
 * - Replication Factor
 * - In-Sync Replicas (ISR)
 * - Leader Election
 *
 * TRAINER NOTES:
 * Use AdminClient to introspect the cluster and show students
 * the actual broker metadata, partition leaders, and ISR lists.
 *
 * ANALOGY TO USE:
 * "Think of Kafka like a distributed filing cabinet:
 *  - Topic = a drawer (e.g., 'payment-created')
 *  - Partition = individual folders inside the drawer
 *  - Broker = the physical cabinet
 *  - Replication = backup copies of each folder on different cabinets"
 * ============================================================
 */
public class BrokerArchitectureDemo {

    private static final Logger logger = LoggerFactory.getLogger(BrokerArchitectureDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 2: KAFKA ARCHITECTURE - Broker Architecture");
        logger.info("============================================================");

        BrokerArchitectureDemo demo = new BrokerArchitectureDemo();

        // Connect to the cluster via AdminClient
        try (AdminClient adminClient = demo.createAdminClient()) {

            // DEMO 1: Show cluster brokers
            demo.describeBrokers(adminClient);

            // DEMO 2: Show topic structure
            demo.describeTopics(adminClient);

            // DEMO 3: Show partition leaders and ISR
            demo.describePartitionLeadersAndISR(adminClient);

            // DEMO 4: Explain replication
            demo.explainReplication();

            // DEMO 5: Explain leader election
            demo.explainLeaderElection();
        }

        logger.info("============================================================");
        logger.info("  Module 2 - Part 1 Demo Complete!");
        logger.info("  Next: Run PartitionReplicationDemo.java");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Describe Cluster Brokers
     *
     * TRAINER SCRIPT:
     * "Let's see our actual Kafka cluster. We have 3 brokers.
     *  A broker is simply a Kafka server process.
     *  The cluster is identified by any broker's address."
     */
    private void describeBrokers(AdminClient adminClient) throws ExecutionException, InterruptedException {
        logger.info("");
        logger.info("--- DEMO 1: Cluster Broker Information ---");

        DescribeClusterResult clusterResult = adminClient.describeCluster();

        // Get cluster ID
        String clusterId = clusterResult.clusterId().get();
        logger.info("Cluster ID: {}", clusterId);

        // Get all brokers (nodes)
        Collection<org.apache.kafka.common.Node> nodes = clusterResult.nodes().get();
        logger.info("Number of Brokers: {}", nodes.size());
        logger.info("");

        nodes.forEach(node -> {
            logger.info("  Broker Details:");
            logger.info("    Broker ID:   {}", node.id());
            logger.info("    Host:        {}", node.host());
            logger.info("    Port:        {}", node.port());
            logger.info("    Rack:        {}", node.rack() != null ? node.rack() : "N/A");
            logger.info("    Is Controller? (see controller below)");
            logger.info("    ----------------------------------------");
        });

        // Get controller (the broker managing cluster metadata)
        org.apache.kafka.common.Node controller = clusterResult.controller().get();
        logger.info("Active Controller Broker ID: {} ({}:{})",
            controller.id(), controller.host(), controller.port());
        logger.info("");
        logger.info("TRAINER NOTE: The controller handles:");
        logger.info("  - Partition leader elections");
        logger.info("  - Broker join/leave notifications");
        logger.info("  - Topic creation/deletion coordination");
    }

    /**
     * DEMO 2: Describe Topic Structure
     *
     * TRAINER SCRIPT:
     * "A Topic is a named category for events.
     *  'payment-created' is our topic for new payments.
     *  Topics are split into partitions for parallelism."
     */
    private void describeTopics(AdminClient adminClient) throws ExecutionException, InterruptedException {
        logger.info("");
        logger.info("--- DEMO 2: Topic Structure ---");

        // List all topics
        ListTopicsResult topicsResult = adminClient.listTopics();
        Set<String> topicNames = topicsResult.names().get();

        logger.info("All topics in cluster: {}", topicNames);
        logger.info("");

        // Describe specific payment topics
        List<String> paymentTopics = List.of("payment-created", "payment-settled",
                                              "payment-fraud-check", "fraud-result");

        // Filter to only existing topics
        paymentTopics.stream()
            .filter(topicNames::contains)
            .forEach(topic -> {
                try {
                    describeOneTopic(adminClient, topic);
                } catch (Exception e) {
                    logger.warn("Could not describe topic {}: {}", topic, e.getMessage());
                }
            });
    }

    /**
     * Helper: Describe one specific topic
     */
    private void describeOneTopic(AdminClient adminClient, String topicName)
            throws ExecutionException, InterruptedException {
        DescribeTopicsResult result = adminClient.describeTopics(
            Collections.singletonList(topicName)
        );

        TopicDescription description = result.allTopicNames().get().get(topicName);
        if (description == null) return;

        logger.info("Topic: {}", description.name());
        logger.info("  Internal: {}", description.isInternal());
        logger.info("  Partitions: {}", description.partitions().size());
        logger.info("");

        for (TopicPartitionInfo partition : description.partitions()) {
            logger.info("  Partition {}:", partition.partition());
            logger.info("    Leader Broker:    Broker-{} ({}:{})",
                partition.leader().id(),
                partition.leader().host(),
                partition.leader().port());
            logger.info("    Replicas (all):   {}",
                partition.replicas().stream()
                    .map(n -> "Broker-" + n.id())
                    .reduce((a, b) -> a + ", " + b).orElse("none"));
            logger.info("    In-Sync Replicas: {}",
                partition.isr().stream()
                    .map(n -> "Broker-" + n.id())
                    .reduce((a, b) -> a + ", " + b).orElse("none"));
        }
        logger.info("");
    }

    /**
     * DEMO 3: Partition Leaders and ISR Explanation
     *
     * TRAINER SCRIPT:
     * "For each partition, ONE broker is the LEADER.
     *  All reads and writes go to the LEADER.
     *  Other brokers are FOLLOWERS that replicate the data.
     *  ISR = In-Sync Replicas = followers that are caught up with the leader."
     */
    private void describePartitionLeadersAndISR(AdminClient adminClient)
            throws ExecutionException, InterruptedException {
        logger.info("");
        logger.info("--- DEMO 3: Partition Leaders and ISR ---");
        logger.info("");
        logger.info("UNDERSTANDING ISR (In-Sync Replicas):");
        logger.info("");
        logger.info("  payment-created (3 partitions, RF=3):");
        logger.info("");
        logger.info("  Partition 0: Leader=Broker1, Replicas=[1,2,3], ISR=[1,2,3]");
        logger.info("  Partition 1: Leader=Broker2, Replicas=[2,3,1], ISR=[2,3,1]");
        logger.info("  Partition 2: Leader=Broker3, Replicas=[3,1,2], ISR=[3,1,2]");
        logger.info("");
        logger.info("  Workload is DISTRIBUTED across all brokers! (No single hotspot)");
        logger.info("");
        logger.info("WHAT HAPPENS IF BROKER 1 GOES DOWN?");
        logger.info("  - Partition 0 leader was Broker1");
        logger.info("  - Controller detects Broker1 is gone");
        logger.info("  - Controller elects new leader from ISR (e.g., Broker2)");
        logger.info("  - ISR becomes [2,3]");
        logger.info("  - Clients reconnect to Broker2 automatically");
        logger.info("  - Recovery time: typically < 30 seconds");
    }

    /**
     * DEMO 4: Explain Replication
     *
     * TRAINER SCRIPT:
     * "Replication Factor (RF) = how many copies of data exist.
     *  RF=3 means data is on 3 brokers. Even if 2 fail, data is safe."
     */
    private void explainReplication() {
        logger.info("");
        logger.info("--- DEMO 4: Replication Explained ---");
        logger.info("");
        logger.info("REPLICATION FACTOR = 3 for payment-created:");
        logger.info("");
        logger.info("  Producer writes PAY-001 to Partition 0 Leader (Broker1)");
        logger.info("  Broker1 immediately replicates to Broker2 and Broker3");
        logger.info("");
        logger.info("  [Broker1-P0-Leader] ──→ [Broker2-P0-Follower]");
        logger.info("        │");
        logger.info("        └──────────────→ [Broker3-P0-Follower]");
        logger.info("");
        logger.info("FINANCIAL SYSTEM RECOMMENDATION:");
        logger.info("  RF=3, min.insync.replicas=2");
        logger.info("  → Producer waits for 2 replicas to confirm");
        logger.info("  → Data safe even if one broker crashes");
        logger.info("  → Can lose 1 broker without data loss OR downtime");
    }

    /**
     * DEMO 5: Leader Election Process
     *
     * TRAINER SCRIPT:
     * "When a broker fails, Zookeeper detects it and the Controller
     *  broker automatically elects a new partition leader from the ISR."
     */
    private void explainLeaderElection() {
        logger.info("");
        logger.info("--- DEMO 5: Leader Election Process ---");
        logger.info("");
        logger.info("LEADER ELECTION STEPS:");
        logger.info("");
        logger.info("  1. Broker 1 (leader of Partition 0) crashes");
        logger.info("  2. Zookeeper detects: '/brokers/ids/1' node disappears");
        logger.info("  3. Controller (e.g., Broker 2) receives notification");
        logger.info("  4. Controller checks ISR for Partition 0: [2, 3]");
        logger.info("  5. Controller elects Broker 2 as new leader");
        logger.info("  6. Controller updates ZooKeeper metadata");
        logger.info("  7. All producers/consumers refresh metadata");
        logger.info("  8. Producers now send to Broker 2 (new leader)");
        logger.info("");
        logger.info("TRAINER: To demo this live:");
        logger.info("  docker stop kafka-broker-1");
        logger.info("  (Watch the UI - leaders will shift)");
        logger.info("  docker start kafka-broker-1");
        logger.info("  (Broker re-joins as follower, then eventually gets partitions back)");
    }

    /**
     * Create AdminClient for cluster introspection
     */
    private AdminClient createAdminClient() {
        Properties props = new Properties();
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(AdminClientConfig.REQUEST_TIMEOUT_MS_CONFIG, "30000");
        props.put(AdminClientConfig.DEFAULT_API_TIMEOUT_MS_CONFIG, "60000");
        return AdminClient.create(props);
    }
}