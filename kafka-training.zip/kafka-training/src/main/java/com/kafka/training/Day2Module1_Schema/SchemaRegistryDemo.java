package com.kafka.training.Day2Module1_Schema;

import io.confluent.kafka.schemaregistry.avro.AvroSchema;
import io.confluent.kafka.schemaregistry.client.CachedSchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.SchemaRegistryClient;
import io.confluent.kafka.schemaregistry.client.rest.exceptions.RestClientException;
import org.apache.avro.Schema;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.List;

/**
 * ============================================================
 * DAY 2 - MODULE 1: SCHEMA & COMPATIBILITY
 * Sub-Demo 1: Schema Registry Operations
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - What is Schema Registry and why we need it
 * - Registering schemas
 * - Schema versions and IDs
 * - Compatibility modes: BACKWARD, FORWARD, FULL, NONE
 * - Testing schema evolution
 * - Breaking vs non-breaking changes
 *
 * FIXES APPLIED:
 * ─────────────────────────────────────────────────────────────
 * ERROR 1 (line ~202):
 *   SchemaRegistryClient.testCompatibility() returns boolean in
 *   older Confluent versions but List<String> in newer ones.
 *   The Confluent 7.5.0 client's testCompatibility() that takes
 *   (subject, schema) returns boolean (is compatible = true/false).
 *   The overload returning List<String> takes additional parameters.
 *
 *   FIX: Use the correct overload signature:
 *     boolean testCompatibility(String subject, ParsedSchema schema)
 *   And check the boolean result directly.
 *
 * ERROR 2 (line ~309):
 *   Same issue in demonstrateBreakingChange() method.
 *   FIX: Same approach - use boolean return value.
 * ─────────────────────────────────────────────────────────────
 *
 * TRAINER NOTES:
 * "Without Schema Registry, producers and consumers must agree
 *  on schema out-of-band. If a producer changes the schema
 *  without telling consumers, consumers BREAK silently.
 *  Schema Registry is the CONTRACT between producer and consumer."
 *
 * PRE-REQUISITES:
 * - Schema Registry running (docker-compose.yml)
 * - http://localhost:8081 accessible
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module1_Schema.SchemaRegistryDemo"
 * ============================================================
 */
public class SchemaRegistryDemo {

    private static final Logger logger = LoggerFactory.getLogger(SchemaRegistryDemo.class);
    private static final String SCHEMA_REGISTRY_URL = "http://localhost:8081";
    private static final String SUBJECT_PAYMENT_VALUE = "payment-created-value";

    // Maximum number of schemas to cache in the client
    private static final int SCHEMA_CACHE_CAPACITY = 100;

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 1: Schema Registry Demo");
        logger.info("============================================================");

        SchemaRegistryDemo demo = new SchemaRegistryDemo();

        // DEMO 1: Connect to Schema Registry and list schemas
        demo.connectAndListSchemas();

        // DEMO 2: Register PaymentEvent v1 schema
        demo.registerPaymentSchemaV1();

        // DEMO 3: Test backward compatibility with v2
        demo.testSchemaCompatibility();

        // DEMO 4: Register v2 schema
        demo.registerPaymentSchemaV2();

        // DEMO 5: Test BREAKING change (forward incompatible)
        demo.demonstrateBreakingChange();

        // DEMO 6: Explain compatibility modes
        demo.explainCompatibilityModes();

        logger.info("============================================================");
        logger.info("  Schema Registry Demo Complete!");
        logger.info("  → Open http://localhost:8081/subjects to see schemas");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Connect and List Schemas
     *
     * TRAINER SCRIPT:
     * "Schema Registry runs as a separate service. Every time
     *  a producer serializes a message with Avro, it:
     *  1. Checks if the schema is registered
     *  2. If not, registers it and gets back a schema ID
     *  3. Embeds the schema ID (4 bytes) in the message header
     *  The consumer uses that ID to fetch and deserialize."
     */
    private void connectAndListSchemas() throws IOException, RestClientException {
        logger.info("");
        logger.info("--- DEMO 1: Connect to Schema Registry ---");
        logger.info("URL: {}", SCHEMA_REGISTRY_URL);
        logger.info("");

        SchemaRegistryClient client = new CachedSchemaRegistryClient(
                SCHEMA_REGISTRY_URL, SCHEMA_CACHE_CAPACITY
        );

        // List all registered subjects
        Collection<String> subjects = client.getAllSubjects();
        logger.info("Registered subjects in Schema Registry: {}", subjects.size());

        if (subjects.isEmpty()) {
            logger.info("  (No schemas registered yet - we will register them now)");
        } else {
            subjects.forEach(subject -> logger.info("  - Subject: {}", subject));
        }

        logger.info("");
        logger.info("HOW SCHEMA REGISTRY WORKS:");
        logger.info("  1. Producer creates Avro message with schema");
        logger.info("  2. KafkaAvroSerializer checks registry for schema ID");
        logger.info("  3. Schema ID embedded in message: [0][schema-id-4-bytes][avro-bytes]");
        logger.info("  4. Consumer reads message, extracts schema ID");
        logger.info("  5. KafkaAvroDeserializer fetches schema from registry");
        logger.info("  6. Message deserialized correctly");
        logger.info("");
        logger.info("BENEFIT: Schema stored ONCE in registry, not per-message");
        logger.info("         Consumers always know how to deserialize");
    }

    /**
     * DEMO 2: Register PaymentEvent V1 Schema
     *
     * TRAINER SCRIPT:
     * "We register our schema under a SUBJECT.
     *  Naming convention: topicName + '-value' or '-key'
     *  Example: payment-created-value"
     */
    private void registerPaymentSchemaV1() throws IOException, RestClientException {
        logger.info("");
        logger.info("--- DEMO 2: Registering PaymentEvent V1 Schema ---");

        SchemaRegistryClient client = new CachedSchemaRegistryClient(
                SCHEMA_REGISTRY_URL, SCHEMA_CACHE_CAPACITY
        );

        // Load V1 schema from classpath
        String schemaString = loadSchemaFromResources("/avro/PaymentEvent.avsc");
        Schema schema = new Schema.Parser().parse(schemaString);
        AvroSchema avroSchema = new AvroSchema(schema);

        // Register the schema - returns the schema ID assigned by registry
        int schemaId = client.register(SUBJECT_PAYMENT_VALUE, avroSchema);

        logger.info("✓ Schema registered successfully!");
        logger.info("  Subject:   {}", SUBJECT_PAYMENT_VALUE);
        logger.info("  Schema ID: {}", schemaId);
        logger.info("  Version:   1");
        logger.info("");
        logger.info("Schema fields registered:");
        schema.getFields().forEach(field ->
                logger.info("  - {} ({}): {}",
                        field.name(),
                        field.schema().getType(),
                        field.doc() != null ? field.doc() : "no doc")
        );
        logger.info("");
        logger.info("→ Verify: curl http://localhost:8081/subjects/{}/versions/latest",
                SUBJECT_PAYMENT_VALUE);
    }

    /**
     * DEMO 3: Test Schema Compatibility (FIXED)
     *
     * TRAINER SCRIPT:
     * "Before registering a new schema version, TEST compatibility.
     *
     *  BACKWARD (default): new schema can read OLD messages
     *  FORWARD:            old schema can read NEW messages
     *  FULL:               both backward AND forward compatible"
     *
     * FIX EXPLANATION:
     * ─────────────────────────────────────────────────────────
     * The Confluent 7.5.0 SchemaRegistryClient interface has:
     *
     *   boolean testCompatibility(String subject, ParsedSchema schema)
     *     → Returns TRUE if compatible, FALSE if not
     *     → Does NOT return a List<String>
     *
     *   List<String> testCompatibilityVerbose(String subject, ParsedSchema schema)
     *     → Returns list of incompatibility messages (empty = compatible)
     *     → Available in newer versions of the client
     *
     * We use the boolean version since that's what 7.5.0 exposes
     * as the standard testCompatibility(String, ParsedSchema) signature.
     * ─────────────────────────────────────────────────────────
     */
    private void testSchemaCompatibility() throws IOException, RestClientException {
        logger.info("");
        logger.info("--- DEMO 3: Testing Schema Compatibility ---");

        SchemaRegistryClient client = new CachedSchemaRegistryClient(
                SCHEMA_REGISTRY_URL, SCHEMA_CACHE_CAPACITY
        );

        // Check if subject exists first - if not, skip compatibility test
        Collection<String> subjects = client.getAllSubjects();
        if (!subjects.contains(SUBJECT_PAYMENT_VALUE)) {
            logger.warn("Subject '{}' not registered yet. Run Demo 2 first.", SUBJECT_PAYMENT_VALUE);
            logger.warn("Skipping compatibility test.");
            return;
        }

        // Load V2 schema (has new fields with defaults)
        String v2SchemaString = loadSchemaFromResources("/avro/PaymentEventV2.avsc");
        Schema v2Schema = new Schema.Parser().parse(v2SchemaString);
        AvroSchema avroSchemaV2 = new AvroSchema(v2Schema);

        logger.info("Testing PaymentEvent V2 against V1 (subject: {})...", SUBJECT_PAYMENT_VALUE);
        logger.info("");

        try {
            // ── FIX: testCompatibility returns boolean, not List<String> ──
            //
            // The method signature in Confluent 7.5.0:
            //   boolean testCompatibility(String subject, ParsedSchema schema)
            //
            // Returns:
            //   true  = the new schema IS compatible with existing versions
            //   false = the new schema is NOT compatible
            //
            boolean isCompatible = client.testCompatibility(
                    SUBJECT_PAYMENT_VALUE,
                    avroSchemaV2
            );
            // ─────────────────────────────────────────────────────────────

            if (isCompatible) {
                logger.info("✓ COMPATIBLE! V2 schema is backward compatible with V1");
                logger.info("  New field 'processingRegion' has DEFAULT value 'US-EAST'");
                logger.info("  New field 'riskScore' is nullable (union with null)");
                logger.info("  → Old consumers reading V2 messages use defaults");
                logger.info("  → New consumers reading V1 messages get default values");
            } else {
                logger.error("✗ INCOMPATIBLE! Schema evolution would BREAK consumers");
                logger.error("  Check your schema changes for missing defaults or type changes");
            }

        } catch (RestClientException e) {
            // HTTP 404 means subject not found, HTTP 422 means incompatible
            if (e.getStatus() == 404) {
                logger.warn("Subject not found in registry. Register V1 schema first (Demo 2).");
            } else if (e.getStatus() == 422) {
                logger.error("✗ Schema Registry rejected as INCOMPATIBLE: {}", e.getMessage());
            } else {
                logger.error("Schema Registry error (status={}): {}", e.getStatus(), e.getMessage());
            }
        }

        logger.info("");
        logger.info("BACKWARD COMPATIBLE CHANGES (safe):");
        logger.info("  ✓ Add new field WITH default value");
        logger.info("  ✓ Remove optional field (has default)");
        logger.info("  ✓ Widen field type (int → long)");
        logger.info("");
        logger.info("BREAKING CHANGES (rejected by registry):");
        logger.info("  ✗ Remove required field (no default)");
        logger.info("  ✗ Add field WITHOUT default");
        logger.info("  ✗ Change field type incompatibly (string → int)");
        logger.info("  ✗ Rename a field");
    }

    /**
     * DEMO 4: Register V2 Schema
     */
    private void registerPaymentSchemaV2() throws IOException, RestClientException {
        logger.info("");
        logger.info("--- DEMO 4: Registering PaymentEvent V2 Schema ---");

        SchemaRegistryClient client = new CachedSchemaRegistryClient(
                SCHEMA_REGISTRY_URL, SCHEMA_CACHE_CAPACITY
        );

        String v2SchemaString = loadSchemaFromResources("/avro/PaymentEventV2.avsc");
        Schema v2Schema = new Schema.Parser().parse(v2SchemaString);
        AvroSchema avroSchemaV2 = new AvroSchema(v2Schema);

        try {
            int schemaId = client.register(SUBJECT_PAYMENT_VALUE, avroSchemaV2);

            logger.info("✓ PaymentEvent V2 registered!");
            logger.info("  Subject:   {}", SUBJECT_PAYMENT_VALUE);
            logger.info("  Schema ID: {} (new ID for V2)", schemaId);

            // List all versions now available
            List<Integer> versions = client.getAllVersions(SUBJECT_PAYMENT_VALUE);
            logger.info("  All versions: {}", versions);

        } catch (RestClientException e) {
            if (e.getStatus() == 409) {
                logger.info("  V2 schema already registered (no change needed)");
            } else {
                throw e;
            }
        }

        logger.info("");
        logger.info("DEPLOYMENT STRATEGY with backward compatibility:");
        logger.info("  1. Register V2 schema ✓");
        logger.info("  2. Deploy NEW CONSUMERS that understand V2");
        logger.info("  3. Wait for consumers to stabilize");
        logger.info("  4. Deploy NEW PRODUCERS that emit V2 messages");
        logger.info("  5. Old consumers still work (V1 messages still flowing)");
        logger.info("  → Zero-downtime schema evolution!");
    }

    /**
     * DEMO 5: Demonstrate Breaking Change (FIXED)
     *
     * TRAINER SCRIPT:
     * "Let me show what happens when someone tries to register
     *  a BREAKING schema change. The registry REJECTS it."
     *
     * FIX: Same as Demo 3 - use boolean return from testCompatibility()
     */
    private void demonstrateBreakingChange() throws IOException, RestClientException {
        logger.info("");
        logger.info("--- DEMO 5: Breaking Schema Change (Rejected by Registry) ---");

        SchemaRegistryClient client = new CachedSchemaRegistryClient(
                SCHEMA_REGISTRY_URL, SCHEMA_CACHE_CAPACITY
        );

        // Check subject exists
        Collection<String> subjects = client.getAllSubjects();
        if (!subjects.contains(SUBJECT_PAYMENT_VALUE)) {
            logger.warn("Subject not registered. Run Demo 2 first.");
            return;
        }

        // Breaking schema: removed required fields, changed amount type
        // This intentionally violates backward compatibility
        String breakingSchemaString =
                "{"
                        + "  \"namespace\": \"com.kafka.training.model\","
                        + "  \"type\": \"record\","
                        + "  \"name\": \"PaymentEventBroken\","
                        + "  \"fields\": ["
                        + "    {\"name\": \"paymentId\", \"type\": \"string\"},"
                        + "    {\"name\": \"customerId\", \"type\": \"string\"},"
                        + "    {\"name\": \"amount\",     \"type\": \"string\"},"
                        + "    {\"name\": \"timestamp\",  \"type\": \"long\"}"
                        + "  ]"
                        + "}";

        Schema breakingSchema = new Schema.Parser().parse(breakingSchemaString);
        AvroSchema avroBreakingSchema = new AvroSchema(breakingSchema);

        logger.info("Attempting to register BREAKING schema change...");
        logger.info("Changes attempted:");
        logger.info("  ✗ REMOVED 'merchantId' field (required, no default)");
        logger.info("  ✗ REMOVED 'status' field (required, no default)");
        logger.info("  ✗ REMOVED 'currency' field (had default)");
        logger.info("  ✗ CHANGED 'amount' from double → string (incompatible type change)");
        logger.info("");

        try {
            // ── FIX: testCompatibility returns boolean, not List<String> ──
            //
            // boolean true  = IS compatible (unlikely here - it's breaking)
            // boolean false = NOT compatible
            //
            boolean isCompatible = client.testCompatibility(
                    SUBJECT_PAYMENT_VALUE,
                    avroBreakingSchema
            );
            // ─────────────────────────────────────────────────────────────

            if (!isCompatible) {
                logger.error("✗ Schema Registry REJECTED the breaking change!");
                logger.error("  The schema is NOT backward compatible.");
                logger.info("");
                logger.info("✓ Schema Registry PROTECTED our consumers!");
                logger.info("  Without Schema Registry, this would:");
                logger.info("    - Deploy silently to production");
                logger.info("    - Cause NullPointerExceptions in consumers");
                logger.info("    - Drop merchantId, status from all new events");
                logger.info("    - Crash consumers trying to parse amount as double");
            } else {
                // Shouldn't happen for this breaking schema, but handle gracefully
                logger.warn("Unexpectedly COMPATIBLE - registry may be in NONE mode");
                logger.warn("Check compatibility level: GET http://localhost:8081/config");
            }

        } catch (RestClientException e) {
            // HTTP 422 = Unprocessable Entity = schema is incompatible
            if (e.getStatus() == 422) {
                logger.error("✗ Schema Registry responded 422 - INCOMPATIBLE schema!");
                logger.info("✓ Registry protection is working correctly.");
            } else if (e.getStatus() == 404) {
                logger.warn("Subject not found (status 404): {}", e.getMessage());
            } else {
                logger.warn("Registry error (status={}): {}", e.getStatus(), e.getMessage());
            }
        }
    }

    /**
     * DEMO 6: Explain All Compatibility Modes
     *
     * TRAINER SCRIPT:
     * "Let me walk through all four compatibility modes and
     *  when to use each in a payment system context."
     */
    private void explainCompatibilityModes() {
        logger.info("");
        logger.info("--- DEMO 6: Schema Compatibility Modes ---");
        logger.info("");
        logger.info("BACKWARD (Default - recommended for most cases):");
        logger.info("  New schema can read OLD messages");
        logger.info("  → Upgrade CONSUMERS first, then PRODUCERS");
        logger.info("  → Safe: consumers ready before new events arrive");
        logger.info("  Config: BACKWARD or BACKWARD_TRANSITIVE");
        logger.info("  Rule:   Only add fields WITH defaults, delete fields safely");
        logger.info("");
        logger.info("FORWARD:");
        logger.info("  Old schema can read NEW messages");
        logger.info("  → Upgrade PRODUCERS first, then CONSUMERS");
        logger.info("  → Risky: old consumers see fields they don't understand");
        logger.info("  Config: FORWARD or FORWARD_TRANSITIVE");
        logger.info("  Rule:   Only add fields (old consumers ignore new fields)");
        logger.info("");
        logger.info("FULL:");
        logger.info("  BOTH backward AND forward compatible");
        logger.info("  → Upgrade in ANY order");
        logger.info("  → RECOMMENDED for payment systems");
        logger.info("  Config: FULL or FULL_TRANSITIVE");
        logger.info("  Rule:   Add fields WITH defaults only");
        logger.info("");
        logger.info("NONE:");
        logger.info("  No compatibility checking at all");
        logger.info("  → Any schema change is allowed");
        logger.info("  → ONLY for local development/testing");
        logger.info("  → NEVER in production for financial data");
        logger.info("");
        logger.info("SET COMPATIBILITY MODE via REST API:");
        logger.info("  # Set globally:");
        logger.info("  curl -X PUT http://localhost:8081/config \\");
        logger.info("       -H 'Content-Type: application/json' \\");
        logger.info("       -d '{\"compatibility\": \"FULL\"}'");
        logger.info("");
        logger.info("  # Set per subject:");
        logger.info("  curl -X PUT http://localhost:8081/config/{} \\",
                SUBJECT_PAYMENT_VALUE);
        logger.info("       -H 'Content-Type: application/json' \\");
        logger.info("       -d '{\"compatibility\": \"FULL\"}'");
        logger.info("");
        logger.info("  # Check current setting:");
        logger.info("  curl http://localhost:8081/config/{}", SUBJECT_PAYMENT_VALUE);
        logger.info("");
        logger.info("→ TRAINER: Show http://localhost:8081/subjects/{}/versions",
                SUBJECT_PAYMENT_VALUE);
    }

    /**
     * Load Avro schema string from classpath resources
     */
    private String loadSchemaFromResources(String resourcePath) throws IOException {
        try (InputStream is = getClass().getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new IOException(
                        "Schema resource not found on classpath: " + resourcePath
                                + "\nEnsure the .avsc files are in src/main/resources/avro/"
                );
            }
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }
}