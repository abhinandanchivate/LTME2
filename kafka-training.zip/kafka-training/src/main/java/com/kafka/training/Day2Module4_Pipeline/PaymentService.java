package com.kafka.training.Day2Module4_Pipeline;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ============================================================
 * DAY 2 - MODULE 4: END-TO-END EVENT PIPELINE
 * Service 1: Payment Service (Producer)
 * ============================================================
 *
 * ROLE IN PIPELINE:
 * PaymentService is the ENTRY POINT of the payment pipeline.
 * It receives payment requests (simulated here) and publishes
 * PaymentCreated events to the payment-created topic.
 *
 * PIPELINE FLOW:
 * PaymentService → [payment-created] → FraudService
 *                                    → AuditService (parallel)
 *
 * FEATURES DEMONSTRATED:
 * - Idempotent producer (no duplicate payments)
 * - Retries with exponential backoff
 * - Dead Letter Queue for failed publishes
 * - Payment event with correlation ID for tracing
 * - Graceful shutdown
 *
 * TRAINER NOTES:
 * Run each service in a separate terminal for best demo effect.
 * Order: PaymentService → FraudService → SettlementService
 *        (PipelineOrchestrator starts all together)
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module4_Pipeline.PaymentService"
 * ============================================================
 */
public class PaymentService {

    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class);

    // Kafka configuration
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";

    // Topics this service produces to
    private static final String TOPIC_PAYMENT_CREATED = "payment-created";
    private static final String TOPIC_PAYMENT_DLQ = "payment-dlq";

    // Metrics
    private final AtomicInteger successCount = new AtomicInteger(0);
    private final AtomicInteger failureCount = new AtomicInteger(0);
    private final AtomicInteger dlqCount = new AtomicInteger(0);

    // JSON serializer
    private static final ObjectMapper objectMapper = new ObjectMapper();

    // Volatile flag for graceful shutdown
    private volatile boolean running = true;

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 4: Payment Service (Pipeline Entry Point)");
        logger.info("============================================================");

        PaymentService service = new PaymentService();

        // Register shutdown hook for graceful stop
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            logger.info("Shutdown signal received...");
            service.running = false;
        }));

        // Run the payment simulation
        service.runPaymentSimulation();
    }

    /**
     * Main simulation: generate and publish payment events
     *
     * TRAINER SCRIPT:
     * "This simulates a payment gateway receiving payment requests.
     *  Each payment gets:
     *  - A unique paymentId (UUID)
     *  - A correlationId for distributed tracing
     *  - Published to Kafka with retries and DLQ fallback"
     */
    public void runPaymentSimulation() throws Exception {
        logger.info("");
        logger.info("Starting Payment Simulation...");
        logger.info("Generating payment events every 2 seconds");
        logger.info("Press Ctrl+C to stop");
        logger.info("");

        Properties props = buildProducerConfig();

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {

            int paymentNumber = 1;

            while (running) {
                try {
                    // Generate a payment request
                    PaymentRequest payment = generatePaymentRequest(paymentNumber);

                    // Publish to Kafka
                    boolean success = publishPaymentEvent(producer, payment);

                    if (success) {
                        successCount.incrementAndGet();
                        logger.info("✓ [PaymentService] Payment published: paymentId={}, " +
                            "customerId={}, amount=${}, correlationId={}",
                            payment.paymentId,
                            payment.customerId,
                            String.format("%.2f", payment.amount),
                            payment.correlationId);
                    } else {
                        failureCount.incrementAndGet();
                        // Send to Dead Letter Queue
                        sendToDLQ(producer, payment, "Publish failed after retries");
                        dlqCount.incrementAndGet();
                    }

                    paymentNumber++;

                    // Print metrics every 10 payments
                    if (paymentNumber % 10 == 0) {
                        printMetrics();
                    }

                    // Simulate realistic payment rate (1 payment per 2 seconds)
                    Thread.sleep(2000);

                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    break;
                } catch (Exception e) {
                    logger.error("[PaymentService] Error processing payment: {}", e.getMessage());
                }
            }

            producer.flush();
        }

        printMetrics();
        logger.info("[PaymentService] Shutdown complete.");
    }

    /**
     * Publish a payment event to Kafka with retry logic
     *
     * TRAINER SCRIPT:
     * "We use async send with callback. If it fails, we retry
     *  up to 3 times with exponential backoff. If all retries fail,
     *  we send to the Dead Letter Queue for investigation."
     */
    private boolean publishPaymentEvent(KafkaProducer<String, String> producer,
                                         PaymentRequest payment) {
        int maxRetries = 3;
        int retryCount = 0;
        long backoffMs = 100;

        while (retryCount <= maxRetries) {
            try {
                String eventJson = buildPaymentEventJson(payment);
                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC_PAYMENT_CREATED, payment.paymentId, eventJson);

                // Add headers for distributed tracing
                record.headers().add("correlationId",
                    payment.correlationId.getBytes());
                record.headers().add("sourceService",
                    "PaymentService".getBytes());
                record.headers().add("eventVersion",
                    "1.0".getBytes());

                // Synchronous send for reliability demonstration
                RecordMetadata metadata = producer.send(record).get();

                logger.debug("[PaymentService] Published: partition={}, offset={}",
                    metadata.partition(), metadata.offset());
                return true;

            } catch (Exception e) {
                retryCount++;
                if (retryCount <= maxRetries) {
                    logger.warn("[PaymentService] Retry {}/{} for paymentId={}: {}",
                        retryCount, maxRetries, payment.paymentId, e.getMessage());
                    try {
                        Thread.sleep(backoffMs);
                        backoffMs *= 2; // Exponential backoff
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        return false;
                    }
                } else {
                    logger.error("[PaymentService] All retries exhausted for paymentId={}",
                        payment.paymentId);
                    return false;
                }
            }
        }
        return false;
    }

    /**
     * Send failed payment to Dead Letter Queue
     *
     * TRAINER SCRIPT:
     * "The DLQ is a safety net. If we can't publish a payment,
     *  we don't just drop it. We write it to the DLQ with:
     *  - The original payment data
     *  - The failure reason
     *  - A timestamp for SLA tracking
     *  Operations team monitors the DLQ and reprocesses manually."
     */
    private void sendToDLQ(KafkaProducer<String, String> producer,
                            PaymentRequest payment, String reason) {
        try {
            ObjectNode dlqEvent = objectMapper.createObjectNode();
            dlqEvent.put("originalPaymentId", payment.paymentId);
            dlqEvent.put("failureReason", reason);
            dlqEvent.put("failedAt", System.currentTimeMillis());
            dlqEvent.put("originalPayload", buildPaymentEventJson(payment));

            String dlqJson = objectMapper.writeValueAsString(dlqEvent);
            ProducerRecord<String, String> dlqRecord =
                new ProducerRecord<>(TOPIC_PAYMENT_DLQ, payment.paymentId, dlqJson);

            producer.send(dlqRecord).get();
            logger.warn("[PaymentService] Sent to DLQ: paymentId={}, reason={}",
                payment.paymentId, reason);

        } catch (Exception e) {
            logger.error("[PaymentService] CRITICAL: Cannot even write to DLQ! paymentId={}",
                payment.paymentId, e);
        }
    }

    /**
     * Generate a realistic payment request
     */
    private PaymentRequest generatePaymentRequest(int sequence) {
        String[] customers = {
            "CUST-ALICE-001", "CUST-BOB-002", "CUST-CHARLIE-003",
            "CUST-DIANA-004", "CUST-EVE-005"
        };
        String[] merchants = {
            "MERCHANT-AMAZON", "MERCHANT-NETFLIX", "MERCHANT-GRAB",
            "MERCHANT-SHOPEE", "MERCHANT-LAZADA"
        };

        Random random = new Random();

        PaymentRequest payment = new PaymentRequest();
        payment.paymentId = "PAY-PIPELINE-" + String.format("%06d", sequence);
        payment.customerId = customers[sequence % customers.length];
        payment.merchantId = merchants[sequence % merchants.length];
        payment.correlationId = UUID.randomUUID().toString();

        // Generate amount - occasionally high (fraud trigger)
        if (sequence % 7 == 0) {
            payment.amount = 50000.00 + (random.nextDouble() * 50000); // High value
        } else {
            payment.amount = 10.0 + (random.nextDouble() * 990); // Normal
        }

        payment.currency = "USD";
        payment.timestamp = System.currentTimeMillis();
        return payment;
    }

    private String buildPaymentEventJson(PaymentRequest payment) {
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("paymentId", payment.paymentId);
            node.put("customerId", payment.customerId);
            node.put("merchantId", payment.merchantId);
            node.put("amount", payment.amount);
            node.put("currency", payment.currency);
            node.put("status", "CREATED");
            node.put("correlationId", payment.correlationId);
            node.put("timestamp", payment.timestamp);
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            return "{}";
        }
    }

    private void printMetrics() {
        logger.info("");
        logger.info("[PaymentService] ── Metrics ──────────────────────────");
        logger.info("[PaymentService]   Successful publishes: {}", successCount.get());
        logger.info("[PaymentService]   Failed publishes:     {}", failureCount.get());
        logger.info("[PaymentService]   DLQ events:          {}", dlqCount.get());
        logger.info("[PaymentService] ─────────────────────────────────────");
        logger.info("");
    }

    private Properties buildProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        // Reliability settings for payment service
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
        props.put(ProducerConfig.RETRIES_CONFIG, String.valueOf(Integer.MAX_VALUE));
        props.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, "5");
        props.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG, "120000");
        props.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG, "30000");
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "payment-service-producer");
        return props;
    }

    // Inner class for payment request data
    static class PaymentRequest {
        String paymentId;
        String customerId;
        String merchantId;
        String correlationId;
        double amount;
        String currency;
        long timestamp;
    }
}