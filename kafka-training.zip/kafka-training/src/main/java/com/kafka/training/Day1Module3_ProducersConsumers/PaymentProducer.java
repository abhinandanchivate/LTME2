package com.kafka.training.Day1Module3_ProducersConsumers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * ============================================================
 * DAY 1 - MODULE 3: PRODUCERS & CONSUMERS
 * Sub-Demo 1: Payment Event Producer
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - Producer configuration (bootstrap servers, serializers, acks)
 * - Synchronous vs Asynchronous sending
 * - Producer callbacks
 * - Producer batching and compression
 * - Record metadata (partition, offset, timestamp)
 *
 * TRAINER NOTES:
 * Show three sending patterns:
 * 1. Fire-and-forget (async, no callback)
 * 2. Synchronous (blocking, wait for ack)
 * 3. Asynchronous with callback (best practice)
 *
 * PAYMENT CONTEXT:
 * "A payment gateway produces PaymentCreated events when a
 *  customer initiates a payment. We need reliable delivery
 *  with proper confirmation."
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module3_ProducersConsumers.PaymentProducer"
 * ============================================================
 */
public class PaymentProducer {

    private static final Logger logger = LoggerFactory.getLogger(PaymentProducer.class);

    // Kafka connection
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";

    // Topics
    private static final String TOPIC_PAYMENT_CREATED = "payment-created";
    private static final String TOPIC_PAYMENT_SETTLED = "payment-settled";

    // Jackson for JSON serialization
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 3: Payment Event Producer Demo");
        logger.info("============================================================");

        PaymentProducer demo = new PaymentProducer();

        // DEMO 1: Synchronous Producer
        logger.info("");
        logger.info("=== DEMO 1: Synchronous Producer (Fire & Wait) ===");
        demo.demonstrateSynchronousProducer();

        // DEMO 2: Asynchronous Producer with Callback
        logger.info("");
        logger.info("=== DEMO 2: Asynchronous Producer with Callback ===");
        demo.demonstrateAsyncProducerWithCallback();

        // DEMO 3: Batch Producer with Performance Config
        logger.info("");
        logger.info("=== DEMO 3: High-Throughput Batch Producer ===");
        demo.demonstrateBatchProducer();

        // DEMO 4: Producer Configuration Deep Dive
        logger.info("");
        logger.info("=== DEMO 4: Producer Configuration Explained ===");
        demo.explainProducerConfiguration();

        logger.info("");
        logger.info("============================================================");
        logger.info("  Producer Demo Complete!");
        logger.info("  → Now run PaymentConsumer.java to consume these events");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Synchronous Producer
     *
     * TRAINER SCRIPT:
     * "Synchronous sending means we WAIT for Kafka to confirm
     *  the message was written. This is the safest approach
     *  but has higher latency because we block the thread.
     *
     *  Use case: When you need to know the offset/partition
     *  immediately, or when producing to a transaction log."
     */
    private void demonstrateSynchronousProducer() throws Exception {
        logger.info("Pattern: producer.send(record).get() - BLOCKS until confirmed");
        logger.info("");

        // Build producer with conservative (safe) settings
        Properties props = buildBasicProducerConfig();
        props.put(ProducerConfig.ACKS_CONFIG, "all");   // Wait for ALL replicas
        props.put(ProducerConfig.RETRIES_CONFIG, 3);     // Retry up to 3 times on failure

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {

            // Produce 5 payment events synchronously
            for (int i = 1; i <= 5; i++) {
                String paymentId = "PAY-SYNC-" + String.format("%04d", i);
                String customerId = "CUST-" + (1000 + i);
                double amount = 100.0 * i;

                // Build payment JSON
                String paymentJson = buildPaymentJson(paymentId, customerId, amount, "CREATED");

                // Create the record: topic, key, value
                // KEY = paymentId ensures ordering per payment
                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC_PAYMENT_CREATED, paymentId, paymentJson);

                long startTime = System.currentTimeMillis();

                // .get() makes this SYNCHRONOUS - blocks until broker confirms
                RecordMetadata metadata = producer.send(record).get();

                long latency = System.currentTimeMillis() - startTime;

                logger.info("✓ Sent [SYNC] paymentId={} → topic={}, partition={}, offset={}, latency={}ms",
                    paymentId,
                    metadata.topic(),
                    metadata.partition(),
                    metadata.offset(),
                    latency);
            }

            logger.info("");
            logger.info("OBSERVATION: Each send waited for broker confirmation");
            logger.info("TRADE-OFF: Safer but slower (sequential, not pipelined)");
        }
    }

    /**
     * DEMO 2: Asynchronous Producer with Callback
     *
     * TRAINER SCRIPT:
     * "Asynchronous sending is the RECOMMENDED approach for most cases.
     *  We send and provide a CALLBACK function. The producer sends
     *  messages in batches, and when Kafka confirms, our callback fires.
     *
     *  This gives us:
     *  - High throughput (non-blocking)
     *  - Error handling via callback
     *  - Automatic batching"
     */
    private void demonstrateAsyncProducerWithCallback() throws Exception {
        logger.info("Pattern: producer.send(record, callback) - NON-BLOCKING");
        logger.info("");

        Properties props = buildBasicProducerConfig();
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.RETRIES_CONFIG, 3);
        // Linger: wait up to 5ms to batch messages together
        props.put(ProducerConfig.LINGER_MS_CONFIG, "5");

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {

            // Track how many callbacks we've received
            int[] successCount = {0};
            int[] failureCount = {0};

            // Produce 10 payment events asynchronously
            for (int i = 1; i <= 10; i++) {
                String paymentId = "PAY-ASYNC-" + String.format("%04d", i);
                String customerId = "CUST-" + (2000 + i);
                double amount = 250.0 * i;

                String paymentJson = buildPaymentJson(paymentId, customerId, amount, "CREATED");

                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC_PAYMENT_CREATED, paymentId, paymentJson);

                final String finalPaymentId = paymentId;

                // CALLBACK: Called when Kafka confirms OR on error
                producer.send(record, (metadata, exception) -> {
                    if (exception == null) {
                        // SUCCESS PATH
                        successCount[0]++;
                        logger.info("✓ Callback [ASYNC] paymentId={} → partition={}, offset={}",
                            finalPaymentId,
                            metadata.partition(),
                            metadata.offset());
                    } else {
                        // ERROR PATH - Handle failures here
                        failureCount[0]++;
                        logger.error("✗ Failed paymentId={} → error: {}",
                            finalPaymentId,
                            exception.getMessage());

                        // In production: send to Dead Letter Queue (DLQ)
                        // sendToDeadLetterQueue(record, exception);
                    }
                });

                logger.info("  Queued [ASYNC] paymentId={} (callback pending...)", paymentId);
            }

            // IMPORTANT: Flush ensures all in-flight messages are sent before close
            logger.info("");
            logger.info("Flushing producer buffer...");
            producer.flush();

            logger.info("");
            logger.info("Results: Success={}, Failures={}", successCount[0], failureCount[0]);
            logger.info("OBSERVATION: Messages sent without blocking!");
            logger.info("OBSERVATION: Callbacks fired after Kafka confirmed batches");
        }
    }

    /**
     * DEMO 3: High-Throughput Batch Producer
     *
     * TRAINER SCRIPT:
     * "For high-volume payment systems (Black Friday, etc.) we need
     *  to tune the producer for maximum throughput.
     *  Key settings:
     *  - batch.size: how many bytes to batch before sending
     *  - linger.ms: how long to wait for a batch to fill
     *  - compression.type: compress batches (snappy/lz4/gzip)
     *  - buffer.memory: total producer buffer size"
     */
    private void demonstrateBatchProducer() throws Exception {
        logger.info("High-throughput configuration for peak payment volumes");
        logger.info("");

        Properties props = buildBasicProducerConfig();
        // ----------------------------------------------------------
        // HIGH THROUGHPUT TUNING
        // ----------------------------------------------------------
        props.put(ProducerConfig.ACKS_CONFIG, "1");           // Only leader ack (faster)
        props.put(ProducerConfig.LINGER_MS_CONFIG, "20");     // Wait 20ms for batch to fill
        props.put(ProducerConfig.BATCH_SIZE_CONFIG, "65536"); // 64KB batch size
        props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, "33554432"); // 32MB buffer
        props.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, "snappy"); // Fast compression
        props.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, "5"); // Pipeline 5 requests

        long startTime = System.currentTimeMillis();
        int messageCount = 1000;

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            int[] sentCount = {0};

            for (int i = 1; i <= messageCount; i++) {
                String paymentId = "PAY-BATCH-" + String.format("%06d", i);
                String paymentJson = buildPaymentJson(
                    paymentId, "CUST-BATCH-" + i, 10.0 * i, "CREATED"
                );

                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC_PAYMENT_CREATED, paymentId, paymentJson);

                producer.send(record, (metadata, ex) -> {
                    if (ex == null) sentCount[0]++;
                });

                // Log progress every 100 messages
                if (i % 100 == 0) {
                    logger.info("  Queued {} of {} messages...", i, messageCount);
                }
            }

            producer.flush(); // Ensure all sent

            long duration = System.currentTimeMillis() - startTime;
            double throughput = (double) sentCount[0] / (duration / 1000.0);

            logger.info("");
            logger.info("✓ Batch Complete:");
            logger.info("  Messages Sent:  {}", sentCount[0]);
            logger.info("  Duration:       {}ms", duration);
            logger.info("  Throughput:     {:.0f} messages/second", throughput);
            logger.info("  (Kafka can achieve 1M+ msg/sec with proper hardware)");
        }
    }

    /**
     * DEMO 4: Producer Configuration Reference
     *
     * TRAINER SCRIPT:
     * "Let me walk you through the key producer configs you'll use
     *  in a production payment system."
     */
    private void explainProducerConfiguration() {
        logger.info("");
        logger.info("KEY PRODUCER CONFIGURATIONS:");
        logger.info("");
        logger.info("  RELIABILITY SETTINGS:");
        logger.info("  acks=0          → Fire and forget (no ack, fastest, risky)");
        logger.info("  acks=1          → Leader ack only (fast, small risk of loss)");
        logger.info("  acks=all (-1)   → All ISR acks (safest, payment systems use this)");
        logger.info("");
        logger.info("  RETRY SETTINGS:");
        logger.info("  retries=3                          → Retry up to 3 times");
        logger.info("  retry.backoff.ms=100               → Wait 100ms between retries");
        logger.info("  delivery.timeout.ms=120000         → Total delivery timeout: 2 min");
        logger.info("");
        logger.info("  THROUGHPUT SETTINGS:");
        logger.info("  batch.size=16384         → 16KB batch (default)");
        logger.info("  linger.ms=0              → No waiting (default, low latency)");
        logger.info("  compression.type=none    → No compression (default)");
        logger.info("");
        logger.info("  MEMORY SETTINGS:");
        logger.info("  buffer.memory=33554432   → 32MB producer buffer");
        logger.info("  max.block.ms=60000       → Block up to 60s if buffer full");
        logger.info("");
        logger.info("  PAYMENT SYSTEM RECOMMENDATION:");
        logger.info("  acks=all, retries=Integer.MAX_VALUE,");
        logger.info("  enable.idempotence=true, max.in.flight.requests.per.connection=5");
    }

    /**
     * Build a payment JSON string
     */
    private String buildPaymentJson(String paymentId, String customerId,
                                     double amount, String status) {
        try {
            ObjectNode node = objectMapper.createObjectNode();
            node.put("paymentId", paymentId);
            node.put("customerId", customerId);
            node.put("amount", amount);
            node.put("currency", "USD");
            node.put("status", status);
            node.put("merchantId", "MERCHANT-001");
            node.put("timestamp", System.currentTimeMillis());
            return objectMapper.writeValueAsString(node);
        } catch (Exception e) {
            return String.format("{\"paymentId\":\"%s\",\"error\":\"serialization failed\"}", paymentId);
        }
    }

    /**
     * Build basic producer configuration
     */
    private Properties buildBasicProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "payment-producer-demo");
        return props;
    }
}