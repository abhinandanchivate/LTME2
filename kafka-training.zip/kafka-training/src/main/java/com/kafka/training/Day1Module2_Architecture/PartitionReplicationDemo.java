package com.kafka.training.Day1Module2_Architecture;

import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.config.TopicConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.Future;

/**
 * ============================================================
 * DAY 1 - MODULE 2: KAFKA ARCHITECTURE
 * Sub-Demo 2: Partition & Replication Hands-On
 * ============================================================
 *
 * TRAINER NOTES:
 * This demo shows:
 * 1. How messages are distributed across partitions
 * 2. The effect of message keys on partition assignment
 * 3. Replication in action
 *
 * HANDS-ON LAB:
 * "Analyze a Kafka cluster handling payment traffic"
 * - Create a topic and observe partition distribution
 * - Produce messages with and without keys
 * - Observe partition assignment differences
 * ============================================================
 */
public class PartitionReplicationDemo {

    private static final Logger logger = LoggerFactory.getLogger(PartitionReplicationDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final String DEMO_TOPIC = "payment-partition-demo";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 2: Partition & Replication Demo");
        logger.info("============================================================");

        PartitionReplicationDemo demo = new PartitionReplicationDemo();

        try (AdminClient adminClient = demo.createAdminClient()) {
            // Create demo topic with explicit partition config
            demo.createDemoTopic(adminClient);

            // Demo 1: Produce without key (round-robin distribution)
            demo.produceWithoutKey();

            // Demo 2: Produce with key (deterministic partition assignment)
            demo.produceWithKey();

            // Demo 3: Describe the topic to see distribution
            demo.describeTopic(adminClient);
        }

        logger.info("============================================================");
        logger.info("  Partition & Replication Demo Complete!");
        logger.info("  → Check http://localhost:8080 to visualize partition distribution");
        logger.info("============================================================");
    }

    /**
     * Create a demo topic with specific configuration
     *
     * TRAINER SCRIPT:
     * "Let's create a topic with 6 partitions to demonstrate
     *  how Kafka distributes data across partitions."
     */
    private void createDemoTopic(AdminClient adminClient) throws Exception {
        logger.info("");
        logger.info("--- Creating Demo Topic: {} ---", DEMO_TOPIC);

        // Check if topic already exists
        Set<String> existingTopics = adminClient.listTopics().names().get();
        if (existingTopics.contains(DEMO_TOPIC)) {
            logger.info("Topic {} already exists, skipping creation", DEMO_TOPIC);
            return;
        }

        // Configure topic properties
        Map<String, String> topicConfig = new HashMap<>();
        topicConfig.put(TopicConfig.RETENTION_MS_CONFIG, "3600000"); // 1 hour retention for demo
        topicConfig.put(TopicConfig.MIN_IN_SYNC_REPLICAS_CONFIG, "2"); // Require 2 ISRs
        topicConfig.put(TopicConfig.CLEANUP_POLICY_CONFIG, TopicConfig.CLEANUP_POLICY_DELETE);

        // Create the topic: 6 partitions, replication factor 3
        NewTopic newTopic = new NewTopic(DEMO_TOPIC, 6, (short) 3);
        newTopic.configs(topicConfig);

        CreateTopicsResult result = adminClient.createTopics(
            Collections.singletonList(newTopic)
        );
        result.all().get(); // Wait for completion

        logger.info("✓ Topic created: {}", DEMO_TOPIC);
        logger.info("  Partitions:         6");
        logger.info("  Replication Factor: 3");
        logger.info("  Min ISR:            2");
        logger.info("  Retention:          1 hour (demo only)");
    }

    /**
     * DEMO 1: Produce without key - Round Robin distribution
     *
     * TRAINER SCRIPT:
     * "When a producer doesn't specify a key, Kafka uses round-robin
     *  to distribute messages across partitions. This maximizes parallelism
     *  but messages for the same customer could go to different partitions."
     */
    private void produceWithoutKey() throws Exception {
        logger.info("");
        logger.info("--- DEMO 1: Producing WITHOUT Key (Round Robin) ---");
        logger.info("Messages will be distributed across ALL partitions randomly");
        logger.info("");

        Properties props = buildProducerConfig();

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            for (int i = 1; i <= 12; i++) {
                String paymentJson = String.format(
                    "{\"paymentId\":\"PAY-NOKEY-%03d\",\"amount\":%.2f}",
                    i, (double)(i * 100)
                );

                // No key specified - null key means round-robin
                ProducerRecord<String, String> record =
                    new ProducerRecord<>(DEMO_TOPIC, null, paymentJson);

                Future<RecordMetadata> future = producer.send(record);
                RecordMetadata metadata = future.get(); // Synchronous for demo clarity

                logger.info("  Message {} → Partition {}, Offset {}",
                    i, metadata.partition(), metadata.offset());
            }
        }
        logger.info("");
        logger.info("OBSERVATION: Messages distributed across multiple partitions");
    }

    /**
     * DEMO 2: Produce with key - Deterministic partition assignment
     *
     * TRAINER SCRIPT:
     * "When we use a key (like customerId or paymentId), Kafka hashes
     *  the key to determine the partition. The SAME key ALWAYS goes to
     *  the SAME partition. This guarantees ordering per key!"
     */
    private void produceWithKey() throws Exception {
        logger.info("");
        logger.info("--- DEMO 2: Producing WITH Key (Deterministic Partitioning) ---");
        logger.info("Same key → Same partition ALWAYS (ordering guarantee)");
        logger.info("");

        Properties props = buildProducerConfig();

        // Simulate 3 customers making multiple payments
        String[] customerIds = {"CUST-AAA", "CUST-BBB", "CUST-CCC"};

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            for (String customerId : customerIds) {
                // Each customer makes 4 payments
                for (int txn = 1; txn <= 4; txn++) {
                    String paymentId = String.format("PAY-%s-%d", customerId, txn);
                    String paymentJson = String.format(
                        "{\"paymentId\":\"%s\",\"customerId\":\"%s\",\"amount\":%.2f}",
                        paymentId, customerId, (double)(txn * 50)
                    );

                    // KEY = customerId → all payments for same customer → same partition
                    ProducerRecord<String, String> record =
                        new ProducerRecord<>(DEMO_TOPIC, customerId, paymentJson);

                    Future<RecordMetadata> future = producer.send(record);
                    RecordMetadata metadata = future.get();

                    logger.info("  Key={}, Payment={} → Partition {}, Offset {}",
                        customerId, paymentId, metadata.partition(), metadata.offset());
                }
                logger.info("  --- {} always → same partition ---", customerId);
            }
        }

        logger.info("");
        logger.info("OBSERVATION: All events for CUST-AAA go to the SAME partition");
        logger.info("BENEFIT: Payment order is preserved per customer!");
        logger.info("WARNING: If a customer generates too many events, that partition");
        logger.info("         could become a 'hot partition'. Design keys carefully!");
    }

    /**
     * Describe topic after producing to see partition stats
     */
    private void describeTopic(AdminClient adminClient) throws Exception {
        logger.info("");
        logger.info("--- Topic Description After Producing ---");

        DescribeTopicsResult result = adminClient.describeTopics(
            Collections.singletonList(DEMO_TOPIC)
        );
        TopicDescription desc = result.allTopicNames().get().get(DEMO_TOPIC);

        logger.info("Topic: {}", desc.name());
        desc.partitions().forEach(p -> {
            logger.info("  Partition {}: Leader=Broker-{}, Replicas={}, ISR={}",
                p.partition(),
                p.leader().id(),
                p.replicas().stream().map(n -> String.valueOf(n.id()))
                    .reduce((a, b) -> a + "," + b).orElse(""),
                p.isr().stream().map(n -> String.valueOf(n.id()))
                    .reduce((a, b) -> a + "," + b).orElse(""));
        });
    }

    private Properties buildProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.RETRIES_CONFIG, 3);
        return props;
    }

    private AdminClient createAdminClient() {
        Properties props = new Properties();
        props.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        return AdminClient.create(props);
    }
}