package com.kafka.training.Day1Module4_Reliability;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/**
 * ============================================================
 * DAY 1 - MODULE 4: RELIABILITY & ORDERING
 * Sub-Demo 1: Acknowledgements (ACKs)
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - acks=0 (fire and forget)
 * - acks=1 (leader only)
 * - acks=all (all ISR replicas)
 * - Trade-offs between safety and performance
 * - min.insync.replicas configuration
 *
 * TRAINER NOTES:
 * This is the core reliability concept.
 * Show each ACK mode with timing to demonstrate the latency difference.
 *
 * PAYMENT CONTEXT:
 * "A payment must NEVER be silently lost.
 *  We need acks=all to ensure the payment event is safely
 *  stored on multiple brokers before confirming to the customer."
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module4_Reliability.AcknowledgementDemo"
 * ============================================================
 */
public class AcknowledgementDemo {

    private static final Logger logger = LoggerFactory.getLogger(AcknowledgementDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final String TOPIC = "payment-created";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 4: Acknowledgement (ACK) Demo");
        logger.info("============================================================");

        AcknowledgementDemo demo = new AcknowledgementDemo();

        // DEMO 1: acks=0 - Fire and Forget
        demo.demonstrateAcksZero();

        // DEMO 2: acks=1 - Leader Only
        demo.demonstrateAcksOne();

        // DEMO 3: acks=all - Maximum Safety
        demo.demonstrateAcksAll();

        // DEMO 4: Compare latencies
        demo.compareAckLatencies();

        // DEMO 5: min.insync.replicas interaction
        demo.explainMinInsyncReplicas();

        logger.info("============================================================");
        logger.info("  ACK Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: acks=0 - Fire and Forget
     *
     * TRAINER SCRIPT:
     * "With acks=0, the producer sends the message and immediately
     *  moves on. It never waits for Kafka to respond.
     *
     *  RISK: If the broker crashes right after receiving the message
     *  but before writing to disk, the message is LOST with NO notification.
     *
     *  NEVER use this for payment events!"
     */
    private void demonstrateAcksZero() throws Exception {
        logger.info("");
        logger.info("--- DEMO 1: acks=0 (Fire and Forget) ---");
        logger.info("Producer sends → immediately continues → NO confirmation");
        logger.info("RISK: Message may be LOST silently!");
        logger.info("");

        Properties props = buildProducerConfig("0"); // acks=0

        long startTime = System.currentTimeMillis();
        int messageCount = 100;

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            for (int i = 1; i <= messageCount; i++) {
                String key = "PAY-ACK0-" + i;
                String value = buildPaymentJson(key, 100.0 * i);

                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC, key, value);

                // No .get() and no callback - truly fire and forget
                producer.send(record);
            }
            producer.flush();
        }

        long duration = System.currentTimeMillis() - startTime;
        logger.info("acks=0: Sent {} messages in {}ms ({:.0f} msg/sec)",
            messageCount, duration, (double) messageCount / (duration / 1000.0));
        logger.info("WARNING: NO guarantee any of these were written to Kafka!");
    }

    /**
     * DEMO 2: acks=1 - Leader Acknowledgement
     *
     * TRAINER SCRIPT:
     * "With acks=1, the leader broker writes the message and immediately
     *  responds. Followers replicate asynchronously AFTER the ack.
     *
     *  RISK: If leader crashes between ack and follower replication,
     *  the message is LOST even though producer received confirmation!
     *
     *  MEDIUM risk: OK for non-critical streams, not for payments."
     */
    private void demonstrateAcksOne() throws Exception {
        logger.info("");
        logger.info("--- DEMO 2: acks=1 (Leader Acknowledgement) ---");
        logger.info("Leader writes → Leader responds → Followers replicate async");
        logger.info("RISK: If leader crashes before replication, message is LOST");
        logger.info("");

        Properties props = buildProducerConfig("1"); // acks=1

        long startTime = System.currentTimeMillis();
        int messageCount = 100;
        int[] confirmed = {0};

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            for (int i = 1; i <= messageCount; i++) {
                String key = "PAY-ACK1-" + i;
                String value = buildPaymentJson(key, 200.0 * i);

                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC, key, value);

                producer.send(record, (metadata, ex) -> {
                    if (ex == null) confirmed[0]++;
                });
            }
            producer.flush();
        }

        long duration = System.currentTimeMillis() - startTime;
        logger.info("acks=1: Sent {} messages, {} confirmed by LEADER in {}ms",
            messageCount, confirmed[0], duration);
        logger.info("RISK: Follower replication NOT confirmed - data could be lost on leader crash");
    }

    /**
     * DEMO 3: acks=all - Maximum Safety
     *
     * TRAINER SCRIPT:
     * "With acks=all (or acks=-1), the leader waits for ALL
     *  in-sync replicas (ISR) to confirm before responding.
     *
     *  SAFE: Data is on multiple brokers before confirmation.
     *  Even if the leader crashes, followers have the data.
     *
     *  ALWAYS use acks=all for payment events!"
     */
    private void demonstrateAcksAll() throws Exception {
        logger.info("");
        logger.info("--- DEMO 3: acks=all (Maximum Safety) ---");
        logger.info("Leader writes → ALL ISR replicas write → Leader responds");
        logger.info("SAFE: Data persisted across multiple brokers before confirmation");
        logger.info("");

        Properties props = buildProducerConfig("all"); // acks=all
        // Also set min.insync.replicas expectation
        props.put(ProducerConfig.RETRIES_CONFIG, "3");

        long startTime = System.currentTimeMillis();
        int messageCount = 100;
        int[] confirmed = {0};
        int[] failed = {0};

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            for (int i = 1; i <= messageCount; i++) {
                String key = "PAY-ACKALL-" + i;
                String value = buildPaymentJson(key, 500.0 * i);

                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC, key, value);

                producer.send(record, (metadata, ex) -> {
                    if (ex == null) confirmed[0]++;
                    else failed[0]++;
                });
            }
            producer.flush();
        }

        long duration = System.currentTimeMillis() - startTime;
        logger.info("acks=all: Sent {} messages, {} confirmed by ALL ISR in {}ms, {} failed",
            messageCount, confirmed[0], duration, failed[0]);
        logger.info("SAFE: Each message confirmed across ALL in-sync replicas");
    }

    /**
     * DEMO 4: Compare ACK Latencies
     */
    private void compareAckLatencies() throws Exception {
        logger.info("");
        logger.info("--- DEMO 4: ACK Latency Comparison (Single Message) ---");
        logger.info("");

        String[] ackModes = {"0", "1", "all"};
        String[] ackLabels = {"acks=0 (Fire&Forget)", "acks=1 (Leader)", "acks=all (All ISR)"};

        for (int i = 0; i < ackModes.length; i++) {
            Properties props = buildProducerConfig(ackModes[i]);

            try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
                String key = "PAY-LATENCY-" + ackModes[i];
                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC, key, buildPaymentJson(key, 100.0));

                long start = System.nanoTime();
                Future<RecordMetadata> future = producer.send(record);
                if (!ackModes[i].equals("0")) {
                    future.get(); // Wait for confirmation
                }
                producer.flush();
                long latencyMs = (System.nanoTime() - start) / 1_000_000;

                logger.info("  {}: {}ms", ackLabels[i], latencyMs);
            }
        }

        logger.info("");
        logger.info("TRADE-OFF SUMMARY:");
        logger.info("  acks=0:   Fastest  | Least Safe  | NOT for payments");
        logger.info("  acks=1:   Medium   | Medium Safe | Consider risk");
        logger.info("  acks=all: Slowest  | Safest      | REQUIRED for payments");
    }

    /**
     * DEMO 5: min.insync.replicas Explanation
     *
     * TRAINER SCRIPT:
     * "min.insync.replicas works WITH acks=all.
     *  It defines the MINIMUM number of replicas that must be in-sync
     *  for the producer's write to succeed.
     *
     *  Topic: min.insync.replicas=2, RF=3
     *  - Normal: 3 ISR → writes succeed (3 >= 2)
     *  - 1 broker down: 2 ISR → writes succeed (2 >= 2)
     *  - 2 brokers down: 1 ISR → writes FAIL (1 < 2) → NotEnoughReplicasException
     *
     *  This prevents 'dirty' writes where data might be lost."
     */
    private void explainMinInsyncReplicas() {
        logger.info("");
        logger.info("--- DEMO 5: min.insync.replicas Explained ---");
        logger.info("");
        logger.info("Configuration: topic min.insync.replicas=2, Replication Factor=3");
        logger.info("");
        logger.info("SCENARIO 1: All 3 brokers healthy");
        logger.info("  ISR = [Broker1, Broker2, Broker3]  (3 >= 2) ✓ WRITES SUCCEED");
        logger.info("");
        logger.info("SCENARIO 2: Broker3 goes down");
        logger.info("  ISR = [Broker1, Broker2]            (2 >= 2) ✓ WRITES SUCCEED");
        logger.info("");
        logger.info("SCENARIO 3: Broker2 AND Broker3 go down");
        logger.info("  ISR = [Broker1]                     (1 <  2) ✗ WRITES FAIL");
        logger.info("  Error: NotEnoughReplicasException");
        logger.info("  → Cluster refuses to accept new payments until replicas recover");
        logger.info("  → PREVENTS data loss by refusing rather than proceeding unsafely");
        logger.info("");
        logger.info("PAYMENT SYSTEM RECOMMENDATION:");
        logger.info("  Broker config:   min.insync.replicas=2");
        logger.info("  Topic config:    replication.factor=3");
        logger.info("  Producer config: acks=all, retries=Integer.MAX_VALUE");
        logger.info("  → Tolerates 1 broker failure with zero data loss");
    }

    private Properties buildProducerConfig(String acks) {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, acks);
        return props;
    }

    private String buildPaymentJson(String paymentId, double amount) {
        return String.format(
            "{\"paymentId\":\"%s\",\"amount\":%.2f,\"timestamp\":%d}",
            paymentId, amount, System.currentTimeMillis()
        );
    }
}