package com.kafka.training.Day2Module1_Schema;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

/**
 * ============================================================
 * DAY 2 - MODULE 1: SCHEMA & COMPATIBILITY
 * Sub-Demo 3: Avro Consumer with Schema Registry
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - Consuming Avro messages with KafkaAvroDeserializer
 * - Schema reader vs writer compatibility
 * - Reading V2 messages with V1 consumer (backward compat demo)
 *
 * TRAINER NOTES:
 * "The consumer's deserializer:
 *  1. Reads magic byte (0x00) - validates it's Confluent format
 *  2. Reads 4-byte schema ID
 *  3. Fetches schema from registry using that ID
 *  4. Deserializes the Avro binary payload
 *  The consumer NEVER needs to know the schema upfront!"
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module1_Schema.AvroConsumer"
 * (Run AvroProducer first!)
 * ============================================================
 */
public class AvroConsumer {

    private static final Logger logger = LoggerFactory.getLogger(AvroConsumer.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final String SCHEMA_REGISTRY_URL = "http://localhost:8081";
    private static final String TOPIC = "payment-created";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 1: Avro Consumer Demo");
        logger.info("============================================================");

        AvroConsumer demo = new AvroConsumer();

        // DEMO 1: Consume Avro messages
        logger.info("");
        logger.info("=== DEMO 1: Consume Avro PaymentEvents ===");
        demo.consumeAvroMessages();

        logger.info("============================================================");
        logger.info("  Avro Consumer Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Consume Avro Messages
     *
     * TRAINER SCRIPT:
     * "Watch how the consumer automatically gets the schema
     *  from the registry and deserializes correctly.
     *  V1 and V2 messages are BOTH handled transparently."
     */
    private void consumeAvroMessages() throws Exception {
        logger.info("Connecting to Kafka and Schema Registry...");
        logger.info("Consuming both V1 and V2 PaymentEvent messages");
        logger.info("");

        Properties props = buildAvroConsumerConfig("avro-payment-consumer-group");

        try (KafkaConsumer<String, GenericRecord> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Collections.singletonList(TOPIC));

            int consumed = 0;
            int maxMessages = 20;
            long endTime = System.currentTimeMillis() + 15_000; // 15 second window

            while (consumed < maxMessages && System.currentTimeMillis() < endTime) {
                ConsumerRecords<String, GenericRecord> records =
                    consumer.poll(Duration.ofMillis(2000));

                for (ConsumerRecord<String, GenericRecord> record : records) {
                    GenericRecord payment = record.value();

                    // Check if this is a V1 or V2 message by checking for new fields
                    boolean isV2 = payment.getSchema().getField("processingRegion") != null;

                    logger.info("--- Consumed {} Message ---", isV2 ? "V2" : "V1");
                    logger.info("  Kafka metadata:");
                    logger.info("    partition={}, offset={}", record.partition(), record.offset());
                    logger.info("  Payment data:");
                    logger.info("    paymentId:   {}", payment.get("paymentId"));
                    logger.info("    customerId:  {}", payment.get("customerId"));
                    logger.info("    amount:      {}", payment.get("amount"));
                    logger.info("    currency:    {}", payment.get("currency"));
                    logger.info("    status:      {}", payment.get("status"));
                    logger.info("    merchantId:  {}", payment.get("merchantId"));
                    logger.info("    timestamp:   {}", payment.get("timestamp"));

                    if (isV2) {
                        // V2-specific fields
                        logger.info("    processingRegion: {} (V2 field)",
                            payment.get("processingRegion"));
                        logger.info("    riskScore:        {} (V2 field)",
                            payment.get("riskScore"));
                    } else {
                        logger.info("    processingRegion: N/A (V1 message)");
                        logger.info("    riskScore:        N/A (V1 message)");
                    }

                    // Commit offset after successful processing
                    consumer.commitSync();
                    consumed++;

                    if (consumed >= maxMessages) break;
                }

                if (records.isEmpty()) {
                    logger.info("No new Avro messages (waiting...)");
                }
            }

            logger.info("");
            logger.info("✓ Consumed {} Avro messages", consumed);
            logger.info("  Schema compatibility demonstrated:");
            logger.info("  - V1 messages deserialized correctly");
            logger.info("  - V2 messages deserialized with new fields");
            logger.info("  - Single consumer handled BOTH versions transparently");
        }
    }

    private Properties buildAvroConsumerConfig(String groupId) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        // Avro deserializer
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
            KafkaAvroDeserializer.class.getName());
        // Schema Registry URL
        props.put(KafkaAvroDeserializerConfig.SCHEMA_REGISTRY_URL_CONFIG, SCHEMA_REGISTRY_URL);
        // Use GenericRecord (not SpecificRecord) for flexibility
        props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, false);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        return props;
    }
}