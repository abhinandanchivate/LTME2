package com.kafka.training.Day2Module1_Schema;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Properties;

/**
 * ============================================================
 * DAY 2 - MODULE 1: SCHEMA & COMPATIBILITY
 * Sub-Demo 2: Avro Producer with Schema Registry
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - Producing Avro messages with KafkaAvroSerializer
 * - GenericRecord vs SpecificRecord
 * - Schema Registry auto-registration
 * - Message format: [magic byte][schema ID][avro bytes]
 *
 * TRAINER NOTES:
 * "KafkaAvroSerializer automatically:
 *  1. Connects to Schema Registry
 *  2. Registers schema if not exists
 *  3. Gets schema ID
 *  4. Serializes message as: magic(1 byte) + schemaId(4 bytes) + avro payload
 *  The consumer then reverses this process."
 *
 * FIX APPLIED:
 * - Lambda callback captures 'paymentId' as effectively final
 *   by assigning to a new final local variable inside the loop
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module1_Schema.AvroProducer"
 * ============================================================
 */
public class AvroProducer {

    private static final Logger logger = LoggerFactory.getLogger(AvroProducer.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final String SCHEMA_REGISTRY_URL = "http://localhost:8081";
    private static final String TOPIC = "payment-created";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 2 - MODULE 1: Avro Producer Demo");
        logger.info("============================================================");

        AvroProducer demo = new AvroProducer();

        // DEMO 1: Produce using Generic Record (schema loaded at runtime)
        logger.info("");
        logger.info("=== DEMO 1: Produce Avro PaymentEvent using GenericRecord ===");
        demo.produceWithGenericRecord();

        // DEMO 2: Produce V2 messages (schema evolution demo)
        logger.info("");
        logger.info("=== DEMO 2: Produce V2 PaymentEvent (Schema Evolution) ===");
        demo.produceWithV2Schema();

        // DEMO 3: Show the wire format
        demo.explainAvroWireFormat();

        logger.info("============================================================");
        logger.info("  Avro Producer Demo Complete!");
        logger.info("  → Now run AvroConsumer.java to consume these events");
        logger.info("  → Check http://localhost:8081/subjects for registered schemas");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Produce using GenericRecord
     *
     * TRAINER SCRIPT:
     * "GenericRecord lets you work with Avro without generating
     *  Java classes. You reference fields by name as strings.
     *  This is flexible but less type-safe.
     *
     *  SpecificRecord (generated classes) is more type-safe
     *  but requires schema compilation step."
     *
     * FIX: The lambda callback in producer.send() cannot capture
     *      a loop variable (paymentId) unless it is effectively final.
     *      Solution: assign paymentId to a new final variable
     *      'finalPaymentId' before the lambda, and use that instead.
     */
    private void produceWithGenericRecord() throws Exception {
        logger.info("Loading PaymentEvent schema from classpath...");

        // Load schema from resources
        Schema schema = loadSchema("/avro/PaymentEvent.avsc");
        logger.info("Schema loaded: {}", schema.getName());
        logger.info("");

        // Build Avro producer config
        Properties props = buildAvroProducerConfig();

        try (KafkaProducer<String, GenericRecord> producer = new KafkaProducer<>(props)) {

            // Create 5 payment events as Avro GenericRecords
            for (int i = 1; i <= 5; i++) {

                // ── FIX: declare as final so lambda can capture it ────────
                final String paymentId = "PAY-AVRO-" + String.format("%04d", i);
                // ─────────────────────────────────────────────────────────

                final String customerId = "CUST-" + (3000 + i);
                final int index = i; // capture loop index if needed inside lambda

                // Build GenericRecord - fields must match schema exactly
                GenericRecord paymentRecord = new GenericData.Record(schema);
                paymentRecord.put("paymentId", paymentId);
                paymentRecord.put("customerId", customerId);
                paymentRecord.put("amount", 100.0 * i);
                paymentRecord.put("currency", "USD");
                paymentRecord.put("status", "CREATED");         // Must match enum symbol
                paymentRecord.put("merchantId", "MERCHANT-001");
                paymentRecord.put("timestamp", System.currentTimeMillis());

                // Build metadata map
                HashMap<String, String> metadata = new HashMap<>();
                metadata.put("channel", "WEB");
                metadata.put("ipAddress", "192.168.1." + i);
                paymentRecord.put("metadata", metadata);

                // Create Kafka record with paymentId as key
                ProducerRecord<String, GenericRecord> record =
                        new ProducerRecord<>(TOPIC, paymentId, paymentRecord);

                // ── CALLBACK: paymentId is final, safe to use in lambda ───
                producer.send(record, (metadata2, exception) -> {
                    if (exception == null) {
                        logger.info("✓ Avro message sent: paymentId={} → partition={}, offset={}",
                                paymentId,                  // effectively final ✓
                                metadata2.partition(),
                                metadata2.offset());
                    } else {
                        logger.error("✗ Failed to send: paymentId={}, error={}",
                                paymentId,                  // effectively final ✓
                                exception.getMessage());
                    }
                });
                // ─────────────────────────────────────────────────────────

                logger.info("  Queued: paymentId={}, amount=${}, customerId={}",
                        paymentId, 100.0 * i, customerId);
            }

            producer.flush();
            logger.info("");
            logger.info("✓ All Avro payment events sent!");
            logger.info("  Schema auto-registered in Schema Registry");
            logger.info("  Each message contains: [0x00][schemaId(4)][avro-bytes]");
        }
    }

    /**
     * DEMO 2: Produce V2 Messages (Schema Evolution)
     *
     * TRAINER SCRIPT:
     * "Now we produce with the V2 schema that has new fields.
     *  Old consumers using V1 schema will still work because:
     *  - New fields have defaults
     *  - Old consumers simply ignore the new fields"
     *
     * FIX: Same pattern - all loop-related variables declared final
     *      before use inside the lambda callback.
     */
    private void produceWithV2Schema() throws Exception {
        logger.info("Loading PaymentEvent V2 schema...");

        Schema v2Schema = loadSchema("/avro/PaymentEventV2.avsc");
        logger.info("V2 Schema loaded with new fields: processingRegion, riskScore");
        logger.info("");

        Properties props = buildAvroProducerConfig();

        try (KafkaProducer<String, GenericRecord> producer = new KafkaProducer<>(props)) {

            for (int i = 1; i <= 3; i++) {

                // ── FIX: effectively final variables for lambda capture ───
                final String paymentId = "PAY-AVRO-V2-" + String.format("%04d", i);
                final double riskScoreValue = 0.15 * i;
                // ─────────────────────────────────────────────────────────

                GenericRecord paymentV2 = new GenericData.Record(v2Schema);
                paymentV2.put("paymentId", paymentId);
                paymentV2.put("customerId", "CUST-V2-" + i);
                paymentV2.put("amount", 250.0 * i);
                paymentV2.put("currency", "USD");
                paymentV2.put("status", "CREATED");
                paymentV2.put("merchantId", "MERCHANT-001");
                paymentV2.put("timestamp", System.currentTimeMillis());
                paymentV2.put("metadata", new HashMap<String, String>());
                // V2-specific fields
                paymentV2.put("processingRegion", "EU-WEST");
                paymentV2.put("riskScore", riskScoreValue);

                ProducerRecord<String, GenericRecord> record =
                        new ProducerRecord<>(TOPIC, paymentId, paymentV2);

                // ── CALLBACK: all captured variables are effectively final ─
                producer.send(record, (metadata, ex) -> {
                    if (ex == null) {
                        logger.info("✓ V2 Avro sent: paymentId={} → partition={}, offset={}",
                                paymentId,              // effectively final ✓
                                metadata.partition(),
                                metadata.offset());
                    } else {
                        logger.error("✗ V2 send failed: paymentId={}, error={}",
                                paymentId,              // effectively final ✓
                                ex.getMessage());
                    }
                });
                // ─────────────────────────────────────────────────────────

                logger.info("  V2 Message: paymentId={}, region=EU-WEST, riskScore={}",
                        paymentId, riskScoreValue);
            }

            producer.flush();
            logger.info("");
            logger.info("✓ V2 messages produced!");
            logger.info("  V1 consumers will still read these correctly (using defaults)");
            logger.info("  V2 consumers will read all fields including new ones");
        }
    }

    /**
     * Explain Avro Wire Format
     *
     * TRAINER SCRIPT:
     * "Every Kafka Avro message has a 5-byte header prepended
     *  by the Confluent serializer before the actual Avro binary payload."
     */
    private void explainAvroWireFormat() {
        logger.info("");
        logger.info("--- Avro Wire Format Explanation ---");
        logger.info("");
        logger.info("EVERY Kafka Avro message has this format:");
        logger.info("");
        logger.info("  Byte 0:     Magic byte = 0x00 (Confluent format identifier)");
        logger.info("  Bytes 1-4:  Schema ID (4-byte integer, e.g., 0x00000001 = ID 1)");
        logger.info("  Bytes 5+:   Avro binary encoded payload");
        logger.info("");
        logger.info("EXAMPLE for paymentId='PAY-AVRO-0001':");
        logger.info("  [0x00] [0x00 0x00 0x00 0x01] [avro-binary-data...]");
        logger.info("    │              │                      │");
        logger.info("    │              │                      └── Actual payment data");
        logger.info("    │              └── Schema ID: 1 (fetched from registry)");
        logger.info("    └── Confluent magic byte");
        logger.info("");
        logger.info("WHY SCHEMA ID vs FULL SCHEMA?");
        logger.info("  Full Avro schema for PaymentEvent ≈ 800 bytes");
        logger.info("  Schema ID ≈ 4 bytes");
        logger.info("  Savings: 796 bytes per message × millions of messages = significant!");
    }

    /**
     * Load Avro schema from classpath resources
     */
    private Schema loadSchema(String resourcePath) throws IOException {
        try (InputStream is = getClass().getResourceAsStream(resourcePath)) {
            if (is == null) {
                throw new IOException("Schema resource not found: " + resourcePath);
            }
            String schemaString = new String(is.readAllBytes(), StandardCharsets.UTF_8);
            return new Schema.Parser().parse(schemaString);
        }
    }

    /**
     * Build Avro producer configuration
     */
    private Properties buildAvroProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                StringSerializer.class.getName());
        // Avro serializer - handles schema registration automatically
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                KafkaAvroSerializer.class.getName());
        // Schema Registry URL - required by KafkaAvroSerializer
        props.put(KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG,
                SCHEMA_REGISTRY_URL);
        // Auto-register schema if not already registered
        props.put(KafkaAvroSerializerConfig.AUTO_REGISTER_SCHEMAS, true);
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "avro-payment-producer");
        return props;
    }
}