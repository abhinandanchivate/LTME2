package com.kafka.training.Day1Module3_ProducersConsumers;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;

/**
 * ============================================================
 * DAY 1 - MODULE 3: PRODUCERS & CONSUMERS
 * Sub-Demo 2: Payment Event Consumer
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - Consumer configuration (group.id, auto.offset.reset)
 * - Subscribe vs Assign
 * - Poll loop
 * - Manual vs automatic offset commits
 * - Consumer record metadata
 * - Delivery semantics (at-most-once, at-least-once, exactly-once)
 *
 * TRAINER NOTES:
 * Show three consumption patterns:
 * 1. Basic consumer (auto-commit)
 * 2. Manual commit consumer (at-least-once)
 * 3. Consumer with offset seek (replay capability)
 *
 * IMPORTANT: Run PaymentProducer first to have messages to consume!
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module3_ProducersConsumers.PaymentConsumer"
 * ============================================================
 */
public class PaymentConsumer {

    private static final Logger logger = LoggerFactory.getLogger(PaymentConsumer.class);

    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final String TOPIC_PAYMENT_CREATED = "payment-created";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    // Volatile flag to allow graceful shutdown
    private volatile boolean running = true;

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 3: Payment Event Consumer Demo");
        logger.info("============================================================");

        PaymentConsumer demo = new PaymentConsumer();

        // DEMO 1: Auto-Commit Consumer (At-Most-Once)
        logger.info("");
        logger.info("=== DEMO 1: Auto-Commit Consumer (At-Most-Once Delivery) ===");
        demo.demonstrateAutoCommitConsumer();

        // DEMO 2: Manual Commit Consumer (At-Least-Once)
        logger.info("");
        logger.info("=== DEMO 2: Manual Commit Consumer (At-Least-Once Delivery) ===");
        demo.demonstrateManualCommitConsumer();

        // DEMO 3: Seek to Beginning (Event Replay)
        logger.info("");
        logger.info("=== DEMO 3: Event Replay - Seek to Beginning ===");
        demo.demonstrateSeekToBeginning();

        logger.info("");
        logger.info("============================================================");
        logger.info("  Consumer Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Auto-Commit Consumer
     *
     * TRAINER SCRIPT:
     * "Auto-commit means Kafka automatically commits the offset
     *  every 'auto.commit.interval.ms' milliseconds.
     *
     *  RISK: If your app crashes AFTER reading but BEFORE processing,
     *  the offset was committed, so the message is LOST (at-most-once).
     *
     *  USE CASE: Analytics, dashboards where losing a message is OK."
     */
    private void demonstrateAutoCommitConsumer() throws Exception {
        logger.info("Delivery Semantic: AT-MOST-ONCE (may lose messages on crash)");
        logger.info("Config: enable.auto.commit=true, auto.commit.interval.ms=5000");
        logger.info("");

        Properties props = buildConsumerConfig("payment-processor-auto-commit-group");
        // AUTO-COMMIT SETTINGS
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "true");
        props.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, "5000"); // Every 5 seconds
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest"); // Start from beginning

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Collections.singletonList(TOPIC_PAYMENT_CREATED));

            logger.info("Subscribed to topic: {}", TOPIC_PAYMENT_CREATED);
            logger.info("Polling for messages (10 second window)...");
            logger.info("");

            long endTime = System.currentTimeMillis() + 10_000; // Poll for 10 seconds

            while (System.currentTimeMillis() < endTime) {
                // Poll for records with 1-second timeout
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));

                for (ConsumerRecord<String, String> record : records) {
                    // Process the payment event
                    processPaymentRecord(record, "AUTO-COMMIT");

                    // NOTE: Offset committed automatically in background
                    // If crash here, message might be processed again OR lost
                    // depending on when auto-commit fired
                }

                if (records.isEmpty()) {
                    logger.info("  No new messages (all caught up)...");
                }
            }
        }

        logger.info("");
        logger.info("TRAINER NOTE: Auto-commit is simple but risky for payments!");
    }

    /**
     * DEMO 2: Manual Commit Consumer
     *
     * TRAINER SCRIPT:
     * "Manual commit means WE control when offsets are committed.
     *  We process the message FIRST, then commit the offset.
     *
     *  If we crash after processing but before committing:
     *  → Message gets reprocessed (at-least-once)
     *  → We must make our processing IDEMPOTENT
     *
     *  USE CASE: Payment processing, financial transactions.
     *  Payment systems should ALWAYS use manual commit."
     */
    private void demonstrateManualCommitConsumer() throws Exception {
        logger.info("Delivery Semantic: AT-LEAST-ONCE (may process duplicates)");
        logger.info("Config: enable.auto.commit=false, commitSync after processing");
        logger.info("");

        Properties props = buildConsumerConfig("payment-processor-manual-commit-group");
        // DISABLE AUTO-COMMIT - We control when to commit
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        // Process in small batches for responsiveness
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "10");

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Collections.singletonList(TOPIC_PAYMENT_CREATED));

            logger.info("Subscribed to topic: {} (manual commit mode)", TOPIC_PAYMENT_CREATED);
            logger.info("");

            long endTime = System.currentTimeMillis() + 10_000;

            while (System.currentTimeMillis() < endTime) {
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));

                if (!records.isEmpty()) {
                    // STEP 1: Process all records in the batch
                    for (ConsumerRecord<String, String> record : records) {
                        boolean success = processPaymentRecord(record, "MANUAL-COMMIT");

                        if (!success) {
                            // If processing fails, DO NOT commit
                            // Will be reprocessed on next poll
                            logger.warn("Processing failed for offset {}, will retry", record.offset());
                            break; // Stop processing this batch
                        }
                    }

                    // STEP 2: Commit AFTER successful processing
                    // commitSync() blocks until broker confirms commit
                    try {
                        consumer.commitSync();
                        logger.info("  ✓ Offset committed (processed {} records)", records.count());
                    } catch (CommitFailedException e) {
                        logger.error("  ✗ Commit failed: {} - will reprocess", e.getMessage());
                    }
                } else {
                    logger.info("  No new messages...");
                }
            }
        }

        logger.info("");
        logger.info("TRAINER NOTE: Manual commit is the RIGHT choice for payments!");
        logger.info("IDEMPOTENCY KEY: Use paymentId to detect duplicate processing");
    }

    /**
     * DEMO 3: Seek to Beginning (Event Replay)
     *
     * TRAINER SCRIPT:
     * "One of Kafka's superpowers: you can REPLAY events!
     *  If your fraud detection model is updated, you can replay
     *  ALL payment events from the last 7 days through the new model.
     *
     *  This is IMPOSSIBLE with traditional message queues."
     */
    private void demonstrateSeekToBeginning() throws Exception {
        logger.info("Kafka Superpower: REPLAY events from any point in time!");
        logger.info("");

        Properties props = buildConsumerConfig("payment-replay-group-" + System.currentTimeMillis());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        // NOTE: auto.offset.reset doesn't matter here because we seek manually
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Collections.singletonList(TOPIC_PAYMENT_CREATED));

            // Initial poll to trigger partition assignment
            consumer.poll(Duration.ofMillis(1000));

            // GET all assigned partitions
            Set<TopicPartition> assignedPartitions = consumer.assignment();
            logger.info("Assigned partitions: {}", assignedPartitions);

            // SEEK TO BEGINNING of all assigned partitions
            consumer.seekToBeginning(assignedPartitions);
            logger.info("Seeked to BEGINNING of all partitions - replaying all events!");
            logger.info("");

            // Read and replay up to 20 records
            int maxReplayCount = 20;
            int replayedCount = 0;

            while (replayedCount < maxReplayCount) {
                ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(2000));

                if (records.isEmpty()) {
                    logger.info("  Replay complete - no more records");
                    break;
                }

                for (ConsumerRecord<String, String> record : records) {
                    logger.info("  [REPLAY] partition={}, offset={}, key={} → {}",
                        record.partition(),
                        record.offset(),
                        record.key(),
                        record.value().substring(0, Math.min(60, record.value().length())) + "...");
                    replayedCount++;
                    if (replayedCount >= maxReplayCount) break;
                }
            }

            logger.info("");
            logger.info("Replayed {} events!", replayedCount);
            logger.info("USE CASE: Reprocess payments through updated fraud model");
            logger.info("USE CASE: Rebuild ledger from payment event history");
            logger.info("USE CASE: Debug production issues by replaying traffic");
        }
    }

    /**
     * Process a payment record (simulates business logic)
     *
     * @return true if processing succeeded, false if failed
     */
    private boolean processPaymentRecord(ConsumerRecord<String, String> record,
                                          String mode) {
        try {
            // Parse the JSON payment
            JsonNode payment = objectMapper.readTree(record.value());

            String paymentId = payment.has("paymentId") ? payment.get("paymentId").asText() : "UNKNOWN";
            double amount = payment.has("amount") ? payment.get("amount").asDouble() : 0.0;

            logger.info("  [{}] Processing: key={}, paymentId={}, amount=${:.2f}",
                mode,
                record.key(),
                paymentId,
                amount);
            logger.info("         partition={}, offset={}, timestamp={}",
                record.partition(),
                record.offset(),
                record.timestamp());

            // Simulate processing time
            Thread.sleep(50);

            // Simulate occasional failures for demo (5% failure rate)
            if (Math.random() < 0.05) {
                throw new RuntimeException("Simulated processing failure");
            }

            return true;

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        } catch (Exception e) {
            logger.error("  Failed to process record at offset {}: {}", record.offset(), e.getMessage());
            return false;
        }
    }

    /**
     * Build consumer configuration
     */
    private Properties buildConsumerConfig(String groupId) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.CLIENT_ID_CONFIG, "payment-consumer-" + groupId);
        // Heartbeat settings
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG, "3000");
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, "45000");
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, "300000");
        return props;
    }
}