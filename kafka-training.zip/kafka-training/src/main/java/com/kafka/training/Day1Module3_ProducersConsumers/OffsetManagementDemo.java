package com.kafka.training.Day1Module3_ProducersConsumers;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

/**
 * ============================================================
 * DAY 1 - MODULE 3: PRODUCERS & CONSUMERS
 * Sub-Demo 4: Offset Management
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - What is an offset?
 * - Committed offsets vs current position
 * - offsetsForTimes() - seek by timestamp
 * - Delivery semantics in detail
 *
 * TRAINER NOTES:
 * "Offsets are like page numbers in a book.
 *  Kafka remembers which page each consumer group last read.
 *  You can jump to any page at any time."
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module3_ProducersConsumers.OffsetManagementDemo"
 * ============================================================
 */
public class OffsetManagementDemo {

    private static final Logger logger = LoggerFactory.getLogger(OffsetManagementDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final String TOPIC = "payment-created";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 3: Offset Management Demo");
        logger.info("============================================================");

        OffsetManagementDemo demo = new OffsetManagementDemo();

        // DEMO 1: Show committed offsets
        demo.showCommittedOffsets();

        // DEMO 2: Per-partition manual commit
        demo.demonstratePerPartitionCommit();

        // DEMO 3: Seek by timestamp (powerful replay feature)
        demo.demonstrateSeekByTimestamp();

        // DEMO 4: Delivery semantics summary
        demo.explainDeliverySemantics();

        logger.info("============================================================");
        logger.info("  Offset Management Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Show Current Committed Offsets
     *
     * TRAINER SCRIPT:
     * "Let's see where each consumer group currently is.
     *  The offset tells us the NEXT message the consumer will read."
     */
    private void showCommittedOffsets() {
        logger.info("");
        logger.info("--- DEMO 1: Committed Offsets for Consumer Groups ---");

        Properties props = buildConsumerConfig("offset-viewer-group-" + System.currentTimeMillis());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            // Manually assign all partitions (don't subscribe to avoid rebalance)
            List<TopicPartition> partitions = List.of(
                new TopicPartition(TOPIC, 0),
                new TopicPartition(TOPIC, 1),
                new TopicPartition(TOPIC, 2)
            );
            consumer.assign(partitions);

            // Get beginning offsets (first available offset)
            Map<TopicPartition, Long> beginningOffsets = consumer.beginningOffsets(partitions);

            // Get end offsets (next offset to be written)
            Map<TopicPartition, Long> endOffsets = consumer.endOffsets(partitions);

            logger.info("Partition State for topic '{}':", TOPIC);
            logger.info("");
            for (TopicPartition tp : partitions) {
                long beginning = beginningOffsets.getOrDefault(tp, 0L);
                long end = endOffsets.getOrDefault(tp, 0L);
                long messageCount = end - beginning;

                logger.info("  Partition {}: earliest={}, latest={}, messageCount={}",
                    tp.partition(), beginning, end, messageCount);
            }

            logger.info("");
            logger.info("TRAINER NOTE:");
            logger.info("  'latest' offset = next write position");
            logger.info("  messageCount = end - beginning (not committed!)");
            logger.info("  Run: docker exec kafka-broker-1 kafka-consumer-groups \\");
            logger.info("       --bootstrap-server localhost:9092 --list");
        }
    }

    /**
     * DEMO 2: Per-Partition Manual Commit
     *
     * TRAINER SCRIPT:
     * "Advanced pattern: commit each partition separately.
     *  Gives you fine-grained control over exactly what's committed.
     *  Useful when processing some partitions fails."
     */
    private void demonstratePerPartitionCommit() throws Exception {
        logger.info("");
        logger.info("--- DEMO 2: Per-Partition Manual Commit ---");
        logger.info("Committing each partition offset independently");
        logger.info("");

        Properties props = buildConsumerConfig("per-partition-commit-group");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "5");

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Collections.singletonList(TOPIC));

            // Poll once
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofSeconds(5));

            if (records.isEmpty()) {
                logger.info("No records found. Ensure PaymentProducer has run first.");
                return;
            }

            // Track offsets per partition
            Map<TopicPartition, OffsetAndMetadata> partitionOffsets = new HashMap<>();

            for (ConsumerRecord<String, String> record : records) {
                logger.info("  Processing: partition={}, offset={}, key={}",
                    record.partition(), record.offset(), record.key());

                // Simulate processing
                Thread.sleep(50);

                // Track the offset for this partition
                // Note: commit offset + 1 (next message to consume)
                TopicPartition tp = new TopicPartition(record.topic(), record.partition());
                partitionOffsets.put(tp, new OffsetAndMetadata(
                    record.offset() + 1,
                    "processed-at=" + Instant.now()
                ));
            }

            // Commit all partition offsets at once
            consumer.commitSync(partitionOffsets);
            logger.info("");
            logger.info("✓ Committed offsets per partition: {}", partitionOffsets);
        }
    }

    /**
     * DEMO 3: Seek by Timestamp
     *
     * TRAINER SCRIPT:
     * "This is incredibly powerful for payment systems!
     *  We can say: 'Give me all payments from the last hour'
     *  Without knowing exact offsets - just using timestamps."
     */
    private void demonstrateSeekByTimestamp() throws Exception {
        logger.info("");
        logger.info("--- DEMO 3: Seek by Timestamp (Time-Based Replay) ---");
        logger.info("'Show me all payments from the last 30 minutes'");
        logger.info("");

        Properties props = buildConsumerConfig("timestamp-seek-group-" + System.currentTimeMillis());
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            List<TopicPartition> partitions = List.of(
                new TopicPartition(TOPIC, 0),
                new TopicPartition(TOPIC, 1),
                new TopicPartition(TOPIC, 2)
            );
            consumer.assign(partitions);

            // Calculate timestamp: 30 minutes ago
            long thirtyMinutesAgo = System.currentTimeMillis() - (30 * 60 * 1000);
            logger.info("Looking for messages since: {} (30 min ago)", Instant.ofEpochMilli(thirtyMinutesAgo));

            // Create timestamp query map
            Map<TopicPartition, Long> timestampMap = new HashMap<>();
            for (TopicPartition tp : partitions) {
                timestampMap.put(tp, thirtyMinutesAgo);
            }

            // Find offsets corresponding to the timestamps
            Map<TopicPartition, OffsetAndTimestamp> offsetsForTimes =
                consumer.offsetsForTimes(timestampMap);

            // Seek to the found offsets
            for (Map.Entry<TopicPartition, OffsetAndTimestamp> entry : offsetsForTimes.entrySet()) {
                TopicPartition tp = entry.getKey();
                OffsetAndTimestamp offsetAndTimestamp = entry.getValue();

                if (offsetAndTimestamp != null) {
                    logger.info("  Seeking partition {} to offset {} (timestamp={})",
                        tp.partition(),
                        offsetAndTimestamp.offset(),
                        Instant.ofEpochMilli(offsetAndTimestamp.timestamp()));
                    consumer.seek(tp, offsetAndTimestamp.offset());
                } else {
                    // No messages in this partition since the timestamp
                    logger.info("  Partition {} has no messages since {}", tp.partition(),
                        Instant.ofEpochMilli(thirtyMinutesAgo));
                }
            }

            // Now consume messages from those positions
            int count = 0;
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofSeconds(5));
            for (ConsumerRecord<String, String> record : records) {
                logger.info("  [REPLAY] partition={}, offset={}, timestamp={}, key={}",
                    record.partition(),
                    record.offset(),
                    Instant.ofEpochMilli(record.timestamp()),
                    record.key());
                count++;
                if (count >= 10) break;
            }

            logger.info("");
            logger.info("Found {} recent payment events from the last 30 minutes", count);
        }
    }

    /**
     * DEMO 4: Delivery Semantics Explained
     */
    private void explainDeliverySemantics() {
        logger.info("");
        logger.info("--- DEMO 4: Delivery Semantics Summary ---");
        logger.info("");
        logger.info("AT-MOST-ONCE (Auto Commit BEFORE Processing):");
        logger.info("  + Highest performance");
        logger.info("  - May LOSE messages if crash before processing");
        logger.info("  Use: Metrics, logging, non-critical events");
        logger.info("");
        logger.info("AT-LEAST-ONCE (Manual Commit AFTER Processing):");
        logger.info("  + No message loss");
        logger.info("  - May DUPLICATE messages if crash after processing");
        logger.info("  Requirement: Processing must be IDEMPOTENT");
        logger.info("  Use: Payment processing with idempotency key check");
        logger.info("");
        logger.info("EXACTLY-ONCE (Kafka Transactions + Idempotent Producer):");
        logger.info("  + No loss, no duplicates");
        logger.info("  - Higher overhead, lower throughput");
        logger.info("  Config: enable.idempotence=true, isolation.level=read_committed");
        logger.info("  Use: Financial settlements, ledger updates");
        logger.info("");
        logger.info("PAYMENT SYSTEM RECOMMENDATION:");
        logger.info("  Use AT-LEAST-ONCE + idempotency key in your database");
        logger.info("  OR use Kafka Transactions (exactly-once) for critical flows");
    }

    private Properties buildConsumerConfig(String groupId) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        return props;
    }
}