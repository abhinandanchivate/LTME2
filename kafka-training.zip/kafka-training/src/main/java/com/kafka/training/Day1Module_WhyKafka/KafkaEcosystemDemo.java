package com.kafka.training.Day1Module1_WhyKafka;

import org.apache.kafka.clients.admin.*;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ExecutionException;

/**
 * ============================================================
 * DAY 1 - MODULE 1: WHY KAFKA & WHEN TO USE IT
 * ============================================================
 *
 * TRAINER NOTES:
 * This demo illustrates:
 * 1. Traditional messaging vs Kafka streaming
 * 2. Kafka ecosystem components
 * 3. Payment event use cases
 *
 * KEY CONCEPTS TO EXPLAIN:
 * - Traditional MQ: Point-to-point, message deleted after consume
 * - Kafka: Log-based, messages retained, multiple consumers possible
 * - Kafka is NOT just a message queue - it's an event streaming platform
 *
 * DEMO FLOW:
 * 1. Show traditional messaging problems
 * 2. Show Kafka as a solution
 * 3. Walk through payment use cases
 *
 * PRE-REQUISITES:
 * - Docker Compose running (start-kafka.bat)
 * - Topics created (create-topics.bat)
 * ============================================================
 */
public class KafkaEcosystemDemo {

    private static final Logger logger = LoggerFactory.getLogger(KafkaEcosystemDemo.class);

    // Kafka broker connection string
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";

    // Payment events topics
    private static final String TOPIC_PAYMENT_CREATED = "payment-created";
    private static final String TOPIC_PAYMENT_SETTLED = "payment-settled";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 1: WHY KAFKA & WHEN TO USE IT");
        logger.info("============================================================");

        KafkaEcosystemDemo demo = new KafkaEcosystemDemo();

        // --------------------------------------------------------
        // DEMO 1: Show Traditional Messaging Problems
        // --------------------------------------------------------
        demo.demonstrateTraditionalMessagingProblems();

        // --------------------------------------------------------
        // DEMO 2: Show Kafka as a Solution
        // --------------------------------------------------------
        demo.demonstrateKafkaAdvantages();

        // --------------------------------------------------------
        // DEMO 3: Payment Use Cases
        // --------------------------------------------------------
        demo.demonstratePaymentUseCases();

        // --------------------------------------------------------
        // DEMO 4: Kafka Ecosystem Overview
        // --------------------------------------------------------
        demo.demonstrateKafkaEcosystem();

        logger.info("============================================================");
        logger.info("  Module 1 Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: Traditional Messaging Problems
     *
     * TRAINER SCRIPT:
     * "Imagine you have 5 microservices that need payment events.
     *  With a traditional message queue like RabbitMQ:
     *  - Once a message is consumed, it's GONE
     *  - Only ONE consumer gets each message
     *  - No replay capability
     *  - Tight coupling between producer and consumer"
     */
    private void demonstrateTraditionalMessagingProblems() {
        logger.info("");
        logger.info("--- DEMO 1: Traditional Messaging Problems ---");
        logger.info("PROBLEM 1: Point-to-Point - Only one consumer gets the message");
        logger.info("PROBLEM 2: No message replay after consumption");
        logger.info("PROBLEM 3: Producer/Consumer must be online simultaneously");
        logger.info("PROBLEM 4: Cannot handle high throughput (millions of events/sec)");
        logger.info("PROBLEM 5: Scaling requires complex queue topology");
        logger.info("");
        logger.info("PAYMENT SCENARIO:");
        logger.info("  PaymentService → [Queue] → FraudService");
        logger.info("  BUT: LedgerService, AuditService, AnalyticsService CANNOT all receive!");
        logger.info("  Traditional Solution: Create 4 separate queues = complexity nightmare");
    }

    /**
     * DEMO 2: Kafka Advantages
     *
     * TRAINER SCRIPT:
     * "Kafka solves this with a log-based approach:
     *  - Messages are WRITTEN to a durable log
     *  - ANY number of consumers can read independently
     *  - Messages are RETAINED (configurable, default 7 days)
     *  - Consumers can REPLAY events from any point"
     */
    private void demonstrateKafkaAdvantages() {
        logger.info("");
        logger.info("--- DEMO 2: Kafka Advantages over Traditional Messaging ---");
        logger.info("");
        logger.info("KAFKA SOLUTION - All services read independently:");
        logger.info("                 ┌── FraudService (Consumer Group A)");
        logger.info("  PaymentService ──→ [Kafka Topic: payment-created]");
        logger.info("                 ├── LedgerService (Consumer Group B)");
        logger.info("                 ├── AuditService (Consumer Group C)");
        logger.info("                 └── AnalyticsService (Consumer Group D)");
        logger.info("");
        logger.info("KEY ADVANTAGES:");
        logger.info("  ✓ Each consumer group reads independently");
        logger.info("  ✓ Messages retained (replay possible)");
        logger.info("  ✓ Horizontal scaling via partitions");
        logger.info("  ✓ Fault tolerant via replication");
        logger.info("  ✓ 1M+ messages/second throughput");
        logger.info("  ✓ Decoupled producers and consumers");
    }

    /**
     * DEMO 3: Payment Use Cases
     *
     * TRAINER SCRIPT:
     * "Let's look at real payment use cases where Kafka shines:"
     */
    private void demonstratePaymentUseCases() throws Exception {
        logger.info("");
        logger.info("--- DEMO 3: Payment Event Use Cases ---");
        logger.info("");
        logger.info("USE CASE 1: Real-time Fraud Detection");
        logger.info("  PaymentCreated → [Kafka] → FraudService (ML Model, <100ms)");
        logger.info("");
        logger.info("USE CASE 2: Payment Settlement Pipeline");
        logger.info("  PaymentApproved → [Kafka] → SettlementService → LedgerService");
        logger.info("");
        logger.info("USE CASE 3: Event Sourcing / Audit Trail");
        logger.info("  ALL payment state changes → [Kafka] → AuditLog (immutable)");
        logger.info("");
        logger.info("USE CASE 4: Real-time Analytics Dashboard");
        logger.info("  Payment events → [Kafka Streams] → Aggregations → Dashboard");
        logger.info("");
        logger.info("USE CASE 5: Regulatory Reporting");
        logger.info("  Payment events retained 7 years → Compliance reports on-demand");
        logger.info("");

        // Produce a sample payment event to show it's real
        produceSimplePaymentEvent("PAY-001", "CUST-123", 1500.00, "CREATED");
        produceSimplePaymentEvent("PAY-002", "CUST-456", 250.00, "CREATED");
        produceSimplePaymentEvent("PAY-003", "CUST-789", 9999.99, "CREATED"); // High value for fraud

        logger.info("  ✓ Produced 3 payment events to Kafka");
        logger.info("  → Open Kafka UI at http://localhost:8080 to see them!");
    }

    /**
     * DEMO 4: Kafka Ecosystem Overview
     *
     * TRAINER SCRIPT:
     * "Kafka is more than just a broker. It's an entire ecosystem:"
     */
    private void demonstrateKafkaEcosystem() {
        logger.info("");
        logger.info("--- DEMO 4: Kafka Ecosystem Components ---");
        logger.info("");
        logger.info("CORE COMPONENTS:");
        logger.info("  1. Kafka Broker    - The event storage & distribution engine");
        logger.info("  2. Zookeeper       - Cluster coordination (being replaced by KRaft)");
        logger.info("  3. Kafka Producer  - Writes events to topics");
        logger.info("  4. Kafka Consumer  - Reads events from topics");
        logger.info("");
        logger.info("ECOSYSTEM TOOLS:");
        logger.info("  5. Schema Registry - Enforce event schema contracts (Avro/JSON)");
        logger.info("  6. Kafka Connect   - Integrate with databases, S3, Elasticsearch");
        logger.info("  7. Kafka Streams   - Stream processing library (real-time analytics)");
        logger.info("  8. ksqlDB          - SQL interface for stream processing");
        logger.info("  9. Kafka UI        - Visual management dashboard");
        logger.info("");
        logger.info("OUR TRAINING CLUSTER:");
        logger.info("  Brokers:          localhost:9092, 9093, 9094");
        logger.info("  Schema Registry:  http://localhost:8081");
        logger.info("  Kafka UI:         http://localhost:8080");
        logger.info("");
        logger.info("→ TRAINER: Open http://localhost:8080 and show the cluster health");
    }

    /**
     * Helper method: Produce a simple payment event to Kafka
     * Used to demonstrate real data flowing through the system
     */
    private void produceSimplePaymentEvent(String paymentId, String customerId,
                                            double amount, String status) throws Exception {
        // Build producer configuration
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all"); // Wait for all replicas

        // Create JSON payload (we use simple JSON here, Avro is covered in Day 2)
        String eventJson = String.format(
            "{\"paymentId\":\"%s\",\"customerId\":\"%s\"," +
            "\"amount\":%.2f,\"status\":\"%s\",\"timestamp\":%d}",
            paymentId, customerId, amount, status, System.currentTimeMillis()
        );

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            // Use paymentId as key for partition assignment
            ProducerRecord<String, String> record =
                new ProducerRecord<>(TOPIC_PAYMENT_CREATED, paymentId, eventJson);

            producer.send(record, (metadata, exception) -> {
                if (exception == null) {
                    logger.info("  Event produced: paymentId={} → topic={}, partition={}, offset={}",
                        paymentId, metadata.topic(), metadata.partition(), metadata.offset());
                } else {
                    logger.error("  Failed to produce event: {}", exception.getMessage());
                }
            });
        }
    }
}