package com.kafka.training.Day1Module4_Reliability;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;
import java.util.concurrent.ExecutionException;

/**
 * ============================================================
 * DAY 1 - MODULE 4: RELIABILITY & ORDERING
 * Sub-Demo 2: Idempotent Producer
 * ============================================================
 *
 * CONCEPTS COVERED:
 * - Problem: duplicate messages due to retries
 * - enable.idempotence=true
 * - Producer ID (PID) and sequence numbers
 * - Exactly-once semantics at producer level
 *
 * TRAINER NOTES:
 * "Without idempotence:
 *  1. Producer sends PAY-001
 *  2. Broker writes PAY-001, network error on ack
 *  3. Producer retries, sends PAY-001 again
 *  4. Broker writes PAY-001 TWICE → duplicate payment!
 *
 *  With idempotence:
 *  1. Producer sends PAY-001 (sequence=1)
 *  2. Broker writes PAY-001, network error on ack
 *  3. Producer retries PAY-001 (same sequence=1)
 *  4. Broker detects duplicate sequence → IGNORES second write
 *  5. Sends ack anyway → producer happy, no duplicate!"
 *
 * RUN: mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module4_Reliability.IdempotentProducerDemo"
 * ============================================================
 */
public class IdempotentProducerDemo {

    private static final Logger logger = LoggerFactory.getLogger(IdempotentProducerDemo.class);
    private static final String BOOTSTRAP_SERVERS = "localhost:9092,localhost:9093,localhost:9094";
    private static final String TOPIC = "payment-created";

    public static void main(String[] args) throws Exception {
        logger.info("============================================================");
        logger.info("  DAY 1 - MODULE 4: Idempotent Producer Demo");
        logger.info("============================================================");

        IdempotentProducerDemo demo = new IdempotentProducerDemo();

        // DEMO 1: Problem - Duplicates without idempotence
        demo.demonstrateDuplicateProblem();

        // DEMO 2: Solution - Idempotent producer
        demo.demonstrateIdempotentProducer();

        // DEMO 3: Kafka Transactions (exactly-once)
        demo.demonstrateTransactionalProducer();

        logger.info("============================================================");
        logger.info("  Idempotent Producer Demo Complete!");
        logger.info("============================================================");
    }

    /**
     * DEMO 1: The Duplicate Problem (Without Idempotence)
     *
     * TRAINER SCRIPT:
     * "Let me show you the PROBLEM first.
     *  Without idempotence, retries can cause duplicate messages."
     */
    private void demonstrateDuplicateProblem() {
        logger.info("");
        logger.info("--- DEMO 1: Duplicate Problem (Without Idempotence) ---");
        logger.info("");
        logger.info("SCENARIO (hypothetical - we can't force network errors easily):");
        logger.info("");
        logger.info("  1. Producer sends: PAY-001 (amount=$500)");
        logger.info("  2. Broker writes PAY-001 to partition log");
        logger.info("  3. Broker sends ACK → NETWORK TIMEOUT!");
        logger.info("  4. Producer thinks: 'No ack received, must retry!'");
        logger.info("  5. Producer sends: PAY-001 AGAIN (amount=$500)");
        logger.info("  6. Broker writes PAY-001 AGAIN → DUPLICATE!");
        logger.info("  7. Result: Customer charged $1000 instead of $500!");
        logger.info("");
        logger.info("WITHOUT idempotence: retries = potential duplicates");
        logger.info("This is the at-least-once problem at the producer level");
    }

    /**
     * DEMO 2: Idempotent Producer Solution
     *
     * TRAINER SCRIPT:
     * "enable.idempotence=true adds a Producer ID (PID) and
     *  sequence number to EVERY message.
     *  The broker tracks which (PID, sequence) it has seen.
     *  If it sees the same (PID, sequence) again → it ignores it."
     */
    private void demonstrateIdempotentProducer() throws Exception {
        logger.info("");
        logger.info("--- DEMO 2: Idempotent Producer (Exactly-Once at Producer Level) ---");
        logger.info("Config: enable.idempotence=true");
        logger.info("Effect: Broker deduplicates retries using PID + SequenceNumber");
        logger.info("");

        Properties props = buildIdempotentProducerConfig();

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            logger.info("Producer created with idempotence enabled");
            logger.info("Kafka assigned this producer a unique PID (Producer ID)");
            logger.info("");

            // Produce 5 payment events
            for (int i = 1; i <= 5; i++) {
                String paymentId = "PAY-IDEMPOTENT-" + String.format("%03d", i);
                String paymentJson = String.format(
                    "{\"paymentId\":\"%s\",\"amount\":%.2f,\"timestamp\":%d}",
                    paymentId, 100.0 * i, System.currentTimeMillis()
                );

                ProducerRecord<String, String> record =
                    new ProducerRecord<>(TOPIC, paymentId, paymentJson);

                RecordMetadata metadata = producer.send(record).get();

                logger.info("✓ Produced [IDEMPOTENT]: paymentId={} → partition={}, offset={}",
                    paymentId, metadata.partition(), metadata.offset());
                logger.info("  Internal: PID assigned by broker, sequence={}", i);
                logger.info("  If this retry'd: broker would detect duplicate and drop it");
            }

            logger.info("");
            logger.info("✓ All messages produced exactly once!");
            logger.info("");
            logger.info("REQUIREMENTS for idempotence:");
            logger.info("  enable.idempotence=true");
            logger.info("  max.in.flight.requests.per.connection <= 5");
            logger.info("  acks=all (automatically set when idempotence enabled)");
            logger.info("  retries > 0 (automatically set to Integer.MAX_VALUE)");
        }
    }

    /**
     * DEMO 3: Transactional Producer (Exactly-Once End-to-End)
     *
     * TRAINER SCRIPT:
     * "Transactions let you write to MULTIPLE topics atomically.
     *  Either ALL writes succeed, or NONE do.
     *
     *  Payment use case:
     *  - Atomically write to payment-settled AND debit-ledger
     *  - If settlement succeeds but ledger write fails → ROLLBACK both
     *  - No partial updates!"
     */
    private void demonstrateTransactionalProducer() throws Exception {
        logger.info("");
        logger.info("--- DEMO 3: Transactional Producer (Atomic Multi-Topic Writes) ---");
        logger.info("Config: transactional.id=payment-service-txn-1");
        logger.info("Effect: Write to payment-settled AND payment-created atomically");
        logger.info("");

        Properties props = buildTransactionalProducerConfig("payment-service-txn-1");

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            // MUST call initTransactions first
            producer.initTransactions();
            logger.info("✓ Transactions initialized");
            logger.info("");

            // TRANSACTION 1: Successful payment settlement
            logger.info("TRANSACTION 1: Successful Payment Settlement");
            try {
                producer.beginTransaction();
                logger.info("  → Transaction STARTED");

                // Write to multiple topics atomically
                String paymentId = "PAY-TXN-001";

                // Write 1: Update payment status
                producer.send(new ProducerRecord<>(TOPIC, paymentId,
                    "{\"paymentId\":\"" + paymentId + "\",\"status\":\"SETTLED\"}"));
                logger.info("  → Written to payment-created (status=SETTLED)");

                // Write 2: Write to settlement topic
                producer.send(new ProducerRecord<>("payment-settled", paymentId,
                    "{\"paymentId\":\"" + paymentId + "\",\"settledAt\":" + System.currentTimeMillis() + "}"));
                logger.info("  → Written to payment-settled");

                // Commit both writes atomically
                producer.commitTransaction();
                logger.info("  → Transaction COMMITTED ✓");
                logger.info("  RESULT: Both topics updated atomically");

            } catch (Exception e) {
                producer.abortTransaction();
                logger.error("  → Transaction ABORTED: {}", e.getMessage());
            }

            logger.info("");

            // TRANSACTION 2: Failed transaction (rollback)
            logger.info("TRANSACTION 2: Simulated Failure (Rollback Demo)");
            try {
                producer.beginTransaction();
                logger.info("  → Transaction STARTED");

                String paymentId = "PAY-TXN-002";

                producer.send(new ProducerRecord<>(TOPIC, paymentId,
                    "{\"paymentId\":\"" + paymentId + "\",\"status\":\"SETTLING\"}"));
                logger.info("  → Written to payment-created (status=SETTLING)");

                // Simulate a business rule failure
                if (true) { // Always throws for demo
                    throw new RuntimeException("Insufficient funds for settlement!");
                }

                producer.commitTransaction();

            } catch (Exception e) {
                // ABORT: Both writes are ROLLED BACK
                producer.abortTransaction();
                logger.warn("  → Transaction ABORTED: {}", e.getMessage());
                logger.warn("  RESULT: payment-created write ROLLED BACK");
                logger.warn("  RESULT: No partial state in Kafka!");
            }

            logger.info("");
            logger.info("TRANSACTIONAL SUMMARY:");
            logger.info("  + Atomic writes across multiple topics");
            logger.info("  + Exactly-once semantics (no duplicates on retry)");
            logger.info("  - ~10-20% throughput overhead");
            logger.info("  - Consumers need isolation.level=read_committed");
        }
    }

    private Properties buildIdempotentProducerConfig() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        // THE KEY SETTING:
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
        // These are automatically set by enable.idempotence=true:
        // acks=all, retries=Integer.MAX_VALUE, max.in.flight.requests.per.connection=5
        return props;
    }

    private Properties buildTransactionalProducerConfig(String transactionalId) {
        Properties props = buildIdempotentProducerConfig();
        // Transactional ID must be UNIQUE per producer instance
        props.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, transactionalId);
        // Transaction timeout (how long coordinator waits before aborting)
        props.put(ProducerConfig.TRANSACTION_TIMEOUT_CONFIG, "30000"); // 30 seconds
        return props;
    }
}