# Kafka Training Project

Complete hands-on training project for Apache Kafka covering
fundamentals through advanced Event-Driven Architecture patterns
using a Payment Processing domain.

## Environment Requirements

| Tool           | Version | Purpose           |
| -------------- | ------- | ----------------- |
| Java           | 17      | Run all demos     |
| Maven          | 3.8+    | Build project     |
| Docker Desktop | Latest  | Run Kafka cluster |
| Windows        | 11      | Host OS           |

## Quick Start

### 1. Start the Cluster
```bat
cd scripts
start-kafka.bat
```

### 2. Create Topics
```bat
create-topics.bat
```

### 3. Build the Project
```bat
cd ..
mvn clean package -DskipTests
```

### 4. Open Kafka UI
Open browser: http://localhost:8080

---

## Module Run Commands

### Day 1 - Module 1: Why Kafka
```bat
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module1_WhyKafka.KafkaEcosystemDemo"
```

### Day 1 - Module 2: Architecture
```bat
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module2_Architecture.BrokerArchitectureDemo"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module2_Architecture.PartitionReplicationDemo"
```

### Day 1 - Module 3: Producers & Consumers
```bat
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module3_ProducersConsumers.PaymentProducer"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module3_ProducersConsumers.PaymentConsumer"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module3_ProducersConsumers.ConsumerGroupDemo"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module3_ProducersConsumers.OffsetManagementDemo"
```

### Day 1 - Module 4: Reliability
```bat
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module4_Reliability.AcknowledgementDemo"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module4_Reliability.IdempotentProducerDemo"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day1Module4_Reliability.KeyBasedPartitioningDemo"
```

### Day 2 - Module 1: Schema Registry
```bat
mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module1_Schema.SchemaRegistryDemo"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module1_Schema.AvroProducer"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module1_Schema.AvroConsumer"
```

### Day 2 - Module 2: Security
```bat
cd docker\ssl && generate-certs.bat
docker-compose -f docker\docker-compose-ssl.yml up -d
mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module2_Security.SSLProducerDemo"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module2_Security.SSLConsumerDemo"
```

### Day 2 - Module 3: EDA
```bat
mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module3_EDA.PaymentEventDemo"
mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module3_EDA.SagaPatternDemo"
```

### Day 2 - Module 4: Full Pipeline
```bat
mvn exec:java -Dexec.mainClass="com.kafka.training.Day2Module4_Pipeline.PipelineOrchestrator"
```

---

## Service Endpoints

| Service         | URL                   | Purpose           |
| --------------- | --------------------- | ----------------- |
| Kafka Broker 1  | localhost:9092        | Primary broker    |
| Kafka Broker 2  | localhost:9093        | Secondary broker  |
| Kafka Broker 3  | localhost:9094        | Third broker      |
| Schema Registry | http://localhost:8081 | Schema management |
| Kafka UI        | http://localhost:8080 | Visual dashboard  |
| SSL Broker      | localhost:9096        | SSL demo broker   |

---

## Topics Created

| Topic               | Partitions | RF  | Purpose              |
| ------------------- | ---------- | --- | -------------------- |
| payment-created     | 3          | 3   | New payment events   |
| payment-settled     | 3          | 3   | Settlement events    |
| payment-fraud-check | 3          | 3   | Fraud check requests |
| fraud-result        | 3          | 3   | Fraud decisions      |
| payment-dlq         | 1          | 3   | Dead letter queue    |


# For Mac

## macOS Quick Start

### One-Time Setup
```bash
# Clone project, then:
chmod +x init-mac.sh
./init-mac.sh

# Check prerequisites
./scripts/setup.sh
```

### Daily Workflow
```bash
# Start cluster
./scripts/start-kafka.sh

# Create topics (first time only)
./scripts/create-topics.sh

# Run any demo interactively
./scripts/run-demo.sh

# Stop cluster
./scripts/stop-kafka.sh
```

### Install Prerequisites on Mac
```bash
# Java 17
brew install openjdk@17
echo 'export JAVA_HOME=$(brew --prefix openjdk@17)' >> ~/.zshrc
echo 'export PATH=$JAVA_HOME/bin:$PATH' >> ~/.zshrc
source ~/.zshrc

# Maven
brew install maven

# Docker Desktop
# Download from: https://www.docker.com/products/docker-desktop/
```

### SSL Demo on Mac
```bash
# Generate certificates
chmod +x docker/ssl/generate-certs.sh
./docker/ssl/generate-certs.sh

# Start SSL broker
./scripts/start-ssl-kafka.sh
