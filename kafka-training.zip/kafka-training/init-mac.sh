#!/bin/bash
# ============================================================
# macOS One-Time Initialization Script
# Run this ONCE after cloning the project on Mac
# ============================================================

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}  Kafka Training - macOS Initialization${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""

# Make all shell scripts executable
echo "Setting executable permissions on all scripts..."

find . -name "*.sh" -type f | while read SCRIPT; do
    chmod +x "$SCRIPT"
    echo -e "  ${GREEN}✓${NC} $SCRIPT"
done

echo ""
echo "Verifying Docker is running..."
if docker info &> /dev/null; then
    echo -e "  ${GREEN}✓ Docker is running${NC}"
else
    echo -e "  ${YELLOW}⚠ Docker not running - start Docker Desktop${NC}"
fi

echo ""
echo -e "${GREEN}============================================================${NC}"
echo -e "${GREEN}  Initialization complete!${NC}"
echo -e "${GREEN}============================================================${NC}"
echo ""
echo "Quick Start:"
echo "  ./scripts/setup.sh          ← Check all prerequisites"
echo "  ./scripts/start-kafka.sh    ← Start Kafka cluster"
echo "  ./scripts/create-topics.sh  ← Create all topics"
echo "  ./scripts/run-demo.sh       ← Interactive demo menu"
echo ""
echo "Kafka UI: http://localhost:8080"
echo ""