// shell/src/app/store/auth/auth.reducer.ts
import { createFeature, createReducer, on } from '@ngrx/store';
import { AuthUser } from '../../../shared/src/models';
import { AuthActions } from './auth.actions';

export interface AuthState {
  user: AuthUser | null;
  token: string | null;     // In-memory only — NEVER localStorage
  isLoading: boolean;
  isRefreshing: boolean;
  error: string | null;
}

const initialState: AuthState = {
  user: null,
  token: null,
  isLoading: false,
  isRefreshing: false,
  error: null,
};

export const authFeature = createFeature({
  name: 'auth',
  reducer: createReducer(
    initialState,

    on(AuthActions.login, (state) => ({
      ...state,
      isLoading: true,
      error: null,
    })),

    on(AuthActions.loginSuccess, (state, { user, token }) => ({
      ...state,
      user,
      token,
      isLoading: false,
      error: null,
    })),

    on(AuthActions.loginFailure, (state, { error }) => ({
      ...state,
      user: null,
      token: null,
      isLoading: false,
      error,
    })),

    on(AuthActions.logout, (state) => ({
      ...state,
      isLoading: true,
    })),

    on(AuthActions.logoutComplete, () => ({
      ...initialState,
    })),

    on(AuthActions.refreshToken, (state) => ({
      ...state,
      isRefreshing: true,
    })),

    on(AuthActions.refreshTokenSuccess, (state, { user, token }) => ({
      ...state,
      user,
      token,
      isRefreshing: false,
    })),

    on(AuthActions.refreshTokenFailure, () => ({
      ...initialState,
    }))
  ),
});

export const {
  name: authFeatureName,
  reducer: authReducer,
  selectAuthState,
  selectUser,
  selectToken,
  selectIsLoading,
  selectIsRefreshing,
  selectError,
} = authFeature;
