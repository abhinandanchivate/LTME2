// shell/src/app/store/auth/auth.actions.ts
import { createActionGroup, emptyProps, props } from '@ngrx/store';
import { AuthUser, LoginRequest } from '../../../shared/src/models';

export const AuthActions = createActionGroup({
  source: 'Auth',
  events: {
    'Login':           props<{ credentials: LoginRequest }>(),
    'Login Success':   props<{ user: AuthUser; token: string }>(),
    'Login Failure':   props<{ error: string }>(),

    'Logout':          emptyProps(),
    'Logout Complete': emptyProps(),

    'Refresh Token':          emptyProps(),
    'Refresh Token Success':  props<{ user: AuthUser; token: string }>(),
    'Refresh Token Failure':  emptyProps(),

    'Restore Session':        emptyProps(),
  },
});
