// shell/src/app/store/mfe-registry/mfe-registry.actions.ts
import { createActionGroup, emptyProps, props } from '@ngrx/store';
import { MfeRegistryMap } from '../../../shared/src/models';

export const MfeRegistryActions = createActionGroup({
  source: 'MFE Registry',
  events: {
    'Load Registry':         emptyProps(),
    'Load Registry Success': props<{ registry: MfeRegistryMap }>(),
    'Load Registry Failure': props<{ error: string }>(),
  },
});

// ─────────────────────────────────────────────────────────────────────────────

// shell/src/app/store/mfe-registry/mfe-registry.reducer.ts
import { createFeature, createReducer, on } from '@ngrx/store';

export interface MfeRegistryState {
  registry: MfeRegistryMap;
  loaded: boolean;
  loading: boolean;
  error: string | null;
}

const initialMfeState: MfeRegistryState = {
  registry: {},
  loaded: false,
  loading: false,
  error: null,
};

export const mfeRegistryFeature = createFeature({
  name: 'mfeRegistry',
  reducer: createReducer(
    initialMfeState,

    on(MfeRegistryActions.loadRegistry, (state) => ({
      ...state,
      loading: true,
      error: null,
    })),

    on(MfeRegistryActions.loadRegistrySuccess, (state, { registry }) => ({
      ...state,
      registry,
      loaded: true,
      loading: false,
    })),

    on(MfeRegistryActions.loadRegistryFailure, (state, { error }) => ({
      ...state,
      loading: false,
      error,
    }))
  ),
});

export const {
  name: mfeRegistryFeatureName,
  reducer: mfeRegistryReducer,
  selectMfeRegistryState,
  selectRegistry,
  selectLoaded,
  selectLoading,
} = mfeRegistryFeature;

// ─── Selectors ────────────────────────────────────────────────────────────────
import { createSelector } from '@ngrx/store';

export const selectRemoteEntry = (mfeName: string) =>
  createSelector(selectRegistry, (registry) => registry[mfeName]?.remoteEntry ?? null);

export const selectExposedModule = (mfeName: string) =>
  createSelector(selectRegistry, (registry) => registry[mfeName]?.exposedModule ?? null);
