// shell/src/app/guards/auth.guard.ts
import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { map, take } from 'rxjs';
import { selectIsAuthenticated } from '../store/auth/auth.selectors';

export const authGuard: CanActivateFn = () => {
  const store = inject(Store);
  const router = inject(Router);

  return store.select(selectIsAuthenticated).pipe(
    take(1),
    map((isAuthenticated) => {
      if (isAuthenticated) return true;
      return router.createUrlTree(['/login']);
    })
  );
};

// ─── Role Guard ───────────────────────────────────────────────────────────────

import { ActivatedRouteSnapshot } from '@angular/router';
import { selectUserRoles } from '../store/auth/auth.selectors';
import { UserRole } from '../../../shared/src/models';

export const roleGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => {
  const store = inject(Store);
  const router = inject(Router);
  const requiredRoles: UserRole[] = route.data['roles'] ?? [];

  return store.select(selectUserRoles).pipe(
    take(1),
    map((userRoles) => {
      const hasRole = requiredRoles.some((r) => userRoles.includes(r));
      if (hasRole || requiredRoles.length === 0) return true;
      return router.createUrlTree(['/unauthorized']);
    })
  );
};
