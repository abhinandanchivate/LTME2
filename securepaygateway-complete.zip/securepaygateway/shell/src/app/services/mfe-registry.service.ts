// shell/src/app/services/mfe-registry.service.ts
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of, shareReplay, tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { MfeRegistryMap, RemoteConfig } from '../../../shared/src/models';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class MfeRegistryService {
  private readonly http = inject(HttpClient);

  /** Fallback registry using environment file values */
  private readonly fallback: MfeRegistryMap = {
    paymentsMfe: {
      remoteEntry: environment.remotes.paymentsMfe,
      exposedModule: './TransactionRoutes',
    },
    reportsMfe: {
      remoteEntry: environment.remotes.reportsMfe,
      exposedModule: './ReportRoutes',
    },
  };

  /**
   * Fetched ONCE at startup, cached for the app lifetime.
   * Falls back to environment.remotes if the API call fails.
   * shareReplay({ refCount: false }) keeps the cache even if all subscribers unsubscribe.
   */
  readonly registry$: Observable<MfeRegistryMap> = this.http
    .get<MfeRegistryMap>(`${environment.apiUrl}/mfe-registry`)
    .pipe(
      tap((registry) => {
        console.log('[MFE Registry] Registry loaded:', registry);
      }),
      catchError((err) => {
        console.warn(
          '[MFE Registry] Registry fetch failed — using default environment config:',
          err?.message
        );
        return of(this.fallback);
      }),
      shareReplay({ bufferSize: 1, refCount: false })
    );

  /** Fetch registry (used by Effects and APP_INITIALIZER) */
  fetchRegistry(): Observable<MfeRegistryMap> {
    return this.registry$;
  }

  /** Get remote config for a specific MFE name synchronously from cached registry */
  getRemoteConfig(mfeName: string): Observable<RemoteConfig | null> {
    return this.registry$.pipe(
      map((registry) => registry[mfeName] ?? this.fallback[mfeName] ?? null)
    );
  }
}
