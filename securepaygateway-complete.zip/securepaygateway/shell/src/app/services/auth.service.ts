// shell/src/app/services/auth.service.ts
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthUser, JwtPayload, LoginRequest, LoginResponse } from '../../../shared/src/models';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http = inject(HttpClient);
  private readonly apiUrl = environment.apiUrl;

  /**
   * Decode JWT payload without verifying signature (client-side only).
   * Signature verification happens on the server.
   */
  decodeToken(token: string): JwtPayload | null {
    try {
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      const payload = JSON.parse(atob(parts[1]));
      return payload as JwtPayload;
    } catch {
      return null;
    }
  }

  /** Map a raw JWT to a typed AuthUser */
  private buildUser(token: string, expiresIn: number): AuthUser | null {
    const payload = this.decodeToken(token);
    if (!payload) return null;
    return {
      id: payload.sub,
      email: payload.email,
      roles: payload.roles,
      expiresAt: new Date(Date.now() + expiresIn * 1000),
    };
  }

  /** POST /auth/login — returns token + user; stores token in MEMORY via Store */
  login(credentials: LoginRequest): Observable<{ user: AuthUser; token: string }> {
    return this.http
      .post<LoginResponse>(`${this.apiUrl}/auth/login`, credentials, {
        withCredentials: true, // httpOnly refresh cookie
      })
      .pipe(
        map(({ accessToken, expiresIn }) => {
          const user = this.buildUser(accessToken, expiresIn);
          if (!user) throw new Error('Invalid token received from server');
          // ✅ NEVER store in localStorage or sessionStorage
          return { user, token: accessToken };
        })
      );
  }

  /** POST /auth/refresh — uses httpOnly cookie, returns new access token */
  refreshAccessToken(): Observable<{ user: AuthUser; token: string }> {
    return this.http
      .post<LoginResponse>(`${this.apiUrl}/auth/refresh`, {}, {
        withCredentials: true,
      })
      .pipe(
        map(({ accessToken, expiresIn }) => {
          const user = this.buildUser(accessToken, expiresIn);
          if (!user) throw new Error('Invalid token from refresh');
          return { user, token: accessToken };
        })
      );
  }

  /** POST /auth/logout — invalidates the httpOnly refresh cookie on server */
  logout(): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/auth/logout`, {}, {
      withCredentials: true,
    });
  }
}
