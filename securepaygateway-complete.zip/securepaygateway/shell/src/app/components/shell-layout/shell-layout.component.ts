// shell/src/app/components/shell-layout/shell-layout.component.ts
import {
  Component,
  ChangeDetectionStrategy,
  inject,
  OnInit,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { Store } from '@ngrx/store';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { selectCurrentUser, selectIsAuthenticated } from '../../store/auth/auth.selectors';
import { selectSidebarOpen, selectTheme, selectNotifications } from '../../store/ui/ui.state';
import { AuthActions } from '../../store/auth/auth.actions';
import { UiActions } from '../../store/ui/ui.state';
import { MfeEventBusService } from '../../../../shared/src/mfe-event-bus.service';

@Component({
  selector: 'app-shell-layout',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="shell-layout" [attr.data-theme]="theme$ | async">
      <!-- Top Navbar -->
      <nav class="navbar">
        <div class="navbar-left">
          <button class="menu-btn" (click)="toggleSidebar()" aria-label="Toggle sidebar">
            ☰
          </button>
          <span class="brand">SecurePayment Gateway</span>
        </div>
        <div class="navbar-right">
          <button class="theme-btn" (click)="toggleTheme()">
            {{ (theme$ | async) === 'dark' ? '☀️' : '🌙' }}
          </button>
          <span class="user-email">{{ (user$ | async)?.email }}</span>
          <button class="logout-btn" (click)="logout()">Logout</button>
        </div>
      </nav>

      <!-- Notifications -->
      <div class="notifications" *ngIf="(notifications$ | async)?.length">
        <div
          *ngFor="let n of notifications$ | async"
          class="notification"
          [class]="'notification--' + n.type"
        >
          {{ n.message }}
          <button class="notification-close" (click)="dismissNotification(n.id)">✕</button>
        </div>
      </div>

      <div class="content-area">
        <!-- Sidebar -->
        <aside class="sidebar" [class.sidebar--collapsed]="!(sidebarOpen$ | async)">
          <nav class="sidebar-nav">
            <a routerLink="/dashboard" routerLinkActive="active" class="nav-item">
              <span class="nav-icon">📊</span>
              <span class="nav-label">Dashboard</span>
            </a>
            <a routerLink="/transactions" routerLinkActive="active" class="nav-item">
              <span class="nav-icon">💳</span>
              <span class="nav-label">Transactions</span>
            </a>
            <a routerLink="/reports" routerLinkActive="active" class="nav-item">
              <span class="nav-icon">📈</span>
              <span class="nav-label">Reports</span>
            </a>
          </nav>
        </aside>

        <!-- Main Content — MFEs render here via router -->
        <main class="main-content">
          <router-outlet />
        </main>
      </div>
    </div>
  `,
  styles: [`
    .shell-layout {
      display: flex;
      flex-direction: column;
      height: 100vh;
      background: #f8fafc;
      font-family: 'Segoe UI', system-ui, sans-serif;
    }

    /* Navbar */
    .navbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 56px;
      background: #1e3a5f;
      color: white;
      padding: 0 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.2);
      z-index: 100;
    }
    .navbar-left, .navbar-right {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .brand { font-size: 18px; font-weight: 700; letter-spacing: -0.3px; }
    .menu-btn, .theme-btn, .logout-btn {
      background: none;
      border: 1px solid rgba(255,255,255,0.3);
      color: white;
      border-radius: 6px;
      padding: 4px 10px;
      cursor: pointer;
      font-size: 14px;
      transition: background 0.2s;
    }
    .menu-btn:hover, .theme-btn:hover { background: rgba(255,255,255,0.1); }
    .logout-btn { background: #dc2626; border-color: #dc2626; }
    .logout-btn:hover { background: #b91c1c; }
    .user-email { font-size: 13px; opacity: 0.85; }

    /* Notifications */
    .notifications {
      position: fixed;
      top: 64px;
      right: 16px;
      z-index: 200;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .notification {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 14px;
      min-width: 300px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .notification--success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
    .notification--error   { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
    .notification--info    { background: #dbeafe; color: #1e40af; border: 1px solid #93c5fd; }
    .notification--warning { background: #fef9c3; color: #854d0e; border: 1px solid #fde047; }
    .notification-close {
      background: none; border: none; cursor: pointer;
      font-size: 12px; opacity: 0.6; padding: 0;
    }

    /* Content layout */
    .content-area {
      display: flex;
      flex: 1;
      overflow: hidden;
    }

    /* Sidebar */
    .sidebar {
      width: 220px;
      background: #1e3a5f;
      transition: width 0.3s ease;
      overflow: hidden;
      flex-shrink: 0;
    }
    .sidebar--collapsed { width: 56px; }
    .sidebar-nav {
      display: flex;
      flex-direction: column;
      padding: 16px 0;
    }
    .nav-item {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 16px;
      color: rgba(255,255,255,0.75);
      text-decoration: none;
      transition: background 0.2s, color 0.2s;
      white-space: nowrap;
      font-size: 14px;
      font-weight: 500;
    }
    .nav-item:hover  { background: rgba(255,255,255,0.1); color: white; }
    .nav-item.active { background: rgba(255,255,255,0.15); color: white; border-right: 3px solid #60a5fa; }
    .nav-icon { font-size: 18px; min-width: 24px; text-align: center; }

    /* Main content */
    .main-content {
      flex: 1;
      overflow-y: auto;
      padding: 24px;
    }

    /* Dark theme */
    [data-theme="dark"] .shell-layout { background: #0f172a; color: #f1f5f9; }
    [data-theme="dark"] .main-content { color: #f1f5f9; }
  `],
})
export class ShellLayoutComponent implements OnInit {
  private readonly store = inject(Store);
  private readonly eventBus = inject(MfeEventBusService);

  user$          = this.store.select(selectCurrentUser);
  theme$         = this.store.select(selectTheme);
  sidebarOpen$   = this.store.select(selectSidebarOpen);
  notifications$ = this.store.select(selectNotifications);

  private currentTheme: 'light' | 'dark' = 'light';

  ngOnInit() {
    // Track theme changes for toggle
    this.store.select(selectTheme)
      .pipe(takeUntilDestroyed())
      .subscribe((theme) => (this.currentTheme = theme));

    // Listen for theme changes from other MFEs
    this.eventBus.on('THEME_CHANGED')
      .pipe(takeUntilDestroyed())
      .subscribe(({ theme }) => {
        this.store.dispatch(UiActions.setTheme({ theme }));
      });

    // Listen for logout events from MFEs
    this.eventBus.on('USER_LOGGED_OUT')
      .pipe(takeUntilDestroyed())
      .subscribe(() => {
        this.store.dispatch(AuthActions.logout());
      });
  }

  toggleSidebar() {
    this.store.dispatch(UiActions.toggleSidebar());
  }

  toggleTheme() {
    const next = this.currentTheme === 'light' ? 'dark' : 'light';
    this.store.dispatch(UiActions.setTheme({ theme: next }));
    this.eventBus.emit({ type: 'THEME_CHANGED', payload: { theme: next } });
  }

  logout() {
    this.store.dispatch(AuthActions.logout());
  }

  dismissNotification(id: string) {
    this.store.dispatch(UiActions.dismissNotification({ id }));
  }
}
