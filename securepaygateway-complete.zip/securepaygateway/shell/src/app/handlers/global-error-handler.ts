// shell/src/app/handlers/global-error-handler.ts
import { ErrorHandler, Injectable, inject, NgZone } from '@angular/core';
import { Store } from '@ngrx/store';
import { UiActions } from '../store/ui/ui.state';
import { environment } from '../../environments/environment';

@Injectable()
export class SecurePaymentErrorHandler implements ErrorHandler {
  private store = inject(Store);
  private zone = inject(NgZone);

  handleError(error: unknown): void {
    const err = error instanceof Error ? error : new Error(String(error));

    // In development: log full error
    if (!environment.production) {
      console.error('[GlobalErrorHandler]', err);
    } else {
      // In production: log only sanitized message (no stack trace)
      console.error('[Error]', err.message);
      // TODO: send to monitoring service (Datadog, Sentry, etc.)
      // this.monitoringService.captureException(err);
    }

    // Show user-friendly notification via NgRx store
    this.zone.run(() => {
      this.store.dispatch(
        UiActions.addNotification({
          message: this.getUserFriendlyMessage(err),
          type: 'error',
        })
      );
    });
  }

  private getUserFriendlyMessage(err: Error): string {
    // Map technical errors to user-friendly messages
    if (err.message.includes('ChunkLoadError')) {
      return 'A module failed to load. Please refresh the page.';
    }
    if (err.message.includes('ERR_CONNECTION_REFUSED')) {
      return 'Cannot reach the server. Please check your connection.';
    }
    if (err.message.includes('Unauthorized') || err.message.includes('401')) {
      return 'Your session has expired. Please log in again.';
    }
    return 'An unexpected error occurred. Our team has been notified.';
  }
}
