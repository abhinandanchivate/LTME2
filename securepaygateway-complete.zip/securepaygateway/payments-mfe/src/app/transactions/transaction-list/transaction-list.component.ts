// payments-mfe/src/app/transactions/transaction-list/transaction-list.component.ts
import {
  Component,
  ChangeDetectionStrategy,
  inject,
  OnInit,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MfeEventBusService } from '../../../../../shared/src/mfe-event-bus.service';
import { TransactionActions } from '../../store/transactions.state';
import {
  selectFilteredTransactions,
  selectLoading,
  selectError,
  selectCurrentPage,
  selectTotalPages,
  selectTotalItems,
} from '../../store/transactions.state';
import { Transaction, TransactionStatus } from '../../../../../shared/src/models';

@Component({
  selector: 'app-transaction-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="transaction-list">
      <div class="list-header">
        <h2 class="page-title">Transactions</h2>
        <a routerLink="new" class="btn btn--primary">+ New Transaction</a>
      </div>

      <!-- Filter Bar -->
      <div class="filter-bar">
        <input
          type="text"
          placeholder="Search by reference or account name..."
          [ngModel]="searchQuery()"
          (ngModelChange)="onSearch($event)"
          class="search-input"
        />
        <select
          [ngModel]="statusFilter()"
          (ngModelChange)="onStatusFilter($event)"
          class="filter-select"
        >
          <option value="">All Statuses</option>
          <option value="PENDING">Pending</option>
          <option value="PROCESSING">Processing</option>
          <option value="COMPLETED">Completed</option>
          <option value="FAILED">Failed</option>
          <option value="REVERSED">Reversed</option>
        </select>
        <button class="btn btn--ghost" (click)="clearFilters()">Clear</button>
      </div>

      <!-- Loading State -->
      <div class="loading-state" *ngIf="loading$ | async">
        <div class="spinner"></div>
        <p>Loading transactions...</p>
      </div>

      <!-- Error State -->
      <div class="error-state" *ngIf="error$ | async as error">
        <p>⚠️ {{ error }}</p>
        <button class="btn btn--primary" (click)="loadTransactions()">Retry</button>
      </div>

      <!-- Transaction Table -->
      <div class="table-wrapper" *ngIf="!(loading$ | async)">
        <table class="table">
          <thead>
            <tr>
              <th>Reference</th>
              <th>Account</th>
              <th>Type</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr
              *ngFor="let tx of transactions$ | async"
              [class.row--selected]="selectedTxId() === tx.id"
              (click)="selectTransaction(tx)"
            >
              <td class="ref-cell">
                <span class="ref-number">{{ tx.referenceNumber }}</span>
              </td>
              <td>
                <!-- ✅ Clicking account name emits ACCOUNT_SELECTED via EventBus -->
                <button
                  class="account-link"
                  (click)="onAccountClick($event, tx.fromAccount.accountId, tx.fromAccount.accountName, tx.fromAccount.accountType)"
                >
                  {{ tx.fromAccount.accountName }}
                </button>
                <span class="account-sub">{{ tx.fromAccount.accountNumber }}</span>
              </td>
              <td>
                <span class="badge badge--type">{{ tx.type }}</span>
              </td>
              <td class="amount-cell">
                <span class="amount">{{ tx.amount | number:'1.2-2' }}</span>
                <span class="currency">{{ tx.currency }}</span>
              </td>
              <td>
                <span class="badge" [class]="'badge--' + tx.status.toLowerCase()">
                  {{ tx.status }}
                </span>
              </td>
              <td class="date-cell">
                {{ tx.initiatedAt | date:'dd MMM, HH:mm' }}
              </td>
              <td>
                <a [routerLink]="[tx.id]" class="btn btn--sm">View</a>
              </td>
            </tr>

            <!-- Empty State -->
            <tr *ngIf="(transactions$ | async)?.length === 0">
              <td colspan="7" class="empty-state">
                No transactions found matching your filters.
              </td>
            </tr>
          </tbody>
        </table>

        <!-- Pagination -->
        <div class="pagination" *ngIf="(totalPages$ | async)! > 1">
          <button
            class="btn btn--sm"
            [disabled]="(currentPage$ | async) === 1"
            (click)="goToPage((currentPage$ | async)! - 1)"
          >
            ← Prev
          </button>
          <span class="page-info">
            Page {{ currentPage$ | async }} of {{ totalPages$ | async }}
            ({{ totalItems$ | async }} transactions)
          </span>
          <button
            class="btn btn--sm"
            [disabled]="(currentPage$ | async) === (totalPages$ | async)"
            (click)="goToPage((currentPage$ | async)! + 1)"
          >
            Next →
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .transaction-list { max-width: 1200px; }

    .list-header {
      display: flex; align-items: center; justify-content: space-between;
      margin-bottom: 20px;
    }
    .page-title { font-size: 22px; font-weight: 700; color: #1e3a5f; margin: 0; }

    /* Filter Bar */
    .filter-bar {
      display: flex; gap: 12px; margin-bottom: 20px;
      flex-wrap: wrap;
    }
    .search-input {
      flex: 1; min-width: 200px;
      padding: 8px 14px; border: 1px solid #d1d5db;
      border-radius: 8px; font-size: 14px; outline: none;
    }
    .search-input:focus { border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,0.1); }
    .filter-select {
      padding: 8px 12px; border: 1px solid #d1d5db;
      border-radius: 8px; font-size: 14px; background: white; cursor: pointer;
    }

    /* Buttons */
    .btn {
      padding: 8px 16px; border-radius: 8px; border: none;
      font-size: 14px; font-weight: 500; cursor: pointer;
      text-decoration: none; display: inline-flex; align-items: center;
      transition: background 0.2s, opacity 0.2s;
    }
    .btn--primary { background: #1e3a5f; color: white; }
    .btn--primary:hover { background: #2563eb; }
    .btn--ghost { background: #f3f4f6; color: #374151; border: 1px solid #d1d5db; }
    .btn--ghost:hover { background: #e5e7eb; }
    .btn--sm { padding: 4px 12px; font-size: 13px; background: #f3f4f6; color: #374151; border: 1px solid #d1d5db; }
    .btn--sm:hover { background: #e5e7eb; }
    .btn:disabled { opacity: 0.4; cursor: not-allowed; }

    /* Table */
    .table-wrapper {
      background: white; border-radius: 12px;
      box-shadow: 0 1px 4px rgba(0,0,0,0.08); overflow: hidden;
    }
    .table { width: 100%; border-collapse: collapse; }
    .table th {
      background: #f8fafc; padding: 12px 16px;
      text-align: left; font-size: 12px; font-weight: 600;
      color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px;
      border-bottom: 1px solid #e5e7eb;
    }
    .table td {
      padding: 12px 16px; border-bottom: 1px solid #f3f4f6;
      font-size: 14px; color: #374151; vertical-align: middle;
    }
    .table tr:hover td { background: #f8fafc; }
    .table tr.row--selected td { background: #eff6ff; }
    .table tr:last-child td { border-bottom: none; }

    /* Account link */
    .account-link {
      background: none; border: none; color: #2563eb;
      cursor: pointer; font-size: 14px; padding: 0; font-weight: 500;
      text-align: left;
    }
    .account-link:hover { text-decoration: underline; }
    .account-sub { display: block; font-size: 12px; color: #9ca3af; }

    /* Badges */
    .badge {
      padding: 3px 8px; border-radius: 99px;
      font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;
    }
    .badge--type      { background: #e0e7ff; color: #3730a3; }
    .badge--pending   { background: #fef9c3; color: #854d0e; }
    .badge--processing{ background: #dbeafe; color: #1e40af; }
    .badge--completed { background: #dcfce7; color: #166534; }
    .badge--failed    { background: #fee2e2; color: #991b1b; }
    .badge--reversed  { background: #f3f4f6; color: #6b7280; }

    /* Amounts */
    .amount-cell { font-variant-numeric: tabular-nums; }
    .amount { font-weight: 600; }
    .currency { font-size: 12px; color: #9ca3af; margin-left: 4px; }

    /* States */
    .loading-state, .empty-state {
      display: flex; flex-direction: column; align-items: center;
      padding: 48px; color: #6b7280; text-align: center;
    }
    .error-state {
      background: #fee2e2; border-radius: 8px; padding: 20px;
      color: #991b1b; margin-bottom: 20px;
      display: flex; align-items: center; justify-content: space-between;
    }
    .spinner {
      width: 32px; height: 32px; border: 3px solid #e5e7eb;
      border-top-color: #2563eb; border-radius: 50%;
      animation: spin 0.8s linear infinite; margin-bottom: 12px;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Pagination */
    .pagination {
      display: flex; align-items: center; justify-content: center;
      gap: 16px; padding: 16px; border-top: 1px solid #f3f4f6;
    }
    .page-info { font-size: 13px; color: #6b7280; }
    .ref-cell .ref-number { font-family: monospace; font-size: 12px; color: #6b7280; }
  `],
})
export class TransactionListComponent implements OnInit {
  private readonly store    = inject(Store);
  private readonly eventBus = inject(MfeEventBusService);

  // Store selectors
  transactions$ = this.store.select(selectFilteredTransactions);
  loading$      = this.store.select(selectLoading);
  error$        = this.store.select(selectError);
  currentPage$  = this.store.select(selectCurrentPage);
  totalPages$   = this.store.select(selectTotalPages);
  totalItems$   = this.store.select(selectTotalItems);

  // Local UI state (signals for template reactivity)
  selectedTxId = signal<string | null>(null);
  searchQuery  = signal('');
  statusFilter = signal('');

  ngOnInit() {
    this.loadTransactions();
  }

  loadTransactions() {
    this.store.dispatch(TransactionActions.loadTransactions({}));
  }

  selectTransaction(tx: Transaction) {
    this.selectedTxId.set(tx.id);
    this.store.dispatch(TransactionActions.selectTransaction({ id: tx.id }));
  }

  /**
   * ✅ Clicking an account name emits ACCOUNT_SELECTED to the cross-MFE EventBus.
   * The Reports MFE (if loaded) will receive this via ReplaySubject(1) immediately.
   * If Reports MFE is not yet loaded, the event is buffered and delivered when it loads.
   */
  onAccountClick(
    event: MouseEvent,
    accountId: string,
    accountName: string,
    accountType: string
  ) {
    event.stopPropagation(); // Don't also select the row
    console.log(`[Payments MFE] Account clicked: ${accountId}`);
    this.eventBus.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId, accountName, accountType },
    });
  }

  onSearch(query: string) {
    this.searchQuery.set(query);
    this.store.dispatch(
      TransactionActions.setFilter({
        filter: { search: query, status: this.statusFilter() as any || undefined },
      })
    );
  }

  onStatusFilter(status: string) {
    this.statusFilter.set(status);
    this.store.dispatch(
      TransactionActions.setFilter({
        filter: { status: status as any || undefined, search: this.searchQuery() || undefined },
      })
    );
  }

  clearFilters() {
    this.searchQuery.set('');
    this.statusFilter.set('');
    this.store.dispatch(TransactionActions.clearFilter());
    this.loadTransactions();
  }

  goToPage(page: number) {
    this.store.dispatch(TransactionActions.setPage({ page }));
    this.store.dispatch(TransactionActions.loadTransactions({ page }));
  }
}
