// payments-mfe/src/app/store/transactions.actions.ts
import { createActionGroup, emptyProps, props } from '@ngrx/store';
import { Transaction, TransactionFilter, PaginatedResponse } from '../../../../shared/src/models';

export const TransactionActions = createActionGroup({
  source: 'Transactions',
  events: {
    // Load list
    'Load Transactions':         props<{ filter?: TransactionFilter; page?: number }>(),
    'Load Transactions Success': props<{ response: PaginatedResponse<Transaction> }>(),
    'Load Transactions Failure': props<{ error: string }>(),

    // Load single
    'Load Transaction':         props<{ id: string }>(),
    'Load Transaction Success': props<{ transaction: Transaction }>(),
    'Load Transaction Failure': props<{ error: string }>(),

    // Create
    'Create Transaction':         props<{ payload: Partial<Transaction> }>(),
    'Create Transaction Success': props<{ transaction: Transaction }>(),
    'Create Transaction Failure': props<{ error: string }>(),

    // UI
    'Select Transaction':   props<{ id: string | null }>(),
    'Set Filter':           props<{ filter: TransactionFilter }>(),
    'Clear Filter':         emptyProps(),
    'Set Page':             props<{ page: number }>(),
  },
});

// ─────────────────────────────────────────────────────────────────────────────

// payments-mfe/src/app/store/transactions.reducer.ts
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { createFeature, createReducer, on } from '@ngrx/store';

export interface TransactionsState extends EntityState<Transaction> {
  selectedId: string | null;
  loading: boolean;
  error: string | null;
  filter: TransactionFilter;
  currentPage: number;
  totalItems: number;
  totalPages: number;
}

export const transactionAdapter: EntityAdapter<Transaction> =
  createEntityAdapter<Transaction>();

const initialState: TransactionsState = transactionAdapter.getInitialState({
  selectedId: null,
  loading: false,
  error: null,
  filter: {},
  currentPage: 1,
  totalItems: 0,
  totalPages: 0,
});

export const transactionsFeature = createFeature({
  name: 'transactions',
  reducer: createReducer(
    initialState,

    on(TransactionActions.loadTransactions, (state) => ({
      ...state,
      loading: true,
      error: null,
    })),

    on(TransactionActions.loadTransactionsSuccess, (state, { response }) =>
      transactionAdapter.setAll(response.data, {
        ...state,
        loading: false,
        totalItems: response.total,
        totalPages: response.totalPages,
        currentPage: response.page,
      })
    ),

    on(TransactionActions.loadTransactionsFailure, (state, { error }) => ({
      ...state,
      loading: false,
      error,
    })),

    on(TransactionActions.loadTransactionSuccess, (state, { transaction }) =>
      transactionAdapter.upsertOne(transaction, state)
    ),

    on(TransactionActions.createTransactionSuccess, (state, { transaction }) =>
      transactionAdapter.addOne(transaction, { ...state, loading: false })
    ),

    on(TransactionActions.selectTransaction, (state, { id }) => ({
      ...state,
      selectedId: id,
    })),

    on(TransactionActions.setFilter, (state, { filter }) => ({
      ...state,
      filter,
      currentPage: 1,
    })),

    on(TransactionActions.clearFilter, (state) => ({
      ...state,
      filter: {},
      currentPage: 1,
    })),

    on(TransactionActions.setPage, (state, { page }) => ({
      ...state,
      currentPage: page,
    }))
  ),
});

export const {
  name: transactionsFeatureName,
  reducer: transactionsReducer,
  selectTransactionsState,
  selectLoading,
  selectError,
  selectFilter,
  selectCurrentPage,
  selectTotalItems,
  selectTotalPages,
  selectSelectedId,
} = transactionsFeature;

// Entity selectors
const { selectAll, selectEntities, selectTotal } =
  transactionAdapter.getSelectors(selectTransactionsState);

export {
  selectAll as selectAllTransactions,
  selectEntities as selectTransactionEntities,
  selectTotal as selectTransactionTotal,
};

// ─── Composed Selectors ───────────────────────────────────────────────────────
import { createSelector } from '@ngrx/store';

export const selectSelectedTransaction = createSelector(
  selectTransactionEntities,
  selectSelectedId,
  (entities, id) => (id ? entities[id] ?? null : null)
);

export const selectFilteredTransactions = createSelector(
  selectAllTransactions,
  selectFilter,
  (transactions, filter) => {
    let result = transactions;
    if (filter.status)     result = result.filter((t) => t.status === filter.status);
    if (filter.type)       result = result.filter((t) => t.type === filter.type);
    if (filter.accountId)  result = result.filter((t) => t.fromAccount.accountId === filter.accountId);
    if (filter.search) {
      const q = filter.search.toLowerCase();
      result = result.filter(
        (t) =>
          t.referenceNumber.toLowerCase().includes(q) ||
          t.fromAccount.accountName.toLowerCase().includes(q)
      );
    }
    return result;
  }
);
