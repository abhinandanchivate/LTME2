// payments-mfe/src/app/store/transactions.effects.ts
import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, exhaustMap, map, of, switchMap, tap } from 'rxjs';
import { TransactionService } from '../services/transaction.service';
import { MfeEventBusService } from '../../../../shared/src/mfe-event-bus.service';
import { TransactionActions } from './transactions.state';
import { Store } from '@ngrx/store';
import { UiActions } from '../../../shell/src/app/store/ui/ui.state';

@Injectable()
export class TransactionEffects {
  private actions$ = inject(Actions);
  private service  = inject(TransactionService);
  private eventBus = inject(MfeEventBusService);

  loadTransactions$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TransactionActions.loadTransactions),
      switchMap(({ filter, page }) =>
        this.service.getTransactions(filter, page).pipe(
          map((response) => TransactionActions.loadTransactionsSuccess({ response })),
          catchError((err) =>
            of(TransactionActions.loadTransactionsFailure({ error: err.message }))
          )
        )
      )
    )
  );

  loadTransaction$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TransactionActions.loadTransaction),
      exhaustMap(({ id }) =>
        this.service.getTransaction(id).pipe(
          map((transaction) => TransactionActions.loadTransactionSuccess({ transaction })),
          catchError((err) =>
            of(TransactionActions.loadTransactionFailure({ error: err.message }))
          )
        )
      )
    )
  );

  createTransaction$ = createEffect(() =>
    this.actions$.pipe(
      ofType(TransactionActions.createTransaction),
      exhaustMap(({ payload }) =>
        this.service.createTransaction(payload).pipe(
          map((transaction) => {
            // ✅ Emit cross-MFE event so Reports MFE knows a new transaction was created
            this.eventBus.emit({
              type: 'TRANSACTION_CREATED',
              payload: {
                transactionId: transaction.id,
                amount: transaction.amount,
                currency: transaction.currency,
              },
            });
            return TransactionActions.createTransactionSuccess({ transaction });
          }),
          catchError((err) =>
            of(TransactionActions.createTransactionFailure({ error: err.message }))
          )
        )
      )
    )
  );
}
