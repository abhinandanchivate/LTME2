// payments-mfe/src/app/app.config.ts
import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { provideStoreDevtools } from '@ngrx/store-devtools';

import { STANDALONE_ROUTES } from './app.routes';
import { transactionsReducer } from './store/transactions.state';
import { TransactionEffects } from './store/transactions.effects';

/**
 * When running standalone (port 4201 directly), the MFE uses its own store.
 * When loaded via the shell, it uses the shell's singleton NgRx store
 * (because @ngrx/store is singleton-shared via Module Federation).
 *
 * The transactions feature reducer is registered in both configs
 * so the slice is available either way.
 */
export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(STANDALONE_ROUTES),
    provideHttpClient(),
    provideAnimationsAsync(),

    // Feature store registration
    // When inside shell: this merges into the existing shell store
    // When standalone: creates a fresh store with this slice only
    provideStore({ transactions: transactionsReducer }),
    provideEffects([TransactionEffects]),
    provideStoreDevtools({ maxAge: 25 }),
  ],
};
