// @securepaygateway/shell-contracts — mfe-event-bus.service.ts
// This service MUST be provided in the shell's root injector.
// Both MFEs reference the SAME instance because @angular/core is singleton-shared
// via Module Federation's shareAll({ singleton: true }).

import { Injectable } from '@angular/core';
import { ReplaySubject, Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';

// ─── Typed Event Union ───────────────────────────────────────────────────────

export type MfeEvent =
  | {
      type: 'ACCOUNT_SELECTED';
      payload: { accountId: string; accountName: string; accountType: string };
    }
  | {
      type: 'TRANSACTION_CREATED';
      payload: { transactionId: string; amount: number; currency: string };
    }
  | {
      type: 'THEME_CHANGED';
      payload: { theme: 'light' | 'dark' };
    }
  | {
      type: 'USER_LOGGED_OUT';
      payload: Record<string, never>;
    };

export type MfeEventType = MfeEvent['type'];

// ─── Service ─────────────────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' }) // Shell's root injector — TRUE singleton
export class MfeEventBusService {
  /**
   * ReplaySubject(1): buffers the LAST emitted event.
   * When Reports MFE loads AFTER the user selected an account in Payments,
   * it immediately receives the buffered ACCOUNT_SELECTED event.
   */
  private readonly _events$ = new ReplaySubject<MfeEvent>(1);

  /** Emit a typed event to all subscribers (current + future via replay) */
  emit<T extends MfeEvent>(event: T): void {
    console.debug(`[EventBus] ▶ ${event.type}`, event.payload);
    this._events$.next(event);
  }

  /**
   * Subscribe to a specific event type.
   * Returns a strongly-typed Observable of just the payload.
   *
   * Usage:
   *   this.eventBus.on('ACCOUNT_SELECTED').subscribe(({ accountId }) => ...)
   */
  on<T extends MfeEventType>(
    eventType: T
  ): Observable<Extract<MfeEvent, { type: T }>['payload']> {
    return this._events$.pipe(
      filter((e): e is Extract<MfeEvent, { type: T }> => e.type === eventType),
      map((e) => (e as Extract<MfeEvent, { type: T }>).payload)
    );
  }

  /** Get all events (useful for debugging) */
  all$(): Observable<MfeEvent> {
    return this._events$.asObservable();
  }
}
