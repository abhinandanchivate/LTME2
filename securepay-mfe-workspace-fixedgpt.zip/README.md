# SecurePay Angular Micro Frontend Workspace

This workspace contains one Angular shell and two Angular Micro Frontends using Webpack Module Federation.

## Applications

| App | Type | Port | Route in Shell | Remote Entry |
| --- | --- | ---: | --- | --- |
| shell | Host | 4200 | `/dashboard` | N/A |
| payments-mfe | Remote | 4201 | `/transactions` | `http://localhost:4201/remoteEntry.js` |
| reports-mfe | Remote | 4202 | `/reports` | `http://localhost:4202/remoteEntry.js` |

## How to Run

```bash
npm install
npm run start:all
```

Open:

```text
http://localhost:4200
```

## Verify Remote Entry Files

After running all apps, open these URLs in browser:

```text
http://localhost:4201/remoteEntry.js
http://localhost:4202/remoteEntry.js
```

If these URLs load JavaScript, the remotes are exposed correctly.

## Demo Flow

1. Start all apps with `npm run start:all`.
2. Open shell: `http://localhost:4200`.
3. Click **Payments MFE**.
4. Click **Select Account** for any transaction.
5. Click **Reports MFE**.
6. Reports shows the account context sent by Payments using a browser event contract.

## Important Files

```text
angular.json
projects/shell/webpack.config.js
projects/payments-mfe/webpack.config.js
projects/reports-mfe/webpack.config.js
projects/shell/src/app/app.routes.ts
projects/payments-mfe/src/app/transactions/transaction.routes.ts
projects/reports-mfe/src/app/reports/report.routes.ts
```

## Module Federation Contract

Payments exposes:

```js
'./TransactionRoutes': './projects/payments-mfe/src/app/transactions/transaction.routes.ts'
```

Reports exposes:

```js
'./ReportRoutes': './projects/reports-mfe/src/app/reports/report.routes.ts'
```

Shell consumes:

```ts
loadRemoteModule({
  type: 'module',
  remoteEntry: 'http://localhost:4201/remoteEntry.js',
  exposedModule: './TransactionRoutes'
})
```

## Notes

- Keep the Angular versions same across shell and remotes.
- Keep `singleton: true`, `strictVersion: true`, `requiredVersion: 'auto'` for shared dependencies.
- For production, replace localhost remote URLs with environment-specific remote URLs or a runtime MFE registry.
