const { shareAll, withModuleFederationPlugin } = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  // Static remote map for local development. The shell also uses explicit remoteEntry URLs in routes.
  remotes: {
    paymentsMfe: 'paymentsMfe@http://localhost:4201/remoteEntry.js',
    reportsMfe: 'reportsMfe@http://localhost:4202/remoteEntry.js'
  },
  shared: {
    ...shareAll({ singleton: true, strictVersion: true, requiredVersion: 'auto' })
  }
});
