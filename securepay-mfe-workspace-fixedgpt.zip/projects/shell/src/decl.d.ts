declare module 'paymentsMfe/TransactionRoutes';
declare module 'reportsMfe/ReportRoutes';
