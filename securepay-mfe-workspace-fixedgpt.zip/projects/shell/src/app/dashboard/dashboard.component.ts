import { Component, signal } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  template: `
    <section class="grid">
      <div class="card hero">
        <div>
          <span class="badge">Shell-owned screen</span>
          <h2>Banking Micro Frontend Demo</h2>
          <p>The shell owns layout, navigation and runtime loading. Payments and Reports are independent Angular remotes.</p>
        </div>
        <div class="ports">
          <strong>Local Ports</strong>
          <span>Shell: 4200</span>
          <span>Payments: 4201</span>
          <span>Reports: 4202</span>
        </div>
      </div>

      <div class="cards">
        <div class="card"><h3>Runtime Loading</h3><p>The shell loads remoteEntry.js only when the user opens remote routes.</p></div>
        <div class="card"><h3>Shared Singletons</h3><p>Angular, Router and RxJS are shared as singleton packages.</p></div>
        <div class="card"><h3>Cross-MFE Event</h3><p>Select account in Payments, then open Reports to see the selected account context.</p></div>
      </div>
    </section>
  `,
  styles: [`
    .hero { display: flex; justify-content: space-between; gap: 24px; align-items: center; }
    h2 { font-size: 32px; margin: 12px 0; }
    p { color: var(--muted); line-height: 1.6; }
    .ports { display: grid; gap: 8px; min-width: 220px; background: #f8fafc; border-radius: 14px; padding: 16px; }
    .ports span { color: var(--muted); }
    .cards { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; }
    @media (max-width: 800px) { .hero, .cards { grid-template-columns: 1fr; display: grid; } }
  `]
})
export class DashboardComponent {
  protected loaded = signal(true);
}
