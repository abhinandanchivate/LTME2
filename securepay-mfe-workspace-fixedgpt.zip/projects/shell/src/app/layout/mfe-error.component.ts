import { Component, inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-mfe-error',
  standalone: true,
  template: `
    <div class="card error">
      <h2>{{ moduleName }} is temporarily unavailable</h2>
      <p>Start the remote server and refresh this route.</p>
      <code>npm run start:all</code>
    </div>
  `,
  styles: [`.error { border-color: #f4c7c3; background: #fff8f7; } code { background: #111827; color: white; padding: 8px 10px; border-radius: 8px; display: inline-block; }`]
})
export class MfeErrorComponent {
  private route = inject(ActivatedRoute);
  moduleName = this.route.snapshot.data['moduleName'] ?? 'Remote module';
}
