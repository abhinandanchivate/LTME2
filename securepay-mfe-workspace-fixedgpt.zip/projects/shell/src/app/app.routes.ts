import { Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/module-federation';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MfeErrorComponent } from './layout/mfe-error.component';

export const APP_ROUTES: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
  { path: 'dashboard', component: DashboardComponent },
  {
    path: 'transactions',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: 'http://localhost:4201/remoteEntry.js',
        exposedModule: './TransactionRoutes'
      })
        .then(m => m.TRANSACTION_ROUTES)
        .catch(() => [{ path: '', component: MfeErrorComponent, data: { moduleName: 'Payments MFE' } }])
  },
  {
    path: 'reports',
    loadChildren: () =>
      loadRemoteModule({
        type: 'module',
        remoteEntry: 'http://localhost:4202/remoteEntry.js',
        exposedModule: './ReportRoutes'
      })
        .then(m => m.REPORT_ROUTES)
        .catch(() => [{ path: '', component: MfeErrorComponent, data: { moduleName: 'Reports MFE' } }])
  },
  { path: '**', redirectTo: 'dashboard' }
];
