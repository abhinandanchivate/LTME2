import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <header class="topbar">
      <div>
        <h1>SecurePayment Gateway</h1>
        <p>Shell Host + Payments MFE + Reports MFE</p>
      </div>
      <span class="badge">Shell :4200</span>
    </header>

    <nav class="nav">
      <a routerLink="/dashboard" routerLinkActive="active">Dashboard</a>
      <a routerLink="/transactions" routerLinkActive="active">Payments MFE</a>
      <a routerLink="/reports" routerLinkActive="active">Reports MFE</a>
    </nav>

    <main class="page">
      <router-outlet />
    </main>
  `,
  styles: [`
    .topbar { background: linear-gradient(135deg, #0b2f63, #174ea6); color: white; padding: 22px 28px; display: flex; justify-content: space-between; align-items: center; }
    h1 { margin: 0; font-size: 26px; }
    p { margin: 6px 0 0; opacity: .9; }
    .nav { display: flex; gap: 12px; padding: 14px 28px; background: white; border-bottom: 1px solid var(--border); }
    .nav a { text-decoration: none; padding: 10px 14px; border-radius: 10px; color: var(--primary-dark); font-weight: 700; }
    .nav a.active, .nav a:hover { background: #e8f0fe; }
    .page { padding: 24px; max-width: 1180px; margin: 0 auto; }
  `]
})
export class AppComponent {}
