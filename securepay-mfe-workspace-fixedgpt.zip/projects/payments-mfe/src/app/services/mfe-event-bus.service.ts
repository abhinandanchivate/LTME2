import { Injectable } from '@angular/core';
import { Observable, filter, fromEvent, map } from 'rxjs';

export type MfeEvent =
  | { type: 'ACCOUNT_SELECTED'; payload: { accountId: string; accountName: string } }
  | { type: 'TRANSACTION_CREATED'; payload: { transactionId: string; amount: number; accountId: string } };

export type MfeEventType = MfeEvent['type'];
export type MfePayload<T extends MfeEventType> = Extract<MfeEvent, { type: T }>['payload'];

const EVENT_NAME = 'securepay:mfe-event';

@Injectable({ providedIn: 'root' })
export class MfeEventBusService {
  emit(event: MfeEvent): void {
    window.dispatchEvent(new CustomEvent<MfeEvent>(EVENT_NAME, { detail: event }));
  }

  on<T extends MfeEventType>(type: T): Observable<MfePayload<T>> {
    return fromEvent<CustomEvent<MfeEvent>>(window, EVENT_NAME).pipe(
      map(event => event.detail),
      filter(event => event.type === type),
      map(event => event.payload as MfePayload<T>)
    );
  }
}
