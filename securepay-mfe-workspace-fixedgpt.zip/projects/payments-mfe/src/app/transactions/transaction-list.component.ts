import { Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CurrencyPipe, DatePipe } from '@angular/common';
import { MfeEventBusService } from '../services/mfe-event-bus.service';

interface Transaction {
  id: string;
  accountId: string;
  accountName: string;
  amount: number;
  status: 'SUCCESS' | 'PENDING' | 'FAILED';
  createdAt: Date;
}

@Component({
  selector: 'payments-transaction-list',
  standalone: true,
  imports: [RouterLink, CurrencyPipe, DatePipe],
  template: `
    <div class="grid">
      <div class="card heading">
        <div>
          <span class="badge">Payments MFE loaded from remoteEntry.js</span>
          <h2>Transactions</h2>
          <p>Select an account here. Reports MFE listens using the shared browser event contract.</p>
        </div>
        <a class="btn" routerLink="new">Create Payment</a>
      </div>

      <div class="card table-card">
        <table>
          <thead>
            <tr><th>ID</th><th>Account</th><th>Amount</th><th>Status</th><th>Created</th><th>Action</th></tr>
          </thead>
          <tbody>
            @for (tx of transactions(); track tx.id) {
              <tr>
                <td>{{ tx.id }}</td>
                <td>{{ tx.accountName }}</td>
                <td>{{ tx.amount | currency:'INR' }}</td>
                <td><span class="status" [class.pending]="tx.status === 'PENDING'" [class.failed]="tx.status === 'FAILED'">{{ tx.status }}</span></td>
                <td>{{ tx.createdAt | date:'medium' }}</td>
                <td><button class="btn secondary" (click)="selectAccount(tx)">Select Account</button></td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .heading { display:flex; justify-content:space-between; gap:20px; align-items:center; }
    h2 { margin:10px 0; font-size:28px; }
    p { color:var(--muted); }
    table { width:100%; border-collapse:collapse; }
    th, td { padding:12px; border-bottom:1px solid var(--border); text-align:left; }
    th { color:var(--muted); font-size:13px; }
    .status { padding:4px 10px; border-radius:999px; background:#dcfce7; color:#166534; font-weight:700; font-size:12px; }
    .status.pending { background:#fef9c3; color:#854d0e; }
    .status.failed { background:#fee2e2; color:#991b1b; }
    .table-card { overflow:auto; }
  `]
})
export class TransactionListComponent {
  private eventBus = inject(MfeEventBusService);
  transactions = signal<Transaction[]>([
    { id: 'TXN-1001', accountId: 'ACC-1001', accountName: 'Corporate Salary Account', amount: 125000, status: 'SUCCESS', createdAt: new Date() },
    { id: 'TXN-1002', accountId: 'ACC-2001', accountName: 'Vendor Settlement Account', amount: 84500, status: 'PENDING', createdAt: new Date(Date.now() - 3600_000) },
    { id: 'TXN-1003', accountId: 'ACC-3001', accountName: 'Refund Control Account', amount: 12999, status: 'FAILED', createdAt: new Date(Date.now() - 7200_000) }
  ]);

  selectAccount(tx: Transaction): void {
    this.eventBus.emit({ type: 'ACCOUNT_SELECTED', payload: { accountId: tx.accountId, accountName: tx.accountName } });
    alert(`Account selected: ${tx.accountName}. Now open Reports MFE.`);
  }
}
