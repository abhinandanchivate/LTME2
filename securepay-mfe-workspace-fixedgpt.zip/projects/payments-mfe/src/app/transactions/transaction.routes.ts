import { Routes } from '@angular/router';
import { TransactionListComponent } from './transaction-list.component';
import { PaymentFormComponent } from './payment-form.component';

export const TRANSACTION_ROUTES: Routes = [
  { path: '', component: TransactionListComponent },
  { path: 'new', component: PaymentFormComponent }
];
