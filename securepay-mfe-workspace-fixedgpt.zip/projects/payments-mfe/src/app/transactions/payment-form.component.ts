import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { MfeEventBusService } from '../services/mfe-event-bus.service';

@Component({
  selector: 'payments-payment-form',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink],
  template: `
    <div class="card form-card">
      <span class="badge">Standalone component exposed through remote route</span>
      <h2>Create Payment</h2>
      <form [formGroup]="form" (ngSubmit)="submit()">
        <label>Account ID <input formControlName="accountId" placeholder="ACC-1001" /></label>
        <label>Beneficiary <input formControlName="beneficiary" placeholder="Vendor ABC" /></label>
        <label>Amount <input type="number" formControlName="amount" /></label>
        <div class="actions">
          <button class="btn" type="submit" [disabled]="form.invalid">Submit Payment</button>
          <a routerLink="/transactions">Back</a>
        </div>
      </form>
    </div>
  `,
  styles: [`
    .form-card { max-width:560px; }
    form { display:grid; gap:14px; margin-top:18px; }
    label { display:grid; gap:6px; font-weight:700; }
    input { border:1px solid var(--border); border-radius:10px; padding:12px; font-size:15px; }
    .actions { display:flex; align-items:center; gap:14px; }
    button:disabled { opacity:.5; cursor:not-allowed; }
  `]
})
export class PaymentFormComponent {
  private fb = inject(FormBuilder);
  private eventBus = inject(MfeEventBusService);

  form = this.fb.nonNullable.group({
    accountId: ['ACC-1001', Validators.required],
    beneficiary: ['', Validators.required],
    amount: [1000, [Validators.required, Validators.min(1)]]
  });

  submit(): void {
    if (this.form.invalid) return;
    const value = this.form.getRawValue();
    this.eventBus.emit({
      type: 'TRANSACTION_CREATED',
      payload: { transactionId: `TXN-${Math.floor(Math.random() * 9000 + 1000)}`, amount: value.amount, accountId: value.accountId }
    });
    alert('Payment submitted and TRANSACTION_CREATED event emitted.');
  }
}
