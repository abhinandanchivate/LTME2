import { Routes } from '@angular/router';
import { PaymentsHomeComponent } from './home/payments-home.component';
import { TRANSACTION_ROUTES } from './transactions/transaction.routes';

export const APP_ROUTES: Routes = [
  { path: '', component: PaymentsHomeComponent },
  { path: 'transactions', children: TRANSACTION_ROUTES },
  { path: '**', redirectTo: '' }
];
