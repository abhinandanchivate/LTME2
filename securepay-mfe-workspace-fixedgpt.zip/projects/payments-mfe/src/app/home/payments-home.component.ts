import { Component } from '@angular/core';

@Component({
  selector: 'payments-home',
  standalone: true,
  template: `
    <div class="card">
      <span class="badge">Remote running independently</span>
      <h2>Payments MFE</h2>
      <p>This application can run alone on port 4201 and can also be loaded inside the shell at <strong>/transactions</strong>.</p>
    </div>
  `
})
export class PaymentsHomeComponent {}
