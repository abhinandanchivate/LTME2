const { shareAll, withModuleFederationPlugin } = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  name: 'paymentsMfe',
  filename: 'remoteEntry.js',
  exposes: {
    './TransactionRoutes': './projects/payments-mfe/src/app/transactions/transaction.routes.ts'
  },
  shared: {
    ...shareAll({ singleton: true, strictVersion: true, requiredVersion: 'auto' })
  }
});
