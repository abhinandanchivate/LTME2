import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <header class="remote-header">
      <strong>Reports Remote</strong>
      <span class="badge">Standalone :4202</span>
    </header>
    <nav class="remote-nav">
      <a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{ exact: true }">Home</a>
      <a routerLink="/reports" routerLinkActive="active">Reports</a>
    </nav>
    <main class="remote-page"><router-outlet /></main>
  `,
  styles: [`
    .remote-header { display:flex; justify-content:space-between; align-items:center; padding:18px 24px; background:#0f5132; color:white; }
    .remote-nav { display:flex; gap:12px; padding:12px 24px; background:white; border-bottom:1px solid var(--border); }
    .remote-nav a { text-decoration:none; padding:8px 12px; border-radius:10px; color:#0f5132; font-weight:700; }
    .remote-nav a.active, .remote-nav a:hover { background:#dcfce7; }
    .remote-page { padding:24px; }
  `]
})
export class AppComponent {}
