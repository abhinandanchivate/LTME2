import { Routes } from '@angular/router';
import { ReportsHomeComponent } from './home/reports-home.component';
import { REPORT_ROUTES } from './reports/report.routes';

export const APP_ROUTES: Routes = [
  { path: '', component: ReportsHomeComponent },
  { path: 'reports', children: REPORT_ROUTES },
  { path: '**', redirectTo: '' }
];
