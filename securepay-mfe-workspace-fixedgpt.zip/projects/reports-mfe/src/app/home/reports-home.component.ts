import { Component } from '@angular/core';

@Component({
  selector: 'reports-home',
  standalone: true,
  template: `
    <div class="card">
      <span class="badge">Remote running independently</span>
      <h2>Reports MFE</h2>
      <p>This application can run alone on port 4202 and can also be loaded inside the shell at <strong>/reports</strong>.</p>
    </div>
  `
})
export class ReportsHomeComponent {}
