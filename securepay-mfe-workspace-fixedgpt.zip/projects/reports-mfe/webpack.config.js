const { shareAll, withModuleFederationPlugin } = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  name: 'reportsMfe',
  filename: 'remoteEntry.js',
  exposes: {
    './ReportRoutes': './projects/reports-mfe/src/app/reports/report.routes.ts'
  },
  shared: {
    ...shareAll({ singleton: true, strictVersion: true, requiredVersion: 'auto' })
  }
});
