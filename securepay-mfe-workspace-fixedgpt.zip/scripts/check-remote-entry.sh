#!/usr/bin/env bash
set -euo pipefail
curl -I http://localhost:4201/remoteEntry.js
curl -I http://localhost:4202/remoteEntry.js
