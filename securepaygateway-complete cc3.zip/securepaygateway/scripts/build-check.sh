#!/bin/bash
# scripts/build-check.sh
# ✅ CI guard: fails if any forbidden patterns are found in the production build.
# Run after: ng build --configuration=production

set -e

DIST_DIR="${1:-dist/shell/browser}"

if [ ! -d "$DIST_DIR" ]; then
  echo "[Build Check] ❌ dist directory not found: $DIST_DIR"
  echo "  Run: ng build --configuration=production first"
  exit 1
fi

echo "[Build Check] Scanning ${DIST_DIR} for forbidden patterns..."
echo ""

# Patterns that must NEVER appear in a production build
FORBIDDEN=(
  "staging-api.securepaygateway"   # Staging API URL
  "test-pg.securepaygateway"       # Test payment gateway
  "localhost:8080"                 # Dev API
  "localhost:4201"                 # Dev Payments MFE
  "localhost:4202"                 # Dev Reports MFE
  "devTools:true"                  # DevTools enabled flag
  "logLevel:debug"                 # Debug log level
  "logLevel:\"debug\""             # Alternative form
  "sourceMappingURL"               # Source maps (should be stripped)
)

FOUND=0

for pattern in "${FORBIDDEN[@]}"; do
  if grep -rq "$pattern" "$DIST_DIR" 2>/dev/null; then
    echo "[Build Check] ❌ CRITICAL: '$pattern' found in production build!"
    # Show which file contains the issue
    grep -rl "$pattern" "$DIST_DIR" | while read -r file; do
      echo "              └─ Found in: $file"
    done
    FOUND=1
  fi
done

echo ""

if [ $FOUND -eq 1 ]; then
  echo "[Build Check] 🚫 Production build REJECTED — forbidden patterns found."
  echo "  Fix: ensure environment.production.ts does not contain dev/staging values."
  exit 1
fi

# ─── Verify required prod values are present ──────────────────────────────────

REQUIRED=(
  "api.securepaygateway.in"
  "pg.securepaygateway.in"
)

MISSING=0
for pattern in "${REQUIRED[@]}"; do
  if ! grep -rq "$pattern" "$DIST_DIR" 2>/dev/null; then
    echo "[Build Check] ⚠️  WARNING: Expected production URL '$pattern' not found!"
    MISSING=1
  fi
done

if [ $MISSING -eq 1 ]; then
  echo "[Build Check] ⚠️  Production URLs may not be set correctly."
  echo "  Check: src/environments/environment.production.ts"
fi

echo "[Build Check] ✅ Production build verified — no forbidden patterns found."
echo "[Build Check] 🎉 Build is safe to deploy."
exit 0
