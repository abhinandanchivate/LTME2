import { Injectable } from '@angular/core';
import { ReplaySubject, Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';

export interface AccountSelectedPayload {
  accountId: string;
  accountName: string;
  accountType: string;
}

export interface TransactionCreatedPayload {
  transactionId: string;
  amount: number;
  currency: string;
}

export interface ThemeChangedPayload {
  theme: 'light' | 'dark';
}

export interface UserLoggedOutPayload {}

export type MfeEvent =
  | { type: 'ACCOUNT_SELECTED';    payload: AccountSelectedPayload }
  | { type: 'TRANSACTION_CREATED'; payload: TransactionCreatedPayload }
  | { type: 'THEME_CHANGED';       payload: ThemeChangedPayload }
  | { type: 'USER_LOGGED_OUT';     payload: UserLoggedOutPayload };

export type MfeEventType = MfeEvent['type'];

@Injectable({ providedIn: 'root' })
export class MfeEventBusService {
  private readonly _events$ = new ReplaySubject<MfeEvent>(1);

  emit(event: MfeEvent): void {
    console.debug(`[EventBus] ▶ ${event.type}`, event.payload);
    this._events$.next(event);
  }

  on(eventType: 'ACCOUNT_SELECTED'): Observable<AccountSelectedPayload>;
  on(eventType: 'TRANSACTION_CREATED'): Observable<TransactionCreatedPayload>;
  on(eventType: 'THEME_CHANGED'): Observable<ThemeChangedPayload>;
  on(eventType: 'USER_LOGGED_OUT'): Observable<UserLoggedOutPayload>;
  on(eventType: MfeEventType): Observable<any> {
    return this._events$.pipe(
      filter((e) => e.type === eventType),
      map((e) => e.payload)
    );
  }

  all$(): Observable<MfeEvent> {
    return this._events$.asObservable();
  }
}
