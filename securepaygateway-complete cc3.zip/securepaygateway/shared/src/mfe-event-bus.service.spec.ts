// shared/src/mfe-event-bus.service.spec.ts
import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { MfeEventBusService } from './mfe-event-bus.service';

describe('MfeEventBusService', () => {
  let service: MfeEventBusService;

  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [MfeEventBusService] });
    service = TestBed.inject(MfeEventBusService);
  });

  it('should deliver typed events to subscribers', fakeAsync(() => {
    let received: any;
    service.on('ACCOUNT_SELECTED').subscribe((p) => (received = p));

    service.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId: 'ACC-001', accountName: 'HDFC', accountType: 'CURRENT' },
    });
    tick();

    expect(received.accountId).toBe('ACC-001');
    expect(received.accountName).toBe('HDFC');
  }));

  it('should NOT deliver events of other types', fakeAsync(() => {
    let accountReceived: any;
    let transactionReceived: any;

    service.on('ACCOUNT_SELECTED').subscribe((p) => (accountReceived = p));
    service.on('TRANSACTION_CREATED').subscribe((p) => (transactionReceived = p));

    service.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId: 'ACC-001', accountName: 'HDFC', accountType: 'CURRENT' },
    });
    tick();

    expect(accountReceived).toBeTruthy();
    expect(transactionReceived).toBeUndefined(); // ✅ Not delivered to wrong subscriber
  }));

  it('should deliver last event to late subscribers via ReplaySubject(1)', fakeAsync(() => {
    // Emit FIRST (no subscribers yet)
    service.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId: 'ACC-999', accountName: 'SBI', accountType: 'CURRENT' },
    });
    tick();

    // Subscribe LATER — simulates Reports MFE loading after account was selected
    let received: any;
    service.on('ACCOUNT_SELECTED').subscribe((p) => (received = p));
    tick();

    // ✅ ReplaySubject(1) delivers the buffered last event
    expect(received).toBeTruthy();
    expect(received.accountId).toBe('ACC-999');
  }));

  it('should only replay the LAST event (buffer size = 1)', fakeAsync(() => {
    const received: string[] = [];

    service.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId: 'ACC-001', accountName: 'First', accountType: 'CURRENT' },
    });
    service.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId: 'ACC-002', accountName: 'Second', accountType: 'SAVINGS' },
    });
    tick();

    service.on('ACCOUNT_SELECTED').subscribe((p) => received.push(p.accountId));
    tick();

    // ✅ Only the LAST event replayed (not both)
    expect(received.length).toBe(1);
    expect(received[0]).toBe('ACC-002');
  }));

  it('should allow subscribing to TRANSACTION_CREATED separately', fakeAsync(() => {
    let received: any;
    service.on('TRANSACTION_CREATED').subscribe((p) => (received = p));

    service.emit({
      type: 'TRANSACTION_CREATED',
      payload: { transactionId: 'TXN-001', amount: 50000, currency: 'INR' },
    });
    tick();

    expect(received.transactionId).toBe('TXN-001');
    expect(received.amount).toBe(50000);
  }));
});
