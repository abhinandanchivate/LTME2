// @securepaygateway/shell-contracts — models.ts
// Shared domain models used by all MFEs

// ─── Auth Models ─────────────────────────────────────────────────────────────

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  accessToken: string;
  expiresIn: number; // seconds
}

export interface JwtPayload {
  sub: string;           // user ID
  email: string;
  roles: UserRole[];
  exp: number;           // Unix timestamp
  iat: number;
}

export type UserRole = 'ADMIN' | 'OPERATIONS' | 'COMPLIANCE' | 'VIEWER';

export interface AuthUser {
  id: string;
  email: string;
  roles: UserRole[];
  expiresAt: Date;
}

// ─── Transaction Models ───────────────────────────────────────────────────────

export type TransactionStatus =
  | 'PENDING'
  | 'PROCESSING'
  | 'COMPLETED'
  | 'FAILED'
  | 'REVERSED';

export type TransactionType = 'NEFT' | 'RTGS' | 'IMPS' | 'UPI' | 'SWIFT';

export interface Transaction {
  id: string;
  referenceNumber: string;
  amount: number;
  currency: string;
  type: TransactionType;
  status: TransactionStatus;
  fromAccount: AccountSummary;
  toAccount: AccountSummary;
  description: string;
  initiatedAt: string;  // ISO 8601
  completedAt?: string; // ISO 8601
  metadata?: Record<string, string>;
}

export interface AccountSummary {
  accountId: string;
  accountName: string;
  accountNumber: string; // masked: XXXX1234
  ifscCode: string;
  bankName: string;
  accountType: 'SAVINGS' | 'CURRENT' | 'NRE' | 'NRO';
}

export interface TransactionFilter {
  status?: TransactionStatus;
  type?: TransactionType;
  fromDate?: string;
  toDate?: string;
  accountId?: string;
  minAmount?: number;
  maxAmount?: number;
  search?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// ─── Report Models ───────────────────────────────────────────────────────────

export interface ReportSummary {
  accountId: string;
  accountName: string;
  totalTransactions: number;
  totalVolume: number;
  currency: string;
  successRate: number;       // 0–100
  avgProcessingTime: number; // seconds
  periodStart: string;
  periodEnd: string;
}

export interface ChartDataPoint {
  label: string;
  value: number;
  color?: string;
}

export interface TransactionVolumeChart {
  dates: string[];
  series: {
    name: string;
    data: number[];
    color: string;
  }[];
}

// ─── MFE Registry ────────────────────────────────────────────────────────────

export interface RemoteConfig {
  remoteEntry: string;
  exposedModule: string;
}

export type MfeRegistryMap = Record<string, RemoteConfig>;

export interface MfeRegistryResponse {
  paymentsMfe: RemoteConfig;
  reportsMfe: RemoteConfig;
}
