// shell/webpack.config.js — Module Federation HOST configuration
const {
  shareAll,
  withModuleFederationPlugin,
} = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  // ✅ HOST: declares remotes it can load at runtime
  remotes: {
    paymentsMfe: 'paymentsMfe@http://localhost:4201/remoteEntry.js',
    reportsMfe:  'reportsMfe@http://localhost:4202/remoteEntry.js',
  },

  shared: {
    ...shareAll({
      singleton: true,      // One instance across shell + all remotes
      strictVersion: true,  // Hard fail on major version mismatch
      requiredVersion: 'auto', // Reads from this app's package.json
    }),

    // NgRx must also be singleton — one store instance across all MFEs
    '@ngrx/store':      { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/effects':    { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/entity':     { singleton: true, strictVersion: true, requiredVersion: 'auto' },
  },
});
