// shell/src/main.ts — dynamic import required for Module Federation
// The dynamic import allows Module Federation to initialize shared modules
// before the Angular bootstrap runs.
import('./bootstrap').catch((err) => console.error('Bootstrap failed:', err));
