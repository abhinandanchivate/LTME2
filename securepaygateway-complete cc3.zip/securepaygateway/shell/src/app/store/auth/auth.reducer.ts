import { createFeature, createReducer, on } from '@ngrx/store';
import { AuthUser } from '../../../services/auth.service';
import { AuthActions } from './auth.actions';

export interface AuthState {
  user: AuthUser | null;
  token: string | null;
  isLoading: boolean;
  isRefreshing: boolean;
  error: string | null;
}

const initialState: AuthState = {
  user: null, token: null, isLoading: false, isRefreshing: false, error: null,
};

export const authFeature = createFeature({
  name: 'auth',
  reducer: createReducer(
    initialState,
    on(AuthActions.login,               (s)         => ({ ...s, isLoading: true,  error: null })),
    on(AuthActions.loginSuccess,        (s, { user, token }) => ({ ...s, user, token, isLoading: false, error: null })),
    on(AuthActions.loginFailure,        (s, { error })       => ({ ...s, user: null, token: null, isLoading: false, error })),
    on(AuthActions.logout,              (s)         => ({ ...s, isLoading: true })),
    on(AuthActions.logoutComplete,      ()          => ({ ...initialState })),
    on(AuthActions.refreshToken,        (s)         => ({ ...s, isRefreshing: true })),
    on(AuthActions.refreshTokenSuccess, (s, { user, token }) => ({ ...s, user, token, isRefreshing: false })),
    on(AuthActions.refreshTokenFailure, ()          => ({ ...initialState })),
  ),
});

export const {
  name: authFeatureName,
  reducer: authReducer,
  selectAuthState,
  selectUser,
  selectToken,
  selectIsLoading,
  selectIsRefreshing,
  selectError,
} = authFeature;
