// shell/src/app/store/auth/auth.selectors.ts
import { createSelector } from '@ngrx/store';
import { selectAuthState } from './auth.reducer';

export const selectIsAuthenticated = createSelector(
  selectAuthState,
  (auth) => !!auth.token && !!auth.user
);

export const selectCurrentUser = createSelector(
  selectAuthState,
  (auth) => auth.user
);

export const selectAccessToken = createSelector(
  selectAuthState,
  (auth) => auth.token
);

export const selectUserRoles = createSelector(
  selectAuthState,
  (auth) => auth.user?.roles ?? []
);

export const selectHasRole = (role: string) =>
  createSelector(selectUserRoles, (roles) => roles.includes(role as any));

export const selectAuthLoading = createSelector(
  selectAuthState,
  (auth) => auth.isLoading
);

export const selectAuthError = createSelector(
  selectAuthState,
  (auth) => auth.error
);

export const selectTokenExpiresAt = createSelector(
  selectAuthState,
  (auth) => auth.user?.expiresAt ?? null
);
