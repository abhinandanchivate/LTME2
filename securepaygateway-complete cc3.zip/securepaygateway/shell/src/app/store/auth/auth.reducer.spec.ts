// shell/src/app/store/auth/auth.reducer.spec.ts
import { authReducer, AuthState } from './auth.reducer';
import { AuthActions } from './auth.actions';
import { AuthUser } from '../../../../shared/src/models';

const mockUser: AuthUser = {
  id: 'user-001',
  email: 'ops@bank.in',
  roles: ['OPERATIONS'],
  expiresAt: new Date(Date.now() + 900_000),
};

describe('authReducer', () => {
  const initialState: AuthState = {
    user: null,
    token: null,
    isLoading: false,
    isRefreshing: false,
    error: null,
  };

  it('should return initial state', () => {
    const state = authReducer(undefined, { type: '@@INIT' } as any);
    expect(state).toEqual(initialState);
  });

  it('should set isLoading on login', () => {
    const state = authReducer(
      initialState,
      AuthActions.login({ credentials: { username: 'x', password: 'y' } })
    );
    expect(state.isLoading).toBeTrue();
    expect(state.error).toBeNull();
  });

  it('should set user + token on loginSuccess', () => {
    const state = authReducer(
      { ...initialState, isLoading: true },
      AuthActions.loginSuccess({ user: mockUser, token: 'fake-jwt' })
    );
    expect(state.user).toEqual(mockUser);
    expect(state.token).toBe('fake-jwt');
    expect(state.isLoading).toBeFalse();
    expect(state.error).toBeNull();
  });

  it('should set error and clear token on loginFailure', () => {
    const state = authReducer(
      { ...initialState, isLoading: true },
      AuthActions.loginFailure({ error: 'Invalid credentials' })
    );
    expect(state.user).toBeNull();
    expect(state.token).toBeNull();
    expect(state.error).toBe('Invalid credentials');
    expect(state.isLoading).toBeFalse();
  });

  it('should reset to initialState on logoutComplete', () => {
    const loggedIn: AuthState = {
      user: mockUser,
      token: 'jwt',
      isLoading: false,
      isRefreshing: false,
      error: null,
    };
    const state = authReducer(loggedIn, AuthActions.logoutComplete());
    expect(state).toEqual(initialState);
  });

  it('should set isRefreshing on refreshToken', () => {
    const state = authReducer(initialState, AuthActions.refreshToken());
    expect(state.isRefreshing).toBeTrue();
  });

  it('should update token on refreshTokenSuccess', () => {
    const state = authReducer(
      { ...initialState, isRefreshing: true, user: mockUser, token: 'old-jwt' },
      AuthActions.refreshTokenSuccess({ user: mockUser, token: 'new-jwt' })
    );
    expect(state.token).toBe('new-jwt');
    expect(state.isRefreshing).toBeFalse();
  });

  it('should reset state on refreshTokenFailure', () => {
    const state = authReducer(
      { ...initialState, user: mockUser, token: 'jwt', isRefreshing: true },
      AuthActions.refreshTokenFailure()
    );
    expect(state.user).toBeNull();
    expect(state.token).toBeNull();
    expect(state.isRefreshing).toBeFalse();
  });
});
