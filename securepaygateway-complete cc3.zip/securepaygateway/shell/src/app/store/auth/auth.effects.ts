// shell/src/app/store/auth/auth.effects.ts
import { Injectable, inject } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, exhaustMap, map, of, switchMap, tap, timer } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { AuthActions } from './auth.actions';

@Injectable()
export class AuthEffects {
  private actions$ = inject(Actions);
  private authService = inject(AuthService);
  private router = inject(Router);

  // ─── Login ────────────────────────────────────────────────────────────────

  login$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.login),
      exhaustMap(({ credentials }) =>
        this.authService.login(credentials).pipe(
          map(({ user, token }) =>
            AuthActions.loginSuccess({ user, token })
          ),
          catchError((err) =>
            of(AuthActions.loginFailure({ error: err.message || 'Login failed' }))
          )
        )
      )
    )
  );

  loginSuccess$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.loginSuccess),
        tap(() => this.router.navigate(['/dashboard']))
      ),
    { dispatch: false }
  );

  // ─── Logout ───────────────────────────────────────────────────────────────

  logout$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.logout),
      switchMap(() =>
        this.authService.logout().pipe(
          map(() => AuthActions.logoutComplete()),
          catchError(() => of(AuthActions.logoutComplete()))
        )
      )
    )
  );

  logoutComplete$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.logoutComplete),
        tap(() => this.router.navigate(['/login']))
      ),
    { dispatch: false }
  );

  // ─── Token Refresh ────────────────────────────────────────────────────────

  /**
   * When login succeeds, schedule a token refresh 60 seconds before expiry.
   * Uses timer() so it cancels automatically when a new loginSuccess arrives.
   */
  scheduleRefresh$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.loginSuccess, AuthActions.refreshTokenSuccess),
      switchMap(({ user }) => {
        const expiresIn = user.expiresAt.getTime() - Date.now();
        const refreshAfter = Math.max(0, expiresIn - 60_000); // 60s before expiry
        console.log(
          `[AuthEffects] Token refresh scheduled in ${Math.round(refreshAfter / 1000)}s`
        );
        return timer(refreshAfter).pipe(
          map(() => AuthActions.refreshToken())
        );
      })
    )
  );

  refreshToken$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.refreshToken),
      exhaustMap(() =>
        this.authService.refreshAccessToken().pipe(
          map(({ user, token }) =>
            AuthActions.refreshTokenSuccess({ user, token })
          ),
          catchError(() => of(AuthActions.refreshTokenFailure()))
        )
      )
    )
  );

  refreshTokenFailure$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.refreshTokenFailure),
        tap(() => {
          console.warn('[AuthEffects] Token refresh failed — redirecting to login');
          this.router.navigate(['/login']);
        })
      ),
    { dispatch: false }
  );
}
