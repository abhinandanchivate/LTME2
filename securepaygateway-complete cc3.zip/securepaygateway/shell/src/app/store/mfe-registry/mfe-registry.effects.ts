// shell/src/app/store/mfe-registry/mfe-registry.effects.ts
import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';
import { MfeRegistryService } from '../../services/mfe-registry.service';
import { MfeRegistryActions } from './mfe-registry.state';

@Injectable()
export class MfeRegistryEffects {
  private actions$ = inject(Actions);
  private registryService = inject(MfeRegistryService);

  loadRegistry$ = createEffect(() =>
    this.actions$.pipe(
      ofType(MfeRegistryActions.loadRegistry),
      switchMap(() =>
        this.registryService.fetchRegistry().pipe(
          map((registry) => MfeRegistryActions.loadRegistrySuccess({ registry })),
          catchError((err) =>
            of(
              MfeRegistryActions.loadRegistryFailure({
                error: err.message || 'Registry fetch failed',
              })
            )
          )
        )
      )
    )
  );
}
