import { createActionGroup, emptyProps, props } from '@ngrx/store';
import { createFeature, createReducer, on, createSelector } from '@ngrx/store';
import { MfeRegistryMap } from '../../services/mfe-registry.service';

export const MfeRegistryActions = createActionGroup({
  source: 'MFE Registry',
  events: {
    'Load Registry':         emptyProps(),
    'Load Registry Success': props<{ registry: MfeRegistryMap }>(),
    'Load Registry Failure': props<{ error: string }>(),
  },
});

export interface MfeRegistryState {
  registry: MfeRegistryMap;
  loaded: boolean;
  loading: boolean;
  error: string | null;
}

const initialMfeState: MfeRegistryState = {
  registry: {}, loaded: false, loading: false, error: null,
};

export const mfeRegistryFeature = createFeature({
  name: 'mfeRegistry',
  reducer: createReducer(
    initialMfeState,
    on(MfeRegistryActions.loadRegistry,        (s)             => ({ ...s, loading: true, error: null })),
    on(MfeRegistryActions.loadRegistrySuccess, (s, { registry }) => ({ ...s, registry, loaded: true, loading: false })),
    on(MfeRegistryActions.loadRegistryFailure, (s, { error })    => ({ ...s, loading: false, error })),
  ),
});

export const {
  name: mfeRegistryFeatureName,
  reducer: mfeRegistryReducer,
  selectMfeRegistryState,
  selectRegistry,
  selectLoaded,
  selectLoading,
} = mfeRegistryFeature;

export const selectRemoteEntry = (mfeName: string) =>
  createSelector(selectRegistry, (r) => r[mfeName]?.remoteEntry ?? null);
