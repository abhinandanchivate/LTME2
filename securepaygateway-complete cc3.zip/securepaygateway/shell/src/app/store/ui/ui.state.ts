import { createActionGroup, emptyProps, props } from '@ngrx/store';
import { createFeature, createReducer, on } from '@ngrx/store';

// ── NgRx does not allow a prop named 'type' inside props<>()
// so we use 'notificationType' internally and map it in the reducer
export type NotificationType = 'success' | 'error' | 'info' | 'warning';

export const UiActions = createActionGroup({
  source: 'UI',
  events: {
    'Toggle Sidebar':       emptyProps(),
    'Set Theme':            props<{ theme: 'light' | 'dark' }>(),
    'Add Notification':     props<{ message: string; notificationType: NotificationType; id?: string }>(),
    'Dismiss Notification': props<{ id: string }>(),
    'Clear Notifications':  emptyProps(),
  },
});

export interface Notification {
  id: string;
  message: string;
  type: NotificationType;
  timestamp: number;
}

export interface UiState {
  sidebarOpen: boolean;
  theme: 'light' | 'dark';
  notifications: Notification[];
}

const initialUiState: UiState = {
  sidebarOpen: true,
  theme: 'light',
  notifications: [],
};

export const uiFeature = createFeature({
  name: 'ui',
  reducer: createReducer(
    initialUiState,

    on(UiActions.toggleSidebar, (state) => ({
      ...state,
      sidebarOpen: !state.sidebarOpen,
    })),

    on(UiActions.setTheme, (state, { theme }) => ({
      ...state,
      theme,
    })),

    on(UiActions.addNotification, (state, { message, notificationType, id }) => ({
      ...state,
      notifications: [
        ...state.notifications,
        {
          id: id ?? `notif-${Date.now()}`,
          message,
          type: notificationType,
          timestamp: Date.now(),
        },
      ],
    })),

    on(UiActions.dismissNotification, (state, { id }) => ({
      ...state,
      notifications: state.notifications.filter((n) => n.id !== id),
    })),

    on(UiActions.clearNotifications, (state) => ({
      ...state,
      notifications: [],
    }))
  ),
});

export const {
  name: uiFeatureName,
  reducer: uiReducer,
  selectUiState,
  selectSidebarOpen,
  selectTheme,
  selectNotifications,
} = uiFeature;
