import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../environments/environment';

export interface LoginRequest  { username: string; password: string; }
export interface LoginResponse { accessToken: string; expiresIn: number; }
export type UserRole = 'ADMIN' | 'OPERATIONS' | 'COMPLIANCE' | 'VIEWER';

export interface AuthUser {
  id: string;
  email: string;
  roles: UserRole[];
  expiresAt: Date;
}

export interface JwtPayload {
  sub: string;
  email: string;
  roles: UserRole[];
  exp: number;
  iat: number;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly http   = inject(HttpClient);
  private readonly apiUrl = environment.apiUrl;

  decodeToken(token: string): JwtPayload | null {
    try {
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      return JSON.parse(atob(parts[1])) as JwtPayload;
    } catch { return null; }
  }

  private buildUser(token: string, expiresIn: number): AuthUser | null {
    const p = this.decodeToken(token);
    if (!p) return null;
    return { id: p.sub, email: p.email, roles: p.roles, expiresAt: new Date(Date.now() + expiresIn * 1000) };
  }

  login(credentials: LoginRequest): Observable<{ user: AuthUser; token: string }> {
    return this.http
      .post<LoginResponse>(`${this.apiUrl}/auth/login`, credentials, { withCredentials: true })
      .pipe(map(({ accessToken, expiresIn }) => {
        const user = this.buildUser(accessToken, expiresIn);
        if (!user) throw new Error('Invalid token received');
        return { user, token: accessToken };
      }));
  }

  refreshAccessToken(): Observable<{ user: AuthUser; token: string }> {
    return this.http
      .post<LoginResponse>(`${this.apiUrl}/auth/refresh`, {}, { withCredentials: true })
      .pipe(map(({ accessToken, expiresIn }) => {
        const user = this.buildUser(accessToken, expiresIn);
        if (!user) throw new Error('Invalid token from refresh');
        return { user, token: accessToken };
      }));
  }

  logout(): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/auth/logout`, {}, { withCredentials: true });
  }
}
