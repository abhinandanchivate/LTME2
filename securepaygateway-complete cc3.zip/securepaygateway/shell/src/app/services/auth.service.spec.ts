// shell/src/app/services/auth.service.spec.ts
import { TestBed, fakeAsync, tick, discardPeriodicTasks } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { AuthService } from './auth.service';
import { environment } from '../../environments/environment';

// ─── JWT Test Helper ──────────────────────────────────────────────────────────

function buildFakeJwt(
  overrides: Partial<{ sub: string; email: string; roles: string[]; exp: number }> = {}
): string {
  const now = Math.floor(Date.now() / 1000);
  const payload = {
    sub:   overrides.sub   ?? 'user-001',
    email: 'ops@bank.in',
    roles: overrides.roles ?? ['OPERATIONS'],
    exp:   overrides.exp   ?? now + 900,
    iat:   now,
  };
  const header  = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body    = btoa(JSON.stringify(payload));
  return `${header}.${body}.fake-sig`;
}

// ─────────────────────────────────────────────────────────────────────────────

describe('AuthService', () => {
  let service: AuthService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    localStorage.clear();
    sessionStorage.clear();

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AuthService],
    });

    service  = TestBed.inject(AuthService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
    localStorage.clear();
    sessionStorage.clear();
  });

  // ─── Test 1: Happy Path Login ───────────────────────────────────────────────

  it('should decode token correctly and NOT store it in localStorage or sessionStorage', fakeAsync(() => {
    const token = buildFakeJwt({ exp: Math.floor(Date.now() / 1000) + 900 });
    let result: any;

    service.login({ username: 'ops@bank.in', password: 'Ops@123' }).subscribe({
      next: (v) => (result = v),
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/login`);
    expect(req.request.method).toBe('POST');
    expect(req.request.withCredentials).toBeTrue();

    req.flush({ accessToken: token, expiresIn: 900 });
    tick();

    // ✅ Returns user + token
    expect(result.token).toBe(token);
    expect(result.user.email).toBe('ops@bank.in');
    expect(result.user.roles).toContain('OPERATIONS');

    // ✅ SECURITY: Token MUST NOT be in any web storage
    expect(localStorage.getItem('jwt_token')).toBeNull();
    expect(sessionStorage.getItem('jwt_token')).toBeNull();
    expect(localStorage.length).toBe(0);
    expect(sessionStorage.length).toBe(0);
  }));

  // ─── Test 2: Login Failure ──────────────────────────────────────────────────

  it('should propagate error on 401 and return no token', fakeAsync(() => {
    let error: any;
    let result: any;

    service.login({ username: 'bad@bank.in', password: 'wrong' }).subscribe({
      next: (v) => (result = v),
      error: (e) => (error = e),
    });

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/login`);
    req.flush(
      { message: 'Invalid credentials' },
      { status: 401, statusText: 'Unauthorized' }
    );
    tick();

    expect(error).toBeDefined();
    expect(result).toBeUndefined(); // No success emission
    expect(localStorage.length).toBe(0); // Nothing stored
  }));

  // ─── Test 3: Token Decode ───────────────────────────────────────────────────

  it('should decode JWT payload correctly', () => {
    const exp = Math.floor(Date.now() / 1000) + 300;
    const token = buildFakeJwt({ sub: 'u-999', roles: ['ADMIN', 'COMPLIANCE'], exp });
    const payload = service.decodeToken(token);

    expect(payload).toBeTruthy();
    expect(payload!.sub).toBe('u-999');
    expect(payload!.roles).toContain('ADMIN');
    expect(payload!.exp).toBe(exp);
  });

  it('should return null for malformed JWT', () => {
    expect(service.decodeToken('not.a.jwt.at.all')).toBeNull();
    expect(service.decodeToken('')).toBeNull();
    expect(service.decodeToken('only-one-part')).toBeNull();
  });

  // ─── Test 4: Refresh Token ──────────────────────────────────────────────────

  it('should return new user + token on successful refresh', fakeAsync(() => {
    const newToken = buildFakeJwt({ exp: Math.floor(Date.now() / 1000) + 1800 });
    let result: any;

    service.refreshAccessToken().subscribe({ next: (v) => (result = v) });

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/refresh`);
    expect(req.request.withCredentials).toBeTrue();
    req.flush({ accessToken: newToken, expiresIn: 1800 });
    tick();

    expect(result.token).toBe(newToken);
    expect(result.user).toBeTruthy();
    expect(localStorage.length).toBe(0); // Still not in storage
  }));

  // ─── Test 5: Logout ─────────────────────────────────────────────────────────

  it('should call POST /auth/logout with credentials', fakeAsync(() => {
    let completed = false;

    service.logout().subscribe({ complete: () => (completed = true) });

    const req = httpMock.expectOne(`${environment.apiUrl}/auth/logout`);
    expect(req.request.method).toBe('POST');
    expect(req.request.withCredentials).toBeTrue();
    req.flush({});
    tick();

    expect(completed).toBeTrue();
  }));
});
