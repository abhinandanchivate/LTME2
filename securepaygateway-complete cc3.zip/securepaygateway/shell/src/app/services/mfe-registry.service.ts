import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of, shareReplay, tap } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

export interface RemoteConfig { remoteEntry: string; exposedModule: string; }
export type MfeRegistryMap = Record<string, RemoteConfig>;

@Injectable({ providedIn: 'root' })
export class MfeRegistryService {
  private readonly http = inject(HttpClient);

  private readonly fallback: MfeRegistryMap = {
    paymentsMfe: { remoteEntry: environment.remotes.paymentsMfe, exposedModule: './TransactionRoutes' },
    reportsMfe:  { remoteEntry: environment.remotes.reportsMfe,  exposedModule: './ReportRoutes' },
  };

  readonly registry$: Observable<MfeRegistryMap> = this.http
    .get<MfeRegistryMap>(`${environment.apiUrl}/mfe-registry`)
    .pipe(
      tap((r) => console.log('[MFE Registry] Loaded:', r)),
      catchError((err) => {
        console.warn('[MFE Registry] Fetch failed — using defaults:', err?.message);
        return of(this.fallback);
      }),
      shareReplay({ bufferSize: 1, refCount: false })
    );

  fetchRegistry(): Observable<MfeRegistryMap> { return this.registry$; }

  getRemoteConfig(mfeName: string): Observable<RemoteConfig | null> {
    return this.registry$.pipe(map((r) => r[mfeName] ?? this.fallback[mfeName] ?? null));
  }
}
