import { inject } from '@angular/core';
import { CanActivateFn, Router, ActivatedRouteSnapshot } from '@angular/router';
import { Store } from '@ngrx/store';
import { map, take } from 'rxjs';
import { selectIsAuthenticated, selectUserRoles } from '../store/auth/auth.selectors';

export const authGuard: CanActivateFn = () => {
  const store  = inject(Store);
  const router = inject(Router);

  return store.select(selectIsAuthenticated).pipe(
    take(1),
    map((isAuthenticated) => isAuthenticated ? true : router.createUrlTree(['/login']))
  );
};

export const roleGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => {
  const store  = inject(Store);
  const router = inject(Router);
  const requiredRoles: string[] = route.data['roles'] ?? [];

  return store.select(selectUserRoles).pipe(
    take(1),
    map((userRoles) => {
      const hasRole = requiredRoles.length === 0 || requiredRoles.some((r) => userRoles.includes(r as any));
      return hasRole ? true : router.createUrlTree(['/unauthorized']);
    })
  );
};
