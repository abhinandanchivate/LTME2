// shell/src/app/components/dashboard/dashboard.component.ts
import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { selectCurrentUser, selectUserRoles } from '../../store/auth/auth.selectors';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="dashboard">
      <h1 class="page-title">
        Welcome back, {{ (user$ | async)?.email?.split('@')[0] | titlecase }} 👋
      </h1>
      <p class="page-subtitle">
        Roles: <span *ngFor="let role of roles$ | async" class="role-badge">{{ role }}</span>
      </p>

      <div class="cards">
        <a routerLink="/transactions" class="card card--blue">
          <div class="card-icon">💳</div>
          <h3>Transactions</h3>
          <p>View and manage payment transactions</p>
          <span class="card-arrow">→</span>
        </a>
        <a routerLink="/reports" class="card card--green">
          <div class="card-icon">📈</div>
          <h3>Reports</h3>
          <p>Analyse account performance and volumes</p>
          <span class="card-arrow">→</span>
        </a>
      </div>
    </div>
  `,
  styles: [`
    .dashboard { max-width: 900px; }
    .page-title { font-size: 26px; font-weight: 700; color: #1e3a5f; margin: 0 0 8px; }
    .page-subtitle { color: #6b7280; margin: 0 0 32px; display: flex; align-items: center; gap: 8px; }
    .role-badge {
      background: #dbeafe; color: #1d4ed8;
      font-size: 12px; font-weight: 600;
      padding: 2px 8px; border-radius: 99px;
    }
    .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 20px; }
    .card {
      position: relative;
      padding: 28px;
      border-radius: 12px;
      text-decoration: none;
      color: white;
      display: flex;
      flex-direction: column;
      gap: 8px;
      transition: transform 0.2s, box-shadow 0.2s;
    }
    .card:hover { transform: translateY(-3px); box-shadow: 0 8px 30px rgba(0,0,0,0.15); }
    .card--blue  { background: linear-gradient(135deg, #1e3a5f, #2563eb); }
    .card--green { background: linear-gradient(135deg, #065f46, #059669); }
    .card-icon { font-size: 32px; }
    .card h3 { margin: 0; font-size: 18px; font-weight: 700; }
    .card p  { margin: 0; opacity: 0.85; font-size: 14px; }
    .card-arrow {
      position: absolute; right: 24px; top: 50%;
      transform: translateY(-50%);
      font-size: 24px; opacity: 0.5;
    }
  `],
})
export class DashboardComponent {
  private store = inject(Store);
  user$  = this.store.select(selectCurrentUser);
  roles$ = this.store.select(selectUserRoles);
}
