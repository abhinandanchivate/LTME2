// shell/src/app/components/unauthorized/unauthorized.component.ts
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-unauthorized',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 60vh; gap: 16px; font-family: system-ui, sans-serif;">
      <div style="font-size: 64px;">🔒</div>
      <h2 style="margin: 0; color: #1e3a5f;">Access Denied</h2>
      <p style="color: #6b7280; margin: 0;">You don't have permission to view this page.</p>
      <a routerLink="/dashboard" style="padding: 10px 24px; background: #1e3a5f; color: white; text-decoration: none; border-radius: 8px;">
        Back to Dashboard
      </a>
    </div>
  `,
})
export class UnauthorizedComponent {}
