import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { AuthActions } from '../../store/auth/auth.actions';
import { selectAuthLoading, selectAuthError } from '../../store/auth/auth.selectors';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="login-page">
      <div class="login-card">
        <div class="login-header">
          <div class="logo">🏦</div>
          <h1>SecurePayment Gateway</h1>
          <p>Sign in to continue</p>
        </div>

        <form [formGroup]="form" (ngSubmit)="onSubmit()" class="login-form">
          <div class="field">
            <label for="username">Email</label>
            <input id="username" type="email" formControlName="username"
              placeholder="ops&#64;bank.in" autocomplete="username" />
            <span class="field-error"
              *ngIf="form.get('username')?.touched && form.get('username')?.invalid">
              Valid email required
            </span>
          </div>

          <div class="field">
            <label for="password">Password</label>
            <input id="password" type="password" formControlName="password"
              placeholder="••••••••" autocomplete="current-password" />
            <span class="field-error"
              *ngIf="form.get('password')?.touched && form.get('password')?.invalid">
              Password required
            </span>
          </div>

          <div class="error-banner" *ngIf="error$ | async as error">{{ error }}</div>

          <button type="submit" class="login-btn"
            [disabled]="form.invalid || (loading$ | async)">
            {{ (loading$ | async) ? 'Signing in...' : 'Sign In' }}
          </button>
        </form>

        <p class="demo-hint">Demo: <code>ops&#64;bank.in / Ops&#64;123</code></p>
      </div>
    </div>
  `,
  styles: [`
    .login-page { min-height:100vh; display:flex; align-items:center; justify-content:center; background:linear-gradient(135deg,#1e3a5f,#2563eb); padding:24px; }
    .login-card { background:white; border-radius:16px; padding:48px; width:100%; max-width:400px; box-shadow:0 20px 60px rgba(0,0,0,.3); }
    .login-header { text-align:center; margin-bottom:32px; }
    .logo { font-size:48px; }
    h1 { font-size:22px; font-weight:700; color:#1e3a5f; margin:8px 0 4px; }
    p  { color:#6b7280; font-size:14px; margin:0; }
    .login-form { display:flex; flex-direction:column; gap:16px; }
    .field { display:flex; flex-direction:column; gap:4px; }
    label { font-size:13px; font-weight:600; color:#374151; }
    input { padding:10px 14px; border:1px solid #d1d5db; border-radius:8px; font-size:14px; outline:none; }
    input:focus { border-color:#2563eb; box-shadow:0 0 0 3px rgba(37,99,235,.1); }
    .field-error { font-size:12px; color:#dc2626; }
    .error-banner { padding:10px 14px; background:#fee2e2; color:#991b1b; border-radius:8px; font-size:13px; }
    .login-btn { padding:12px; background:#1e3a5f; color:white; border:none; border-radius:8px; font-size:15px; font-weight:600; cursor:pointer; }
    .login-btn:hover:not(:disabled) { background:#2563eb; }
    .login-btn:disabled { opacity:.6; cursor:not-allowed; }
    .demo-hint { margin-top:20px; text-align:center; font-size:12px; color:#9ca3af; }
    code { background:#f3f4f6; padding:2px 6px; border-radius:4px; font-family:monospace; }
  `],
})
export class LoginComponent {
  private readonly store = inject(Store);
  private readonly fb    = inject(FormBuilder);

  loading$ = this.store.select(selectAuthLoading);
  error$   = this.store.select(selectAuthError);

  form = this.fb.group({
    username: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });

  onSubmit() {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    const { username, password } = this.form.getRawValue();
    this.store.dispatch(AuthActions.login({
      credentials: { username: username!, password: password! },
    }));
  }
}
