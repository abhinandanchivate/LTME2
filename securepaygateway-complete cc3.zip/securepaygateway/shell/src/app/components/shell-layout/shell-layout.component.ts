import { Component, ChangeDetectionStrategy, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { Store } from '@ngrx/store';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { selectCurrentUser } from '../../store/auth/auth.selectors';
import { selectSidebarOpen, selectTheme, selectNotifications, UiActions } from '../../store/ui/ui.state';
import { AuthActions } from '../../store/auth/auth.actions';
import { MfeEventBusService } from '../../../../../shared/src/mfe-event-bus.service';

@Component({
  selector: 'app-shell-layout',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="shell-layout" [attr.data-theme]="theme$ | async">
      <nav class="navbar">
        <div class="navbar-left">
          <button class="menu-btn" (click)="toggleSidebar()">☰</button>
          <span class="brand">SecurePayment Gateway</span>
        </div>
        <div class="navbar-right">
          <button class="theme-btn" (click)="toggleTheme()">
            {{ (theme$ | async) === 'dark' ? '☀️' : '🌙' }}
          </button>
          <span class="user-email">{{ (user$ | async)?.email }}</span>
          <button class="logout-btn" (click)="logout()">Logout</button>
        </div>
      </nav>

      <div class="notifications" *ngIf="(notifications$ | async)?.length">
        <div
          *ngFor="let n of notifications$ | async"
          class="notification"
          [class]="'notification--' + n.type"
        >
          {{ n.message }}
          <button class="notification-close" (click)="dismissNotification(n.id)">✕</button>
        </div>
      </div>

      <div class="content-area">
        <aside class="sidebar" [class.sidebar--collapsed]="!(sidebarOpen$ | async)">
          <nav class="sidebar-nav">
            <a routerLink="/dashboard"    routerLinkActive="active" class="nav-item">
              <span class="nav-icon">📊</span><span class="nav-label">Dashboard</span>
            </a>
            <a routerLink="/transactions" routerLinkActive="active" class="nav-item">
              <span class="nav-icon">💳</span><span class="nav-label">Transactions</span>
            </a>
            <a routerLink="/reports"      routerLinkActive="active" class="nav-item">
              <span class="nav-icon">📈</span><span class="nav-label">Reports</span>
            </a>
          </nav>
        </aside>
        <main class="main-content">
          <router-outlet />
        </main>
      </div>
    </div>
  `,
  styles: [`
    .shell-layout { display:flex; flex-direction:column; height:100vh; background:#f8fafc; font-family:'Segoe UI',system-ui,sans-serif; }
    .navbar { display:flex; align-items:center; justify-content:space-between; height:56px; background:#1e3a5f; color:white; padding:0 16px; box-shadow:0 2px 8px rgba(0,0,0,.2); z-index:100; }
    .navbar-left,.navbar-right { display:flex; align-items:center; gap:12px; }
    .brand { font-size:18px; font-weight:700; }
    .menu-btn,.theme-btn,.logout-btn { background:none; border:1px solid rgba(255,255,255,.3); color:white; border-radius:6px; padding:4px 10px; cursor:pointer; font-size:14px; }
    .logout-btn { background:#dc2626; border-color:#dc2626; }
    .user-email { font-size:13px; opacity:.85; }
    .notifications { position:fixed; top:64px; right:16px; z-index:200; display:flex; flex-direction:column; gap:8px; }
    .notification { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:12px 16px; border-radius:8px; font-size:14px; min-width:300px; box-shadow:0 4px 12px rgba(0,0,0,.15); }
    .notification--success { background:#dcfce7; color:#166534; }
    .notification--error   { background:#fee2e2; color:#991b1b; }
    .notification--info    { background:#dbeafe; color:#1e40af; }
    .notification--warning { background:#fef9c3; color:#854d0e; }
    .notification-close { background:none; border:none; cursor:pointer; font-size:12px; opacity:.6; padding:0; }
    .content-area { display:flex; flex:1; overflow:hidden; }
    .sidebar { width:220px; background:#1e3a5f; transition:width .3s; overflow:hidden; flex-shrink:0; }
    .sidebar--collapsed { width:56px; }
    .sidebar-nav { display:flex; flex-direction:column; padding:16px 0; }
    .nav-item { display:flex; align-items:center; gap:12px; padding:12px 16px; color:rgba(255,255,255,.75); text-decoration:none; transition:background .2s; white-space:nowrap; font-size:14px; font-weight:500; }
    .nav-item:hover,.nav-item.active { background:rgba(255,255,255,.15); color:white; }
    .nav-item.active { border-right:3px solid #60a5fa; }
    .nav-icon { font-size:18px; min-width:24px; text-align:center; }
    .main-content { flex:1; overflow-y:auto; padding:24px; }
  `],
})
export class ShellLayoutComponent implements OnInit {
  private readonly store    = inject(Store);
  private readonly eventBus = inject(MfeEventBusService);

  user$          = this.store.select(selectCurrentUser);
  theme$         = this.store.select(selectTheme);
  sidebarOpen$   = this.store.select(selectSidebarOpen);
  notifications$ = this.store.select(selectNotifications);

  private currentTheme: 'light' | 'dark' = 'light';

  ngOnInit() {
    this.store.select(selectTheme)
      .pipe(takeUntilDestroyed())
      .subscribe((t) => (this.currentTheme = t));

    this.eventBus.on('THEME_CHANGED')
      .pipe(takeUntilDestroyed())
      .subscribe(({ theme }) => this.store.dispatch(UiActions.setTheme({ theme })));

    this.eventBus.on('USER_LOGGED_OUT')
      .pipe(takeUntilDestroyed())
      .subscribe(() => this.store.dispatch(AuthActions.logout()));
  }

  toggleSidebar() { this.store.dispatch(UiActions.toggleSidebar()); }

  toggleTheme() {
    const next = this.currentTheme === 'light' ? 'dark' : 'light';
    this.store.dispatch(UiActions.setTheme({ theme: next }));
    this.eventBus.emit({ type: 'THEME_CHANGED', payload: { theme: next } });
  }

  logout() { this.store.dispatch(AuthActions.logout()); }

  dismissNotification(id: string) {
    this.store.dispatch(UiActions.dismissNotification({ id }));
  }
}
