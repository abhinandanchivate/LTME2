// shell/src/app/app.integration.spec.ts
import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterTestingHarness } from '@angular/router/testing';
import { Component } from '@angular/core';
import { provideMockStore } from '@ngrx/store/testing';
import * as federation from '@angular-architects/module-federation';
import { AppComponent } from './app.component';
import { APP_ROUTES } from './app.routes';
import { MfeEventBusService } from '../../shared/src/mfe-event-bus.service';

// ─── Mock MFE Components ──────────────────────────────────────────────────────

@Component({
  selector: 'app-mock-transaction-list',
  standalone: true,
  template: `<div class="payments-mfe">Mock Payments MFE Loaded</div>`,
})
class MockTransactionListComponent {}

@Component({
  selector: 'app-mock-report-dashboard',
  standalone: true,
  template: `<div class="reports-mfe">Mock Reports MFE Loaded</div>`,
})
class MockReportDashboardComponent {}

// ─────────────────────────────────────────────────────────────────────────────

describe('Shell MFE Integration', () => {
  let harness: RouterTestingHarness;
  let eventBus: MfeEventBusService;

  const initialState = {
    auth: {
      user: { id: 'u1', email: 'ops@bank.in', roles: ['OPERATIONS'], expiresAt: new Date(Date.now() + 900_000) },
      token: 'fake-jwt',
      isLoading: false,
      isRefreshing: false,
      error: null,
    },
    ui: { sidebarOpen: true, theme: 'light', notifications: [] },
    mfeRegistry: { registry: {}, loaded: false, loading: false, error: null },
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(APP_ROUTES),
        AppComponent,
      ],
      providers: [
        provideMockStore({ initialState }),
        MfeEventBusService,
      ],
    }).compileComponents();

    harness  = await RouterTestingHarness.create();
    eventBus = TestBed.inject(MfeEventBusService);
  });

  // ─── Test 1: Payments MFE loads ────────────────────────────────────────────

  it('should load Payments MFE routes on /transactions navigation', fakeAsync(async () => {
    // ✅ Mock loadRemoteModule — no real HTTP to remoteEntry.js
    spyOn(federation, 'loadRemoteModule').and.resolveTo({
      TRANSACTION_ROUTES: [
        { path: '', component: MockTransactionListComponent },
      ],
    });

    await harness.navigateByUrl('/transactions');
    tick(500); // resolve lazy routes + MFE load

    const element = harness.routeNativeElement;
    expect(element?.querySelector('.payments-mfe')).toBeTruthy();
    expect(element?.textContent).toContain('Mock Payments MFE Loaded');
    expect(federation.loadRemoteModule).toHaveBeenCalledWith(
      jasmine.objectContaining({ exposedModule: './TransactionRoutes' })
    );
  }));

  // ─── Test 2: Error boundary when remote fails ───────────────────────────────

  it('should show error boundary when remote fails to load', fakeAsync(async () => {
    spyOn(federation, 'loadRemoteModule').and.rejectWith(
      new Error('net::ERR_CONNECTION_REFUSED')
    );

    await harness.navigateByUrl('/transactions');
    tick(500);

    const element = harness.routeNativeElement;
    // ✅ Error boundary shown — NOT a white screen
    expect(element?.querySelector('.error-boundary')).toBeTruthy();
    expect(element?.textContent).toContain('Service Temporarily Unavailable');
  }));

  // ─── Test 3: EventBus delivers ACCOUNT_SELECTED ────────────────────────────

  it('should deliver ACCOUNT_SELECTED event to all subscribers', fakeAsync(() => {
    let received: any;
    eventBus.on('ACCOUNT_SELECTED').subscribe((p) => (received = p));

    eventBus.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId: 'ACC-001', accountName: 'HDFC Current A/c', accountType: 'CURRENT' },
    });
    tick();

    expect(received).toEqual({
      accountId: 'ACC-001',
      accountName: 'HDFC Current A/c',
      accountType: 'CURRENT',
    });
  }));

  // ─── Test 4: ReplaySubject(1) — late subscriber gets last event ─────────────

  it('should deliver last ACCOUNT_SELECTED to late subscriber (ReplaySubject)', fakeAsync(() => {
    // Emit FIRST
    eventBus.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId: 'ACC-003', accountName: 'SBI Corporate', accountType: 'CURRENT' },
    });
    tick();

    // Subscribe AFTER (simulates Reports MFE loading after user clicked account)
    let received: any;
    eventBus.on('ACCOUNT_SELECTED').subscribe((p) => (received = p));
    tick();

    expect(received).toEqual({
      accountId: 'ACC-003',
      accountName: 'SBI Corporate',
      accountType: 'CURRENT',
    });
  }));
});
