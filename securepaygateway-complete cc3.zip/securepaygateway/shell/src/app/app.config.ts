// shell/src/app/app.config.ts
import {
  ApplicationConfig,
  APP_INITIALIZER,
  ErrorHandler,
  isDevMode,
} from '@angular/core';
import {
  provideRouter,
  withComponentInputBinding,
  withViewTransitions,
} from '@angular/router';
import {
  provideHttpClient,
  withInterceptors,
} from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideStore } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { provideStoreDevtools } from '@ngrx/store-devtools';
import { firstValueFrom } from 'rxjs';

import { APP_ROUTES } from './app.routes';
import { authInterceptor, secureHttpInterceptor } from './interceptors/auth.interceptor';
import { SecurePaymentErrorHandler } from './handlers/global-error-handler';
import { MfeRegistryService } from './services/mfe-registry.service';
import { AuthEffects } from './store/auth/auth.effects';
import { MfeRegistryEffects } from './store/mfe-registry/mfe-registry.effects';
import { authReducer } from './store/auth/auth.reducer';
import { uiReducer } from './store/ui/ui.state';
import { mfeRegistryReducer, MfeRegistryActions } from './store/mfe-registry/mfe-registry.state';
import { Store } from '@ngrx/store';

// ─── APP_INITIALIZER: Pre-load MFE Registry ──────────────────────────────────

function preloadMfeRegistry(registryService: MfeRegistryService) {
  return async () => {
    console.log('[MFE Registry] Pre-loading registry at startup...');
    try {
      const registry = await firstValueFrom(registryService.registry$);
      console.log('[MFE Registry] Registry pre-loaded:', Object.keys(registry));
    } catch (err) {
      console.warn('[MFE Registry] Pre-load failed — falling back to environment defaults');
    }
  };
}

// ─── App Config ───────────────────────────────────────────────────────────────

export const appConfig: ApplicationConfig = {
  providers: [
    // ─── Router ──────────────────────────────────────────────────────────────
    provideRouter(
      APP_ROUTES,
      withComponentInputBinding(),
      withViewTransitions()
    ),

    // ─── HTTP ─────────────────────────────────────────────────────────────────
    provideHttpClient(
      withInterceptors([secureHttpInterceptor, authInterceptor])
    ),

    // ─── Animations ───────────────────────────────────────────────────────────
    provideAnimationsAsync(),

    // ─── NgRx Store ───────────────────────────────────────────────────────────
    // All reducers registered here in the shell.
    // MFEs access the SAME store because @ngrx/store is singleton via Module Federation.
    provideStore({
      auth: authReducer,
      ui: uiReducer,
      mfeRegistry: mfeRegistryReducer,
    }),

    // ─── NgRx Effects ─────────────────────────────────────────────────────────
    provideEffects([AuthEffects, MfeRegistryEffects]),

    // ─── NgRx DevTools (dev only) ─────────────────────────────────────────────
    provideStoreDevtools({
      maxAge: 25,
      logOnly: !isDevMode(),
      autoPause: true,
      trace: false,
      traceLimit: 75,
    }),

    // ─── Global Error Handler ────────────────────────────────────────────────
    { provide: ErrorHandler, useClass: SecurePaymentErrorHandler },

    // ─── APP_INITIALIZER: fetch MFE registry before routing ──────────────────
    {
      provide: APP_INITIALIZER,
      useFactory: preloadMfeRegistry,
      deps: [MfeRegistryService],
      multi: true,
    },
  ],
};
