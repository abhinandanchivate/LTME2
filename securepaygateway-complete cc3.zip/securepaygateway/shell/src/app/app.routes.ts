// shell/src/app/app.routes.ts
import { Routes } from '@angular/router';
import { loadRemoteModule } from '@angular-architects/module-federation';
import { Component } from '@angular/core';
import { authGuard } from './guards/auth.guard';
import { environment } from '../environments/environment';

// ─── Error Boundary Component ─────────────────────────────────────────────────

@Component({
  standalone: true,
  selector: 'app-mfe-error-boundary',
  template: `
    <div class="error-boundary" style="
      display: flex; flex-direction: column; align-items: center;
      justify-content: center; height: 50vh; gap: 16px;
      font-family: system-ui, sans-serif; color: #374151;
    ">
      <div style="font-size: 48px;">⚠️</div>
      <h2 style="margin: 0; font-size: 20px; font-weight: 600;">
        Service Temporarily Unavailable
      </h2>
      <p style="margin: 0; color: #6B7280;">
        The module is currently unavailable. Please try again shortly.
      </p>
      <button
        onclick="location.reload()"
        style="
          padding: 8px 24px; background: #1d4ed8; color: white;
          border: none; border-radius: 6px; cursor: pointer; font-size: 14px;
        "
      >
        Retry
      </button>
    </div>
  `,
})
export class MfeErrorBoundaryComponent {}

// ─── Safe Remote Loader ───────────────────────────────────────────────────────

/**
 * Wraps loadRemoteModule in a try/catch.
 * On failure: returns a module with error boundary routes instead of crashing.
 *
 * @param remoteName  Logical name for logging (e.g. 'paymentsMfe')
 * @param remoteEntry Full URL to remoteEntry.js
 * @param exposedModule The exposed key (e.g. './TransactionRoutes')
 */
async function loadRemoteSafely(
  remoteName: string,
  remoteEntry: string,
  exposedModule: string
): Promise<any> {
  try {
    console.log(`[Shell] Loading remote: ${remoteName} from ${remoteEntry}`);
    const module = await loadRemoteModule({ type: 'module', remoteEntry, exposedModule });
    console.log(`[Shell] Remote loaded successfully: ${remoteName}`);
    return module;
  } catch (err) {
    console.error(
      `[Shell] Failed to load remote ${remoteName} — showing error boundary`,
      err
    );
    return {
      TRANSACTION_ROUTES: [{ path: '**', component: MfeErrorBoundaryComponent }],
      REPORT_ROUTES: [{ path: '**', component: MfeErrorBoundaryComponent }],
    };
  }
}

// ─── App Routes ───────────────────────────────────────────────────────────────

export const APP_ROUTES: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  },

  // Public routes
  {
    path: 'login',
    loadComponent: () =>
      import('./components/login/login.component').then((m) => m.LoginComponent),
  },
  {
    path: 'unauthorized',
    loadComponent: () =>
      import('./components/unauthorized/unauthorized.component').then(
        (m) => m.UnauthorizedComponent
      ),
  },

  // Protected routes (require authentication)
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./components/shell-layout/shell-layout.component').then(
        (m) => m.ShellLayoutComponent
      ),
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./components/dashboard/dashboard.component').then(
            (m) => m.DashboardComponent
          ),
      },

      // ✅ Payments MFE — loaded from remote at runtime
      {
        path: 'transactions',
        loadChildren: () =>
          loadRemoteSafely(
            'paymentsMfe',
            environment.remotes.paymentsMfe,
            './TransactionRoutes'
          ).then((m: any) => m.TRANSACTION_ROUTES),
        data: { roles: ['ADMIN', 'OPERATIONS'] },
      },

      // ✅ Reports MFE — loaded from remote at runtime
      {
        path: 'reports',
        loadChildren: () =>
          loadRemoteSafely(
            'reportsMfe',
            environment.remotes.reportsMfe,
            './ReportRoutes'
          ).then((m: any) => m.REPORT_ROUTES),
        data: { roles: ['ADMIN', 'OPERATIONS', 'COMPLIANCE'] },
      },
    ],
  },

  { path: '**', redirectTo: 'dashboard' },
];
