// shell/src/app/interceptors/auth.interceptor.ts
import { HttpInterceptorFn, HttpRequest, HttpHandlerFn, HttpEvent } from '@angular/common/http';
import { inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, switchMap, take } from 'rxjs';
import { selectAccessToken } from '../store/auth/auth.selectors';

/**
 * Functional HTTP interceptor.
 * Reads the JWT from NgRx store (in-memory) and attaches it as Bearer token.
 * No localStorage reads anywhere in the app.
 */
export const authInterceptor: HttpInterceptorFn = (
  req: HttpRequest<unknown>,
  next: HttpHandlerFn
): Observable<HttpEvent<unknown>> => {
  const store = inject(Store);

  return store.select(selectAccessToken).pipe(
    take(1),
    switchMap((token) => {
      if (!token) {
        return next(req);
      }

      const authReq = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
          'X-Client-Version': '1.0.0',
          'X-Request-ID': crypto.randomUUID(),
        },
        withCredentials: true,
      });

      return next(authReq);
    })
  );
};

// ─── Security Interceptor ─────────────────────────────────────────────────────

// shell/src/app/interceptors/secure-http.interceptor.ts
export const secureHttpInterceptor: HttpInterceptorFn = (
  req: HttpRequest<unknown>,
  next: HttpHandlerFn
): Observable<HttpEvent<unknown>> => {
  // Block non-HTTPS in production
  if (req.url.startsWith('http://') && location.protocol === 'https:') {
    throw new Error(`[Security] Blocked non-HTTPS request to: ${req.url}`);
  }

  return next(req);
};
