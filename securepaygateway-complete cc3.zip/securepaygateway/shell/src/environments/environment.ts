// shell/src/environments/environment.ts — DEVELOPMENT
export const environment = {
  name: 'development' as const,
  production: false,
  apiUrl: 'http://localhost:8080',
  paymentGatewayUrl: 'https://test-pg.securepaygateway.in',
  devTools: true,
  logLevel: 'debug' as const,
  remotes: {
    paymentsMfe: 'http://localhost:4201/remoteEntry.js',
    reportsMfe:  'http://localhost:4202/remoteEntry.js',
  },
};
