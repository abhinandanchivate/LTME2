// shell/src/environments/environment.production.ts — PRODUCTION
export const environment = {
  name: 'production' as const,
  production: true,
  apiUrl: 'https://api.securepaygateway.in',
  paymentGatewayUrl: 'https://pg.securepaygateway.in',
  devTools: false,
  logLevel: 'error' as const,
  remotes: {
    paymentsMfe: 'https://payments.securepaygateway.in/remoteEntry.js',
    reportsMfe:  'https://reports.securepaygateway.in/remoteEntry.js',
  },
};
