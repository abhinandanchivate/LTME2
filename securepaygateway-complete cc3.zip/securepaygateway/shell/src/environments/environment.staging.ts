// shell/src/environments/environment.staging.ts — STAGING
export const environment = {
  name: 'staging' as const,
  production: false,
  apiUrl: 'https://staging-api.securepaygateway.in',
  paymentGatewayUrl: 'https://test-pg.securepaygateway.in',
  devTools: false,
  logLevel: 'warn' as const,
  remotes: {
    paymentsMfe: 'https://staging-payments.securepaygateway.in/remoteEntry.js',
    reportsMfe:  'https://staging-reports.securepaygateway.in/remoteEntry.js',
  },
};
