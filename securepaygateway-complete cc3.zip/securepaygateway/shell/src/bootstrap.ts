// shell/src/bootstrap.ts
import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';
import { environment } from './environments/environment';

async function bootstrap() {
  if (environment.production) {
    // ✅ Block Angular DevTools — prevent component tree inspection in production
    Object.defineProperty(window, 'ng', {
      get: () => {
        console.warn('[Security] Angular DevTools access blocked in production.');
        return undefined;
      },
      configurable: false,
      enumerable: false,
    });

    // ✅ Suppress non-error console output in production
    // Keep console.error for monitoring integrations
    console.log   = () => {};
    console.debug = () => {};
    console.info  = () => {};
    // console.warn is kept for critical warnings
  }

  await bootstrapApplication(AppComponent, appConfig);
}

bootstrap().catch((err) => {
  // ✅ Never expose bootstrap errors to end users in production
  if (!environment.production) {
    console.error('Bootstrap failed:', err);
  }
  // In production: send to monitoring
  // monitoringService.captureException(err);
});
