// shell/webpack.prod.config.js — Production Module Federation HOST
const {
  shareAll,
  withModuleFederationPlugin,
} = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  remotes: {
    paymentsMfe: 'paymentsMfe@https://payments.securepaygateway.in/remoteEntry.js',
    reportsMfe:  'reportsMfe@https://reports.securepaygateway.in/remoteEntry.js',
  },
  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: 'auto',
    }),
    '@ngrx/store':   { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/effects': { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/entity':  { singleton: true, strictVersion: true, requiredVersion: 'auto' },
  },
});
