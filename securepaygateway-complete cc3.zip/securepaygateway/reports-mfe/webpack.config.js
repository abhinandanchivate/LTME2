// reports-mfe/webpack.config.js — Module Federation REMOTE configuration
const {
  shareAll,
  withModuleFederationPlugin,
} = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  name: 'reportsMfe',

  // Fixed filename — shell knows exactly where to fetch it
  filename: 'remoteEntry.js',

  exposes: {
    './ReportRoutes': './src/app/reports/report.routes.ts',
  },

  shared: {
    ...shareAll({
      singleton: true,
      strictVersion: true,
      requiredVersion: 'auto',
    }),
    '@ngrx/store':   { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/effects': { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/entity':  { singleton: true, strictVersion: true, requiredVersion: 'auto' },
  },
});
