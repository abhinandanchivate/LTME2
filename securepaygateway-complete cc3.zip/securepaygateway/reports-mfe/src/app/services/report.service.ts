// reports-mfe/src/app/services/report.service.ts
import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import {
  ReportSummary,
  ChartDataPoint,
  TransactionVolumeChart,
} from '../../../../shared/src/models';

// ─── Mock Data ────────────────────────────────────────────────────────────────

const SUMMARIES: Record<string, ReportSummary> = {
  'ACC-001': {
    accountId: 'ACC-001',
    accountName: 'HDFC Current A/c',
    totalTransactions: 142,
    totalVolume: 28_500_000,
    currency: 'INR',
    successRate: 96.4,
    avgProcessingTime: 23,
    periodStart: '2024-04-14',
    periodEnd: '2024-05-14',
  },
  'ACC-002': {
    accountId: 'ACC-002',
    accountName: 'ICICI Savings',
    totalTransactions: 87,
    totalVolume: 4_250_000,
    currency: 'INR',
    successRate: 91.2,
    avgProcessingTime: 18,
    periodStart: '2024-04-14',
    periodEnd: '2024-05-14',
  },
  'ACC-003': {
    accountId: 'ACC-003',
    accountName: 'SBI Corporate A/c',
    totalTransactions: 214,
    totalVolume: 145_000_000,
    currency: 'INR',
    successRate: 98.1,
    avgProcessingTime: 31,
    periodStart: '2024-04-14',
    periodEnd: '2024-05-14',
  },
};

const ALL_ACCOUNTS_SUMMARY: ReportSummary = {
  accountId: 'ALL',
  accountName: 'All Accounts',
  totalTransactions: 443,
  totalVolume: 177_750_000,
  currency: 'INR',
  successRate: 95.3,
  avgProcessingTime: 24,
  periodStart: '2024-04-14',
  periodEnd: '2024-05-14',
};

function generateVolumeChart(accountId?: string): TransactionVolumeChart {
  const dates: string[] = [];
  const neft: number[] = [];
  const rtgs: number[] = [];
  const imps: number[] = [];

  const base = accountId === 'ACC-003' ? 5 : accountId === 'ACC-001' ? 3 : 1;

  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    dates.push(d.toISOString().slice(0, 10));
    neft.push(Math.floor(Math.random() * 8 * base) + 2);
    rtgs.push(Math.floor(Math.random() * 4 * base));
    imps.push(Math.floor(Math.random() * 6 * base) + 1);
  }

  return {
    dates,
    series: [
      { name: 'NEFT', data: neft, color: '#2563eb' },
      { name: 'RTGS', data: rtgs, color: '#7c3aed' },
      { name: 'IMPS', data: imps, color: '#059669' },
    ],
  };
}

function generateStatusBreakdown(accountId?: string): ChartDataPoint[] {
  const isGood = accountId === 'ACC-003';
  return [
    { label: 'Completed',  value: isGood ? 210 : 95,  color: '#22c55e' },
    { label: 'Processing', value: isGood ? 18  : 8,   color: '#3b82f6' },
    { label: 'Pending',    value: isGood ? 12  : 6,   color: '#f59e0b' },
    { label: 'Failed',     value: isGood ? 4   : 12,  color: '#ef4444' },
    { label: 'Reversed',   value: isGood ? 2   : 3,   color: '#8b5cf6' },
  ];
}

// ─────────────────────────────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' })
export class ReportService {
  getSummary(accountId?: string): Observable<ReportSummary> {
    const summary =
      accountId ? (SUMMARIES[accountId] ?? ALL_ACCOUNTS_SUMMARY) : ALL_ACCOUNTS_SUMMARY;
    return of(summary).pipe(delay(300));
  }

  getVolumeChart(accountId?: string, days = 30): Observable<TransactionVolumeChart> {
    return of(generateVolumeChart(accountId)).pipe(delay(400));
  }

  getStatusBreakdown(accountId?: string): Observable<ChartDataPoint[]> {
    return of(generateStatusBreakdown(accountId)).pipe(delay(250));
  }
}
