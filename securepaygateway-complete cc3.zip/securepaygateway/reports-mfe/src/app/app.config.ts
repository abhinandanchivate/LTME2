import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideState } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { STANDALONE_REPORT_ROUTES } from './reports/report.routes';
import { reportsReducer } from './store/reports.state';
import { ReportEffects } from './store/reports.effects';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(STANDALONE_REPORT_ROUTES),
    provideHttpClient(),
    provideAnimationsAsync(),
    provideState({ name: 'reports', reducer: reportsReducer }),
    provideEffects([ReportEffects]),
  ],
};
