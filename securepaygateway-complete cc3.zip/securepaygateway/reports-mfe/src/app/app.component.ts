// reports-mfe/src/app/app.component.ts
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <div style="padding: 24px; font-family: system-ui, sans-serif;">
      <div style="background: #065f46; color: white; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px;">
        📈 Reports MFE — Running Standalone on port 4202
      </div>
      <router-outlet />
    </div>
  `,
})
export class AppComponent {}
