// reports-mfe/src/app/reports/report-dashboard/report-dashboard.component.ts
import {
  Component,
  ChangeDetectionStrategy,
  inject,
  OnInit,
  signal,
  computed,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Store } from '@ngrx/store';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import {
  selectSelectedAccount,
  selectSummary,
  selectVolumeChart,
  selectStatusBreakdown,
  selectLoading,
} from '../../store/reports.state';
import { ReportActions } from '../../store/reports.state';
import { MfeEventBusService } from '../../../../../shared/src/mfe-event-bus.service';
import { ChartDataPoint, TransactionVolumeChart } from '../../../../../shared/src/models';

// ─── Inline Chart Component ───────────────────────────────────────────────────
// Pure SVG chart — no external charting library needed for the MFE

@Component({
  selector: 'app-bar-chart',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="bar-chart-wrap">
      <div class="chart-legend">
        <span *ngFor="let s of chart.series" class="legend-item">
          <span class="legend-dot" [style.background]="s.color"></span>
          {{ s.name }}
        </span>
      </div>
      <div class="bar-chart">
        <div
          *ngFor="let date of visibleDates; let i = index"
          class="bar-group"
        >
          <div class="bars">
            <div
              *ngFor="let series of chart.series"
              class="bar"
              [style.height.%]="(series.data[i + offset] / maxVal) * 100"
              [style.background]="series.color"
              [title]="series.name + ': ' + series.data[i + offset]"
            ></div>
          </div>
          <div class="bar-label">{{ date | slice:5 }}</div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .bar-chart-wrap { width: 100%; }
    .chart-legend { display: flex; gap: 16px; margin-bottom: 12px; flex-wrap: wrap; }
    .legend-item { display: flex; align-items: center; gap: 6px; font-size: 12px; color: #6b7280; }
    .legend-dot { width: 10px; height: 10px; border-radius: 50%; }
    .bar-chart {
      display: flex; gap: 2px; align-items: flex-end; height: 140px;
      overflow-x: auto; padding-bottom: 20px;
    }
    .bar-group {
      display: flex; flex-direction: column; align-items: center; gap: 4px;
      flex: 1; min-width: 24px; max-width: 40px;
    }
    .bars {
      display: flex; gap: 1px; align-items: flex-end; height: 120px; width: 100%;
    }
    .bar {
      flex: 1; border-radius: 2px 2px 0 0; min-height: 2px;
      transition: height 0.4s ease; cursor: pointer;
    }
    .bar:hover { opacity: 0.8; }
    .bar-label { font-size: 9px; color: #9ca3af; white-space: nowrap; }
  `],
  inputs: ['chart'],
})
export class BarChartComponent {
  chart!: TransactionVolumeChart;

  get offset() { return Math.max(0, this.chart.dates.length - 14); }
  get visibleDates() { return this.chart.dates.slice(this.offset); }
  get maxVal() {
    const vals = this.chart.series.flatMap((s) => s.data.slice(this.offset));
    return Math.max(...vals, 1);
  }
}

@Component({
  selector: 'app-donut-chart',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="donut-wrap">
      <svg viewBox="0 0 120 120" class="donut-svg">
        <g *ngFor="let seg of segments; let i = index">
          <circle
            r="40" cx="60" cy="60"
            fill="none"
            [attr.stroke]="seg.color"
            stroke-width="20"
            [attr.stroke-dasharray]="seg.dash"
            [attr.stroke-dashoffset]="seg.offset"
            transform="rotate(-90, 60, 60)"
          />
        </g>
        <text x="60" y="57" text-anchor="middle" font-size="14" font-weight="700" fill="#1e3a5f">
          {{ total }}
        </text>
        <text x="60" y="70" text-anchor="middle" font-size="8" fill="#9ca3af">total</text>
      </svg>
      <div class="donut-legend">
        <div *ngFor="let d of data" class="donut-item">
          <span class="donut-dot" [style.background]="d.color"></span>
          <span class="donut-label">{{ d.label }}</span>
          <span class="donut-val">{{ d.value }}</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .donut-wrap { display: flex; gap: 20px; align-items: center; flex-wrap: wrap; }
    .donut-svg { width: 120px; height: 120px; flex-shrink: 0; }
    .donut-legend { display: flex; flex-direction: column; gap: 6px; }
    .donut-item { display: flex; align-items: center; gap: 8px; font-size: 13px; }
    .donut-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
    .donut-label { color: #374151; flex: 1; }
    .donut-val { font-weight: 600; color: #1e3a5f; min-width: 28px; text-align: right; }
  `],
  inputs: ['data'],
})
export class DonutChartComponent {
  data!: ChartDataPoint[];

  get total() { return this.data?.reduce((s, d) => s + d.value, 0) ?? 0; }

  get segments() {
    const circumference = 2 * Math.PI * 40;
    let cumulative = 0;
    return (this.data ?? []).map((d) => {
      const pct = this.total ? d.value / this.total : 0;
      const dash = pct * circumference;
      const gap = circumference - dash;
      const offset = -cumulative * circumference;
      cumulative += pct;
      return { ...d, dash: `${dash} ${gap}`, offset };
    });
  }
}

// ─── Main Dashboard Component ─────────────────────────────────────────────────

@Component({
  selector: 'app-report-dashboard',
  standalone: true,
  imports: [CommonModule, BarChartComponent, DonutChartComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="reports-dashboard">

      <!-- Header -->
      <div class="reports-header">
        <div>
          <h2 class="page-title">Analytics Dashboard</h2>
          <!-- ✅ Auto-updates when ACCOUNT_SELECTED event is received from Payments MFE -->
          <p class="page-subtitle" *ngIf="selectedAccount$ | async as acct; else allAccounts">
            <span class="filter-tag">
              📊 Showing analytics for: <strong>{{ acct.accountName }}</strong>
              ({{ acct.accountType }})
              <button class="clear-btn" (click)="clearAccountFilter()">✕ Clear</button>
            </span>
          </p>
          <ng-template #allAccounts>
            <p class="page-subtitle">
              Showing data for <strong>all accounts</strong> — click an account in Transactions to filter
            </p>
          </ng-template>
        </div>
        <div class="date-range">Last 30 days</div>
      </div>

      <!-- Loading -->
      <div class="loading-overlay" *ngIf="loading$ | async">
        <div class="spinner"></div>
        <p>Loading analytics...</p>
      </div>

      <!-- Summary Cards -->
      <div class="summary-cards" *ngIf="summary$ | async as s">
        <div class="stat-card">
          <div class="stat-icon">💳</div>
          <div class="stat-body">
            <p class="stat-label">Total Transactions</p>
            <p class="stat-value">{{ s.totalTransactions | number }}</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">💰</div>
          <div class="stat-body">
            <p class="stat-label">Total Volume</p>
            <p class="stat-value">₹{{ s.totalVolume | number:'1.0-0' }}</p>
          </div>
        </div>
        <div class="stat-card" [class.stat-card--good]="s.successRate >= 95" [class.stat-card--warn]="s.successRate < 95">
          <div class="stat-icon">✅</div>
          <div class="stat-body">
            <p class="stat-label">Success Rate</p>
            <p class="stat-value">{{ s.successRate | number:'1.1-1' }}%</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">⚡</div>
          <div class="stat-body">
            <p class="stat-label">Avg Processing Time</p>
            <p class="stat-value">{{ s.avgProcessingTime }}s</p>
          </div>
        </div>
      </div>

      <!-- Charts Row -->
      <div class="charts-row">
        <!-- Volume Chart -->
        <div class="chart-card chart-card--wide">
          <h3 class="chart-title">Transaction Volume (Last 14 Days)</h3>
          <app-bar-chart
            *ngIf="volumeChart$ | async as chart"
            [chart]="chart"
          />
          <div class="chart-empty" *ngIf="!(volumeChart$ | async)">
            Loading chart data...
          </div>
        </div>

        <!-- Status Breakdown -->
        <div class="chart-card">
          <h3 class="chart-title">Status Breakdown</h3>
          <app-donut-chart
            *ngIf="(statusBreakdown$ | async)?.length"
            [data]="(statusBreakdown$ | async)!"
          />
          <div class="chart-empty" *ngIf="!(statusBreakdown$ | async)?.length">
            Loading...
          </div>
        </div>
      </div>

      <!-- Account Quick Stats -->
      <div class="quick-insights" *ngIf="selectedAccount$ | async as acct">
        <h3>Quick Insights for {{ acct.accountName }}</h3>
        <div class="insights-grid">
          <div class="insight">
            <span class="insight-icon">📈</span>
            <span>Volume trending <strong>{{ trendLabel }}</strong> vs last month</span>
          </div>
          <div class="insight">
            <span class="insight-icon">⚠️</span>
            <span>{{ failedCount }} failed transactions require review</span>
          </div>
          <div class="insight">
            <span class="insight-icon">🕐</span>
            <span>Peak transaction time: <strong>10:00–14:00 IST</strong></span>
          </div>
        </div>
      </div>

    </div>
  `,
  styles: [`
    .reports-dashboard { max-width: 1100px; }

    /* Header */
    .reports-header {
      display: flex; align-items: flex-start; justify-content: space-between;
      margin-bottom: 24px; flex-wrap: wrap; gap: 12px;
    }
    .page-title { font-size: 22px; font-weight: 700; color: #1e3a5f; margin: 0 0 6px; }
    .page-subtitle { margin: 0; font-size: 14px; color: #6b7280; }
    .filter-tag {
      display: inline-flex; align-items: center; gap: 8px;
      background: #dbeafe; color: #1e40af;
      padding: 4px 12px; border-radius: 99px; font-size: 13px;
    }
    .clear-btn {
      background: none; border: none; color: #1e40af;
      cursor: pointer; font-size: 12px; padding: 0; opacity: 0.7;
    }
    .clear-btn:hover { opacity: 1; }
    .date-range {
      background: #f3f4f6; padding: 6px 14px;
      border-radius: 8px; font-size: 13px; color: #6b7280;
      align-self: flex-start;
    }

    /* Loading */
    .loading-overlay {
      display: flex; flex-direction: column; align-items: center;
      padding: 40px; color: #6b7280;
    }
    .spinner {
      width: 32px; height: 32px; border: 3px solid #e5e7eb;
      border-top-color: #2563eb; border-radius: 50%;
      animation: spin 0.8s linear infinite; margin-bottom: 12px;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Summary Cards */
    .summary-cards {
      display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 16px; margin-bottom: 24px;
    }
    .stat-card {
      background: white; border-radius: 12px;
      padding: 20px; display: flex; gap: 16px; align-items: center;
      box-shadow: 0 1px 4px rgba(0,0,0,0.08);
      border-left: 4px solid #e5e7eb;
      transition: transform 0.2s;
    }
    .stat-card:hover { transform: translateY(-2px); }
    .stat-card--good { border-left-color: #22c55e; }
    .stat-card--warn { border-left-color: #f59e0b; }
    .stat-icon { font-size: 28px; }
    .stat-label { margin: 0 0 4px; font-size: 12px; color: #9ca3af; font-weight: 500; text-transform: uppercase; letter-spacing: 0.5px; }
    .stat-value { margin: 0; font-size: 22px; font-weight: 700; color: #1e3a5f; }

    /* Charts */
    .charts-row {
      display: grid; grid-template-columns: 2fr 1fr;
      gap: 20px; margin-bottom: 24px;
    }
    @media (max-width: 700px) { .charts-row { grid-template-columns: 1fr; } }
    .chart-card {
      background: white; border-radius: 12px;
      padding: 24px; box-shadow: 0 1px 4px rgba(0,0,0,0.08);
    }
    .chart-title { margin: 0 0 16px; font-size: 14px; font-weight: 600; color: #374151; }
    .chart-empty { color: #9ca3af; font-size: 14px; padding: 20px 0; }

    /* Insights */
    .quick-insights {
      background: white; border-radius: 12px;
      padding: 24px; box-shadow: 0 1px 4px rgba(0,0,0,0.08);
    }
    .quick-insights h3 { margin: 0 0 16px; font-size: 15px; font-weight: 600; color: #1e3a5f; }
    .insights-grid { display: flex; flex-direction: column; gap: 12px; }
    .insight {
      display: flex; gap: 12px; align-items: center;
      font-size: 14px; color: #374151;
      padding: 10px 14px; background: #f8fafc; border-radius: 8px;
    }
    .insight-icon { font-size: 18px; }
  `],
})
export class ReportDashboardComponent implements OnInit {
  private readonly store    = inject(Store);
  private readonly eventBus = inject(MfeEventBusService);

  selectedAccount$  = this.store.select(selectSelectedAccount);
  summary$          = this.store.select(selectSummary);
  volumeChart$      = this.store.select(selectVolumeChart);
  statusBreakdown$  = this.store.select(selectStatusBreakdown);
  loading$          = this.store.select(selectLoading);

  trendLabel = 'up 12%';
  failedCount = 4;

  ngOnInit() {
    // Load initial data (all accounts)
    this.store.dispatch(ReportActions.loadSummary({}));
    this.store.dispatch(ReportActions.loadVolumeChart({}));
    this.store.dispatch(ReportActions.loadStatusBreakdown({}));

    /**
     * ✅ CROSS-MFE COMMUNICATION:
     * The ReportEffects already listens to the EventBus.
     * This component-level subscription is for updating local UI hints.
     *
     * ReplaySubject(1): if user selected an account in Payments MFE
     * BEFORE navigating here, we still get that event immediately.
     */
    this.eventBus.on('ACCOUNT_SELECTED')
      .pipe(takeUntilDestroyed())
      .subscribe(({ accountId }) => {
        console.log(`[Reports] Received ACCOUNT_SELECTED for ${accountId} — store already updated via Effects`);
      });

    // Update insights when new transaction created
    this.eventBus.on('TRANSACTION_CREATED')
      .pipe(takeUntilDestroyed())
      .subscribe(() => {
        // Trigger a refresh to include the new transaction
        this.selectedAccount$.pipe().subscribe((acct) => {
          if (acct) {
            this.store.dispatch(ReportActions.loadSummary({ accountId: acct.accountId }));
          }
        }).unsubscribe();
      });
  }

  clearAccountFilter() {
    this.store.dispatch(ReportActions.clearSelectedAccount());
    this.store.dispatch(ReportActions.loadSummary({}));
    this.store.dispatch(ReportActions.loadVolumeChart({}));
    this.store.dispatch(ReportActions.loadStatusBreakdown({}));
  }
}
