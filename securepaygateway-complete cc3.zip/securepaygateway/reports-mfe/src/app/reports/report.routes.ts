// reports-mfe/src/app/reports/report.routes.ts
// ✅ Exposed via webpack: exposes: { './ReportRoutes': this file }
// Shell loads: loadRemoteModule(..., './ReportRoutes').then(m => m.REPORT_ROUTES)

import { Routes } from '@angular/router';

export const REPORT_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./report-dashboard/report-dashboard.component').then(
        (m) => m.ReportDashboardComponent
      ),
  },
];

// ─── Standalone Routes ────────────────────────────────────────────────────────
export const STANDALONE_REPORT_ROUTES: Routes = [
  {
    path: 'reports',
    children: REPORT_ROUTES,
  },
  {
    path: '',
    redirectTo: 'reports',
    pathMatch: 'full',
  },
];
