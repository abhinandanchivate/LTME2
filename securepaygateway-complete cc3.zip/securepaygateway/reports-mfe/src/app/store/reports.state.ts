// reports-mfe/src/app/store/reports.actions.ts
import { createActionGroup, emptyProps, props } from '@ngrx/store';
import { ReportSummary, ChartDataPoint, TransactionVolumeChart } from '../../../../shared/src/models';

export const ReportActions = createActionGroup({
  source: 'Reports',
  events: {
    // Account selection (driven by EventBus ACCOUNT_SELECTED)
    'Set Selected Account': props<{ accountId: string; accountName: string; accountType: string }>(),
    'Clear Selected Account': emptyProps(),

    // Summary
    'Load Summary':         props<{ accountId?: string }>(),
    'Load Summary Success': props<{ summary: ReportSummary }>(),
    'Load Summary Failure': props<{ error: string }>(),

    // Volume chart
    'Load Volume Chart':         props<{ accountId?: string; days?: number }>(),
    'Load Volume Chart Success': props<{ chart: TransactionVolumeChart }>(),
    'Load Volume Chart Failure': props<{ error: string }>(),

    // Status breakdown
    'Load Status Breakdown':         props<{ accountId?: string }>(),
    'Load Status Breakdown Success': props<{ data: ChartDataPoint[] }>(),
    'Load Status Breakdown Failure': props<{ error: string }>(),
  },
});

// ─────────────────────────────────────────────────────────────────────────────

// reports-mfe/src/app/store/reports.reducer.ts
import { createFeature, createReducer, on } from '@ngrx/store';

export interface SelectedAccount {
  accountId: string;
  accountName: string;
  accountType: string;
}

export interface ReportsState {
  selectedAccount: SelectedAccount | null;
  summary: ReportSummary | null;
  volumeChart: TransactionVolumeChart | null;
  statusBreakdown: ChartDataPoint[];
  loading: boolean;
  error: string | null;
}

const initialReportsState: ReportsState = {
  selectedAccount: null,
  summary: null,
  volumeChart: null,
  statusBreakdown: [],
  loading: false,
  error: null,
};

export const reportsFeature = createFeature({
  name: 'reports',
  reducer: createReducer(
    initialReportsState,

    on(ReportActions.setSelectedAccount, (state, { accountId, accountName, accountType }) => ({
      ...state,
      selectedAccount: { accountId, accountName, accountType },
    })),

    on(ReportActions.clearSelectedAccount, (state) => ({
      ...state,
      selectedAccount: null,
    })),

    on(ReportActions.loadSummary, (state) => ({
      ...state,
      loading: true,
      error: null,
    })),

    on(ReportActions.loadSummarySuccess, (state, { summary }) => ({
      ...state,
      summary,
      loading: false,
    })),

    on(ReportActions.loadSummaryFailure, (state, { error }) => ({
      ...state,
      loading: false,
      error,
    })),

    on(ReportActions.loadVolumeChartSuccess, (state, { chart }) => ({
      ...state,
      volumeChart: chart,
    })),

    on(ReportActions.loadStatusBreakdownSuccess, (state, { data }) => ({
      ...state,
      statusBreakdown: data,
    }))
  ),
});

export const {
  name: reportsFeatureName,
  reducer: reportsReducer,
  selectReportsState,
  selectSelectedAccount,
  selectSummary,
  selectVolumeChart,
  selectStatusBreakdown,
  selectLoading,
  selectError,
} = reportsFeature;
