// reports-mfe/src/app/store/reports.effects.ts
import { Injectable, inject } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap, tap } from 'rxjs';
import { ReportService } from '../services/report.service';
import { MfeEventBusService } from '../../../../shared/src/mfe-event-bus.service';
import { ReportActions } from './reports.state';

@Injectable()
export class ReportEffects {
  private actions$  = inject(Actions);
  private service   = inject(ReportService);
  private eventBus  = inject(MfeEventBusService);

  /**
   * ✅ KEY CROSS-MFE INTEGRATION:
   * Listens to the EventBus for ACCOUNT_SELECTED events from Payments MFE.
   *
   * ReplaySubject(1) guarantees:
   * - If the user selected an account BEFORE navigating to /reports,
   *   this effect still receives the last event immediately on subscription.
   * - Zero direct coupling between Payments MFE and Reports MFE.
   *
   * This effect runs forever (no takeUntil needed — NgRx manages lifecycle).
   */
  listenToAccountSelected$ = createEffect(() =>
    this.eventBus.on('ACCOUNT_SELECTED').pipe(
      tap(({ accountId, accountName }) => {
        console.log(`[Reports] Account selected event received — filtering for: ${accountId}`);
      }),
      map(({ accountId, accountName, accountType }) =>
        ReportActions.setSelectedAccount({ accountId, accountName, accountType })
      )
    )
  );

  /**
   * When an account is selected (from EventBus or directly), reload all report data.
   */
  loadDataOnAccountChange$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ReportActions.setSelectedAccount),
      switchMap(({ accountId }) => [
        ReportActions.loadSummary({ accountId }),
        ReportActions.loadVolumeChart({ accountId, days: 30 }),
        ReportActions.loadStatusBreakdown({ accountId }),
      ])
    )
  );

  loadSummary$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ReportActions.loadSummary),
      switchMap(({ accountId }) =>
        this.service.getSummary(accountId).pipe(
          map((summary) => ReportActions.loadSummarySuccess({ summary })),
          catchError((err) =>
            of(ReportActions.loadSummaryFailure({ error: err.message }))
          )
        )
      )
    )
  );

  loadVolumeChart$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ReportActions.loadVolumeChart),
      switchMap(({ accountId, days }) =>
        this.service.getVolumeChart(accountId, days).pipe(
          map((chart) => ReportActions.loadVolumeChartSuccess({ chart })),
          catchError((err) =>
            of(ReportActions.loadVolumeChartFailure({ error: err.message }))
          )
        )
      )
    )
  );

  loadStatusBreakdown$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ReportActions.loadStatusBreakdown),
      switchMap(({ accountId }) =>
        this.service.getStatusBreakdown(accountId).pipe(
          map((data) => ReportActions.loadStatusBreakdownSuccess({ data })),
          catchError((err) =>
            of(ReportActions.loadStatusBreakdownFailure({ error: err.message }))
          )
        )
      )
    )
  );
}
