// reports-mfe/src/app/app.routes.ts
export { STANDALONE_REPORT_ROUTES } from './reports/report.routes';
