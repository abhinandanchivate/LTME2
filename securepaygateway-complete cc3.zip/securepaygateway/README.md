# SecurePayment Gateway — Angular Day 3 Complete Implementation

## Architecture Overview

```
securepaygateway/
├── shell/              (port 4200) — Host MFE, NgRx global store
├── payments-mfe/       (port 4201) — Payments Remote MFE
├── reports-mfe/        (port 4202) — Reports Remote MFE
└── shared/             — Shared contracts, types, event bus
```

## Quick Start

```bash
# Install all dependencies
npm run install:all

# Start all three apps simultaneously
npm run start:all

# Or start individually
cd shell && npm start          # http://localhost:4200
cd payments-mfe && npm start   # http://localhost:4201
cd reports-mfe && npm start    # http://localhost:4202
```

## State Management (NgRx)

### Shell Store
- `auth` — JWT token, user roles, login/logout
- `mfe-registry` — Dynamic remote URLs loaded at startup
- `ui` — Theme, sidebar state, notifications

### Payments MFE Store
- `transactions` — Transaction list, filters, selected transaction
- Shares `auth` state from shell via singleton service

### Reports MFE Store
- `reports` — Chart data, selected account, date range
- Receives `ACCOUNT_SELECTED` events from EventBus → dispatches to store

## Cross-MFE Communication
- `MfeEventBusService` — ReplaySubject(1) based event bus, singleton in shell
- Events: `ACCOUNT_SELECTED`, `TRANSACTION_CREATED`, `THEME_CHANGED`
- Reports MFE auto-filters when Payments MFE emits `ACCOUNT_SELECTED`

## Security
- JWT stored in memory only (not localStorage/sessionStorage)
- Angular DevTools blocked in production
- CSP meta tag blocks unsafe-inline scripts
- Global ErrorHandler catches and sanitizes all errors
