// payments-mfe/webpack.config.js — Module Federation REMOTE configuration
const {
  shareAll,
  withModuleFederationPlugin,
} = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  // ✅ REMOTE: unique name — shell references this in loadRemoteModule()
  name: 'paymentsMfe',

  // ✅ Fixed filename — not content-hashed so shell knows the exact URL
  filename: 'remoteEntry.js',

  // ✅ What this remote exposes to the shell
  exposes: {
    './TransactionRoutes': './src/app/transactions/transaction.routes.ts',
  },

  shared: {
    ...shareAll({
      singleton: true,      // One instance of Angular/RxJS/NgRx across the whole federated app
      strictVersion: true,  // Hard fail on major version mismatch — better than silent bugs
      requiredVersion: 'auto', // Reads version from this app's package.json
    }),

    // Ensure NgRx uses the shell's singleton store
    '@ngrx/store':  { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/effects': { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/entity': { singleton: true, strictVersion: true, requiredVersion: 'auto' },
  },
});
