const { shareAll, withModuleFederationPlugin } = require('@angular-architects/module-federation/webpack');

module.exports = withModuleFederationPlugin({
  name: 'paymentsMfe',
  filename: 'remoteEntry.js',
  exposes: {
    './TransactionRoutes': './src/app/transactions/transaction.routes.ts',
  },
  shared: {
    ...shareAll({ singleton: true, strictVersion: true, requiredVersion: 'auto' }),
    '@ngrx/store':   { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/effects': { singleton: true, strictVersion: true, requiredVersion: 'auto' },
    '@ngrx/entity':  { singleton: true, strictVersion: true, requiredVersion: 'auto' },
  },
});
