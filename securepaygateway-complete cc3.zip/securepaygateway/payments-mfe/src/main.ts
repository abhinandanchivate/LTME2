// payments-mfe/src/main.ts
// ✅ Dynamic import is REQUIRED for Module Federation
// This allows MF to initialize shared modules before Angular bootstraps
import('./bootstrap').catch((err) => console.error(err));
