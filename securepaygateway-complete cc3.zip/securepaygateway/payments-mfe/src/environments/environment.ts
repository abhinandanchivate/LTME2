export const environment = {
  name: 'development' as const,
  production: false,
  apiUrl: 'http://localhost:8080',
};
