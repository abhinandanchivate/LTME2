export const environment = {
  name: 'production' as const,
  production: true,
  apiUrl: 'https://api.securepaygateway.in',
};
