// payments-mfe/src/bootstrap.ts
import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';

// Standalone bootstrap — MFE works independently on port 4201
// AND inside the shell at /transactions
bootstrapApplication(AppComponent, appConfig).catch((err) => console.error(err));
