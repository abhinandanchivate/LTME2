import { createActionGroup, emptyProps, props } from '@ngrx/store';
import { createEntityAdapter, EntityAdapter, EntityState } from '@ngrx/entity';
import { createFeature, createReducer, on, createSelector } from '@ngrx/store';

// ── Inline types (no dependency on shared package at compile time) ─────────────

export type TransactionStatus = 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED' | 'REVERSED';
export type TransactionType   = 'NEFT' | 'RTGS' | 'IMPS' | 'UPI' | 'SWIFT';

export interface AccountSummary {
  accountId: string; accountName: string; accountNumber: string;
  ifscCode: string; bankName: string; accountType: string;
}

export interface Transaction {
  id: string; referenceNumber: string; amount: number; currency: string;
  type: TransactionType; status: TransactionStatus;
  fromAccount: AccountSummary; toAccount: AccountSummary;
  description: string; initiatedAt: string; completedAt?: string;
}

export interface TransactionFilter {
  status?: TransactionStatus; type?: TransactionType;
  accountId?: string; search?: string;
  minAmount?: number; maxAmount?: number;
}

export interface PaginatedResponse<T> {
  data: T[]; total: number; page: number; pageSize: number; totalPages: number;
}

// ── Actions ───────────────────────────────────────────────────────────────────

export const TransactionActions = createActionGroup({
  source: 'Transactions',
  events: {
    'Load Transactions':         props<{ filter?: TransactionFilter; page?: number }>(),
    'Load Transactions Success': props<{ response: PaginatedResponse<Transaction> }>(),
    'Load Transactions Failure': props<{ error: string }>(),
    'Load Transaction':          props<{ id: string }>(),
    'Load Transaction Success':  props<{ transaction: Transaction }>(),
    'Load Transaction Failure':  props<{ error: string }>(),
    'Create Transaction':         props<{ payload: Partial<Transaction> }>(),
    'Create Transaction Success': props<{ transaction: Transaction }>(),
    'Create Transaction Failure': props<{ error: string }>(),
    'Select Transaction':  props<{ id: string | null }>(),
    'Set Filter':          props<{ filter: TransactionFilter }>(),
    'Clear Filter':        emptyProps(),
    'Set Page':            props<{ page: number }>(),
  },
});

// ── Reducer ───────────────────────────────────────────────────────────────────

export interface TransactionsState extends EntityState<Transaction> {
  selectedId: string | null;
  loading: boolean;
  error: string | null;
  filter: TransactionFilter;
  currentPage: number;
  totalItems: number;
  totalPages: number;
}

export const transactionAdapter: EntityAdapter<Transaction> =
  createEntityAdapter<Transaction>();

const initialState: TransactionsState = transactionAdapter.getInitialState({
  selectedId: null, loading: false, error: null,
  filter: {}, currentPage: 1, totalItems: 0, totalPages: 0,
});

export const transactionsFeature = createFeature({
  name: 'transactions',
  reducer: createReducer(
    initialState,
    on(TransactionActions.loadTransactions,        (s)             => ({ ...s, loading: true, error: null })),
    on(TransactionActions.loadTransactionsSuccess, (s, { response }) =>
      transactionAdapter.setAll(response.data, { ...s, loading: false, totalItems: response.total, totalPages: response.totalPages, currentPage: response.page })),
    on(TransactionActions.loadTransactionsFailure, (s, { error })   => ({ ...s, loading: false, error })),
    on(TransactionActions.loadTransactionSuccess,  (s, { transaction }) => transactionAdapter.upsertOne(transaction, s)),
    on(TransactionActions.createTransactionSuccess,(s, { transaction }) => transactionAdapter.addOne(transaction, { ...s, loading: false })),
    on(TransactionActions.selectTransaction,       (s, { id })      => ({ ...s, selectedId: id })),
    on(TransactionActions.setFilter,               (s, { filter })  => ({ ...s, filter, currentPage: 1 })),
    on(TransactionActions.clearFilter,             (s)              => ({ ...s, filter: {}, currentPage: 1 })),
    on(TransactionActions.setPage,                 (s, { page })    => ({ ...s, currentPage: page })),
  ),
});

export const {
  name: transactionsFeatureName,
  reducer: transactionsReducer,
  selectTransactionsState,
  selectLoading,
  selectError,
  selectFilter,
  selectCurrentPage,
  selectTotalItems,
  selectTotalPages,
  selectSelectedId,
} = transactionsFeature;

// ── Entity selectors ──────────────────────────────────────────────────────────

const { selectAll, selectEntities } = transactionAdapter.getSelectors(selectTransactionsState);

export const selectAllTransactions      = selectAll;
export const selectTransactionEntities  = selectEntities;

export const selectSelectedTransaction = createSelector(
  selectTransactionEntities,
  selectSelectedId,
  (entities, id) => (id ? (entities[id] ?? null) : null)
);

export const selectFilteredTransactions = createSelector(
  selectAllTransactions,
  selectFilter,
  (transactions: Transaction[], filter: TransactionFilter) => {
    let result = [...transactions];
    if (filter.status)    result = result.filter((t) => t.status === filter.status);
    if (filter.type)      result = result.filter((t) => t.type === filter.type);
    if (filter.accountId) result = result.filter((t) => t.fromAccount.accountId === filter.accountId);
    if (filter.search) {
      const q = filter.search.toLowerCase();
      result = result.filter((t) =>
        t.referenceNumber.toLowerCase().includes(q) ||
        t.fromAccount.accountName.toLowerCase().includes(q)
      );
    }
    return result;
  }
);
