// payments-mfe/src/app/services/transaction.service.ts
import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of, delay } from 'rxjs';
import {
  Transaction,
  TransactionFilter,
  PaginatedResponse,
} from '../../../../shared/src/models';

// ─── Mock Data (replace with real API calls) ──────────────────────────────────

const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: 'TXN-001',
    referenceNumber: 'NEFT/240514/001',
    amount: 150000,
    currency: 'INR',
    type: 'NEFT',
    status: 'COMPLETED',
    fromAccount: {
      accountId: 'ACC-001',
      accountName: 'HDFC Current A/c',
      accountNumber: 'XXXX4321',
      ifscCode: 'HDFC0001234',
      bankName: 'HDFC Bank',
      accountType: 'CURRENT',
    },
    toAccount: {
      accountId: 'ACC-002',
      accountName: 'ICICI Savings',
      accountNumber: 'XXXX8765',
      ifscCode: 'ICIC0005678',
      bankName: 'ICICI Bank',
      accountType: 'SAVINGS',
    },
    description: 'Vendor payment — Invoice INV-2024-001',
    initiatedAt: '2024-05-14T09:30:00Z',
    completedAt: '2024-05-14T09:45:00Z',
  },
  {
    id: 'TXN-002',
    referenceNumber: 'RTGS/240514/002',
    amount: 5000000,
    currency: 'INR',
    type: 'RTGS',
    status: 'PROCESSING',
    fromAccount: {
      accountId: 'ACC-003',
      accountName: 'SBI Corporate A/c',
      accountNumber: 'XXXX9900',
      ifscCode: 'SBIN0012345',
      bankName: 'State Bank of India',
      accountType: 'CURRENT',
    },
    toAccount: {
      accountId: 'ACC-001',
      accountName: 'HDFC Current A/c',
      accountNumber: 'XXXX4321',
      ifscCode: 'HDFC0001234',
      bankName: 'HDFC Bank',
      accountType: 'CURRENT',
    },
    description: 'Bulk payroll transfer — May 2024',
    initiatedAt: '2024-05-14T10:00:00Z',
  },
  {
    id: 'TXN-003',
    referenceNumber: 'UPI/240514/003',
    amount: 25000,
    currency: 'INR',
    type: 'UPI',
    status: 'FAILED',
    fromAccount: {
      accountId: 'ACC-002',
      accountName: 'ICICI Savings',
      accountNumber: 'XXXX8765',
      ifscCode: 'ICIC0005678',
      bankName: 'ICICI Bank',
      accountType: 'SAVINGS',
    },
    toAccount: {
      accountId: 'ACC-004',
      accountName: 'Axis Business A/c',
      accountNumber: 'XXXX3344',
      ifscCode: 'UTIB0009876',
      bankName: 'Axis Bank',
      accountType: 'CURRENT',
    },
    description: 'Subscription payment',
    initiatedAt: '2024-05-14T11:15:00Z',
  },
  {
    id: 'TXN-004',
    referenceNumber: 'IMPS/240514/004',
    amount: 75000,
    currency: 'INR',
    type: 'IMPS',
    status: 'COMPLETED',
    fromAccount: {
      accountId: 'ACC-001',
      accountName: 'HDFC Current A/c',
      accountNumber: 'XXXX4321',
      ifscCode: 'HDFC0001234',
      bankName: 'HDFC Bank',
      accountType: 'CURRENT',
    },
    toAccount: {
      accountId: 'ACC-003',
      accountName: 'SBI Corporate A/c',
      accountNumber: 'XXXX9900',
      ifscCode: 'SBIN0012345',
      bankName: 'State Bank of India',
      accountType: 'CURRENT',
    },
    description: 'Emergency fund transfer',
    initiatedAt: '2024-05-14T12:00:00Z',
    completedAt: '2024-05-14T12:02:00Z',
  },
  {
    id: 'TXN-005',
    referenceNumber: 'NEFT/240514/005',
    amount: 320000,
    currency: 'INR',
    type: 'NEFT',
    status: 'PENDING',
    fromAccount: {
      accountId: 'ACC-004',
      accountName: 'Axis Business A/c',
      accountNumber: 'XXXX3344',
      ifscCode: 'UTIB0009876',
      bankName: 'Axis Bank',
      accountType: 'CURRENT',
    },
    toAccount: {
      accountId: 'ACC-002',
      accountName: 'ICICI Savings',
      accountNumber: 'XXXX8765',
      ifscCode: 'ICIC0005678',
      bankName: 'ICICI Bank',
      accountType: 'SAVINGS',
    },
    description: 'Quarterly consultant fee',
    initiatedAt: '2024-05-14T13:30:00Z',
  },
];

// ─────────────────────────────────────────────────────────────────────────────

@Injectable({ providedIn: 'root' })
export class TransactionService {
  private readonly http = inject(HttpClient);

  // Use mock data during development — replace with real API calls
  getTransactions(
    filter?: TransactionFilter,
    page = 1,
    pageSize = 20
  ): Observable<PaginatedResponse<Transaction>> {
    // Mock: filter in memory
    let data = [...MOCK_TRANSACTIONS];
    if (filter?.status)    data = data.filter((t) => t.status === filter.status);
    if (filter?.type)      data = data.filter((t) => t.type === filter.type);
    if (filter?.accountId) data = data.filter((t) => t.fromAccount.accountId === filter.accountId);

    const total = data.length;
    const start = (page - 1) * pageSize;
    const paged = data.slice(start, start + pageSize);

    return of({
      data: paged,
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize),
    }).pipe(delay(300)); // Simulate network latency
  }

  getTransaction(id: string): Observable<Transaction> {
    const t = MOCK_TRANSACTIONS.find((tx) => tx.id === id);
    if (!t) throw new Error(`Transaction ${id} not found`);
    return of(t).pipe(delay(200));
  }

  createTransaction(payload: Partial<Transaction>): Observable<Transaction> {
    const newTx: Transaction = {
      id: `TXN-${Date.now()}`,
      referenceNumber: `NEFT/${new Date().toISOString().slice(0, 10).replace(/-/g, '')}/${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
      amount: payload.amount ?? 0,
      currency: 'INR',
      type: payload.type ?? 'NEFT',
      status: 'PENDING',
      fromAccount: payload.fromAccount!,
      toAccount: payload.toAccount!,
      description: payload.description ?? '',
      initiatedAt: new Date().toISOString(),
    };
    return of(newTx).pipe(delay(500));
  }
}
