// payments-mfe/src/app/app.component.ts
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  template: `
    <div style="padding: 24px; font-family: system-ui, sans-serif;">
      <div style="background: #1e3a5f; color: white; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px;">
        💳 Payments MFE — Running Standalone on port 4201
      </div>
      <router-outlet />
    </div>
  `,
})
export class AppComponent {}
