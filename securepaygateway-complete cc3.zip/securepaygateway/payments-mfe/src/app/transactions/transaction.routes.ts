// payments-mfe/src/app/transactions/transaction.routes.ts
// ✅ This file is EXPOSED via webpack.config.js exposes: { './TransactionRoutes': this file }
// The shell loads it as: loadRemoteModule(..., './TransactionRoutes').then(m => m.TRANSACTION_ROUTES)

import { Routes } from '@angular/router';

export const TRANSACTION_ROUTES: Routes = [
  {
    path: '',
    loadComponent: () =>
      import('./transaction-list/transaction-list.component').then(
        (m) => m.TransactionListComponent
      ),
  },
  {
    path: ':id',
    loadComponent: () =>
      import('./transaction-detail/transaction-detail.component').then(
        (m) => m.TransactionDetailComponent
      ),
  },
  {
    path: 'new',
    loadComponent: () =>
      import('./transaction-form/transaction-form.component').then(
        (m) => m.TransactionFormComponent
      ),
  },
];

// ─── Standalone Routes (for running MFE independently on port 4201) ──────────
export const STANDALONE_ROUTES: Routes = [
  {
    path: 'transactions',
    children: TRANSACTION_ROUTES,
  },
  {
    path: '',
    redirectTo: 'transactions',
    pathMatch: 'full',
  },
];
