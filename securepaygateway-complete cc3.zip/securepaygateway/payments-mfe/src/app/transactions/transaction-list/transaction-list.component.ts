import { Component, ChangeDetectionStrategy, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Store } from '@ngrx/store';
import { MfeEventBusService } from '../../../../../shared/src/mfe-event-bus.service';
import { TransactionActions, selectFilteredTransactions, selectLoading, selectError, selectCurrentPage, selectTotalPages, selectTotalItems, Transaction, TransactionFilter } from '../../store/transactions.state';

@Component({
  selector: 'app-transaction-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="transaction-list">
      <div class="list-header">
        <h2 class="page-title">Transactions</h2>
        <a routerLink="new" class="btn btn--primary">+ New Transaction</a>
      </div>

      <div class="filter-bar">
        <input type="text" placeholder="Search by reference or account..."
          [ngModel]="searchQuery()" (ngModelChange)="onSearch($event)" class="search-input" />
        <select [ngModel]="statusFilter()" (ngModelChange)="onStatusFilter($event)" class="filter-select">
          <option value="">All Statuses</option>
          <option value="PENDING">Pending</option>
          <option value="PROCESSING">Processing</option>
          <option value="COMPLETED">Completed</option>
          <option value="FAILED">Failed</option>
          <option value="REVERSED">Reversed</option>
        </select>
        <button class="btn btn--ghost" (click)="clearFilters()">Clear</button>
      </div>

      <div class="loading-state" *ngIf="loading$ | async">
        <div class="spinner"></div><p>Loading transactions...</p>
      </div>

      <div class="error-state" *ngIf="error$ | async as error">
        <p>⚠️ {{ error }}</p>
        <button class="btn btn--primary" (click)="loadTransactions()">Retry</button>
      </div>

      <div class="table-wrapper" *ngIf="!(loading$ | async)">
        <table class="table">
          <thead>
            <tr>
              <th>Reference</th><th>Account</th><th>Type</th>
              <th>Amount</th><th>Status</th><th>Date</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let tx of transactions$ | async"
              [class.row--selected]="selectedTxId() === tx.id"
              (click)="selectTransaction(tx)">
              <td><span class="ref-number">{{ tx.referenceNumber }}</span></td>
              <td>
                <button class="account-link"
                  (click)="onAccountClick($event, tx.fromAccount.accountId, tx.fromAccount.accountName, tx.fromAccount.accountType)">
                  {{ tx.fromAccount.accountName }}
                </button>
                <span class="account-sub">{{ tx.fromAccount.accountNumber }}</span>
              </td>
              <td><span class="badge badge--type">{{ tx.type }}</span></td>
              <td class="amount-cell">
                <span class="amount">{{ tx.amount | number:'1.2-2' }}</span>
                <span class="currency">{{ tx.currency }}</span>
              </td>
              <td><span class="badge" [class]="'badge--' + tx.status.toLowerCase()">{{ tx.status }}</span></td>
              <td>{{ tx.initiatedAt | date:'dd MMM, HH:mm' }}</td>
              <td><a [routerLink]="[tx.id]" class="btn btn--sm">View</a></td>
            </tr>
            <tr *ngIf="!(transactions$ | async)?.length">
              <td colspan="7" class="empty-state">No transactions found.</td>
            </tr>
          </tbody>
        </table>

        <div class="pagination" *ngIf="totalPages > 1">
          <button class="btn btn--sm" [disabled]="currentPage === 1"
            (click)="goToPage(currentPage - 1)">← Prev</button>
          <span class="page-info">Page {{ currentPage }} of {{ totalPages }} ({{ totalItems }} total)</span>
          <button class="btn btn--sm" [disabled]="currentPage === totalPages"
            (click)="goToPage(currentPage + 1)">Next →</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .transaction-list { max-width:1200px; }
    .list-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
    .page-title { font-size:22px; font-weight:700; color:#1e3a5f; margin:0; }
    .filter-bar { display:flex; gap:12px; margin-bottom:20px; flex-wrap:wrap; }
    .search-input { flex:1; min-width:200px; padding:8px 14px; border:1px solid #d1d5db; border-radius:8px; font-size:14px; outline:none; }
    .search-input:focus { border-color:#2563eb; }
    .filter-select { padding:8px 12px; border:1px solid #d1d5db; border-radius:8px; font-size:14px; background:white; }
    .btn { padding:8px 16px; border-radius:8px; border:none; font-size:14px; font-weight:500; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; }
    .btn--primary { background:#1e3a5f; color:white; }
    .btn--primary:hover { background:#2563eb; }
    .btn--ghost { background:#f3f4f6; color:#374151; border:1px solid #d1d5db; }
    .btn--sm { padding:4px 12px; font-size:13px; background:#f3f4f6; color:#374151; border:1px solid #d1d5db; }
    .btn:disabled { opacity:.4; cursor:not-allowed; }
    .table-wrapper { background:white; border-radius:12px; box-shadow:0 1px 4px rgba(0,0,0,.08); overflow:hidden; }
    .table { width:100%; border-collapse:collapse; }
    .table th { background:#f8fafc; padding:12px 16px; text-align:left; font-size:12px; font-weight:600; color:#6b7280; text-transform:uppercase; border-bottom:1px solid #e5e7eb; }
    .table td { padding:12px 16px; border-bottom:1px solid #f3f4f6; font-size:14px; color:#374151; vertical-align:middle; }
    .table tr:hover td { background:#f8fafc; }
    .row--selected td { background:#eff6ff; }
    .account-link { background:none; border:none; color:#2563eb; cursor:pointer; font-size:14px; padding:0; font-weight:500; text-align:left; display:block; }
    .account-link:hover { text-decoration:underline; }
    .account-sub { font-size:12px; color:#9ca3af; }
    .badge { padding:3px 8px; border-radius:99px; font-size:11px; font-weight:600; text-transform:uppercase; }
    .badge--type { background:#e0e7ff; color:#3730a3; }
    .badge--pending { background:#fef9c3; color:#854d0e; }
    .badge--processing { background:#dbeafe; color:#1e40af; }
    .badge--completed { background:#dcfce7; color:#166534; }
    .badge--failed { background:#fee2e2; color:#991b1b; }
    .badge--reversed { background:#f3f4f6; color:#6b7280; }
    .amount { font-weight:600; }
    .currency { font-size:12px; color:#9ca3af; margin-left:4px; }
    .loading-state,.empty-state { display:flex; flex-direction:column; align-items:center; padding:48px; color:#6b7280; text-align:center; }
    .error-state { background:#fee2e2; border-radius:8px; padding:20px; color:#991b1b; margin-bottom:20px; display:flex; align-items:center; justify-content:space-between; }
    .spinner { width:32px; height:32px; border:3px solid #e5e7eb; border-top-color:#2563eb; border-radius:50%; animation:spin .8s linear infinite; margin-bottom:12px; }
    @keyframes spin { to { transform:rotate(360deg); } }
    .pagination { display:flex; align-items:center; justify-content:center; gap:16px; padding:16px; border-top:1px solid #f3f4f6; }
    .page-info { font-size:13px; color:#6b7280; }
    .ref-number { font-family:monospace; font-size:12px; color:#6b7280; }
  `],
})
export class TransactionListComponent implements OnInit {
  private readonly store    = inject(Store);
  private readonly eventBus = inject(MfeEventBusService);

  transactions$ = this.store.select(selectFilteredTransactions);
  loading$      = this.store.select(selectLoading);
  error$        = this.store.select(selectError);

  // Sync values for use in event handlers (avoids async pipe in (click))
  currentPage = 1;
  totalPages  = 1;
  totalItems  = 0;

  selectedTxId = signal<string | null>(null);
  searchQuery  = signal('');
  statusFilter = signal('');

  ngOnInit() {
    this.loadTransactions();
    this.store.select(selectCurrentPage).subscribe((p) => (this.currentPage = p));
    this.store.select(selectTotalPages).subscribe((p) => (this.totalPages = p));
    this.store.select(selectTotalItems).subscribe((t) => (this.totalItems = t));
  }

  loadTransactions() {
    this.store.dispatch(TransactionActions.loadTransactions({}));
  }

  selectTransaction(tx: Transaction) {
    this.selectedTxId.set(tx.id);
    this.store.dispatch(TransactionActions.selectTransaction({ id: tx.id }));
  }

  onAccountClick(event: MouseEvent, accountId: string, accountName: string, accountType: string) {
    event.stopPropagation();
    this.eventBus.emit({ type: 'ACCOUNT_SELECTED', payload: { accountId, accountName, accountType } });
  }

  onSearch(query: string) {
    this.searchQuery.set(query);
    this.store.dispatch(TransactionActions.setFilter({
      filter: { search: query || undefined, status: (this.statusFilter() as any) || undefined },
    }));
  }

  onStatusFilter(status: string) {
    this.statusFilter.set(status);
    this.store.dispatch(TransactionActions.setFilter({
      filter: { status: (status as any) || undefined, search: this.searchQuery() || undefined },
    }));
  }

  clearFilters() {
    this.searchQuery.set('');
    this.statusFilter.set('');
    this.store.dispatch(TransactionActions.clearFilter());
    this.loadTransactions();
  }

  goToPage(page: number) {
    this.store.dispatch(TransactionActions.setPage({ page }));
    this.store.dispatch(TransactionActions.loadTransactions({ page }));
  }
}
