// payments-mfe/src/app/transactions/transaction-form/transaction-form.component.harness.ts
import { ComponentHarness } from '@angular/cdk/testing';

export class TransactionFormHarness extends ComponentHarness {
  static hostSelector = 'app-transaction-form';

  private getAmountInput     = this.locatorFor('[data-testid="amount-input"]');
  private getIfscInput       = this.locatorFor('[data-testid="ifsc-input"]');
  private getBeneficiaryInput= this.locatorFor('[data-testid="beneficiary-input"]');
  private getSubmitBtn       = this.locatorFor('[data-testid="submit-btn"]');
  private getAllErrors        = this.locatorForAll('[data-testid="field-error"]');

  async setAmount(value: string): Promise<void> {
    const el = await this.getAmountInput();
    await el.clear();
    if (value) await el.sendKeys(value);
    await el.blur();
  }

  async setIfsc(value: string): Promise<void> {
    const el = await this.getIfscInput();
    await el.clear();
    if (value) await el.sendKeys(value);
    await el.blur();
  }

  async setBeneficiary(value: string): Promise<void> {
    const el = await this.getBeneficiaryInput();
    await el.clear();
    if (value) await el.sendKeys(value);
    await el.blur();
  }

  async isSubmitDisabled(): Promise<boolean> {
    const btn = await this.getSubmitBtn();
    return btn.getProperty<boolean>('disabled');
  }

  async clickSubmit(): Promise<void> {
    const btn = await this.getSubmitBtn();
    await btn.click();
  }

  async getErrorMessages(): Promise<string[]> {
    const errors = await this.getAllErrors();
    return Promise.all(errors.map((e) => e.text()));
  }
}
