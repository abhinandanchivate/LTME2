// payments-mfe/src/app/transactions/transaction-form/transaction-form.component.spec.ts
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TestbedHarnessEnvironment } from '@angular/cdk/testing/testbed';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { TransactionFormComponent } from './transaction-form.component';
import { TransactionFormHarness } from './transaction-form.component.harness';

describe('TransactionFormComponent (Harness)', () => {
  let fixture: ComponentFixture<TransactionFormComponent>;
  let harness: TransactionFormHarness;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        TransactionFormComponent,
        ReactiveFormsModule,
        RouterTestingModule,
      ],
      providers: [
        provideMockStore({ initialState: { transactions: {} } }),
      ],
    }).compileComponents();

    fixture = TestBed.createComponent(TransactionFormComponent);
    harness = await TestbedHarnessEnvironment.harnessForFixture(
      fixture,
      TransactionFormHarness
    );
  });

  // ─── Test 1 ────────────────────────────────────────────────────────────────

  it('should disable Submit when form is empty', async () => {
    expect(await harness.isSubmitDisabled()).toBeTrue();
  });

  // ─── Test 2 ────────────────────────────────────────────────────────────────

  it('should show validation error for amount = 0', async () => {
    await harness.setAmount('0');
    const errors = await harness.getErrorMessages();
    expect(errors.some((e) => e.toLowerCase().includes('greater than 0'))).toBeTrue();
    expect(await harness.isSubmitDisabled()).toBeTrue();
  });

  // ─── Test 3 ────────────────────────────────────────────────────────────────

  it('should validate IFSC format', async () => {
    // Invalid IFSC
    await harness.setIfsc('INVALID');
    let errors = await harness.getErrorMessages();
    expect(errors.some((e) => e.toLowerCase().includes('ifsc'))).toBeTrue();

    // Valid IFSC
    await harness.setIfsc('HDFC0001234');
    errors = await harness.getErrorMessages();
    expect(errors.some((e) => e.toLowerCase().includes('ifsc'))).toBeFalse();
  });

  // ─── Test 4 ────────────────────────────────────────────────────────────────

  it('should enable Submit only when all required fields are valid', async () => {
    await harness.setAmount('50000');
    expect(await harness.isSubmitDisabled()).toBeTrue(); // Missing IFSC + beneficiary

    await harness.setIfsc('HDFC0001234');
    expect(await harness.isSubmitDisabled()).toBeTrue(); // Missing beneficiary

    await harness.setBeneficiary('Anand Venkataraman');
    // Also need type — let's set it directly
    fixture.componentInstance.form.patchValue({ type: 'NEFT' });
    fixture.detectChanges();

    expect(await harness.isSubmitDisabled()).toBeFalse(); // All valid
  });

  // ─── Test 5 ────────────────────────────────────────────────────────────────

  it('should disable Submit after successful submission (prevent double-submit)', async () => {
    await harness.setAmount('50000');
    await harness.setIfsc('HDFC0001234');
    await harness.setBeneficiary('Anand Venkataraman');
    fixture.componentInstance.form.patchValue({ type: 'NEFT' });
    fixture.detectChanges();

    expect(await harness.isSubmitDisabled()).toBeFalse();

    await harness.clickSubmit();
    fixture.detectChanges();

    // ✅ After submit, button must be disabled (submitted signal = true)
    expect(await harness.isSubmitDisabled()).toBeTrue();
  });
});
