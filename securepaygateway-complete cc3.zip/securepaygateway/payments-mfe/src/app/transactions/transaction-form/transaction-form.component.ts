// payments-mfe/src/app/transactions/transaction-form/transaction-form.component.ts
import {
  Component,
  ChangeDetectionStrategy,
  inject,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import {
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  AbstractControl,
  ValidationErrors,
} from '@angular/forms';
import { Store } from '@ngrx/store';
import { TransactionActions } from '../../store/transactions.state';

// ─── Custom Validators ────────────────────────────────────────────────────────

function ifscValidator(control: AbstractControl): ValidationErrors | null {
  const IFSC_REGEX = /^[A-Z]{4}0[A-Z0-9]{6}$/;
  if (!control.value) return null; // Let required handle empty
  return IFSC_REGEX.test(control.value) ? null : { invalidIfsc: true };
}

function positiveAmountValidator(control: AbstractControl): ValidationErrors | null {
  const val = Number(control.value);
  return val > 0 ? null : { notPositive: true };
}

// ─────────────────────────────────────────────────────────────────────────────

@Component({
  selector: 'app-transaction-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="form-view">
      <a routerLink=".." class="back-link">← Back</a>
      <h2>New Transaction</h2>

      <div class="form-card">
        <form [formGroup]="form" (ngSubmit)="onSubmit()">

          <!-- Amount -->
          <div class="field">
            <label for="amount">Amount (INR) *</label>
            <input
              id="amount"
              type="number"
              formControlName="amount"
              placeholder="0.00"
              data-testid="amount-input"
            />
            <span class="field-error" *ngIf="showError('amount', 'required')" data-testid="field-error">
              Amount is required
            </span>
            <span class="field-error" *ngIf="showError('amount', 'notPositive')" data-testid="field-error">
              Amount must be greater than 0
            </span>
          </div>

          <!-- Transaction Type -->
          <div class="field">
            <label for="type">Transaction Type *</label>
            <select id="type" formControlName="type">
              <option value="">Select type...</option>
              <option value="NEFT">NEFT</option>
              <option value="RTGS">RTGS</option>
              <option value="IMPS">IMPS</option>
              <option value="UPI">UPI</option>
            </select>
            <span class="field-error" *ngIf="showError('type', 'required')" data-testid="field-error">
              Transaction type is required
            </span>
          </div>

          <!-- Beneficiary Name -->
          <div class="field">
            <label for="beneficiary">Beneficiary Name *</label>
            <input
              id="beneficiary"
              type="text"
              formControlName="beneficiary"
              placeholder="Full name as per bank records"
              data-testid="beneficiary-input"
            />
            <span class="field-error" *ngIf="showError('beneficiary', 'required')" data-testid="field-error">
              Beneficiary name is required
            </span>
          </div>

          <!-- IFSC Code -->
          <div class="field">
            <label for="ifsc">Beneficiary IFSC Code *</label>
            <input
              id="ifsc"
              type="text"
              formControlName="ifsc"
              placeholder="HDFC0001234"
              maxlength="11"
              style="text-transform: uppercase"
              data-testid="ifsc-input"
            />
            <span class="field-help">Format: ABCD0XXXXXX (4 letters + 0 + 6 alphanumeric)</span>
            <span class="field-error" *ngIf="showError('ifsc', 'required')" data-testid="field-error">
              IFSC code is required
            </span>
            <span class="field-error" *ngIf="showError('ifsc', 'invalidIfsc')" data-testid="field-error">
              Invalid IFSC format (e.g. HDFC0001234)
            </span>
          </div>

          <!-- Description -->
          <div class="field">
            <label for="description">Description</label>
            <textarea
              id="description"
              formControlName="description"
              rows="3"
              placeholder="Payment description..."
            ></textarea>
          </div>

          <!-- Actions -->
          <div class="form-actions">
            <a routerLink=".." class="btn btn--ghost">Cancel</a>
            <button
              type="submit"
              class="btn btn--primary"
              [disabled]="form.invalid || submitted()"
              data-testid="submit-btn"
            >
              {{ submitted() ? 'Submitted ✓' : 'Submit Transaction' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
  styles: [`
    .form-view { max-width: 600px; }
    .back-link { display: inline-block; color: #2563eb; text-decoration: none; font-size: 14px; margin-bottom: 16px; }
    h2 { margin: 0 0 24px; font-size: 22px; font-weight: 700; color: #1e3a5f; }
    .form-card { background: white; border-radius: 12px; padding: 32px; box-shadow: 0 1px 4px rgba(0,0,0,0.08); }
    .field { display: flex; flex-direction: column; gap: 4px; margin-bottom: 20px; }
    label { font-size: 13px; font-weight: 600; color: #374151; }
    input, select, textarea {
      padding: 10px 14px; border: 1px solid #d1d5db;
      border-radius: 8px; font-size: 14px; outline: none;
      transition: border-color 0.2s; font-family: inherit;
    }
    input:focus, select:focus, textarea:focus {
      border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37,99,235,0.1);
    }
    .field-error { font-size: 12px; color: #dc2626; }
    .field-help  { font-size: 12px; color: #9ca3af; }
    .form-actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 8px; }
    .btn { padding: 10px 20px; border-radius: 8px; border: none; font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; }
    .btn--primary { background: #1e3a5f; color: white; }
    .btn--primary:hover:not(:disabled) { background: #2563eb; }
    .btn--primary:disabled { opacity: 0.5; cursor: not-allowed; }
    .btn--ghost { background: #f3f4f6; color: #374151; border: 1px solid #d1d5db; }
  `],
})
export class TransactionFormComponent {
  private readonly store = inject(Store);
  private readonly fb    = inject(FormBuilder);

  // Signal: tracks whether form has been submitted (prevents double-submit)
  submitted = signal(false);

  form = this.fb.group({
    amount:      [null as number | null, [Validators.required, positiveAmountValidator]],
    type:        ['', [Validators.required]],
    beneficiary: ['', [Validators.required, Validators.minLength(2)]],
    ifsc:        ['', [Validators.required, ifscValidator]],
    description: [''],
  });

  /** Helper: show error only after field is touched */
  showError(field: string, error: string): boolean {
    const control = this.form.get(field);
    return !!(control?.touched && control?.errors?.[error]);
  }

  onSubmit() {
    if (this.form.invalid || this.submitted()) return;

    this.form.markAllAsTouched();
    if (this.form.invalid) return;

    const { amount, type, beneficiary, ifsc, description } = this.form.getRawValue();

    this.store.dispatch(
      TransactionActions.createTransaction({
        payload: {
          amount: amount!,
          type: type as any,
          toAccount: {
            accountId: `ACC-${Date.now()}`,
            accountName: beneficiary!,
            accountNumber: 'XXXX0000',
            ifscCode: ifsc!.toUpperCase(),
            bankName: 'Unknown Bank',
            accountType: 'CURRENT',
          },
          fromAccount: {
            accountId: 'ACC-001',
            accountName: 'HDFC Current A/c',
            accountNumber: 'XXXX4321',
            ifscCode: 'HDFC0001234',
            bankName: 'HDFC Bank',
            accountType: 'CURRENT',
          },
          description: description ?? '',
        },
      })
    );

    // ✅ Disable submit button after submission (prevent double-submit)
    this.submitted.set(true);
  }
}
