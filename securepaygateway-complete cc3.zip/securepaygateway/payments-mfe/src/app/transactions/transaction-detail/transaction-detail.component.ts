// payments-mfe/src/app/transactions/transaction-detail/transaction-detail.component.ts
import {
  Component,
  ChangeDetectionStrategy,
  inject,
  OnInit,
  input,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { selectSelectedTransaction } from '../../store/transactions.state';
import { TransactionActions } from '../../store/transactions.state';
import { MfeEventBusService } from '../../../../../shared/src/mfe-event-bus.service';

@Component({
  selector: 'app-transaction-detail',
  standalone: true,
  imports: [CommonModule, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="detail-view">
      <a routerLink=".." class="back-link">← Back to Transactions</a>

      <ng-container *ngIf="transaction$ | async as tx; else loading">
        <div class="detail-header">
          <h2>{{ tx.referenceNumber }}</h2>
          <span class="badge" [class]="'badge--' + tx.status.toLowerCase()">{{ tx.status }}</span>
        </div>

        <div class="detail-grid">
          <!-- From Account -->
          <div class="detail-card">
            <h3>From Account</h3>
            <button class="account-btn" (click)="viewAccountReport(tx.fromAccount.accountId, tx.fromAccount.accountName, tx.fromAccount.accountType)">
              View in Reports →
            </button>
            <dl>
              <dt>Account Name</dt><dd>{{ tx.fromAccount.accountName }}</dd>
              <dt>Account Number</dt><dd>{{ tx.fromAccount.accountNumber }}</dd>
              <dt>IFSC Code</dt><dd>{{ tx.fromAccount.ifscCode }}</dd>
              <dt>Bank</dt><dd>{{ tx.fromAccount.bankName }}</dd>
              <dt>Type</dt><dd>{{ tx.fromAccount.accountType }}</dd>
            </dl>
          </div>

          <!-- To Account -->
          <div class="detail-card">
            <h3>To Account</h3>
            <dl>
              <dt>Account Name</dt><dd>{{ tx.toAccount.accountName }}</dd>
              <dt>Account Number</dt><dd>{{ tx.toAccount.accountNumber }}</dd>
              <dt>IFSC Code</dt><dd>{{ tx.toAccount.ifscCode }}</dd>
              <dt>Bank</dt><dd>{{ tx.toAccount.bankName }}</dd>
              <dt>Type</dt><dd>{{ tx.toAccount.accountType }}</dd>
            </dl>
          </div>

          <!-- Transaction Details -->
          <div class="detail-card detail-card--full">
            <h3>Transaction Details</h3>
            <dl class="dl--grid">
              <dt>Amount</dt>
              <dd class="amount">{{ tx.amount | number:'1.2-2' }} {{ tx.currency }}</dd>
              <dt>Type</dt><dd>{{ tx.type }}</dd>
              <dt>Status</dt>
              <dd><span class="badge" [class]="'badge--' + tx.status.toLowerCase()">{{ tx.status }}</span></dd>
              <dt>Description</dt><dd>{{ tx.description }}</dd>
              <dt>Initiated At</dt><dd>{{ tx.initiatedAt | date:'dd MMM yyyy, HH:mm:ss' }}</dd>
              <dt>Completed At</dt><dd>{{ tx.completedAt ? (tx.completedAt | date:'dd MMM yyyy, HH:mm:ss') : 'N/A' }}</dd>
            </dl>
          </div>
        </div>
      </ng-container>

      <ng-template #loading>
        <div class="loading-state">
          <div class="spinner"></div>
          <p>Loading transaction...</p>
        </div>
      </ng-template>
    </div>
  `,
  styles: [`
    .detail-view { max-width: 900px; }
    .back-link {
      display: inline-flex; align-items: center; gap: 6px;
      color: #2563eb; text-decoration: none; font-size: 14px; margin-bottom: 20px;
    }
    .back-link:hover { text-decoration: underline; }
    .detail-header {
      display: flex; align-items: center; gap: 16px; margin-bottom: 24px;
    }
    h2 { margin: 0; font-size: 20px; font-weight: 700; color: #1e3a5f; }
    h3 { margin: 0 0 16px; font-size: 15px; font-weight: 600; color: #374151; }
    .detail-grid {
      display: grid; grid-template-columns: 1fr 1fr; gap: 20px;
    }
    .detail-card {
      background: white; border-radius: 12px;
      padding: 24px; box-shadow: 0 1px 4px rgba(0,0,0,0.08);
    }
    .detail-card--full { grid-column: 1 / -1; }
    .account-btn {
      background: none; border: 1px solid #2563eb; color: #2563eb;
      padding: 4px 12px; border-radius: 6px; cursor: pointer;
      font-size: 12px; margin-bottom: 16px;
    }
    .account-btn:hover { background: #dbeafe; }
    dl { margin: 0; }
    dt { font-size: 12px; color: #9ca3af; font-weight: 500; margin-top: 12px; }
    dd { margin: 2px 0 0 0; font-size: 14px; color: #374151; font-weight: 500; }
    .dl--grid { display: grid; grid-template-columns: 1fr 2fr; gap: 4px 16px; }
    .dl--grid dt { margin-top: 0; padding: 8px 0; border-bottom: 1px solid #f3f4f6; }
    .dl--grid dd { margin: 0; padding: 8px 0; border-bottom: 1px solid #f3f4f6; }
    .amount { font-size: 20px; font-weight: 700; color: #1e3a5f; }
    .badge { padding: 3px 8px; border-radius: 99px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
    .badge--completed { background: #dcfce7; color: #166534; }
    .badge--pending   { background: #fef9c3; color: #854d0e; }
    .badge--processing{ background: #dbeafe; color: #1e40af; }
    .badge--failed    { background: #fee2e2; color: #991b1b; }
    .badge--reversed  { background: #f3f4f6; color: #6b7280; }
    .loading-state { display: flex; flex-direction: column; align-items: center; padding: 48px; }
    .spinner {
      width: 32px; height: 32px; border: 3px solid #e5e7eb;
      border-top-color: #2563eb; border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
  `],
})
export class TransactionDetailComponent implements OnInit {
  private readonly store    = inject(Store);
  private readonly eventBus = inject(MfeEventBusService);

  // Angular 17 signal input — receives the :id route param via withComponentInputBinding()
  id = input<string>('');

  transaction$ = this.store.select(selectSelectedTransaction);

  ngOnInit() {
    if (this.id()) {
      this.store.dispatch(TransactionActions.loadTransaction({ id: this.id() }));
    }
  }

  /**
   * Navigating to reports for a specific account:
   * Emits ACCOUNT_SELECTED to EventBus and the Reports MFE will auto-filter.
   */
  viewAccountReport(accountId: string, accountName: string, accountType: string) {
    this.eventBus.emit({
      type: 'ACCOUNT_SELECTED',
      payload: { accountId, accountName, accountType },
    });
    // In a real app: also navigate to /reports using Router
    // this.router.navigate(['/reports']);
  }
}
