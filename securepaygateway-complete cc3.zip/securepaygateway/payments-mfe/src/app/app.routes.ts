// payments-mfe/src/app/app.routes.ts
export { STANDALONE_ROUTES } from './transactions/transaction.routes';
