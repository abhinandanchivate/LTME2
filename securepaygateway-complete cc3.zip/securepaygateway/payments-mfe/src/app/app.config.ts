import { ApplicationConfig } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideState } from '@ngrx/store';
import { provideEffects } from '@ngrx/effects';
import { STANDALONE_ROUTES } from './app.routes';
import { transactionsReducer } from './store/transactions.state';
import { TransactionEffects } from './store/transactions.effects';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(STANDALONE_ROUTES),
    provideHttpClient(),
    provideAnimationsAsync(),
    provideState({ name: 'transactions', reducer: transactionsReducer }),
    provideEffects([TransactionEffects]),
  ],
};
